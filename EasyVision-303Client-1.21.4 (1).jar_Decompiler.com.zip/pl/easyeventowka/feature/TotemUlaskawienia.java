package pl.easyeventowka.feature;

import java.util.List;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public final class TotemUlaskawienia {
   private static final List<String> LORE = List.of("&8 » &7Jest to przedmiot z:", "&8 » &feventu halloween (2023)", "&r", "&8 » &7Trzymając go po śmierci &dnie", "&8 » &dstracisz &7swoich przedmiotów!");
   private static final Disguise.Spec SPEC;
   public static final FakeItemOption OPTION;

   private TotemUlaskawienia() {
   }

   private static List<class_2561> lore() {
      return LORE.stream().map(LegacyText::parse).toList();
   }

   static {
      SPEC = new Disguise.Spec(class_1802.field_8288, LegacyText.parse("&5&lTotem ułaskawienia"), lore(), 1.0F, false, true, false, Disguise.Ability.NONE, (Disguise.Consumable)null, 0);
      OPTION = new FakeItemOption(() -> SPEC);
   }
}
