package pl.easyeventowka.feature;

import net.minecraft.class_1297;
import net.minecraft.class_1536;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_746;

public final class FlightlessRod {
   private static final int COOLDOWN_TICKS = 600;
   private static final int CATCH_TICKS = 300;
   private static final double MAX_DISTANCE = (double)30.0F;
   private static long readyAtTick;
   private static class_1657 caught;
   private static long releaseAtTick;
   private static class_1297 handled;

   private FlightlessRod() {
   }

   private static boolean holdsRod(class_746 player) {
      return Disguise.hasAbility(player.method_6047(), Disguise.Ability.FLIGHTLESS_ROD) || Disguise.hasAbility(player.method_6079(), Disguise.Ability.FLIGHTLESS_ROD);
   }

   public static void tick(class_310 client) {
      class_746 player = client.field_1724;
      if (player != null && client.field_1687 != null) {
         class_1536 bobber = player.field_7513;
         boolean holding = holdsRod(player);
         if (bobber != null && holding) {
            if (caught != null) {
               tickCaught(player);
            } else {
               class_1297 hooked = bobber.method_26957();
               if (hooked == null) {
                  handled = null;
               } else if (hooked != handled) {
                  handled = hooked;
                  if (hooked instanceof class_1657) {
                     class_1657 target = (class_1657)hooked;
                     if (target != player) {
                        onHooked(player, target);
                     }
                  }
               }
            }
         } else {
            handled = null;
            if (caught != null) {
               release();
            }
         }
      } else {
         caught = null;
         handled = null;
      }

   }

   private static void tickCaught(class_746 player) {
      if (caught.method_31481() || (double)caught.method_5739(player) > (double)30.0F || ClientClock.ticks() >= releaseAtTick) {
         release();
      }

   }

   private static void onHooked(class_746 player, class_1657 target) {
      long left = readyAtTick - ClientClock.ticks();
      if (left > 0L) {
         Titles.cooldown((int)Math.ceil((double)left / (double)20.0F));
         Titles.playSound(class_3417.field_15203, 0.8F, 1.0F);
      } else {
         caught = target;
         releaseAtTick = ClientClock.ticks() + 300L;
         readyAtTick = ClientClock.ticks() + 600L;
         player.method_7357().method_62835(player.method_6047(), 600);
         String nick = target.method_5477().getString();
         Titles.playSound(class_3417.field_14596, 1.0F, 0.8F);
         Titles.show(LegacyText.parse("&a&lZłapałeś gracza!"), LegacyText.parse("&7Złapany gracz: &e" + nick));
         player.method_7353(LegacyText.parse("&aZłapałeś gracza &e" + nick + "&7!"), false);
      }

   }

   private static void release() {
      caught = null;
      Titles.show(LegacyText.parse("&c&lPuściłeś gracza!"), LegacyText.parse("&cPuściłeś gracza!"));
   }
}
