package pl.easyeventowka.feature;

import com.mojang.authlib.GameProfile;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1304;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1669;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_638;
import net.minecraft.class_745;
import net.minecraft.class_746;

public final class IllusionistWand {
   private static final int LEFT_COOLDOWN_TICKS = 1200;
   private static final int RIGHT_COOLDOWN_TICKS = 2400;
   private static final int WAVES = 3;
   private static final int FANGS_PER_WAVE = 3;
   private static final double WAVE_SPACING = (double)2.0F;
   private static final int WAVE_DELAY_TICKS = 5;
   private static final int INVISIBILITY_TICKS = 80;
   private static final int CLONE_TICKS = 60;
   private static final double CLONE_HEAD_START = (double)1.5F;
   private static final double CLONE_SPAWN_STEP = (double)0.25F;
   private static final double CLONE_UNSTICK_HEIGHT = (double)2.0F;
   private static final double CLONE_SPEED = 0.2806;
   private static final double CLONE_GRAVITY = 0.08;
   private static final double CLONE_DRAG = 0.98;
   private static final double CLONE_JUMP = 0.42;
   private static final int FANGS_LIFETIME_TICKS = 30;
   private static final class_1304[] COPIED_SLOTS;
   private static long leftReadyAtTick;
   private static long rightReadyAtTick;
   private static int wavesLeft;
   private static long nextWaveAtTick;
   private static class_243 waveOrigin;
   private static class_243 waveDirection;
   private static final List<Fangs> activeFangs;
   private static class_745 clone;
   private static long cloneEndsAtTick;
   private static long visibleAgainAtTick;
   private static double cloneFallSpeed;
   private static class_1657 cloneSkinSource;
   private static boolean wasAttackDown;
   private static int nextVisualId;

   private IllusionistWand() {
   }

   public static boolean onRightClick(class_1799 stack) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            if (ClientClock.ticks() < rightReadyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(rightReadyAtTick - ClientClock.ticks()) / (double)20.0F));
               return true;
            }

            rightReadyAtTick = ClientClock.ticks() + 2400L;
            player.method_7357().method_62835(stack, 2400);
            FakeEffects.apply(class_1294.field_5905, 80, 0);
            visibleAgainAtTick = ClientClock.ticks() + 80L;
            spawnClone(world, player);
            Titles.playSound(class_3417.field_15019, 1.0F, 1.2F);
            Titles.show(class_2561.method_43473(), LegacyText.parse("&aZniknięcie &7zostało &aaktywowane&7!"));
            return true;
         }
      }

      return true;
   }

   private static void spawnClone(class_638 world, class_1657 player) {
      discardClone();
      class_243 look = player.method_5828(1.0F);
      class_243 ahead = (new class_243(look.field_1352, (double)0.0F, look.field_1350)).method_1029();
      class_745 copy = new class_745(world, cloneProfile(player));
      copy.method_5838(nextVisualId--);
      copy.method_33574(freeSpotAhead(world, copy, player.method_19538(), ahead));
      copy.method_36456(player.method_36454());
      copy.method_5847(player.method_36454());
      copy.method_5636(player.method_36454());

      for(class_1304 slot : COPIED_SLOTS) {
         copy.method_5673(slot, player.method_6118(slot).method_7972());
      }

      copy.method_5728(true);
      world.method_53875(copy);
      clone = copy;
      cloneSkinSource = player;
      cloneEndsAtTick = ClientClock.ticks() + 60L;
      cloneFallSpeed = (double)0.0F;
   }

   public static class_1657 cloneSkinSource() {
      return cloneSkinSource;
   }

   private static class_243 freeSpotAhead(class_638 world, class_745 copy, class_243 from, class_243 ahead) {
      class_243 best = from;

      for(double step = (double)0.25F; step <= (double)1.5F; step += (double)0.25F) {
         class_243 at = from.method_1019(ahead.method_1021(step));
         if (!fits(world, copy, at)) {
            break;
         }

         best = at;
      }

      return best;
   }

   private static boolean fits(class_638 world, class_745 copy, class_243 at) {
      return world.method_8587(copy, copy.method_18377(copy.method_18376()).method_30757(at));
   }

   private static GameProfile cloneProfile(class_1657 player) {
      GameProfile source = player.method_7334();
      GameProfile copy = new GameProfile(UUID.randomUUID(), source.getName());
      copy.getProperties().putAll(source.getProperties());
      return copy;
   }

   public static boolean isClone(class_1297 entity) {
      return clone != null && entity == clone;
   }

   public static void tickCloneMovement(class_745 entity) {
      if (entity == clone) {
         class_1937 var2 = entity.method_37908();
         if (var2 instanceof class_638) {
            class_638 world = (class_638)var2;
            if (unstick(world, entity)) {
               class_243 look = class_243.method_1030(0.0F, entity.method_36454());
               double dx = look.field_1352 * 0.2806;
               double dz = look.field_1350 * 0.2806;
               cloneFallSpeed = (cloneFallSpeed - 0.08) * 0.98;
               entity.method_5784(class_1313.field_6308, new class_243(dx, cloneFallSpeed, dz));
               if (entity.method_24828()) {
                  cloneFallSpeed = 0.42;
               } else if (entity.field_5992) {
                  cloneFallSpeed = (double)0.0F;
               }

               entity.method_18800(dx, cloneFallSpeed, dz);
            }
         }
      }

   }

   private static boolean unstick(class_638 world, class_745 entity) {
      if (fits(world, entity, entity.method_19538())) {
         return true;
      } else {
         for(double up = (double)0.5F; up <= (double)2.0F; up += (double)0.5F) {
            class_243 above = entity.method_19538().method_1031((double)0.0F, up, (double)0.0F);
            if (fits(world, entity, above)) {
               entity.method_33574(above);
               cloneFallSpeed = (double)0.0F;
               return true;
            }
         }

         discardClone();
         return false;
      }
   }

   private static void castFangs(class_746 player, class_1799 stack) {
      leftReadyAtTick = ClientClock.ticks() + 1200L;
      player.method_7357().method_62835(stack, 1200);
      class_243 look = player.method_5828(1.0F);
      waveDirection = (new class_243(look.field_1352, (double)0.0F, look.field_1350)).method_1029();
      waveOrigin = player.method_19538();
      wavesLeft = 3;
      nextWaveAtTick = ClientClock.ticks();
      Titles.playSound(class_3417.field_14545, 1.0F, 1.0F);
      Titles.show(class_2561.method_43473(), LegacyText.parse("&aSzczęki Evokera&7 zostały &aaktywowane&7!"));
   }

   private static void spawnWave(class_638 world, int waveIndex) {
      double distance = (double)(waveIndex + 1) * (double)2.0F;
      class_243 side = new class_243(-waveDirection.field_1350, (double)0.0F, waveDirection.field_1352);

      for(int i = 0; i < 3; ++i) {
         double offset = (double)i - (double)1.0F;
         class_243 at = waveOrigin.method_1019(waveDirection.method_1021(distance)).method_1019(side.method_1021(offset));
         class_1669 fangs = (class_1669)class_1299.field_6060.method_5883(world, class_3730.field_16461);
         if (fangs == null) {
            return;
         }

         fangs.method_5838(nextVisualId--);
         fangs.method_5814(at.field_1352, waveOrigin.field_1351, at.field_1350);
         world.method_53875(fangs);
         fangs.method_5711((byte)4);
         activeFangs.add(new Fangs(fangs, ClientClock.ticks() + 30L));
      }

   }

   public static void tick(class_310 client) {
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            tickLeftClick(client, player);
            tickWaves(world);
            tickFangs();
            tickClone();
            tickVisibility();
            return;
         }
      }

      discardClone();
      activeFangs.forEach((fangs) -> fangs.entity().method_31472());
      activeFangs.clear();
      wasAttackDown = false;
   }

   private static void tickLeftClick(class_310 client, class_746 player) {
      boolean down = client.field_1690.field_1886.method_1434();
      boolean justPressed = down && !wasAttackDown;
      wasAttackDown = down;
      if (justPressed && client.field_1755 == null) {
         class_1799 held = player.method_6047();
         if (Disguise.hasAbility(held, Disguise.Ability.ILLUSIONIST_WAND)) {
            if (ClientClock.ticks() < leftReadyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(leftReadyAtTick - ClientClock.ticks()) / (double)20.0F));
            } else {
               castFangs(player, held);
            }
         }
      }

   }

   private static void tickWaves(class_638 world) {
      if (wavesLeft > 0 && ClientClock.ticks() >= nextWaveAtTick) {
         spawnWave(world, 3 - wavesLeft);
         --wavesLeft;
         nextWaveAtTick = ClientClock.ticks() + 5L;
      }

   }

   private static void tickFangs() {
      Iterator<Fangs> it = activeFangs.iterator();

      while(it.hasNext()) {
         Fangs fangs = (Fangs)it.next();
         if (ClientClock.ticks() >= fangs.despawnAtTick()) {
            fangs.entity().method_31472();
            it.remove();
         }
      }

   }

   private static void tickClone() {
      if (clone != null && ClientClock.ticks() >= cloneEndsAtTick) {
         discardClone();
      }

   }

   private static void tickVisibility() {
      if (visibleAgainAtTick != 0L && ClientClock.ticks() >= visibleAgainAtTick) {
         visibleAgainAtTick = 0L;
         Titles.show(class_2561.method_43473(), LegacyText.parse("&cZnowu jesteś widoczny!"));
      }

   }

   private static void discardClone() {
      if (clone != null) {
         clone.method_31472();
         clone = null;
      }

   }

   static {
      COPIED_SLOTS = new class_1304[]{class_1304.field_6169, class_1304.field_6174, class_1304.field_6172, class_1304.field_6166, class_1304.field_6173, class_1304.field_6171};
      waveOrigin = class_243.field_1353;
      waveDirection = class_243.field_1353;
      activeFangs = new ArrayList();
      nextVisualId = -3000;
   }

   private static record Fangs(class_1669 entity, long despawnAtTick) {
   }
}
