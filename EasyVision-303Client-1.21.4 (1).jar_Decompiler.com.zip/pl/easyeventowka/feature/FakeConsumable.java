package pl.easyeventowka.feature;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;
import net.minecraft.class_9334;

public final class FakeConsumable {
   private static long readyAtTick;

   private FakeConsumable() {
   }

   public static boolean blocksUse(class_1799 stack) {
      if (!Disguise.isDisguised(stack)) {
         return false;
      } else if (Disguise.abilityOf(stack) != Disguise.Ability.NONE) {
         return false;
      } else if (Disguise.consumableOf(stack) == null) {
         return stack.method_57826(class_9334.field_53964);
      } else {
         class_310 client = class_310.method_1551();
         return client.field_1687 != null && ClientClock.ticks() < readyAtTick;
      }
   }

   public static void onConsume(class_1309 entity) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null && entity == player && client.field_1687 != null) {
         class_1799 stack = player.method_6030();
         Disguise.Consumable consumable = Disguise.consumableOf(stack);
         if (consumable != null) {
            for(Disguise.Effect effect : consumable.effects()) {
               FakeEffects.apply(effect.effect(), effect.duration(), effect.amplifier());
            }

            readyAtTick = ClientClock.ticks() + (long)consumable.cooldownTicks();
            player.method_7357().method_62835(stack, consumable.cooldownTicks());
         }
      }

   }
}
