package pl.easyeventowka.feature;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_746;

public final class FakeEffects {
   private static final Map<class_6880<class_1291>, Long> expiry = new HashMap();

   private FakeEffects() {
   }

   static void apply(class_6880<class_1291> effect, int durationTicks, int amplifier) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null) {
         player.method_6092(new class_1293(effect, durationTicks, amplifier));
         expiry.put(effect, ClientClock.ticks() + (long)durationTicks);
      }

   }

   static void remove(class_6880<class_1291> effect) {
      if (expiry.remove(effect) != null) {
         class_746 player = class_310.method_1551().field_1724;
         if (player != null) {
            player.method_6016(effect);
         }
      }

   }

   public static void tick(class_310 client) {
      if (!expiry.isEmpty()) {
         class_746 player = client.field_1724;
         if (player != null && client.field_1687 != null && player.method_5805()) {
            long now = ClientClock.ticks();
            expiry.entrySet().removeIf((entry) -> {
               if (now < (Long)entry.getValue()) {
                  return false;
               } else {
                  player.method_6016((class_6880)entry.getKey());
                  return true;
               }
            });
         } else {
            expiry.clear();
         }
      }

   }
}
