package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_746;

public final class Scythe {
   private static final int COOLDOWN_TICKS = 800;
   private static long readyAtTick;

   private Scythe() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236) {
            onClientAttack(entity);
         }

         return class_1269.field_5811;
      });
   }

   private static void onClientAttack(class_1297 target) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null && target instanceof class_1309 && target != player) {
         class_1799 held = player.method_6047();
         if (Disguise.hasAbility(held, Disguise.Ability.SCYTHE)) {
            long now = ClientClock.ticks();
            if (now < readyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(readyAtTick - now) / (double)20.0F));
            } else {
               readyAtTick = now + 800L;
               player.method_7357().method_62835(held, 800);
               showHitMessage(target);
            }
         }
      }

   }

   private static void showHitMessage(class_1297 target) {
      class_2583 dark = class_2583.field_24360.method_10977(class_124.field_1063).method_10978(false);
      class_5250 message = class_2561.method_43473().method_10852(LegacyText.parse("&7Oślepiłeś ")).method_10852(class_2561.method_43473().method_10862(dark).method_10852(target.method_5477())).method_10852(LegacyText.parse("&7!"));
      Titles.show(class_2561.method_43473(), message);
   }
}
