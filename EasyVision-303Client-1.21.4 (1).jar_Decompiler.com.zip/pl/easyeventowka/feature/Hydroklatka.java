package pl.easyeventowka.feature;

import java.util.List;
import net.minecraft.class_1802;
import net.minecraft.class_2561;

public final class Hydroklatka {
   private static final List<String> LORE = List.of("&8 » &7Jest to przedmiot zdobyty podczas", "&8 » &fwydarzenia wakacyjnego 2025&7!", "&7", "&8 » &7Po użyciu wystrzeliwuje pocisk, który", "&8 » &7tworzy &3wodną klatkę&7 uwięziającą", "&8 » &7przeciwników w miejscu!");
   private static final Disguise.Spec SPEC;
   public static final FakeItemOption OPTION;

   private Hydroklatka() {
   }

   private static List<class_2561> lore() {
      return LORE.stream().map(LegacyText::parse).toList();
   }

   static {
      SPEC = new Disguise.Spec(class_1802.field_8894, LegacyText.parse("&3&lWyrzutnia Hydro Klatki"), lore(), 2.0F, true, true, true, Disguise.Ability.HYDRO_CAGE, (Disguise.Consumable)null, 0);
      OPTION = new FakeItemOption(() -> SPEC);
   }
}
