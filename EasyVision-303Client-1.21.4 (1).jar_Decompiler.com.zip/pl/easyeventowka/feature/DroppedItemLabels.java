package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;

public final class DroppedItemLabels {
   private static final double MAX_DISTANCE = (double)24.0F;
   private static final double HEIGHT = 0.9;
   private static final float SCALE = 0.025F;

   private DroppedItemLabels() {
   }

   public static void render(WorldRenderContext context) {
      class_310 client = class_310.method_1551();
      if (client.field_1687 != null && client.field_1724 != null) {
         class_4587 matrices = context.matrixStack();
         class_4597 consumers = context.consumers();
         if (matrices != null && consumers != null) {
            class_243 camera = context.camera().method_19326();
            float tickDelta = context.tickCounter().method_60637(false);
            boolean drewAnything = false;

            for(class_1297 entity : client.field_1687.method_18112()) {
               if (entity instanceof class_1542) {
                  class_1542 item = (class_1542)entity;
                  class_2561 name = Disguise.name(item.method_6983());
                  if (name != null && !(item.method_5858(client.field_1724) > (double)576.0F)) {
                     drawLabel(client, matrices, consumers, camera, item.method_30950(tickDelta), name);
                     drewAnything = true;
                  }
               }
            }

            if (drewAnything && consumers instanceof class_4597.class_4598) {
               class_4597.class_4598 immediate = (class_4597.class_4598)consumers;
               immediate.method_22993();
            }
         }
      }

   }

   private static void drawLabel(class_310 client, class_4587 matrices, class_4597 consumers, class_243 camera, class_243 at, class_2561 name) {
      class_327 font = client.field_1772;
      matrices.method_22903();
      matrices.method_22904(at.field_1352 - camera.field_1352, at.field_1351 + 0.9 - camera.field_1351, at.field_1350 - camera.field_1350);
      matrices.method_22907(client.method_1561().method_24197());
      matrices.method_22905(0.025F, -0.025F, 0.025F);
      Matrix4f matrix = matrices.method_23760().method_23761();
      float left = (float)(-font.method_27525(name)) / 2.0F;
      int background = (int)(client.field_1690.method_19343(0.25F) * 255.0F) << 24;
      font.method_27522(name, left, 0.0F, -1, false, matrix, consumers, class_6415.field_33994, background, 15728880);
      matrices.method_22909();
   }
}
