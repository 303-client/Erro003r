package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_5250;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_9381;

public final class PoisonPencil {
   private static final int POISON_COLOR = 5149489;
   private static final int PARTICLES = 12;

   private PoisonPencil() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236) {
            onClientAttack(entity);
         }

         return class_1269.field_5811;
      });
   }

   private static void onClientAttack(class_1297 target) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            if (target instanceof class_1309 && target != player) {
               if (!Disguise.hasAbility(player.method_6047(), Disguise.Ability.POISON_PENCIL)) {
                  return;
               }

               spawnPoison(world, target.method_23317(), target.method_23318(), target.method_23321(), target.method_17681(), target.method_17682());
               Titles.playSound(class_3417.field_14839, 1.0F, 0.8F);
               showMessage(target);
               return;
            }

            return;
         }
      }

   }

   private static void spawnPoison(class_638 world, double x, double y, double z, float width, float height) {
      class_9381 poison = class_9381.method_58256(class_2398.field_11226, 5149489);

      for(int i = 0; i < 12; ++i) {
         world.method_8406(poison, x + (world.field_9229.method_43058() - (double)0.5F) * (double)width, y + world.field_9229.method_43058() * (double)height, z + (world.field_9229.method_43058() - (double)0.5F) * (double)width, (double)0.0F, (double)0.0F, (double)0.0F);
      }

   }

   private static void showMessage(class_1297 target) {
      class_2583 white = class_2583.field_24360.method_10977(class_124.field_1068).method_10978(false);
      class_5250 message = class_2561.method_43473().method_10852(LegacyText.parse("&7Zatrułeś ")).method_10852(class_2561.method_43473().method_10862(white).method_10852(target.method_5477())).method_10852(LegacyText.parse(" &azatrutym ołówkiem&7!"));
      Titles.show(class_2561.method_43473(), message);
   }
}
