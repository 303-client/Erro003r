package pl.easyeventowka.feature;

public final class DamageColor {
   private DamageColor() {
   }

   public static String of(int damage) {
      if (damage <= 0) {
         return "&c";
      } else if (damage <= 10) {
         return "&7";
      } else if (damage <= 29) {
         return "&f";
      } else {
         return damage <= 44 ? "&e" : "&6";
      }
   }

   public static String line(int damage) {
      String var10000 = of(damage);
      return var10000 + "Dodatkowe obrażenia " + damage + "%";
   }
}
