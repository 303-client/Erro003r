package pl.easyeventowka.feature;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_437;

public class PouchScreen extends class_437 {
   private static final class_2960 TEXTURE = class_2960.method_60656("textures/gui/container/generic_54.png");
   private static final int ROWS = 6;
   private static final int BACKGROUND_W = 176;
   private static final int BACKGROUND_H = 222;
   private static final int PAYOUT_SLOT = 49;
   private static final int EXIT_SLOT = 53;
   private static final int SLOT = 18;
   private static final int ICON = 16;
   private final Button payout;
   private final Button exit;
   private int left;
   private int top;
   private boolean playCloseSound = true;

   public PouchScreen() {
      super(LegacyText.parse("&8Sakiewka dropu"));
      this.payout = new Button(49, new class_1799(class_1802.field_8131), List.of(LegacyText.parse("&aWypłać wszystko"), LegacyText.parse("&8 » &7Kliknij, aby odebrać przedmioty!")));
      this.exit = new Button(53, new class_1799(class_1802.field_8077), List.of(LegacyText.parse("&cWyjście"), LegacyText.parse("&8 » &7Kliknij, aby zamknąć sakiewkę!")));
   }

   public static void open() {
      Titles.playSound(class_3417.field_17604, 0.5F, 1.2F);
      class_310.method_1551().method_1507(new PouchScreen());
   }

   protected void method_25426() {
      this.left = (this.field_22789 - 176) / 2;
      this.top = (this.field_22790 - 222) / 2;
   }

   private int slotX(int slot) {
      return this.left + 8 + slot % 9 * 18;
   }

   private int slotY(int slot) {
      return this.top + 18 + slot / 9 * 18;
   }

   private boolean isOver(int x, int y, double mouseX, double mouseY) {
      return mouseX >= (double)x && mouseX < (double)(x + 16) && mouseY >= (double)y && mouseY < (double)(y + 16);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      super.method_25394(context, mouseX, mouseY, delta);
      int chestPart = 125;
      context.method_25290(class_1921::method_62277, TEXTURE, this.left, this.top, 0.0F, 0.0F, 176, chestPart, 256, 256);
      context.method_25290(class_1921::method_62277, TEXTURE, this.left, this.top + chestPart, 0.0F, 126.0F, 176, 96, 256, 256);
      context.method_51439(this.field_22793, this.field_22785, this.left + 8, this.top + 6, 4210752, false);
      context.method_51439(this.field_22793, class_2561.method_43471("container.inventory"), this.left + 8, this.top + 222 - 94, 4210752, false);
      this.drawPlayerInventory(context);
      this.drawButton(context, this.payout, mouseX, mouseY);
      this.drawButton(context, this.exit, mouseX, mouseY);
      this.drawTooltipFor(context, this.payout, mouseX, mouseY);
      this.drawTooltipFor(context, this.exit, mouseX, mouseY);
   }

   private void drawPlayerInventory(class_332 context) {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null) {
         class_1661 inventory = client.field_1724.method_31548();
         int mainTop = this.top + 139;
         int hotbarTop = this.top + 197;

         for(int i = 0; i < 27; ++i) {
            class_1799 stack = inventory.method_5438(i + 9);
            if (!stack.method_7960()) {
               context.method_51427(stack, this.left + 8 + i % 9 * 18, mainTop + i / 9 * 18);
            }
         }

         for(int i = 0; i < 9; ++i) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
               context.method_51427(stack, this.left + 8 + i * 18, hotbarTop);
            }
         }
      }

   }

   private void drawButton(class_332 context, Button button, int mouseX, int mouseY) {
      int x = this.slotX(button.slot());
      int y = this.slotY(button.slot());
      if (this.isOver(x, y, (double)mouseX, (double)mouseY)) {
         context.method_25294(x, y, x + 16, y + 16, -2130706433);
      }

      context.method_51427(button.icon(), x, y);
   }

   private void drawTooltipFor(class_332 context, Button button, int mouseX, int mouseY) {
      if (this.isOver(this.slotX(button.slot()), this.slotY(button.slot()), (double)mouseX, (double)mouseY)) {
         context.method_51434(this.field_22793, new ArrayList(button.tooltip()), mouseX, mouseY);
      }

   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      if (this.isOver(this.slotX(53), this.slotY(53), mouseX, mouseY)) {
         this.method_25419();
         return true;
      } else if (this.isOver(this.slotX(49), this.slotY(49), mouseX, mouseY)) {
         this.playCloseSound = false;
         Titles.playSound(class_3417.field_15197, 0.5F, 1.0F);
         Titles.show(LegacyText.parse("&a&lSAKIEWKA DROPU"), LegacyText.parse("&7Odebrałeś wszystkie dropy do &fEQ&7!"));
         this.method_25419();
         return true;
      } else {
         return super.method_25402(mouseX, mouseY, button);
      }
   }

   public void method_25419() {
      if (this.playCloseSound) {
         Titles.playSound(class_3417.field_17603, 0.5F, 1.2F);
      }

      super.method_25419();
   }

   public boolean method_25421() {
      return false;
   }

   private static record Button(int slot, class_1799 icon, List<class_2561> tooltip) {
   }
}
