package pl.easyeventowka.feature;

import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_345;
import pl.easyeventowka.mixin.BossBarHudAccessor;

final class FakeBossBar {
   private final UUID id;
   private final class_1259.class_1260 color;
   private final class_1259.class_1261 style;

   FakeBossBar(String name, class_1259.class_1260 color, class_1259.class_1261 style) {
      this.id = UUID.nameUUIDFromBytes(("easyeventowka:" + name).getBytes());
      this.color = color;
      this.style = style;
   }

   void show(class_2561 title, float percent) {
      Map<UUID, class_345> bars = bars();
      if (bars != null) {
         class_345 bar = (class_345)bars.get(this.id);
         if (bar == null) {
            bar = new class_345(this.id, title, percent, this.color, this.style, false, false, false);
            bars.put(this.id, bar);
         } else {
            bar.method_5413(title);
         }

         bar.method_5408(Math.max(0.0F, Math.min(1.0F, percent)));
      }

   }

   void hide() {
      Map<UUID, class_345> bars = bars();
      if (bars != null) {
         bars.remove(this.id);
      }

   }

   private static Map<UUID, class_345> bars() {
      class_310 client = class_310.method_1551();
      return client.field_1705 == null ? null : ((BossBarHudAccessor)client.field_1705.method_1740()).easyeventowka$getBossBars();
   }
}
