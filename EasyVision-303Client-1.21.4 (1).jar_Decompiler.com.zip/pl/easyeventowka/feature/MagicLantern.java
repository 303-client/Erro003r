package pl.easyeventowka.feature;

import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_2498;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_5134;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_1259.class_1260;
import net.minecraft.class_1259.class_1261;

public final class MagicLantern {
   private static final int RADIUS = 30;
   private static final int DURATION_TICKS = 600;
   private static final int COOLDOWN_TICKS = 2400;
   private static final int DUST_COLOR = 16750280;
   private static final float DUST_SIZE = 1.5F;
   private static final float ABSORPTION_HEALTH = 10.0F;
   private static final int DUST_PER_TICK = 8;
   private static final double DUST_SPREAD = (double)4.5F;
   private static final int TOTEM_PER_TICK = 4;
   private static final int TOTEM_BURST = 60;
   private static final double TOTEM_SPREAD = (double)6.0F;
   private static final float AMBIENT_DUST_SIZE = 0.8F;
   private static final FakeBossBar BOSS_BAR;
   private static final int BLOCK_FLAGS = 19;
   private static final int BREAKING_ID = -2000;
   private static long readyAtTick;
   private static long endsAtTick;
   private static class_2338 fountain;
   private static class_2680 replaced;
   private static boolean wasInside;
   private static float breakProgress;
   private static long lastMiningTick;
   private static int hitSoundTicks;
   private static boolean absorbing;

   private MagicLantern() {
   }

   public static boolean onPlaced(class_1799 stack, class_2338 pos) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            if (ClientClock.ticks() < readyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(readyAtTick - ClientClock.ticks()) / (double)20.0F));
               return true;
            }

            if (fountain != null) {
               Titles.show(class_2561.method_43473(), LegacyText.parse("&cW tym miejscu jest już aktywna &4latarnia&c!"));
               return true;
            }

            fountain = pos;
            replaced = world.method_8320(pos);
            world.method_8652(pos, class_2246.field_10327.method_9564(), 19);
            endsAtTick = ClientClock.ticks() + 600L;
            readyAtTick = ClientClock.ticks() + 2400L;
            wasInside = false;
            player.method_7357().method_62835(stack, 2400);
            Titles.playSound(class_3417.field_14941, 1.0F, 0.6F);
            totemBurst(world, pos);
            Titles.show(class_2561.method_43473(), LegacyText.parse("&5Cudowna Latarnia! Aktywowana na &d30 sekund&7!"));
            return true;
         }
      }

      return true;
   }

   public static boolean isFountain(class_2338 pos) {
      return fountain != null && fountain.equals(pos);
   }

   public static void onBroken() {
      stop(LegacyText.parse("&cFontanna została zniszczona!"), (class_3414)class_3417.field_15152.comp_349());
   }

   public static void mine(class_1657 player, class_2338 pos, class_2350 side) {
      class_310 client = class_310.method_1551();
      class_638 var5 = client.field_1687;
      if (var5 instanceof class_638) {
         if (player.method_31549().field_7477) {
            onBroken();
         } else if (lastMiningTick != ClientClock.ticks()) {
            lastMiningTick = ClientClock.ticks();
            class_2680 state = var5.method_8320(pos);
            class_2498 sounds = state.method_26231();
            breakProgress += state.method_26165(player, var5, pos);
            player.method_23667(class_1268.field_5808, false);
            client.field_1713.method_3054(pos, side);
            if (hitSoundTicks++ % 4 == 0) {
               Titles.playSound(sounds.method_10596(), (sounds.method_10597() + 1.0F) / 8.0F, sounds.method_10599() * 0.5F);
            }

            if (breakProgress < 1.0F) {
               var5.method_8517(-2000, pos, (int)(breakProgress * 10.0F) - 1);
            } else {
               client.field_1713.method_3046(pos, state);
               Titles.playSound(sounds.method_10595(), (sounds.method_10597() + 1.0F) / 2.0F, sounds.method_10599() * 0.8F);
               stopMining(var5);
               onBroken();
            }
         }
      }

   }

   private static void tickMining(class_310 client) {
      if (lastMiningTick >= 0L && ClientClock.ticks() - lastMiningTick > 1L) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            stopMining(world);
         } else {
            breakProgress = 0.0F;
            hitSoundTicks = 0;
            lastMiningTick = -1L;
         }
      }

   }

   private static void stopMining(class_638 world) {
      if (fountain != null) {
         world.method_8517(-2000, fountain, -1);
      }

      breakProgress = 0.0F;
      hitSoundTicks = 0;
      lastMiningTick = -1L;
   }

   public static void tick(class_310 client) {
      tickMining(client);
      if (fountain != null) {
         class_746 player = client.field_1724;
         if (player != null) {
            class_638 var3 = client.field_1687;
            if (var3 instanceof class_638) {
               if (!var3.method_8320(fountain).method_27852(class_2246.field_10327)) {
                  var3.method_8652(fountain, class_2246.field_10327.method_9564(), 19);
               }

               if (ClientClock.ticks() >= endsAtTick) {
                  stop((class_2561)null, class_3417.field_19344);
                  return;
               }

               spawnParticles(var3);
               updateAura(player);
               long left = endsAtTick - ClientClock.ticks();
               BOSS_BAR.show(LegacyText.parse("&5Cudowna Latarnia aktywna! &8(&d" + (int)Math.ceil((double)left / (double)20.0F) + "s&8)"), (float)left / 600.0F);
               return;
            }
         }

         stop((class_2561)null, (class_3414)null);
      }

   }

   private static void updateAura(class_746 player) {
      boolean inside = fountain.method_19771(player.method_24515(), (double)30.0F);
      if (inside && !wasInside) {
         Titles.playSound(class_3417.field_15045, 0.8F, 1.5F);
      } else if (!inside && wasInside) {
         Titles.playSound(class_3417.field_19344, 0.8F, 0.8F);
         clearAura();
      }

      wasInside = inside;
      if (inside) {
         FakeEffects.apply(class_1294.field_5924, 400, 4);
         FakeEffects.apply(class_1294.field_5898, 200, 5);
         FakeEffects.apply(class_1294.field_5910, 200, 1);
         giveHearts(player);
      }

   }

   private static void giveHearts(class_746 player) {
      class_1324 ceiling = player.method_5996(class_5134.field_45124);
      if (ceiling != null && ceiling.method_6201() != (double)10.0F) {
         ceiling.method_6192((double)10.0F);
      }

      if (player.method_6067() < 10.0F) {
         player.method_6073(10.0F);
      }

      absorbing = true;
   }

   private static void takeHearts() {
      if (absorbing) {
         absorbing = false;
         class_746 player = class_310.method_1551().field_1724;
         if (player != null) {
            player.method_6073(0.0F);
            class_1324 ceiling = player.method_5996(class_5134.field_45124);
            if (ceiling != null) {
               ceiling.method_6192((double)0.0F);
            }
         }
      }

   }

   private static void spawnParticles(class_638 world) {
      double x = (double)fountain.method_10263() + (double)0.5F;
      double y = (double)fountain.method_10264() + 1.2;
      double z = (double)fountain.method_10260() + (double)0.5F;
      world.method_8406(new class_2390(16750280, 1.5F), x, y, z, (double)0.0F, (double)0.0F, (double)0.0F);

      for(int i = 0; i < 8; ++i) {
         double angle = world.field_9229.method_43058() * Math.PI * (double)2.0F;
         double spread = world.field_9229.method_43058() * (double)4.5F;
         world.method_8406(new class_2390(16750280, 0.8F), x + Math.cos(angle) * spread, y + world.field_9229.method_43058() * (double)2.5F, z + Math.sin(angle) * spread, (double)0.0F, (double)0.0F, (double)0.0F);
      }

      for(int i = 0; i < 4; ++i) {
         double angle = world.field_9229.method_43058() * Math.PI * (double)2.0F;
         double spread = world.field_9229.method_43058() * (double)6.0F;
         world.method_8406(class_2398.field_11220, x + Math.cos(angle) * spread, y + world.field_9229.method_43058() * (double)2.5F, z + Math.sin(angle) * spread, world.field_9229.method_43059() * 0.05, world.field_9229.method_43058() * 0.1, world.field_9229.method_43059() * 0.05);
      }

   }

   private static void totemBurst(class_638 world, class_2338 pos) {
      double x = (double)pos.method_10263() + (double)0.5F;
      double y = (double)pos.method_10264() + (double)1.0F;
      double z = (double)pos.method_10260() + (double)0.5F;

      for(int i = 0; i < 60; ++i) {
         world.method_8406(class_2398.field_11220, x, y, z, world.field_9229.method_43059() * 0.35, world.field_9229.method_43059() * 0.35 + 0.2, world.field_9229.method_43059() * 0.35);
      }

      world.method_8486(x, y, z, class_3417.field_14931, class_3419.field_15248, 0.7F, 1.2F, false);
   }

   private static void stop(class_2561 message, class_3414 sound) {
      class_310 client = class_310.method_1551();
      if (fountain != null) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            stopMining(world);
            if (replaced != null) {
               world.method_8652(fountain, replaced, 19);
            }
         }
      }

      fountain = null;
      replaced = null;
      wasInside = false;
      BOSS_BAR.hide();
      clearAura();
      if (sound != null) {
         Titles.playSound(sound, 1.0F, sound == class_3417.field_19344 ? 1.0F : 1.5F);
      }

      if (message != null) {
         Titles.show(class_2561.method_43473(), message);
      }

   }

   private static void clearAura() {
      takeHearts();
      FakeEffects.remove(class_1294.field_5924);
      FakeEffects.remove(class_1294.field_5898);
      FakeEffects.remove(class_1294.field_5910);
   }

   static {
      BOSS_BAR = new FakeBossBar("magic_lantern", class_1260.field_5788, class_1261.field_5791);
      lastMiningTick = -1L;
   }
}
