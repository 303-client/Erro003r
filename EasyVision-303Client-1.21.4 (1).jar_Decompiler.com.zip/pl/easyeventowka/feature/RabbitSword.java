package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_746;

public final class RabbitSword {
   private static final int COOLDOWN_TICKS = 800;
   private static long readyAtTick;

   private RabbitSword() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236) {
            onClientAttack(entity);
         }

         return class_1269.field_5811;
      });
   }

   private static void onClientAttack(class_1297 target) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null && target instanceof class_1309 && target != player) {
         class_1799 held = player.method_6047();
         if (Disguise.hasAbility(held, Disguise.Ability.RABBIT_SWORD)) {
            long now = ClientClock.ticks();
            if (now >= readyAtTick) {
               readyAtTick = now + 800L;
               player.method_7357().method_62835(held, 800);
               Titles.playSound(class_3417.field_15164, 1.0F, 1.0F);
            }
         }
      }

   }
}
