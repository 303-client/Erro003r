package pl.easyeventowka.feature;

import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2398;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class PhantomBlock {
   private static final int COOLDOWN_TICKS = 6000;
   private static final int EFFECT_TICKS = 150;
   private static long readyAtTick;
   private static long effectEndsAtTick;

   private PhantomBlock() {
   }

   public static boolean onUse(class_1799 stack, class_2338 at) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player == null) {
         return true;
      } else if (ClientClock.ticks() < readyAtTick) {
         Titles.cooldown((int)Math.ceil((double)(readyAtTick - ClientClock.ticks()) / (double)20.0F));
         return true;
      } else {
         readyAtTick = ClientClock.ticks() + 6000L;
         effectEndsAtTick = ClientClock.ticks() + 150L;
         player.method_7357().method_62835(stack, 6000);
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            burst(world, at);
         }

         Titles.playSound(class_3417.field_38060, 0.9F, 1.25F);
         Titles.show(class_2561.method_43473(), LegacyText.parse("&cPostawiłeś blok widmo"));
         return true;
      }
   }

   private static void burst(class_638 world, class_2338 at) {
      double x = (double)at.method_10263() + (double)0.5F;
      double y = (double)at.method_10264() + (double)1.0F;
      double z = (double)at.method_10260() + (double)0.5F;
      world.method_8406(class_2398.field_11221, x, y, z, (double)0.0F, (double)0.0F, (double)0.0F);

      for(int i = 0; i < 30; ++i) {
         double angle = world.field_9229.method_43058() * Math.PI * (double)2.0F;
         double speed = 0.1 + world.field_9229.method_43058() * (double)0.25F;
         world.method_8406(class_2398.field_38002, x, y, z, Math.cos(angle) * speed, world.field_9229.method_43058() * 0.3, Math.sin(angle) * speed);
         world.method_8406(class_2398.field_11237, x, y, z, Math.cos(angle) * speed * (double)0.5F, world.field_9229.method_43058() * 0.15, Math.sin(angle) * speed * (double)0.5F);
      }

   }

   public static void tick(class_310 client) {
      if (effectEndsAtTick != 0L && ClientClock.ticks() >= effectEndsAtTick) {
         effectEndsAtTick = 0L;
         Titles.playSound(class_3417.field_38068, 0.7F, 0.8F);
      }

   }
}
