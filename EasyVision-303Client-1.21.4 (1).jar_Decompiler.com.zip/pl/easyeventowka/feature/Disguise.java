package pl.easyeventowka.feature;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1291;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_3481;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9280;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public final class Disguise {
   private static final Map<String, Spec> SPECS = new LinkedHashMap();
   private static final Map<Look, class_1799> LOOKS = new HashMap();
   private static final Map<Spec, class_1799> MODEL_OVERRIDE = new HashMap();

   private Disguise() {
   }

   private static String key(class_1799 stack) {
      List<String> parts = new ArrayList();

      for(Map.Entry<class_9331<?>, Optional<?>> entry : stack.method_57380().method_57846()) {
         if (entry.getKey() != class_9334.field_49629) {
            String var10001 = String.valueOf(entry.getKey());
            parts.add(var10001 + "=" + String.valueOf(((Optional)entry.getValue()).orElse((Object)null)));
         }
      }

      Collections.sort(parts);
      StringBuilder id = new StringBuilder(class_7923.field_41178.method_10221(stack.method_7909()).toString());

      for(String part : parts) {
         id.append('|').append(part);
      }

      return id.toString();
   }

   public static String fingerprint(class_1799 stack) {
      return key(stack);
   }

   public static void modelOverride(Spec spec, class_1799 look) {
      MODEL_OVERRIDE.put(spec, look);
   }

   public static void put(String fingerprint, Spec spec) {
      SPECS.put(fingerprint, spec);
   }

   public static void remove(String fingerprint) {
      SPECS.remove(fingerprint);
   }

   public static void clear() {
      SPECS.clear();
   }

   public static Spec specFor(class_1799 stack) {
      return !SPECS.isEmpty() && stack != null && !stack.method_7960() ? (Spec)SPECS.get(key(stack)) : null;
   }

   public static boolean isDisguised(class_1799 stack) {
      return specFor(stack) != null;
   }

   public static class_1799 model(class_1799 stack) {
      Spec spec = specFor(stack);
      if (spec == null) {
         return stack;
      } else {
         class_1799 ready = (class_1799)MODEL_OVERRIDE.get(spec);
         if (ready != null) {
            return ready;
         } else {
            Look look = new Look(spec.modelItem(), spec.customModelData(), spec.glint());
            return (class_1799)LOOKS.computeIfAbsent(look, Disguise::buildLook);
         }
      }
   }

   private static class_1799 buildLook(Look look) {
      class_1799 stack = new class_1799(look.modelItem());
      if (look.customModelData() != null) {
         stack.method_57379(class_9334.field_49637, new class_9280(List.of(look.customModelData()), List.of(), List.of(), List.of()));
      }

      if (look.glint()) {
         stack.method_57379(class_9334.field_49641, true);
      }

      return stack;
   }

   public static class_2561 name(class_1799 stack) {
      Spec spec = specFor(stack);
      return spec == null ? null : spec.name();
   }

   public static List<class_2561> lore(class_1799 stack) {
      Spec spec = specFor(stack);
      return spec != null && spec.lore() != null ? spec.lore() : List.of();
   }

   public static boolean hidesAttributes(class_1799 stack) {
      Spec spec = specFor(stack);
      return spec != null && spec.hideAttributes();
   }

   public static boolean hidesDurability(class_1799 stack) {
      Spec spec = specFor(stack);
      return spec != null && spec.hideDurability();
   }

   public static Ability abilityOf(class_1799 stack) {
      Spec spec = specFor(stack);
      return spec == null ? Disguise.Ability.NONE : spec.ability();
   }

   public static boolean hasAbility(class_1799 stack, Ability ability) {
      return abilityOf(stack) == ability;
   }

   public static Consumable consumableOf(class_1799 stack) {
      Spec spec = specFor(stack);
      return spec == null ? null : spec.consumable();
   }

   public static int displayCount(class_1799 stack) {
      Spec spec = specFor(stack);
      if (spec == null) {
         return 0;
      } else {
         return spec.ability() == Disguise.Ability.RUBIKS_CUBE ? RubiksCube.shownCount(stack) : spec.count();
      }
   }

   public static boolean blocksPlacing(class_1799 stack, class_1937 world, class_2338 clicked) {
      if (stack.method_7909() instanceof class_1747 && isDisguised(stack)) {
         class_2680 state = world.method_8320(clicked);
         if (state.method_31709()) {
            return false;
         } else {
            return !state.method_26164(class_3481.field_15495) && !state.method_26164(class_3481.field_15487) && !state.method_26164(class_3481.field_25147) && !state.method_26164(class_3481.field_15493);
         }
      } else {
         return false;
      }
   }

   public static String realItemId(class_1799 stack) {
      return class_7923.field_41178.method_10221(stack.method_7909()).toString();
   }

   public static record Spec(class_1792 modelItem, class_2561 name, List<class_2561> lore, Float customModelData, boolean glint, boolean hideAttributes, boolean hideDurability, Ability ability, Consumable consumable, int count) {
   }

   public static record Effect(class_6880<class_1291> effect, int duration, int amplifier) {
   }

   public static record Consumable(int cooldownTicks, List<Effect> effects) {
   }

   public static enum Ability {
      NONE,
      HYDRO_CAGE,
      ILLUSIONIST_WAND,
      PHANTOM_BLOCK,
      MAGIC_LANTERN,
      GRINCH_LIGHTNING,
      DROP_POUCH,
      GUARDIAN_ROD,
      LOLLIPOP,
      FLIGHTLESS_ROD,
      POISON_PENCIL,
      CUPID_ROSE,
      DRACULA_BACKPACK,
      SCYTHE,
      GRINCH_SHOVEL,
      DIVINE_AXE,
      ARCUS_MAGNUS,
      RUBIKS_CUBE,
      RABBIT_SWORD;

      private static Ability[] $values() {
         return new Ability[]{NONE, HYDRO_CAGE, ILLUSIONIST_WAND, PHANTOM_BLOCK, MAGIC_LANTERN, GRINCH_LIGHTNING, DROP_POUCH, GUARDIAN_ROD, LOLLIPOP, FLIGHTLESS_ROD, POISON_PENCIL, CUPID_ROSE, DRACULA_BACKPACK, SCYTHE, GRINCH_SHOVEL, DIVINE_AXE, ARCUS_MAGNUS, RUBIKS_CUBE, RABBIT_SWORD};
      }

      // $FF: synthetic method
      private static Ability[] $values$() {
         return new Ability[]{NONE, HYDRO_CAGE, ILLUSIONIST_WAND, PHANTOM_BLOCK, MAGIC_LANTERN, GRINCH_LIGHTNING, DROP_POUCH, GUARDIAN_ROD, LOLLIPOP, FLIGHTLESS_ROD, POISON_PENCIL, CUPID_ROSE, DRACULA_BACKPACK, SCYTHE, GRINCH_SHOVEL, DIVINE_AXE, ARCUS_MAGNUS, RUBIKS_CUBE, RABBIT_SWORD};
      }
   }

   private static record Look(class_1792 modelItem, Float customModelData, boolean glint) {
   }
}
