package pl.easyeventowka.feature;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1299;
import net.minecraft.class_1674;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2390;
import net.minecraft.class_2398;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_345;
import net.minecraft.class_3481;
import net.minecraft.class_3730;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_1259.class_1260;
import net.minecraft.class_1259.class_1261;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import pl.easyeventowka.mixin.BossBarHudAccessor;

public final class HydroCage {
   private static final int RADIUS = 9;
   private static final int WALL_THICKNESS = 1;
   private static final int CAGE_TICKS = 300;
   private static final int COOLDOWN_TICKS = 1200;
   private static final int LAYERS = 19;
   private static final int BUILD_TICKS = 40;
   private static final int BOSSBAR_RANGE = 13;
   private static final double SPEED = (double)1.5F;
   private static final double GRAVITY = 0.03;
   private static final int MAX_FLIGHT_TICKS = 200;
   private static final int DRIPS_PER_TICK = 12;
   private static final int DUST_COLOR = 5947135;
   private static final float DUST_SIZE = 1.1F;
   private static final float RING_DUST_SIZE = 1.6F;
   private static final int RING_PARTICLES = 20;
   private static final int MOTES_PER_TICK = 4;
   private static final int BLOCK_FLAGS = 19;
   private static final UUID BOSSBAR_ID = UUID.nameUUIDFromBytes("easyeventowka:hydro_cage".getBytes());
   private static Projectile projectile;
   private static Cage cage;
   private static long readyAtTick;
   private static int nextVisualId = -1000;
   private static int lastShownSecond = -1;

   private HydroCage() {
   }

   public static boolean tryShoot(class_1799 stack) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null && client.field_1687 != null) {
         if (ClientClock.ticks() < readyAtTick) {
            Titles.cooldown((int)Math.ceil((double)(readyAtTick - ClientClock.ticks()) / (double)20.0F));
            return true;
         } else if (projectile != null) {
            return true;
         } else {
            readyAtTick = ClientClock.ticks() + 1200L;
            lastShownSecond = -1;
            player.method_7357().method_62835(stack, 1200);
            class_243 start = player.method_33571();
            projectile = new Projectile(start, player.method_5828(1.0F).method_1021((double)1.5F));
            projectile.visual = spawnFireball(client.field_1687, start);
            Titles.playSound(class_3417.field_14970, 1.0F, 0.8F);
            return true;
         }
      } else {
         return false;
      }
   }

   private static class_1674 spawnFireball(class_638 world, class_243 at) {
      class_1674 fireball = (class_1674)class_1299.field_6066.method_5883(world, class_3730.field_16461);
      if (fireball == null) {
         return null;
      } else {
         fireball.method_5838(nextVisualId--);
         fireball.method_5875(true);
         fireball.method_18799(class_243.field_1353);
         fireball.method_5814(at.field_1352, at.field_1351, at.field_1350);
         world.method_53875(fireball);
         return fireball;
      }
   }

   public static void tick(class_310 client) {
      class_638 world = client.field_1687;
      if (world instanceof class_638) {
         tickProjectile(client, world);
         tickCage(client, world);
         tickCooldownCountdown();
      } else {
         if (projectile != null) {
            projectile.discardVisual();
            projectile = null;
         }

         cage = null;
         hideBossBar(client);
      }

   }

   private static void tickProjectile(class_310 client, class_638 world) {
      if (projectile != null) {
         class_243 from = projectile.pos;
         class_243 to = from.method_1019(projectile.velocity);
         class_3965 hit = world.method_17742(new class_3959(from, to, class_3960.field_17558, class_242.field_1348, client.field_1724));
         if (hit != null && hit.method_17783() == class_240.field_1332) {
            projectile.discardVisual();
            projectile = null;
            createCage(client, world, hit.method_17777());
         } else {
            projectile.pos = to;
            projectile.velocity = projectile.velocity.method_1023((double)0.0F, 0.03, (double)0.0F);
            if (projectile.visual != null) {
               projectile.visual.method_5814(to.field_1352, to.field_1351, to.field_1350);
            }

            if (++projectile.ticks > 200) {
               projectile.discardVisual();
               projectile = null;
            }
         }
      }

   }

   private static void tickCage(class_310 client, class_638 world) {
      if (cage != null) {
         if (cage.isBuilding()) {
            buildNextLayers(world, cage);
         }

         holdWalls(world, cage);
         spawnDrips(world, cage);
         spawnMotes(world, cage);
         if (ClientClock.ticks() >= cage.expiresAtTick) {
            removeCage(client, world);
            Titles.playSound(class_3417.field_14979, 1.0F, 1.0F);
         } else {
            updateBossBar(client, (float)(cage.expiresAtTick - ClientClock.ticks()) / 300.0F);
         }
      }

   }

   private static void spawnDrips(class_638 world, Cage standing) {
      class_2338.class_2339 pos = new class_2338.class_2339();

      for(int i = 0; i < 12; ++i) {
         double dx = (world.field_9229.method_43058() * (double)2.0F - (double)1.0F) * (double)9.0F;
         double dz = (world.field_9229.method_43058() * (double)2.0F - (double)1.0F) * (double)9.0F;
         double dy = world.field_9229.method_43058() * (double)9.0F;
         if (!(dx * dx + dy * dy + dz * dz > (double)81.0F)) {
            double x = (double)standing.center.method_10263() + (double)0.5F + dx;
            double y = (double)standing.center.method_10264() + (double)0.5F + dy;
            double z = (double)standing.center.method_10260() + (double)0.5F + dz;
            pos.method_10103((int)Math.floor(x), (int)Math.floor(y), (int)Math.floor(z));
            if (world.method_8320(pos).method_26215()) {
               world.method_8406(class_2398.field_11232, x, y, z, (double)0.0F, (double)0.0F, (double)0.0F);
            }
         }
      }

   }

   private static void spawnLayerRing(class_638 world, Cage building, int dy) {
      double radius = Math.sqrt(Math.max((double)0.0F, (double)81.0F - (double)dy * (double)dy));
      if (!(radius < (double)0.5F)) {
         double y = (double)building.center.method_10264() + (double)0.5F + (double)dy;

         for(int i = 0; i < 20; ++i) {
            double angle = (double)i * (Math.PI / 10D) + world.field_9229.method_43058() * 0.15;
            double x = (double)building.center.method_10263() + (double)0.5F + Math.cos(angle) * radius;
            double z = (double)building.center.method_10260() + (double)0.5F + Math.sin(angle) * radius;
            world.method_8406(new class_2390(5947135, 1.6F), x, y, z, (double)0.0F, (double)0.0F, (double)0.0F);
            if (i % 4 == 0) {
               world.method_8406(class_2398.field_11202, x, y, z, (double)0.0F, 0.05, (double)0.0F);
            }
         }
      }

   }

   private static void spawnMotes(class_638 world, Cage standing) {
      for(int i = 0; i < 4; ++i) {
         double dx = (world.field_9229.method_43058() * (double)2.0F - (double)1.0F) * (double)9.0F;
         double dy = (world.field_9229.method_43058() * (double)2.0F - (double)1.0F) * (double)9.0F;
         double dz = (world.field_9229.method_43058() * (double)2.0F - (double)1.0F) * (double)9.0F;
         if (!(dx * dx + dy * dy + dz * dz > (double)81.0F)) {
            world.method_8406(new class_2390(5947135, 1.1F), (double)standing.center.method_10263() + (double)0.5F + dx, (double)standing.center.method_10264() + (double)0.5F + dy, (double)standing.center.method_10260() + (double)0.5F + dz, (double)0.0F, 0.02, (double)0.0F);
         }
      }

   }

   private static void holdWalls(class_638 world, Cage standing) {
      standing.blocks.forEach((pos, swap) -> {
         if (world.method_8320(pos) != swap.after()) {
            world.method_8652(pos, swap.after(), 19);
         }

      });
   }

   private static void tickCooldownCountdown() {
      long left = readyAtTick - ClientClock.ticks();
      if (left <= 0L) {
         lastShownSecond = -1;
      } else {
         int seconds = (int)Math.ceil((double)left / (double)20.0F);
         if (seconds != lastShownSecond) {
            lastShownSecond = seconds;
            Titles.actionBar(LegacyText.parse("&fStrzał z &3Hydroklatki &fza: &b" + seconds + "s"));
         }
      }

   }

   private static void createCage(class_310 client, class_638 world, class_2338 center) {
      buildCage(client, world, center);
      Titles.playSound(class_3417.field_14700, 1.0F, 1.0F);
   }

   private static void buildCage(class_310 client, class_638 world, class_2338 center) {
      if (cage != null) {
         removeCage(client, world);
      }

      cage = new Cage(center);
      cage.expiresAtTick = ClientClock.ticks() + 300L;
   }

   private static void buildNextLayers(class_638 world, Cage building) {
      int from = building.buildTicks * 19 / 40;
      int to = (building.buildTicks + 1) * 19 / 40;
      class_238 playerSpace = playerSpace();

      for(int layer = from; layer < to; ++layer) {
         int dy = 9 - layer;
         placeLayer(world, building, dy, playerSpace);
         spawnLayerRing(world, building, dy);
      }

      ++building.buildTicks;
   }

   private static class_238 playerSpace() {
      class_746 player = class_310.method_1551().field_1724;
      return player == null ? null : player.method_5829().method_1014(0.1);
   }

   private static void placeLayer(class_638 world, Cage building, int dy, class_238 playerSpace) {
      int inner = 8;
      class_2338.class_2339 pos = new class_2338.class_2339();

      for(int dx = -9; dx <= 9; ++dx) {
         for(int dz = -9; dz <= 9; ++dz) {
            double distance = Math.sqrt((double)(dx * dx + dy * dy + dz * dz));
            if (!(distance > (double)9.0F)) {
               pos.method_10103(building.center.method_10263() + dx, building.center.method_10264() + dy, building.center.method_10260() + dz);
               if (!world.method_31601(pos.method_10264())) {
                  class_2680 was = world.method_8320(pos);
                  boolean onShell = distance > (double)inner;
                  if ((playerSpace == null || !playerSpace.method_994(new class_238(pos)) || was.method_26234(world, pos)) && (!was.method_26215() || onShell)) {
                     class_2680 becomes = onShell ? borderBlock() : cageBlock(was);
                     class_2338 immutable = pos.method_10062();
                     building.blocks.put(immutable, new Swap(was, becomes));
                     world.method_8652(immutable, becomes, 19);
                  }
               }
            }
         }
      }

   }

   private static class_2680 borderBlock() {
      return class_2246.field_10550.method_9564();
   }

   private static class_2680 cageBlock(class_2680 was) {
      if (was.method_26164(class_3481.field_15503)) {
         return class_2246.field_10409.method_9564();
      } else if (was.method_26164(class_3481.field_15475)) {
         return class_2246.field_10000.method_9564();
      } else if (was.method_26164(class_3481.field_15471)) {
         return class_2246.field_10006.method_9564();
      } else {
         return was.method_26164(class_3481.field_25806) ? class_2246.field_10135.method_9564() : class_2246.field_10325.method_9564();
      }
   }

   private static void removeCage(class_310 client, class_638 world) {
      if (cage != null) {
         cage.blocks.forEach((pos, swap) -> world.method_8652(pos, swap.before(), 19));
         cage = null;
         hideBossBar(client);
      }

   }

   public static boolean isCageBlock(class_2338 pos) {
      return cage != null && cage.blocks.containsKey(pos);
   }

   public static boolean isInsideCage(class_2338 pos) {
      return cage != null && cage.center.method_19771(pos, (double)9.0F);
   }

   public static void warnBreak(class_746 player) {
      class_2561 message = LegacyText.parse("&cNie możesz zniszczyć granicy podwodnej klatki!");
      Titles.show(class_2561.method_43473(), message);
      if (player != null) {
         player.method_7353(message, false);
      }

   }

   public static void warnPlace() {
      Titles.show(class_2561.method_43473(), LegacyText.parse("&cNie możesz stawiać bloków w Hydro Klatce!"));
   }

   private static void updateBossBar(class_310 client, float percent) {
      class_746 player = client.field_1724;
      Map<UUID, class_345> bars = bossBars(client);
      if (player != null && bars != null) {
         if (!cage.center.method_19771(player.method_24515(), (double)13.0F)) {
            bars.remove(BOSSBAR_ID);
         } else {
            class_345 bar = (class_345)bars.get(BOSSBAR_ID);
            if (bar == null) {
               bar = new class_345(BOSSBAR_ID, LegacyText.parse("&bHydro Klatka"), percent, class_1260.field_5780, class_1261.field_5795, false, false, false);
               bars.put(BOSSBAR_ID, bar);
            }

            bar.method_5408(Math.max(0.0F, Math.min(1.0F, percent)));
         }
      }

   }

   private static void hideBossBar(class_310 client) {
      Map<UUID, class_345> bars = bossBars(client);
      if (bars != null) {
         bars.remove(BOSSBAR_ID);
      }

   }

   private static Map<UUID, class_345> bossBars(class_310 client) {
      return client.field_1705 == null ? null : ((BossBarHudAccessor)client.field_1705.method_1740()).easyeventowka$getBossBars();
   }

   private static record Swap(class_2680 before, class_2680 after) {
   }

   private static final class Projectile {
      class_243 pos;
      class_243 velocity;
      int ticks;
      class_1674 visual;

      Projectile(class_243 pos, class_243 velocity) {
         this.pos = pos;
         this.velocity = velocity;
      }

      void discardVisual() {
         if (this.visual != null) {
            this.visual.method_31472();
            this.visual = null;
         }

      }
   }

   private static final class Cage {
      final class_2338 center;
      final Map<class_2338, Swap> blocks = new LinkedHashMap();
      long expiresAtTick;
      int buildTicks;

      Cage(class_2338 center) {
         this.center = center;
      }

      boolean isBuilding() {
         return this.buildTicks < 40;
      }
   }
}
