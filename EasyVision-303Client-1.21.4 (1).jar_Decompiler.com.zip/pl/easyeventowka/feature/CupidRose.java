package pl.easyeventowka.feature;

import net.minecraft.class_1294;
import net.minecraft.class_1324;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_746;

public final class CupidRose {
   private static final int EFFECT_TICKS = 100;
   private static final float EXTRA_HEALTH = 10.0F;
   private static float realHealth = -1.0F;
   private static float shownHealth = -1.0F;
   private static double realMax = (double)-1.0F;
   private static double shownMax = (double)-1.0F;
   private static boolean boosted;

   private CupidRose() {
   }

   public static void tick(class_310 client) {
      class_746 player = client.field_1724;
      if (player == null) {
         boosted = false;
         realHealth = -1.0F;
         shownHealth = -1.0F;
         realMax = (double)-1.0F;
         shownMax = (double)-1.0F;
      } else {
         boolean holding = Disguise.hasAbility(player.method_6047(), Disguise.Ability.CUPID_ROSE) || Disguise.hasAbility(player.method_6079(), Disguise.Ability.CUPID_ROSE);
         if (holding) {
            FakeEffects.apply(class_1294.field_5907, 100, 0);
            FakeEffects.apply(class_1294.field_5924, 100, 0);
            addHearts(player);
            boosted = true;
         } else if (boosted) {
            FakeEffects.remove(class_1294.field_5907);
            FakeEffects.remove(class_1294.field_5924);
            removeHearts(player);
            boosted = false;
         }
      }

   }

   private static void addHearts(class_746 player) {
      raiseCeiling(player);
      if (player.method_6032() != shownHealth) {
         realHealth = player.method_6032();
      }

      shownHealth = Math.min(realHealth + 10.0F, player.method_6063());
      player.method_6033(shownHealth);
   }

   private static void raiseCeiling(class_746 player) {
      class_1324 health = player.method_5996(class_5134.field_23716);
      if (health != null) {
         if (health.method_6201() != shownMax) {
            realMax = health.method_6201();
         }

         shownMax = realMax + (double)10.0F;
         if (health.method_6201() != shownMax) {
            health.method_6192(shownMax);
         }
      }

   }

   private static void removeHearts(class_746 player) {
      if (realHealth >= 0.0F) {
         player.method_6033(realHealth);
      }

      class_1324 health = player.method_5996(class_5134.field_23716);
      if (health != null && realMax >= (double)0.0F) {
         health.method_6192(realMax);
      }

      realHealth = -1.0F;
      shownHealth = -1.0F;
      realMax = (double)-1.0F;
      shownMax = (double)-1.0F;
   }
}
