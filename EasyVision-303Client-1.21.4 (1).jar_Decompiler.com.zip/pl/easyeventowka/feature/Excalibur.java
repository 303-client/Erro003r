package pl.easyeventowka.feature;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import pl.easyeventowka.gui.NumberSetting;

public final class Excalibur {
   private static final double KILLS_PER_PERCENT = (double)10.0F;
   private static final int SEGMENTS = 10;
   public static final FakeItemOption OPTION = new FakeItemOption(Excalibur::spec);
   private static NumberSetting damageSetting;
   private static NumberSetting killsSetting;

   private Excalibur() {
   }

   public static void bind(NumberSetting damage, NumberSetting kills) {
      damageSetting = damage;
      killsSetting = kills;
      FakeItemOption var10001 = OPTION;
      Objects.requireNonNull(var10001);
      Objects.requireNonNull(var10001);
      damage.onChange(var10001::refresh);
      var10001 = OPTION;
      Objects.requireNonNull(var10001);
      Objects.requireNonNull(var10001);
      kills.onChange(var10001::refresh);
   }

   private static Disguise.Spec spec() {
      return new Disguise.Spec(class_1802.field_22022, LegacyText.parse("&e&lExcalibur"), lore(), 5.0F, true, true, true, Disguise.Ability.NONE, (Disguise.Consumable)null, 0);
   }

   private static List<class_2561> lore() {
      int damage = damageSetting == null ? 51 : (int)damageSetting.value;
      int kills = killsSetting == null ? 9 : (int)killsSetting.value;
      List<String> lines = new ArrayList(List.of(DamageColor.line(damage), "&r", "&8 » &7Jest to przedmiot zdobyty z", "&8 » &fwydarzenia wakacyjnego 2024&7!", "&r", "&8 » &7Aktualnie zabójstw: &f" + kills, progressBar(kills), "&r", "&8 » &7Zapełnienie paska zapewnia", "&8 » &7Ci &f12 punktów obrażeń&7, co", "&8 » &7jest równoznaczne z &eostrością 7&7!", "&7", "&8 » &7Obrażenia od ataku: &f11.5"));
      return lines.stream().map(LegacyText::parse).toList();
   }

   private static String progressBar(int kills) {
      double percent = Math.min((double)100.0F, (double)Math.round((double)kills / (double)10.0F * (double)10.0F) / (double)10.0F);
      int lit = (int)Math.floor(percent / (double)10.0F);
      StringBuilder bar = new StringBuilder("&8 » ");

      for(int i = 0; i < 10; ++i) {
         bar.append(i < lit ? "&a&m-" : "&f&m-");
      }

      return bar.append(" &r &e").append(formatPercent(percent)).append('%').toString();
   }

   private static String formatPercent(double percent) {
      return percent >= (double)100.0F ? "100" : String.format(Locale.ROOT, "%.1f", percent);
   }
}
