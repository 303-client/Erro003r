package pl.easyeventowka.feature;

import com.mojang.authlib.GameProfile;
import com.mojang.authlib.properties.Property;
import java.util.List;
import java.util.UUID;
import net.minecraft.class_1294;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_9296;
import net.minecraft.class_9334;

public final class Presets {
   private static final Disguise.Consumable VAMPIRE_APPLE;
   private static final String RUBIK_SKIN = "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODUxM2YwZjFkYzA2MzJkYjhmYzFjMjc5MmE2NjI5ZTA5ZDQ3YzdiMTJjNjM4MjRhNzVjOTRiZjRjZDdlODFkYyJ9fX0=";
   public static final FakeItemOption GRINCH_AXE;
   public static final FakeItemOption DROP_POUCH;
   public static final FakeItemOption VAMPIRE_APPLE_ITEM;
   public static final FakeItemOption GUARDIAN_ROD;
   public static final FakeItemOption ILLUSIONIST_WAND;
   public static final FakeItemOption PHANTOM_BLOCK;
   public static final FakeItemOption MAGIC_LANTERN;
   public static final FakeItemOption LOLLIPOP;
   public static final FakeItemOption FLIGHTLESS_ROD;
   public static final FakeItemOption POISON_PENCIL;
   public static final FakeItemOption CUPID_ROSE;
   public static final FakeItemOption DRACULA_BACKPACK;
   public static final FakeItemOption SCYTHE;
   public static final FakeItemOption GRINCH_SHOVEL;
   public static final FakeItemOption DIVINE_AXE;
   public static final FakeItemOption ARCUS_MAGNUS;
   public static final FakeItemOption RUBIKS_CUBE;
   public static final FakeItemOption ROD;

   private Presets() {
   }

   public static void init() {
      Disguise.modelOverride(RUBIKS_CUBE.spec(), rubikHead());
   }

   private static class_1799 rubikHead() {
      class_1799 head = new class_1799(class_1802.field_8575);
      GameProfile profile = new GameProfile(UUID.nameUUIDFromBytes("easyeventowka:rubik".getBytes()), "rubik");
      profile.getProperties().put("textures", new Property("textures", "eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvODUxM2YwZjFkYzA2MzJkYjhmYzFjMjc5MmE2NjI5ZTA5ZDQ3YzdiMTJjNjM4MjRhNzVjOTRiZjRjZDdlODFkYyJ9fX0="));
      head.method_57379(class_9334.field_49617, new class_9296(profile));
      return head;
   }

   private static FakeItemOption option(class_1792 modelItem, float customModelData, String name, List<String> lore, boolean glint, boolean hideAttributes, Disguise.Ability ability, Disguise.Consumable consumable) {
      List<class_2561> lines = lore.stream().map(LegacyText::parse).toList();
      Disguise.Spec spec = new Disguise.Spec(modelItem, LegacyText.parse(name), lines, customModelData, glint, hideAttributes, true, ability, consumable, 0);
      return new FakeItemOption(() -> spec);
   }

   static {
      VAMPIRE_APPLE = new Disguise.Consumable(300, List.of(new Disguise.Effect(class_1294.field_5924, 600, 1), new Disguise.Effect(class_1294.field_5918, 6000, 0), new Disguise.Effect(class_1294.field_5907, 6000, 0), new Disguise.Effect(class_1294.field_5898, 2400, 3), new Disguise.Effect(class_1294.field_5910, 60, 1)));
      GRINCH_AXE = option(class_1802.field_8825, 1.0F, "&2Siekiera Grincha", List.of("&8 » &7Jest to przedmiot z:", "&8 » &feventu świątecznego (2023)", "&r", "&8 » &7Po &auderzeniu &7strzela &fpiorun", "&8 » &7w przeciwnika zadając mu &c30%", "&8 » &7jego życia! &fUmiejętność&7 działa", "&8 » &7raz na 1 minute."), false, false, Disguise.Ability.GRINCH_LIGHTNING, (Disguise.Consumable)null);
      DROP_POUCH = option(class_1802.field_8073, 1.0F, "&a&lSakiewka dropu", List.of("&7", "&8 » &7Posiadając ten przedmiot w", "&8 » &7ekwipunku po &czabiciu &7dowolnego", "&8 » &fgracza &7jego przedmioty trafiają", "&8 » &7do twojej &asakiewki&7!", "&7", "&8 » &eKliknij PRAWYM, aby otworzyć sakiewkę!", "&7"), false, true, Disguise.Ability.DROP_POUCH, (Disguise.Consumable)null);
      VAMPIRE_APPLE_ITEM = option(class_1802.field_8367, 5324.0F, "&c&lWampirze jabłko", List.of("&8 » &7Jest to przedmiot z:", "&8 » &feventu halloween (2024)", "", "&8 » &7Po zjedzeniu otrzymujesz na", "&8 » &7krótki czas efekt &csiły II&7!"), true, true, Disguise.Ability.NONE, VAMPIRE_APPLE);
      GUARDIAN_ROD = option(class_1802.field_8378, 20266.0F, "&3&lWędka Guardiania", List.of("&8 » &7Jest to przedmiot zdobyty podczas", "&8 » &fWydarzenia Wakacyjnego 2026&7!", "&7", "&8 » &7Zarzuć wędkę, aby wystawić &3Strażnika Głębin&7,", "&8 » &7który w promieniu &b6 kratek &7nakłada na wrogów", "&8 » &fzmęczenie kopania I&7.", "&7", "&8 » &7Strażnik trzyma się żyłki, więc musisz cały czas", "&8 » &7trzymać wędkę w ręce, inaczej efekt znika", "&8 » &7Da się go zabić, ale efekt trwa jeszcze &f3 sekundy&7.", "&7", "&8 » &7Na ciebie efekt nie działa!"), true, true, Disguise.Ability.GUARDIAN_ROD, (Disguise.Consumable)null);
      ILLUSIONIST_WAND = option(class_1802.field_8303, 1.0F, "&5&lRóżdżka iluzjonisty", List.of("&8 » &7Jest to przedmiot zdobyty podczas", "&8 » &fwydarzenia cyrkowego 2025&7!", "&7", "&8 » &7LPM: przywołuje &d3 fale Szczęk Evokera", "&8 » &7atakujące przeciwników na wprost.", "&7", "&8 » &7PPM: &dznikasz na &e4s &7i tworzysz", "&8 » &dklona &7biegnącego prosto przed siebie!"), false, true, Disguise.Ability.ILLUSIONIST_WAND, (Disguise.Consumable)null);
      PHANTOM_BLOCK = option(class_1802.field_8238, 0.0F, "&c&lBlok widmo", List.of("&8 » &7Jest to przedmiot zdobyty podczas", "&8 » &fDnia Dziecka 2025&7!", "&7", "&8 » &7Po postawieniu na ziemi,", "&8 » &7uwalnia &eenergię&7, która obniża", "&8 » &fmaksymalny limit &7serc pobliskim", "&8 » &7graczom na określony czas."), true, true, Disguise.Ability.PHANTOM_BLOCK, (Disguise.Consumable)null);
      MAGIC_LANTERN = option(class_1802.field_8668, 0.0F, "&d&lCudowna Latarnia", List.of("&8 » &7Przedmiot z &fświątecznego wydarzenia 2025&7!", "&7", "&8 » &7Po postawieniu otrzymujesz:", "&8 » &dRegeneracje V &8(20s)", "&8 » &eAbsorbcje VI &8(10s)", "&8 » &cSiłę II &8(10s)", "&7", "&8 » &7Fontanna pozostanie przez &f30 sekund&7.", "&8 » &7Efekty działają w zasięgu &f30 kratek&7.", "&8 » &7Zniszczenie fontanny usuwa efekty."), true, true, Disguise.Ability.MAGIC_LANTERN, (Disguise.Consumable)null);
      LOLLIPOP = option(class_1802.field_17500, 1.0F, "&d&lLizak", List.of("&8 » &7Jest to przedmiot zdobyty podczas", "&8 » &fDnia dziecka 2026&7!", "&7", "&8 » &7Trzymając go w ręce zyskujesz &fsiłe I&7,", "&8 » &7a Twoja postać &dzmniejsza się &7do", "&8 » &d0.65x &7swojego normalnego rozmiaru!"), false, true, Disguise.Ability.LOLLIPOP, (Disguise.Consumable)null);
      FLIGHTLESS_ROD = option(class_1802.field_8378, 2.0F, "&5&lWędka nielota", List.of("&8 » &7Wędka nielota była do zdobycia", "&8 » &7w &f2024 roku &7podczas &adnia dziecka&7.", "&r", "&8 » &7Po złapaniu gracza na haczyk", "&8 » &7nie może on odlecieć &delytrą&7!"), false, true, Disguise.Ability.FLIGHTLESS_ROD, (Disguise.Consumable)null);
      POISON_PENCIL = option(class_1802.field_27052, 14.0F, "&a&lZatruty ołówek", List.of("&8 » &7Jest to przedmiot zdobyty z", "&8 » &fwydarzenia szkolnego 2024&7!", "&r", "&8 » &7Po uderzeniu przeciwnika", "&8 » &7otrzymuje on &ctrujący efekt&7!"), false, true, Disguise.Ability.POISON_PENCIL, (Disguise.Consumable)null);
      CUPID_ROSE = option(class_1802.field_8880, 1.0F, "&c&lRóża kupidyna", List.of("&8 » &7Przedmiot zdobyty w &fwalentynki w 2026 roku&7!", "&8 » &7Trzymaj go w ręce aby otrzymać:", "&8  - &fEfekt odporności 1", "&8  - &fEfekt regeneracji 1", "&8  - &f+5 dodatkowych serc"), false, true, Disguise.Ability.CUPID_ROSE, (Disguise.Consumable)null);
      DRACULA_BACKPACK = option(class_1802.field_54316, 1.0F, "&c&lPlecak Drakuli", List.of("&8 » &7Przedmiot z &fwydarzenia halloween 2025&7!", "&7", "&8 » &7Otwiera przenośny &dplecak &7na &e5 slotów&7.", "&8 » &7Zawartość zapisywana jest w &dtym egzemplarzu&7.", "&8 » &7Edytowanie zawartości podczas &cwalki &7jest zablokowane.", "&8 » &7Przedmiot &anie traci się po śmierci&7."), false, true, Disguise.Ability.DRACULA_BACKPACK, (Disguise.Consumable)null);
      SCYTHE = option(class_1802.field_22026, 1.0F, "&8&lKosa", List.of("&8 » &7Jest to przedmiot z:", "&8 » &feventu halloween (2023)", "&r", "&8 » &7Twoje uderzenie może&f co minutę", "&8 » &7przestraszyć przeciwnika nadając", "&8 » &7mu efekty utrudniające widoczność."), true, true, Disguise.Ability.SCYTHE, (Disguise.Consumable)null);
      GRINCH_SHOVEL = option(class_1802.field_8250, 4572321.0F, "&a&lŁopata grincha", List.of("&8 » &7Jest to przedmiot z:", "&8 » &feventu świątecznego (2024)", "&r", "&8 » &7Po &auderzeniu &7przeciwnika", "&8 » &7zostaje on &cogłuszony&7 przez co", "&8 » &7rotacja zostaje wylosowana!"), true, true, Disguise.Ability.GRINCH_SHOVEL, (Disguise.Consumable)null);
      DIVINE_AXE = option(class_1802.field_8475, 3462232.0F, "&b&lBoski topór", List.of("&8 » &7Jest to przedmiot z:", "&8 » &fspecjalnego wydarzenia (2025)", "&r", "&8 » &7Po kliknięciu prawym przyciskiem", "&8 » &7aktywujesz &epotężną fale uderzeniową", "&8 » &7która zapewnia Tobie &cnieśmiertelność&7!"), true, true, Disguise.Ability.DIVINE_AXE, (Disguise.Consumable)null);
      ARCUS_MAGNUS = option(class_1802.field_8102, 5324.0F, "&a&lArcus Magnus", List.of("&8 » &7Jest to przedmiot z:", "&8 » &feventu halloween (2024)", "&r", "&8 » &7Łuk, który pozwala na", "&8 » &eniszczycielskie &7combo!", "&8 » &7Po trafieniu przeciwnika", "&8 » &7zadajesz mu &cogromne obrażenia&7, które", "&8 » &7zwiększają się z każdym trafieniem!"), false, true, Disguise.Ability.ARCUS_MAGNUS, (Disguise.Consumable)null);
      RUBIKS_CUBE = option(class_1802.field_8575, 0.0F, "&e&lKostka rubika", List.of("&8 » &7Kostka rubika była do zdobycia", "&8 » &7w &f2024 roku&7 podczas &adnia dziecka&7.", "&r", "&8 » &7Uderz gracza, aby jego ekwipunek", "&8 » &7został &fprzemieszany&7!"), false, true, Disguise.Ability.RUBIKS_CUBE, (Disguise.Consumable)null);
      ROD = option(class_1802.field_8600, 0.0F, "&8Rózga", List.of("&8 » &7Jest to przetmiot z:", "&8 » &feventu świąteczego (2023)", "&r", "&8 » &cOdrzuca &7z potęzną siłą", "&8 » &7niegrzecznych graczy!"), true, true, Disguise.Ability.NONE, (Disguise.Consumable)null);
   }
}
