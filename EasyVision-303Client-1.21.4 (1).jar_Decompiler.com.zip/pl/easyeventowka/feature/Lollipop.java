package pl.easyeventowka.feature;

import net.minecraft.class_1294;
import net.minecraft.class_1324;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_5134;
import net.minecraft.class_746;

public final class Lollipop {
   private static final double SCALE = 0.65;
   private static final int EFFECT_TICKS = 120;
   private static boolean shrunk;

   private Lollipop() {
   }

   public static void tick(class_310 client) {
      class_746 player = client.field_1724;
      if (player == null) {
         shrunk = false;
      } else {
         boolean holding = Disguise.hasAbility(player.method_6047(), Disguise.Ability.LOLLIPOP) || Disguise.hasAbility(player.method_6079(), Disguise.Ability.LOLLIPOP);
         if (holding) {
            setScale(player, 0.65);
            shrunk = true;
            FakeEffects.apply(class_1294.field_5910, 120, 0);
         } else if (shrunk) {
            setScale(player, (double)1.0F);
            shrunk = false;
            FakeEffects.remove(class_1294.field_5910);
         }
      }

   }

   private static void setScale(class_1657 player, double value) {
      class_1324 scale = player.method_5996(class_5134.field_47760);
      if (scale != null && scale.method_6201() != value) {
         scale.method_6192(value);
      }

   }
}
