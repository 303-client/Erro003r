package pl.easyeventowka.feature;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_2398;
import net.minecraft.class_310;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_1259.class_1260;
import net.minecraft.class_1259.class_1261;

public final class ArcusMagnus {
   private static final double[] DAMAGE = new double[]{(double)0.5F, (double)1.0F, (double)2.0F, (double)4.0F, (double)8.0F};
   private static final int COMBO_TICKS = 80;
   private static final double RANGE = (double)48.0F;
   private static final FakeBossBar BOSS_BAR;
   private static int stage;
   private static long comboEndsAtTick;
   private static final Map<UUID, Integer> lastHurt;

   private ArcusMagnus() {
   }

   public static void tick(class_310 client) {
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 var3 = client.field_1687;
         if (var3 instanceof class_638) {
            boolean var6 = Disguise.hasAbility(player.method_6047(), Disguise.Ability.ARCUS_MAGNUS);
            watchHits(var3, player, var6);
            if (comboEndsAtTick == 0L) {
               return;
            }

            long left = comboEndsAtTick - ClientClock.ticks();
            if (left <= 0L) {
               reset();
               return;
            }

            showBar(left);
            return;
         }
      }

      lastHurt.clear();
      reset();
   }

   private static void watchHits(class_638 world, class_746 player, boolean holding) {
      for(class_1657 target : world.method_18456()) {
         if (target != player) {
            UUID id = target.method_5667();
            int previous = (Integer)lastHurt.getOrDefault(id, 0);
            lastHurt.put(id, target.field_6235);
            if (target.field_6235 > previous && holding && !(target.method_5858(player) > (double)2304.0F)) {
               onHit(world, target);
            }
         }
      }

   }

   private static void onHit(class_638 world, class_1657 target) {
      boolean comboRunning = comboEndsAtTick > 0L && ClientClock.ticks() < comboEndsAtTick;
      stage = comboRunning ? Math.min(stage + 1, DAMAGE.length - 1) : 0;
      comboEndsAtTick = ClientClock.ticks() + 80L;
      spawnHearts(world, target, DAMAGE[stage]);
   }

   private static void spawnHearts(class_638 world, class_1657 target, double hearts) {
      int count = Math.max(1, (int)Math.round(hearts * (double)2.0F));

      for(int i = 0; i < count; ++i) {
         world.method_8406(class_2398.field_11209, target.method_23317() + (world.field_9229.method_43058() - (double)0.5F) * (double)target.method_17681(), target.method_23323((double)0.5F) + (world.field_9229.method_43058() - (double)0.5F) * 0.6, target.method_23321() + (world.field_9229.method_43058() - (double)0.5F) * (double)target.method_17681(), (world.field_9229.method_43058() - (double)0.5F) * 0.3, 0.1 + world.field_9229.method_43058() * 0.2, (world.field_9229.method_43058() - (double)0.5F) * 0.3);
      }

   }

   private static void showBar(long ticksLeft) {
      int millis = (int)(ticksLeft * 50L);
      String damage = trim(DAMAGE[Math.min(stage + 1, DAMAGE.length - 1)]);
      BOSS_BAR.show(LegacyText.parse("&aArcus Magnus &7ma aktywne &eCOMBO&7! Traf przeciwnika w czasie &a" + millis + "ms &7aby zadać mu &c" + damage + "❤"), (float)ticksLeft / 80.0F);
   }

   private static String trim(double value) {
      return value == Math.rint(value) ? String.valueOf((int)value) : String.valueOf(value);
   }

   private static void reset() {
      stage = 0;
      comboEndsAtTick = 0L;
      BOSS_BAR.hide();
   }

   static {
      BOSS_BAR = new FakeBossBar("arcus_magnus", class_1260.field_5784, class_1261.field_5795);
      lastHurt = new HashMap();
   }
}
