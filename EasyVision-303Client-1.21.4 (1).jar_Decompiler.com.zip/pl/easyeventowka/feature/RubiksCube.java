package pl.easyeventowka.feature;

import java.util.List;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class RubiksCube {
   private static final int COOLDOWN_TICKS = 1200;
   private static final int SCRAMBLE_TICKS = 30;
   private static final List<class_1792> SCRAMBLED;
   private static long readyAtTick;
   private static int used;
   private static class_1657 scrambled;
   private static class_1792 scrambledLook;
   private static long scrambleEndsAtTick;

   private RubiksCube() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236) {
            onClientAttack(entity);
         }

         return class_1269.field_5811;
      });
   }

   private static void onClientAttack(class_1297 target) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null && client.field_1687 != null && target instanceof class_1657 victim) {
         if (target != player) {
            class_1799 held = player.method_6047();
            if (!Disguise.hasAbility(held, Disguise.Ability.RUBIKS_CUBE)) {
               return;
            }

            long now = ClientClock.ticks();
            if (now < readyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(readyAtTick - now) / (double)20.0F));
               return;
            }

            readyAtTick = now + 1200L;
            player.method_7357().method_62835(held, 1200);
            ++used;
            scrambled = victim;
            scrambledLook = (class_1792)SCRAMBLED.get(client.field_1687.field_9229.method_43048(SCRAMBLED.size()));
            scrambleEndsAtTick = now + 30L;
            Titles.show(LegacyText.parse("&e&lKostka rubika"), LegacyText.parse("&fPrzemieszałeś ekwipunek gracza &6" + victim.method_5477().getString() + "&f!"));
            return;
         }
      }

   }

   public static void tick(class_310 client) {
      if (scrambled != null && (client.field_1687 == null || scrambled.method_31481() || ClientClock.ticks() >= scrambleEndsAtTick)) {
         scrambled = null;
         scrambledLook = null;
      }

   }

   public static class_1799 shownItem(class_1297 holder, class_1799 stack) {
      if (scrambled != null && holder == scrambled && scrambledLook != null) {
         if (stack.method_7960()) {
            return stack;
         } else {
            if (holder instanceof class_1309) {
               class_1309 living = (class_1309)holder;
               if (living.method_6047() == stack) {
                  return new class_1799(scrambledLook);
               }
            }

            return stack;
         }
      } else {
         return stack;
      }
   }

   static int shownCount(class_1799 stack) {
      int shown = stack.method_7947() - used;
      return shown > 1 ? shown : 0;
   }

   static {
      SCRAMBLED = List.of(class_1802.field_8831, class_1802.field_8803, class_1802.field_8179, class_1802.field_8606, class_1802.field_8777, class_1802.field_8323, class_1802.field_8621, class_1802.field_8317, class_1802.field_8600, class_1802.field_8511);
   }
}
