package pl.easyeventowka.feature;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import pl.easyeventowka.gui.NumberSetting;

public final class KrolicyMiecz {
   public static final FakeItemOption OPTION = new FakeItemOption(KrolicyMiecz::spec);
   private static NumberSetting damageSetting;

   private KrolicyMiecz() {
   }

   public static void bind(NumberSetting damage) {
      damageSetting = damage;
      FakeItemOption var10001 = OPTION;
      Objects.requireNonNull(var10001);
      Objects.requireNonNull(var10001);
      damage.onChange(var10001::refresh);
   }

   private static Disguise.Spec spec() {
      return new Disguise.Spec(class_1802.field_22022, LegacyText.parse("&3&lKróliczy miecz"), lore(), 2.0F, true, false, true, Disguise.Ability.RABBIT_SWORD, (Disguise.Consumable)null, 0);
   }

   private static List<class_2561> lore() {
      int damage = damageSetting == null ? 54 : (int)damageSetting.value;
      List<String> lines = new ArrayList(List.of("&7Enchantments", "   &6Sharpness VI", "   &6Fire Aspect II", DamageColor.line(damage), "&7", "&8 » &7Jest to przedmiot z &fwydarzenia", "&8 » &fwielkanocnego &7z &f2024 roku&7.", "&r", "&8 » &7Po uderzeniu przeciwnika blokuje", "&8 » &7możliwość skakania na &f4 sekundy&7!"));
      return lines.stream().map(LegacyText::parse).toList();
   }
}
