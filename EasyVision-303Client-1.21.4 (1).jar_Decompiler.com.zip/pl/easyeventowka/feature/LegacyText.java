package pl.easyeventowka.feature;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5250;

public final class LegacyText {
   private static final class_2583 BASE;

   private LegacyText() {
   }

   public static class_2561 parse(String legacy) {
      class_5250 result = class_2561.method_43473().method_10862(BASE);
      StringBuilder buffer = new StringBuilder();
      class_2583 style = BASE;

      for(int i = 0; i < legacy.length(); ++i) {
         char c = legacy.charAt(i);
         class_124 formatting = c == '&' && i + 1 < legacy.length() ? class_124.method_544(legacy.charAt(i + 1)) : null;
         if (formatting == null) {
            buffer.append(c);
         } else {
            if (!buffer.isEmpty()) {
               result.method_10852(class_2561.method_43470(buffer.toString()).method_10862(style));
               buffer.setLength(0);
            }

            style = apply(style, formatting);
            ++i;
         }
      }

      if (!buffer.isEmpty()) {
         result.method_10852(class_2561.method_43470(buffer.toString()).method_10862(style));
      }

      return result;
   }

   private static class_2583 apply(class_2583 style, class_124 formatting) {
      if (formatting == class_124.field_1070) {
         return BASE;
      } else {
         return formatting.method_543() ? BASE.method_10977(formatting) : style.method_27706(formatting);
      }
   }

   static {
      BASE = class_2583.field_24360.method_10978(false);
   }
}
