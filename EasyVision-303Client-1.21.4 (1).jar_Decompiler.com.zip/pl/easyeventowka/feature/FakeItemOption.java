package pl.easyeventowka.feature;

import java.util.function.Supplier;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;
import pl.easyeventowka.gui.Status;

public final class FakeItemOption {
   private final Supplier<Disguise.Spec> spec;
   private String fingerprint;

   public FakeItemOption(Supplier<Disguise.Spec> spec) {
      this.spec = spec;
   }

   public Disguise.Spec spec() {
      return (Disguise.Spec)this.spec.get();
   }

   public boolean enable() {
      class_746 player = class_310.method_1551().field_1724;
      if (player == null) {
         Status.error("Musisz być w grze.");
         return false;
      } else {
         class_1799 held = player.method_6047();
         if (held.method_7960()) {
            Status.error("Weź coś do ręki.");
            return false;
         } else {
            this.fingerprint = Disguise.fingerprint(held);
            Disguise.put(this.fingerprint, (Disguise.Spec)this.spec.get());
            Status.info("Gotowe — widzisz to tylko Ty.");
            return true;
         }
      }
   }

   public boolean disable() {
      if (this.fingerprint != null) {
         Disguise.remove(this.fingerprint);
         this.fingerprint = null;
      }

      Status.info("Wyłączone — item wygląda znowu normalnie.");
      return true;
   }

   public void refresh() {
      if (this.fingerprint != null) {
         Disguise.put(this.fingerprint, (Disguise.Spec)this.spec.get());
      }

   }
}
