package pl.easyeventowka.feature;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1921;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3414;
import net.minecraft.class_3417;
import net.minecraft.class_437;

public class BackpackScreen extends class_437 {
   private static final class_2960 TEXTURE = class_2960.method_60656("textures/gui/container/hopper.png");
   private static final int BACKGROUND_W = 176;
   private static final int BACKGROUND_H = 133;
   private static final int SLOTS = 5;
   private static final int SLOT = 18;
   private static final int ICON = 16;
   private static final int BACKPACK_X = 44;
   private static final int BACKPACK_Y = 20;
   private static final int INVENTORY_X = 8;
   private static final int INVENTORY_Y = 51;
   private static final int HOTBAR_Y = 109;
   private static final Map<String, List<class_1799>> CONTENTS = new HashMap();
   private final List<class_1799> slots;
   private class_1799 cursor;
   private int left;
   private int top;

   private BackpackScreen(List<class_1799> slots) {
      super(LegacyText.parse("&8Plecak Drakuli"));
      this.cursor = class_1799.field_8037;
      this.slots = slots;
   }

   public static void open(class_1799 stack) {
      List<class_1799> slots = (List)CONTENTS.computeIfAbsent(Disguise.fingerprint(stack), (key) -> {
         List<class_1799> empty = new ArrayList(5);

         for(int i = 0; i < 5; ++i) {
            empty.add(class_1799.field_8037);
         }

         return empty;
      });
      Titles.playSound(class_3417.field_17604, 0.45F, 1.15F);
      class_310.method_1551().method_1507(new BackpackScreen(slots));
   }

   protected void method_25426() {
      this.left = (this.field_22789 - 176) / 2;
      this.top = (this.field_22790 - 133) / 2;
   }

   private boolean isOver(int x, int y, double mouseX, double mouseY) {
      return mouseX >= (double)x && mouseX < (double)(x + 16) && mouseY >= (double)y && mouseY < (double)(y + 16);
   }

   private int backpackX(int index) {
      return this.left + 44 + index * 18;
   }

   private int backpackY() {
      return this.top + 20;
   }

   private int inventoryX(int index) {
      return this.left + 8 + index % 9 * 18;
   }

   private int inventoryY(int index) {
      return index < 27 ? this.top + 51 + index / 9 * 18 : this.top + 109;
   }

   private static int inventorySlot(int index) {
      return index < 27 ? index + 9 : index - 27;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      super.method_25394(context, mouseX, mouseY, delta);
      context.method_25290(class_1921::method_62277, TEXTURE, this.left, this.top, 0.0F, 0.0F, 176, 133, 256, 256);
      context.method_51439(this.field_22793, this.field_22785, this.left + 8, this.top + 6, 4210752, false);
      context.method_51439(this.field_22793, class_2561.method_43471("container.inventory"), this.left + 8, this.top + 133 - 94, 4210752, false);
      this.drawBackpack(context, mouseX, mouseY);
      this.drawPlayerInventory(context, mouseX, mouseY);
      this.drawHoverTooltip(context, mouseX, mouseY);
      if (!this.cursor.method_7960()) {
         context.method_51427(this.cursor, mouseX - 8, mouseY - 8);
         context.method_51431(this.field_22793, this.cursor, mouseX - 8, mouseY - 8);
      }

   }

   private void drawBackpack(class_332 context, int mouseX, int mouseY) {
      for(int i = 0; i < 5; ++i) {
         int x = this.backpackX(i);
         int y = this.backpackY();
         if (this.isOver(x, y, (double)mouseX, (double)mouseY)) {
            context.method_25294(x, y, x + 16, y + 16, -2130706433);
         }

         class_1799 stack = (class_1799)this.slots.get(i);
         if (!stack.method_7960()) {
            context.method_51427(stack, x, y);
            context.method_51431(this.field_22793, stack, x, y);
         }
      }

   }

   private void drawPlayerInventory(class_332 context, int mouseX, int mouseY) {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null) {
         class_1661 inventory = client.field_1724.method_31548();

         for(int i = 0; i < 36; ++i) {
            int x = this.inventoryX(i);
            int y = this.inventoryY(i);
            if (this.isOver(x, y, (double)mouseX, (double)mouseY)) {
               context.method_25294(x, y, x + 16, y + 16, -2130706433);
            }

            class_1799 stack = inventory.method_5438(inventorySlot(i));
            if (!stack.method_7960()) {
               context.method_51427(stack, x, y);
               context.method_51431(this.field_22793, stack, x, y);
            }
         }
      }

   }

   private void drawHoverTooltip(class_332 context, int mouseX, int mouseY) {
      if (this.cursor.method_7960()) {
         class_1799 hovered = this.stackUnder((double)mouseX, (double)mouseY);
         if (hovered != null && !hovered.method_7960()) {
            context.method_51446(this.field_22793, hovered, mouseX, mouseY);
         }
      }

   }

   private class_1799 stackUnder(double mouseX, double mouseY) {
      for(int i = 0; i < 5; ++i) {
         if (this.isOver(this.backpackX(i), this.backpackY(), mouseX, mouseY)) {
            return (class_1799)this.slots.get(i);
         }
      }

      class_310 client = class_310.method_1551();
      if (client.field_1724 == null) {
         return null;
      } else {
         for(int i = 0; i < 36; ++i) {
            if (this.isOver(this.inventoryX(i), this.inventoryY(i), mouseX, mouseY)) {
               return client.field_1724.method_31548().method_5438(inventorySlot(i));
            }
         }

         return null;
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      for(int i = 0; i < 5; ++i) {
         if (this.isOver(this.backpackX(i), this.backpackY(), mouseX, mouseY)) {
            class_1799 inSlot = (class_1799)this.slots.get(i);
            this.slots.set(i, this.cursor);
            this.cursor = inSlot;
            Titles.playSound((class_3414)class_3417.field_15015.comp_349(), 0.3F, 1.4F);
            return true;
         }
      }

      class_310 client = class_310.method_1551();
      if (client.field_1724 == null) {
         return super.method_25402(mouseX, mouseY, button);
      } else {
         for(int i = 0; i < 36; ++i) {
            if (this.isOver(this.inventoryX(i), this.inventoryY(i), mouseX, mouseY)) {
               this.cursor = this.cursor.method_7960() ? client.field_1724.method_31548().method_5438(inventorySlot(i)).method_7972() : class_1799.field_8037;
               Titles.playSound((class_3414)class_3417.field_15015.comp_349(), 0.3F, 1.4F);
               return true;
            }
         }

         return super.method_25402(mouseX, mouseY, button);
      }
   }

   public void method_25419() {
      this.cursor = class_1799.field_8037;
      Titles.playSound(class_3417.field_17603, 0.45F, 1.0F);
      super.method_25419();
   }

   public boolean method_25421() {
      return false;
   }
}
