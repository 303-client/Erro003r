package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_124;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1538;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_310;
import net.minecraft.class_3730;
import net.minecraft.class_5250;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class GrinchStrike {
   private static final int COOLDOWN_TICKS = 1200;
   private static long readyAtTick;
   private static int nextBoltId = -1;

   private GrinchStrike() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236) {
            onClientAttack(entity);
         }

         return class_1269.field_5811;
      });
   }

   private static void onClientAttack(class_1297 target) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 var4 = client.field_1687;
         if (var4 instanceof class_638) {
            if (target instanceof class_1309 && target != player) {
               class_1799 held = player.method_6047();
               if (!Disguise.hasAbility(held, Disguise.Ability.GRINCH_LIGHTNING)) {
                  return;
               }

               long now = ClientClock.ticks();
               if (now < readyAtTick) {
                  Titles.cooldown((int)Math.ceil((double)(readyAtTick - now) / (double)20.0F));
                  return;
               }

               readyAtTick = now + 1200L;
               player.method_7357().method_62835(held, 1200);
               strike(var4, target.method_23317(), target.method_23318(), target.method_23321());
               showHitMessage(target);
               return;
            }

            return;
         }
      }

   }

   private static void strike(class_638 world, double x, double y, double z) {
      class_1538 bolt = (class_1538)class_1299.field_6112.method_5883(world, class_3730.field_16461);
      if (bolt != null) {
         bolt.method_29498(true);
         bolt.method_5838(nextBoltId--);
         bolt.method_24203(x, y, z);
         world.method_53875(bolt);
      }

   }

   private static void showHitMessage(class_1297 target) {
      class_2583 white = class_2583.field_24360.method_10977(class_124.field_1068).method_10978(false);
      class_5250 message = class_2561.method_43473().method_10852(LegacyText.parse("&7Uderzyłeś ")).method_10852(class_2561.method_43473().method_10862(white).method_10852(target.method_5477())).method_10852(LegacyText.parse(" &7siekierą &agrincha&7!"));
      Titles.show(class_2561.method_43473(), message);
   }
}
