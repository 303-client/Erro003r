package pl.easyeventowka.feature;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class DivineAxe {
   private static final int COOLDOWN_TICKS = 1200;
   private static final double RADIUS = (double)5.0F;
   private static final double VERTICAL_BOOST = 0.2;
   private static final double MIN_FORCE = (double)1.0F;
   private static final double MAX_FORCE = (double)3.0F;
   private static final double FORCE_SCALE = 0.22;
   private static final double GRAVITY = 0.08;
   private static final double DRAG = 0.98;
   private static final double WALK_SPEED = 0.13;
   private static final int MAX_CONTROL_TICKS = 200;
   private static final double ARRIVED = 0.4;
   private static long readyAtTick;
   private static final Map<class_1657, Flight> PUSHED = new HashMap();

   private DivineAxe() {
   }

   public static boolean onRightClick(class_1799 stack) {
      class_310 client = class_310.method_1551();
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 var4 = client.field_1687;
         if (var4 instanceof class_638) {
            long now = ClientClock.ticks();
            if (now < readyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(readyAtTick - now) / (double)20.0F));
               return true;
            }

            readyAtTick = now + 1200L;
            player.method_7357().method_62835(stack, 1200);
            push(var4, player);
            Titles.playSound(class_3417.field_15024, 1.0F, 0.5F);
            Titles.show(class_2561.method_43473(), LegacyText.parse("&bAktywowałeś boski topór&7!"));
            return true;
         }
      }

      return true;
   }

   private static void push(class_638 world, class_746 player) {
      long releaseAt = ClientClock.ticks() + 200L;

      for(class_1657 target : world.method_18456()) {
         if (target != player) {
            class_243 away = target.method_19538().method_1020(player.method_19538());
            double distance = away.method_37267();
            if (!(distance > (double)5.0F) && !(distance < 0.01)) {
               double force = (double)3.0F - (double)2.0F * (distance / (double)5.0F);
               class_243 direction = (new class_243(away.field_1352, (double)0.0F, away.field_1350)).method_1029().method_1021(force * 0.22);
               PUSHED.put(target, new Flight(new class_243(direction.field_1352, force * 0.2, direction.field_1350), releaseAt));
            }
         }
      }

   }

   public static boolean controls(class_1657 player) {
      return PUSHED.containsKey(player);
   }

   public static void tickPushed(class_1657 target) {
      Flight flight = (Flight)PUSHED.get(target);
      if (flight != null) {
         if (ClientClock.ticks() < flight.releaseAtTick && !target.method_31481()) {
            if (flight.walking) {
               walkBack(target, flight);
            } else {
               fly(target, flight);
            }
         } else {
            PUSHED.remove(target);
         }
      }

   }

   private static void fly(class_1657 target, Flight flight) {
      flight.velocity = new class_243(flight.velocity.field_1352, (flight.velocity.field_1351 - 0.08) * 0.98, flight.velocity.field_1350);
      target.method_5784(class_1313.field_6308, flight.velocity);
      target.method_18799(flight.velocity);
      if (target.method_24828()) {
         flight.walking = true;
         flight.velocity = class_243.field_1353;
      }

   }

   private static void walkBack(class_1657 target, Flight flight) {
      class_243 home = target.method_43389().method_60933();
      class_243 step = home.method_1020(target.method_19538());
      if (step.method_37267() < 0.4) {
         PUSHED.remove(target);
      } else {
         class_243 walk = (new class_243(step.field_1352, (double)0.0F, step.field_1350)).method_1029().method_1021(0.13);
         double fall = target.method_24828() ? (double)0.0F : -0.08;
         target.method_5784(class_1313.field_6308, new class_243(walk.field_1352, fall, walk.field_1350));
         target.method_18800(walk.field_1352, fall, walk.field_1350);
         float yaw = (float)Math.toDegrees(Math.atan2(-walk.field_1352, walk.field_1350));
         target.method_36456(yaw);
         target.method_5636(yaw);
         target.method_5847(yaw);
      }

   }

   public static void tick(class_310 client) {
      if (client.field_1687 != null && !PUSHED.isEmpty()) {
         Iterator<class_1657> it = PUSHED.keySet().iterator();

         while(it.hasNext()) {
            if (((class_1657)it.next()).method_31481()) {
               it.remove();
            }
         }
      } else {
         PUSHED.clear();
      }

   }

   private static final class Flight {
      class_243 velocity;
      boolean walking;
      long releaseAtTick;

      Flight(class_243 velocity, long releaseAtTick) {
         this.velocity = velocity;
         this.releaseAtTick = releaseAtTick;
      }
   }
}
