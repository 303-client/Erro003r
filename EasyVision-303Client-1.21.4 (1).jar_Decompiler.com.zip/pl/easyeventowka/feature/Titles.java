package pl.easyeventowka.feature;

import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_3414;

final class Titles {
   private Titles() {
   }

   static void show(class_2561 title, class_2561 subtitle) {
      class_329 hud = class_310.method_1551().field_1705;
      hud.method_34001(2, 30, 8);
      hud.method_34002(subtitle);
      hud.method_34004(title);
   }

   static void cooldown(int secondsLeft) {
      show(LegacyText.parse("&cUmiejętność w odnowieniu"), LegacyText.parse("&7Do użycia za: &e" + secondsLeft + "s"));
   }

   static void actionBar(class_2561 message) {
      class_310.method_1551().field_1705.method_1758(message, false);
   }

   static void playSound(class_3414 sound, float volume, float pitch) {
      class_310.method_1551().method_1483().method_4873(class_1109.method_4757(sound, pitch, volume));
   }
}
