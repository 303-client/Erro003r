package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_746;

public final class GrinchShovel {
   private static final int COOLDOWN_TICKS = 1000;
   private static final int STUN_TICKS = 60;
   private static long readyAtTick;
   private static class_1309 twisted;
   private static long twistUntilTick;
   private static float twistYaw;
   private static float twistBodyYaw;
   private static float twistPitch;

   private GrinchShovel() {
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236) {
            onClientAttack(entity);
         }

         return class_1269.field_5811;
      });
   }

   private static void onClientAttack(class_1297 target) {
      class_746 player = class_310.method_1551().field_1724;
      if (player != null && target instanceof class_1309 && target != player) {
         class_1799 held = player.method_6047();
         if (Disguise.hasAbility(held, Disguise.Ability.GRINCH_SHOVEL)) {
            long now = ClientClock.ticks();
            if (now < readyAtTick) {
               Titles.cooldown((int)Math.ceil((double)(readyAtTick - now) / (double)20.0F));
            } else {
               readyAtTick = now + 1000L;
               player.method_7357().method_62835(held, 1000);
               twisted = (class_1309)target;
               twistUntilTick = now + 60L;
               twistYaw = target.method_59922().method_43057() * 360.0F;
               twistBodyYaw = target.method_59922().method_43057() * 360.0F;
               twistPitch = target.method_59922().method_43057() * 180.0F - 90.0F;
            }
         }
      }

   }

   public static void tick(class_310 client) {
      if (client.field_1724 != null && twisted != null) {
         if (ClientClock.ticks() < twistUntilTick && !twisted.method_31481()) {
            twisted.method_5847(twistYaw);
            twisted.method_5636(twistBodyYaw);
            twisted.method_36456(twistYaw);
            twisted.method_36457(twistPitch);
         } else {
            twisted = null;
         }
      }

   }
}
