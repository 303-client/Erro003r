package pl.easyeventowka.feature;

import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1536;
import net.minecraft.class_1577;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3417;
import net.minecraft.class_3730;
import net.minecraft.class_638;
import net.minecraft.class_746;

public final class GuardianRod {
   private static final int COOLDOWN_TICKS = 3600;
   private static final int LIFETIME_TICKS = 200;
   private static long readyAtTick;
   private static long despawnAtTick;
   private static class_1577 guardian;
   private static int nextVisualId = -2000;

   private GuardianRod() {
   }

   public static boolean blocksUse(class_1799 stack) {
      if (!Disguise.hasAbility(stack, Disguise.Ability.GUARDIAN_ROD)) {
         return false;
      } else {
         class_746 player = class_310.method_1551().field_1724;
         if (player != null && player.field_7513 == null) {
            long left = readyAtTick - ClientClock.ticks();
            if (left <= 0L) {
               return false;
            } else {
               Titles.cooldown((int)Math.ceil((double)left / (double)20.0F));
               return true;
            }
         } else {
            return false;
         }
      }
   }

   public static void register() {
      AttackEntityCallback.EVENT.register((AttackEntityCallback)(player, world, hand, entity, hitResult) -> {
         if (world.field_9236 && guardian != null && entity == guardian) {
            onKilled();
            return class_1269.field_5814;
         } else {
            return class_1269.field_5811;
         }
      });
   }

   public static void tick(class_310 client) {
      class_746 player = client.field_1724;
      if (player != null) {
         class_638 world = client.field_1687;
         if (world instanceof class_638) {
            if (guardian == null) {
               if (player.field_7513 != null && Disguise.hasAbility(player.method_6047(), Disguise.Ability.GUARDIAN_ROD) && ClientClock.ticks() >= readyAtTick) {
                  summon(world, player, player.field_7513);
               }

               return;
            }

            class_1536 bobber = player.field_7513;
            boolean stillHeld = Disguise.hasAbility(player.method_6047(), Disguise.Ability.GUARDIAN_ROD);
            if (bobber != null && stillHeld) {
               if (ClientClock.ticks() >= despawnAtTick) {
                  despawn();
                  return;
               }

               guardian.method_5814(bobber.method_23317(), bobber.method_23318(), bobber.method_23321());
               guardian.method_18799(class_243.field_1353);
               return;
            }

            Titles.show(class_2561.method_43473(), LegacyText.parse("&cStrażnik zerwał się z żyłki i zniknął!"));
            Titles.playSound(class_3417.field_15138, 0.8F, 1.2F);
            despawn();
            return;
         }
      }

      despawn();
   }

   private static void summon(class_638 world, class_746 player, class_1536 bobber) {
      class_1577 summoned = (class_1577)class_1299.field_6118.method_5883(world, class_3730.field_16461);
      if (summoned != null) {
         summoned.method_5838(nextVisualId--);
         summoned.method_5977(true);
         summoned.method_5875(true);
         summoned.method_5665(LegacyText.parse("&3&lStrażnik Głębin"));
         summoned.method_5880(true);
         summoned.method_6033(20.0F);
         summoned.method_5814(bobber.method_23317(), bobber.method_23318(), bobber.method_23321());
         world.method_53875(summoned);
         guardian = summoned;
         despawnAtTick = ClientClock.ticks() + 200L;
         readyAtTick = ClientClock.ticks() + 3600L;
         player.method_7357().method_62835(player.method_6047(), 3600);
         Titles.playSound(class_3417.field_14714, 1.0F, 1.0F);
      }

   }

   private static void onKilled() {
      guardian.method_5711((byte)2);
      Titles.playSound(class_3417.field_14679, 1.0F, 1.0F);
      Titles.show(class_2561.method_43473(), LegacyText.parse("&cStrażnik został zabity i zniknął!"));
      despawn();
   }

   private static void despawn() {
      if (guardian != null) {
         guardian.method_31472();
         guardian = null;
      }

   }

   public static boolean isOurs(class_1297 entity) {
      return guardian != null && entity == guardian;
   }
}
