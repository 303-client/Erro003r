package pl.easyeventowka.mixin;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1836;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_7417;
import net.minecraft.class_9331;
import net.minecraft.class_9334;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.easyeventowka.feature.Disguise;

@Mixin({class_1799.class})
public class ItemStackTooltipMixin {
   private static final String COMPONENT_COUNT_KEY = "item.components";

   @Inject(
      method = {"appendTooltip(Lnet/minecraft/component/ComponentType;Lnet/minecraft/item/Item$TooltipContext;Ljava/util/function/Consumer;Lnet/minecraft/item/tooltip/TooltipType;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$dropRealEnchantsAndLore(class_9331<?> type, class_1792.class_9635 context, Consumer<class_2561> consumer, class_1836 tooltipType, CallbackInfo ci) {
      if (Disguise.isDisguised((class_1799)this) && (type == class_9334.field_49633 || type == class_9334.field_49643 || type == class_9334.field_49632)) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"appendAttributeModifiersTooltip"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$dropAttributes(Consumer<class_2561> consumer, class_1657 player, CallbackInfo ci) {
      if (Disguise.hidesAttributes((class_1799)this)) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"getTooltip"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void easyeventowka$disguiseTooltip(CallbackInfoReturnable<List<class_2561>> cir) {
      class_1799 self = (class_1799)this;
      if (Disguise.isDisguised(self)) {
         List<class_2561> lines = (List)cir.getReturnValue();
         if (lines != null && !lines.isEmpty()) {
            String realId = Disguise.realItemId(self);
            List<class_2561> result = new ArrayList();

            for(int i = 0; i < lines.size(); ++i) {
               class_2561 line = (class_2561)lines.get(i);
               if (!realId.equals(line.getString()) && !isTranslatable(line, "item.components")) {
                  result.add(line);
                  if (i == 0) {
                     result.addAll(Disguise.lore(self));
                  }
               }
            }

            cir.setReturnValue(result);
         }
      }

   }

   private static boolean isTranslatable(class_2561 line, String key) {
      class_7417 var3 = line.method_10851();
      if (var3 instanceof class_2588 translatable) {
         if (key.equals(translatable.method_11022())) {
            boolean var10000 = true;
            return var10000;
         }
      }

      boolean var10000 = false;
      return var10000;
   }
}
