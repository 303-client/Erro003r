package pl.easyeventowka.mixin;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3966;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.easyeventowka.feature.BackpackScreen;
import pl.easyeventowka.feature.Disguise;
import pl.easyeventowka.feature.DivineAxe;
import pl.easyeventowka.feature.FakeConsumable;
import pl.easyeventowka.feature.GuardianRod;
import pl.easyeventowka.feature.HydroCage;
import pl.easyeventowka.feature.IllusionistWand;
import pl.easyeventowka.feature.PouchScreen;

@Mixin({class_636.class})
public class ClientPlayerInteractionManagerMixin {
   @Inject(
      method = {"interactItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$cancelItemUse(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      class_1799 stack = player.method_5998(hand);
      if (!FakeConsumable.blocksUse(stack) && !GuardianRod.blocksUse(stack)) {
         if (Disguise.hasAbility(stack, Disguise.Ability.DROP_POUCH)) {
            PouchScreen.open();
            cir.setReturnValue(class_1269.field_5812);
         } else if (Disguise.hasAbility(stack, Disguise.Ability.DRACULA_BACKPACK)) {
            BackpackScreen.open(stack);
            cir.setReturnValue(class_1269.field_5812);
         } else if (Disguise.hasAbility(stack, Disguise.Ability.HYDRO_CAGE) && HydroCage.tryShoot(stack)) {
            cir.setReturnValue(class_1269.field_21466);
         } else if (Disguise.hasAbility(stack, Disguise.Ability.ILLUSIONIST_WAND) && IllusionistWand.onRightClick(stack)) {
            cir.setReturnValue(class_1269.field_21466);
         } else if (Disguise.hasAbility(stack, Disguise.Ability.DIVINE_AXE) && DivineAxe.onRightClick(stack)) {
            cir.setReturnValue(class_1269.field_21466);
         } else if (Disguise.isDisguised(stack)) {
            cir.setReturnValue(class_1269.field_5811);
         }
      } else {
         cir.setReturnValue(class_1269.field_5814);
      }

   }

   @Inject(
      method = {"interactEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$cancelEntityUse(class_1657 player, class_1297 entity, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      if (Disguise.isDisguised(player.method_5998(hand))) {
         cir.setReturnValue(class_1269.field_5811);
      }

   }

   @Inject(
      method = {"interactEntityAtLocation"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$cancelEntityUseAt(class_1657 player, class_1297 entity, class_3966 hitResult, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      if (Disguise.isDisguised(player.method_5998(hand))) {
         cir.setReturnValue(class_1269.field_5811);
      }

   }
}
