package pl.easyeventowka.mixin;

import net.minecraft.class_1657;
import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.easyeventowka.feature.IllusionistWand;

@Mixin({class_742.class})
public class AbstractClientPlayerEntitySkinMixin {
   @Inject(
      method = {"getSkinTextures"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$cloneWearsMySkin(CallbackInfoReturnable<class_8685> cir) {
      if (IllusionistWand.isClone((class_742)this)) {
         class_1657 source = IllusionistWand.cloneSkinSource();
         if (source instanceof class_742) {
            class_742 dressed = (class_742)source;
            cir.setReturnValue(dressed.method_52814());
         }
      }

   }
}
