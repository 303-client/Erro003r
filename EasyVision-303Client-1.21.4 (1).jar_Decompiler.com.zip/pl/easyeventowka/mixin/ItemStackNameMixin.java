package pl.easyeventowka.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.easyeventowka.feature.Disguise;

@Mixin({class_1799.class})
public class ItemStackNameMixin {
   @Inject(
      method = {"getFormattedName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$disguiseFormattedName(CallbackInfoReturnable<class_2561> cir) {
      class_2561 name = Disguise.name((class_1799)this);
      if (name != null) {
         cir.setReturnValue(name);
      }

   }

   @Inject(
      method = {"getName"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$disguiseName(CallbackInfoReturnable<class_2561> cir) {
      class_2561 name = Disguise.name((class_1799)this);
      if (name != null) {
         cir.setReturnValue(name);
      }

   }
}
