package pl.easyeventowka.mixin;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.easyeventowka.feature.FakeConsumable;

@Mixin({class_1309.class})
public class LivingEntityConsumeMixin {
   @Inject(
      method = {"consumeItem"},
      at = {@At("HEAD")}
   )
   private void easyeventowka$fakeConsumableEaten(CallbackInfo ci) {
      FakeConsumable.onConsume((class_1309)this);
   }
}
