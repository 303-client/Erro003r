package pl.easyeventowka.mixin;

import net.minecraft.class_10442;
import net.minecraft.class_10444;
import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.easyeventowka.feature.Disguise;
import pl.easyeventowka.feature.RubiksCube;

@Mixin({class_10442.class})
public class ItemModelManagerMixin {
   @Unique
   private boolean easyeventowka$swapping;

   @ModifyVariable(
      method = {"update(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;Lnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;I)V"},
      at = {@At("HEAD")},
      argsOnly = true
   )
   private class_1799 easyeventowka$disguiseUpdate(class_1799 stack) {
      return Disguise.model(stack);
   }

   @ModifyVariable(
      method = {"update(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/world/World;Lnet/minecraft/entity/LivingEntity;I)V"},
      at = {@At("HEAD")},
      argsOnly = true
   )
   private class_1799 easyeventowka$disguiseUpdateBool(class_1799 stack) {
      return Disguise.model(stack);
   }

   @Inject(
      method = {"updateForLivingEntity(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/entity/LivingEntity;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$scrambledItem(class_10444 state, class_1799 stack, class_811 mode, boolean bl, class_1309 entity, CallbackInfo ci) {
      if (!this.easyeventowka$swapping && entity != null) {
         class_1799 swapped = RubiksCube.shownItem(entity, stack);
         if (swapped != stack) {
            this.easyeventowka$swapping = true;

            try {
               ((class_10442)this).method_65597(state, swapped, mode, bl, entity);
            } finally {
               this.easyeventowka$swapping = false;
            }

            ci.cancel();
         }
      }

   }

   @ModifyVariable(
      method = {"updateForLivingEntity(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;ZLnet/minecraft/entity/LivingEntity;)V"},
      at = {@At("HEAD")},
      argsOnly = true
   )
   private class_1799 easyeventowka$disguiseLiving(class_1799 stack) {
      return Disguise.model(stack);
   }

   @ModifyVariable(
      method = {"updateForNonLivingEntity(Lnet/minecraft/client/render/item/ItemRenderState;Lnet/minecraft/item/ItemStack;Lnet/minecraft/item/ModelTransformationMode;Lnet/minecraft/entity/Entity;)V"},
      at = {@At("HEAD")},
      argsOnly = true
   )
   private class_1799 easyeventowka$disguiseNonLiving(class_1799 stack) {
      return Disguise.model(stack);
   }
}
