package pl.easyeventowka.mixin;

import net.minecraft.class_745;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.easyeventowka.feature.DivineAxe;
import pl.easyeventowka.feature.IllusionistWand;

@Mixin({class_745.class})
public class OtherClientPlayerEntityCloneMixin {
   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void easyeventowka$moveClone(CallbackInfo ci) {
      class_745 self = (class_745)this;
      IllusionistWand.tickCloneMovement(self);
      DivineAxe.tickPushed(self);
   }

   @Inject(
      method = {"tickMovement"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$holdPushed(CallbackInfo ci) {
      if (DivineAxe.controls((class_745)this)) {
         ci.cancel();
      }

   }
}
