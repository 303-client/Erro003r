package pl.easyeventowka.mixin;

import net.minecraft.class_1799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import pl.easyeventowka.feature.Disguise;

@Mixin({class_1799.class})
public class ItemStackBarMixin {
   @Inject(
      method = {"isDamaged"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$hideDamage(CallbackInfoReturnable<Boolean> cir) {
      if (Disguise.hidesDurability((class_1799)this)) {
         cir.setReturnValue(false);
      }

   }

   @Inject(
      method = {"isItemBarVisible"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$hideItemBar(CallbackInfoReturnable<Boolean> cir) {
      if (Disguise.hidesDurability((class_1799)this)) {
         cir.setReturnValue(false);
      }

   }
}
