package pl.easyeventowka.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_327;
import net.minecraft.class_332;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import pl.easyeventowka.feature.Disguise;

@Mixin({class_332.class})
public class DrawContextCountMixin {
   @Inject(
      method = {"drawStackOverlay(Lnet/minecraft/client/font/TextRenderer;Lnet/minecraft/item/ItemStack;IILjava/lang/String;)V"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void easyeventowka$disguisedCount(class_327 textRenderer, class_1799 stack, int x, int y, String countLabel, CallbackInfo ci) {
      if (countLabel == null) {
         int count = Disguise.displayCount(stack);
         if (count > 0) {
            ((class_332)this).method_51432(textRenderer, stack, x, y, String.valueOf(count));
            ci.cancel();
         }
      }

   }
}
