package pl.easyeventowka;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.fabricmc.fabric.api.event.player.AttackBlockCallback;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675.class_307;
import pl.easyeventowka.config.ConfigManager;
import pl.easyeventowka.feature.ArcusMagnus;
import pl.easyeventowka.feature.ClientClock;
import pl.easyeventowka.feature.CupidRose;
import pl.easyeventowka.feature.Disguise;
import pl.easyeventowka.feature.DivineAxe;
import pl.easyeventowka.feature.DroppedItemLabels;
import pl.easyeventowka.feature.FakeEffects;
import pl.easyeventowka.feature.FlightlessRod;
import pl.easyeventowka.feature.GrinchShovel;
import pl.easyeventowka.feature.GrinchStrike;
import pl.easyeventowka.feature.GuardianRod;
import pl.easyeventowka.feature.HydroCage;
import pl.easyeventowka.feature.IllusionistWand;
import pl.easyeventowka.feature.Lollipop;
import pl.easyeventowka.feature.MagicLantern;
import pl.easyeventowka.feature.PhantomBlock;
import pl.easyeventowka.feature.PoisonPencil;
import pl.easyeventowka.feature.Presets;
import pl.easyeventowka.feature.RabbitSword;
import pl.easyeventowka.feature.RubiksCube;
import pl.easyeventowka.feature.Scythe;
import pl.easyeventowka.gui.EventScreen;
import pl.easyeventowka.gui.Panels;

public class EasyEventowkaClient implements ClientModInitializer {
   public static final String MOD_ID = "easyeventowka";
   public static class_304 openMenuKey;

   public void onInitializeClient() {
      Panels.init();
      Presets.init();
      ConfigManager.load();
      openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304("key.easyeventowka.open_menu", class_307.field_1668, 78, "category.easyeventowka"));
      registerHitAbilities();
      ClientTickEvents.END_CLIENT_TICK.register((ClientTickEvents.EndTick)(client) -> {
         ClientClock.tick();

         while(openMenuKey.method_1436()) {
            if (client.field_1755 == null) {
               client.method_1507(new EventScreen());
            }
         }

         FakeEffects.tick(client);
         HydroCage.tick(client);
         MagicLantern.tick(client);
         PhantomBlock.tick(client);
         IllusionistWand.tick(client);
         GuardianRod.tick(client);
         Lollipop.tick(client);
         CupidRose.tick(client);
         ArcusMagnus.tick(client);
         RubiksCube.tick(client);
         FlightlessRod.tick(client);
         GrinchShovel.tick(client);
         DivineAxe.tick(client);
      });
      WorldRenderEvents.AFTER_ENTITIES.register(DroppedItemLabels::render);
      registerBlockInteractions();
   }

   private static void registerHitAbilities() {
      GrinchStrike.register();
      GuardianRod.register();
      PoisonPencil.register();
      Scythe.register();
      GrinchShovel.register();
      RubiksCube.register();
      RabbitSword.register();
   }

   private static void registerBlockInteractions() {
      AttackBlockCallback.EVENT.register((AttackBlockCallback)(player, world, hand, pos, direction) -> {
         if (!world.field_9236) {
            return class_1269.field_5811;
         } else if (HydroCage.isCageBlock(pos)) {
            HydroCage.warnBreak(class_310.method_1551().field_1724);
            return class_1269.field_5814;
         } else if (MagicLantern.isFountain(pos)) {
            MagicLantern.mine(player, pos, direction);
            return class_1269.field_5814;
         } else {
            return class_1269.field_5811;
         }
      });
      UseBlockCallback.EVENT.register((UseBlockCallback)(player, world, hand, hitResult) -> {
         if (!world.field_9236) {
            return class_1269.field_5811;
         } else if (HydroCage.isInsideCage(hitResult.method_17777())) {
            HydroCage.warnPlace();
            return class_1269.field_5814;
         } else {
            class_1799 stack = player.method_5998(hand);
            class_2338 against = hitResult.method_17777().method_10093(hitResult.method_17780());
            if (Disguise.hasAbility(stack, Disguise.Ability.PHANTOM_BLOCK) && PhantomBlock.onUse(stack, against)) {
               return class_1269.field_5814;
            } else if (Disguise.hasAbility(stack, Disguise.Ability.ILLUSIONIST_WAND) && IllusionistWand.onRightClick(stack)) {
               return class_1269.field_5814;
            } else {
               return (class_1269)(Disguise.hasAbility(stack, Disguise.Ability.MAGIC_LANTERN) && MagicLantern.onPlaced(stack, against) ? class_1269.field_5814 : (class_1269)(Disguise.blocksPlacing(stack, world, hitResult.method_17777()) ? class_1269.field_5814 : class_1269.field_5811));
            }
         }
      });
   }
}
