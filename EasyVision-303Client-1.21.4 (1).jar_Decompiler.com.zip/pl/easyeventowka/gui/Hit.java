package pl.easyeventowka.gui;

public record Hit(Category category, ModOption option, Setting setting, boolean header) {
}
