package pl.easyeventowka.gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ModeSetting extends Setting {
   public final List<String> modes;
   public int index;

   public ModeSetting(String id, String name, List<String> modes, int index) {
      super(id, name);
      this.modes = List.copyOf(modes);
      this.index = index;
   }

   public String getMode() {
      return (String)this.modes.get(this.index);
   }

   public int getHeight() {
      return 13;
   }

   public void render(class_332 ctx, class_327 tr, int x, int y, int width, boolean hovered) {
      this.drawFrame(ctx, x, y, width, hovered);
      ctx.method_51433(tr, this.name, x + 15, y + 3, -8090209, false);
      String mode = this.getMode();
      ctx.method_51433(tr, mode, x + width - 9 - tr.method_1727(mode), y + 3, -11760129, false);
   }

   public void click(double mouseX, int button) {
      if (button == 1) {
         this.index = (this.index - 1 + this.modes.size()) % this.modes.size();
      } else {
         this.index = (this.index + 1) % this.modes.size();
      }

      this.changed();
   }

   public JsonElement save() {
      return new JsonPrimitive(this.index);
   }

   public void load(JsonElement el) {
      if (el != null && el.isJsonPrimitive()) {
         int i = el.getAsInt();
         if (i >= 0 && i < this.modes.size()) {
            this.index = i;
         }
      }

   }
}
