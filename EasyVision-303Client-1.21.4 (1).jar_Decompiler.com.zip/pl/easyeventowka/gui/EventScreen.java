package pl.easyeventowka.gui;

import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import pl.easyeventowka.EasyEventowkaClient;
import pl.easyeventowka.config.ConfigManager;

public class EventScreen extends class_437 {
   private static final String HINT = "LPM - włącz/wyłącz   PPM - ustawienia   nagłówek - przeciągnij";
   private Category dragged;
   private int dragOffsetX;
   private int dragOffsetY;
   private double pressX;
   private double pressY;
   private boolean moved;
   private NumberSetting activeSlider;

   public EventScreen() {
      super(class_2561.method_43470("EasyEventówka"));
   }

   public boolean method_25421() {
      return false;
   }

   protected void method_25426() {
      for(Category c : Panels.CATEGORIES) {
         c.clampTo(this.field_22789, this.field_22790);
      }

   }

   public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
      super.method_25394(ctx, mouseX, mouseY, delta);

      for(Category c : Panels.CATEGORIES) {
         c.render(ctx, this.field_22793, mouseX, mouseY, c == this.dragged);
      }

      String status = Status.current();
      if (status != null) {
         int statusWidth = this.field_22793.method_1727(status);
         ctx.method_51433(this.field_22793, status, (this.field_22789 - statusWidth) / 2, this.field_22790 - 27, Status.color(), true);
      }

      int hintWidth = this.field_22793.method_1727("LPM - włącz/wyłącz   PPM - ustawienia   nagłówek - przeciągnij");
      ctx.method_51433(this.field_22793, "LPM - włącz/wyłącz   PPM - ustawienia   nagłówek - przeciągnij", (this.field_22789 - hintWidth) / 2, this.field_22790 - 14, -8090209, true);
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      List<Category> categories = Panels.CATEGORIES;

      for(int i = categories.size() - 1; i >= 0; --i) {
         Category category = (Category)categories.get(i);
         Hit hit = category.hit(mouseX, mouseY);
         if (hit != null) {
            categories.remove(i);
            categories.add(category);
            if (hit.header()) {
               if (button == 0) {
                  this.dragged = category;
                  this.dragOffsetX = (int)Math.round(mouseX - (double)category.x);
                  this.dragOffsetY = (int)Math.round(mouseY - (double)category.y);
                  this.pressX = mouseX;
                  this.pressY = mouseY;
                  this.moved = false;
               } else if (button == 1) {
                  category.expanded = !category.expanded;
                  category.clampTo(this.field_22789, this.field_22790);
               }

               return true;
            }

            if (hit.setting() != null) {
               hit.setting().click(mouseX, button);
               if (button == 0) {
                  Setting var11 = hit.setting();
                  if (var11 instanceof NumberSetting) {
                     NumberSetting number = (NumberSetting)var11;
                     this.activeSlider = number;
                  }
               }

               return true;
            }

            if (hit.option() != null) {
               if (button == 0) {
                  hit.option().toggle();
               } else if (button == 1) {
                  hit.option().settingsOpen = !hit.option().settingsOpen;
                  category.clampTo(this.field_22789, this.field_22790);
               }

               return true;
            }

            return true;
         }
      }

      return super.method_25402(mouseX, mouseY, button);
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (this.dragged != null && button == 0) {
         if (Math.abs(mouseX - this.pressX) > (double)2.0F || Math.abs(mouseY - this.pressY) > (double)2.0F) {
            this.moved = true;
         }

         this.dragged.x = (int)Math.round(mouseX - (double)this.dragOffsetX);
         this.dragged.y = (int)Math.round(mouseY - (double)this.dragOffsetY);
         this.dragged.clampTo(this.field_22789, this.field_22790);
         return true;
      } else if (this.activeSlider != null) {
         this.activeSlider.setFromMouse(mouseX);
         return true;
      } else {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      if (this.dragged != null && button == 0) {
         if (!this.moved) {
            this.dragged.expanded = !this.dragged.expanded;
            this.dragged.clampTo(this.field_22789, this.field_22790);
         }

         this.dragged = null;
         return true;
      } else if (this.activeSlider != null) {
         this.activeSlider = null;
         return true;
      } else {
         return super.method_25406(mouseX, mouseY, button);
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
      List<Category> categories = Panels.CATEGORIES;

      for(int i = categories.size() - 1; i >= 0; --i) {
         Hit hit = ((Category)categories.get(i)).hit(mouseX, mouseY);
         if (hit != null) {
            Setting var13 = hit.setting();
            if (var13 instanceof NumberSetting) {
               NumberSetting number = (NumberSetting)var13;
               number.scroll(verticalAmount);
               return true;
            }
         }
      }

      return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (EasyEventowkaClient.openMenuKey != null && EasyEventowkaClient.openMenuKey.method_1417(keyCode, scanCode)) {
         this.method_25419();
         return true;
      } else {
         return super.method_25404(keyCode, scanCode, modifiers);
      }
   }

   public void method_25432() {
      ConfigManager.save();
      super.method_25432();
   }
}
