package pl.easyeventowka.gui;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class ModOption {
   public static final int HEIGHT = 18;
   public final String id;
   public final String name;
   public final List<Setting> settings = new ArrayList();
   public boolean enabled;
   public boolean settingsOpen;
   private ToggleHandler toggleHandler;

   public ModOption(String id, String name) {
      this.id = id;
      this.name = name;
   }

   public ModOption with(Setting setting) {
      this.settings.add(setting);
      return this;
   }

   public ModOption onToggle(ToggleHandler handler) {
      this.toggleHandler = handler;
      return this;
   }

   public void toggle() {
      boolean target = !this.enabled;
      if (this.toggleHandler == null || this.toggleHandler.onToggle(target)) {
         this.enabled = target;
      }

   }

   public int totalHeight() {
      int h = 18;
      if (this.settingsOpen) {
         for(Setting s : this.settings) {
            h += s.getHeight();
         }
      }

      return h;
   }

   public int render(class_332 ctx, class_327 tr, int x, int y, int width, int mouseX, int mouseY) {
      boolean hovered = inside((double)mouseX, (double)mouseY, x, y, width, 18);
      ctx.method_25294(x, y, x + width, y + 18, hovered ? -534829518 : -535554015);
      ctx.method_51433(tr, this.name, x + 10, y + 5, this.enabled ? -1643790 : -8090209, false);
      int pillW = 16;
      int pillH = 8;
      int px = x + width - pillW - 10;
      int py = y + (18 - pillH) / 2;
      ctx.method_25294(px, py, px + pillW, py + pillH, this.enabled ? -13934664 : -13288632);
      int knobX = this.enabled ? px + pillW - 7 : px + 1;
      ctx.method_25294(knobX, py + 1, knobX + 6, py + pillH - 1, this.enabled ? -11760129 : -6774350);
      if (!this.settings.isEmpty()) {
         String arrow = this.settingsOpen ? "v" : ">";
         ctx.method_51433(tr, arrow, px - 11, y + 5, this.settingsOpen ? -11760129 : -8090209, false);
      }

      int cy = y + 18;
      if (this.settingsOpen) {
         for(Setting s : this.settings) {
            s.render(ctx, tr, x, cy, width, inside((double)mouseX, (double)mouseY, x, cy, width, s.getHeight()));
            cy += s.getHeight();
         }
      }

      return cy;
   }

   static boolean inside(double mx, double my, int x, int y, int w, int h) {
      return mx >= (double)x && mx < (double)(x + w) && my >= (double)y && my < (double)(y + h);
   }

   @FunctionalInterface
   public interface ToggleHandler {
      boolean onToggle(boolean var1);
   }
}
