package pl.easyeventowka.gui;

import java.util.ArrayList;
import java.util.List;
import pl.easyeventowka.feature.Excalibur;
import pl.easyeventowka.feature.FakeItemOption;
import pl.easyeventowka.feature.Hydroklatka;
import pl.easyeventowka.feature.KrolicyMiecz;
import pl.easyeventowka.feature.Presets;
import pl.easyeventowka.feature.TotemUlaskawienia;

public final class Panels {
   public static final List<Category> CATEGORIES = new ArrayList();

   private Panels() {
   }

   public static void init() {
      CATEGORIES.clear();
      Category fake = new Category("fakeeventowka", "FakeEventówka", 20, 20);
      fake.with(simple("totem_ulaskawienia", "Totem Ułaskawienia", TotemUlaskawienia.OPTION));
      fake.with(excalibur());
      fake.with(krolicyMiecz());
      fake.with(simple("hydroklatka", "Hydroklatka", Hydroklatka.OPTION));
      fake.with(simple("siekiera_grincha", "Siekiera Grincha", Presets.GRINCH_AXE));
      fake.with(simple("sakiewka_dropu", "Sakiewka dropu", Presets.DROP_POUCH));
      fake.with(simple("wampirze_jablko", "Wampirze Jabłko", Presets.VAMPIRE_APPLE_ITEM));
      fake.with(simple("wedka_guardiana", "Wędka Guardiana", Presets.GUARDIAN_ROD));
      fake.with(simple("rozdzka_iluzjonisty", "Różdżka Iluzjonisty", Presets.ILLUSIONIST_WAND));
      fake.with(simple("blok_widmo", "Blok Widmo", Presets.PHANTOM_BLOCK));
      fake.with(simple("cudowna_latarnia", "Cudowna Latarnia", Presets.MAGIC_LANTERN));
      fake.with(simple("lizak", "Lizak", Presets.LOLLIPOP));
      fake.with(simple("wedka_nielota", "Wędka nielota", Presets.FLIGHTLESS_ROD));
      fake.with(simple("zatruty_olowek", "Zatruty ołówek", Presets.POISON_PENCIL));
      fake.with(simple("roza_kupidyna", "Róża kupidyna", Presets.CUPID_ROSE));
      fake.with(simple("plecak_drakuli", "Plecak Drakuli", Presets.DRACULA_BACKPACK));
      fake.with(simple("kosa", "Kosa", Presets.SCYTHE));
      fake.with(simple("lopata_grincha", "Łopata Grincha", Presets.GRINCH_SHOVEL));
      fake.with(simple("boski_topor", "Boski topór", Presets.DIVINE_AXE));
      fake.with(simple("arcus_magnus", "Arcus Magnus", Presets.ARCUS_MAGNUS));
      fake.with(simple("kostka_rubika", "Kostka rubika", Presets.RUBIKS_CUBE));
      fake.with(simple("rozga", "Rózga", Presets.ROD));
      CATEGORIES.add(fake);
   }

   private static ModOption simple(String id, String name, FakeItemOption option) {
      return (new ModOption(id, name)).onToggle((enabled) -> enabled ? option.enable() : option.disable());
   }

   private static ModOption excalibur() {
      NumberSetting damage = new NumberSetting("obrazenia", "Dodatkowe obrażenia", (double)51.0F, (double)-10.0F, (double)100.0F, (double)1.0F, "%");
      NumberSetting kills = new NumberSetting("zabojstwa", "Zabójstwa", (double)9.0F, (double)0.0F, (double)1000.0F, (double)1.0F, "");
      Excalibur.bind(damage, kills);
      return (new ModOption("excalibur", "Excalibur")).with(damage).with(kills).onToggle((enabled) -> enabled ? Excalibur.OPTION.enable() : Excalibur.OPTION.disable());
   }

   private static ModOption krolicyMiecz() {
      NumberSetting damage = new NumberSetting("obrazenia", "Dodatkowe obrażenia", (double)54.0F, (double)-10.0F, (double)100.0F, (double)1.0F, "%");
      KrolicyMiecz.bind(damage);
      return (new ModOption("kroliczy_miecz", "Króliczy miecz")).with(damage).onToggle((enabled) -> enabled ? KrolicyMiecz.OPTION.enable() : KrolicyMiecz.OPTION.disable());
   }

   public static Category byId(String id) {
      for(Category c : CATEGORIES) {
         if (c.id.equals(id)) {
            return c;
         }
      }

      return null;
   }

   public static ModOption optionById(String categoryId, String optionId) {
      Category category = byId(categoryId);
      if (category == null) {
         return null;
      } else {
         for(ModOption option : category.options) {
            if (option.id.equals(optionId)) {
               return option;
            }
         }

         return null;
      }
   }
}
