package pl.easyeventowka.gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class BooleanSetting extends Setting {
   public boolean value;

   public BooleanSetting(String id, String name, boolean value) {
      super(id, name);
      this.value = value;
   }

   public int getHeight() {
      return 13;
   }

   public void render(class_332 ctx, class_327 tr, int x, int y, int width, boolean hovered) {
      this.drawFrame(ctx, x, y, width, hovered);
      ctx.method_51433(tr, this.name, x + 15, y + 3, this.value ? -1643790 : -8090209, false);
      int box = 7;
      int bx = x + width - box - 9;
      int by = y + (this.getHeight() - box) / 2;
      ctx.method_25294(bx, by, bx + box, by + box, this.value ? -11760129 : -13288632);
      ctx.method_49601(bx, by, box, box, -13946302);
   }

   public void click(double mouseX, int button) {
      this.value = !this.value;
      this.changed();
   }

   public JsonElement save() {
      return new JsonPrimitive(this.value);
   }

   public void load(JsonElement el) {
      if (el != null && el.isJsonPrimitive()) {
         this.value = el.getAsBoolean();
      }

   }
}
