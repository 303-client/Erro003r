package pl.easyeventowka.gui;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;
import net.minecraft.class_327;
import net.minecraft.class_332;

public class NumberSetting extends Setting {
   public final double min;
   public final double max;
   public final double step;
   public final String suffix;
   public double value;
   private int barX;
   private int barWidth = 1;

   public NumberSetting(String id, String name, double value, double min, double max, double step, String suffix) {
      super(id, name);
      this.min = min;
      this.max = max;
      this.step = step;
      this.suffix = suffix;
      this.value = this.clamp(value);
   }

   public int getHeight() {
      return 21;
   }

   public void render(class_332 ctx, class_327 tr, int x, int y, int width, boolean hovered) {
      this.drawFrame(ctx, x, y, width, hovered);
      ctx.method_51433(tr, this.name, x + 15, y + 3, -8090209, false);
      String var10000 = this.format(this.value);
      String label = var10000 + this.suffix;
      ctx.method_51433(tr, label, x + width - 9 - tr.method_1727(label), y + 3, -1643790, false);
      this.barX = x + 15;
      this.barWidth = width - 24;
      int barY = y + 14;
      ctx.method_25294(this.barX, barY, this.barX + this.barWidth, barY + 3, -13288632);
      int filled = (int)Math.round((this.value - this.min) / (this.max - this.min) * (double)this.barWidth);
      ctx.method_25294(this.barX, barY, this.barX + filled, barY + 3, -11760129);
      int knob = this.barX + Math.min(this.barWidth - 2, Math.max(0, filled - 1));
      ctx.method_25294(knob, barY - 2, knob + 3, barY + 5, -1643790);
   }

   public void click(double mouseX, int button) {
      this.setFromMouse(mouseX);
   }

   public void setFromMouse(double mouseX) {
      double pct = (mouseX - (double)this.barX) / (double)this.barWidth;
      pct = Math.max((double)0.0F, Math.min((double)1.0F, pct));
      double raw = this.min + pct * (this.max - this.min);
      this.value = this.clamp((double)Math.round(raw / this.step) * this.step);
      this.changed();
   }

   public void scroll(double amount) {
      double next = this.clamp(this.value + Math.signum(amount) * this.step);
      if (next != this.value) {
         this.value = next;
         this.changed();
      }

   }

   private double clamp(double v) {
      double c = Math.max(this.min, Math.min(this.max, v));
      return BigDecimal.valueOf(c).setScale(3, RoundingMode.HALF_UP).doubleValue();
   }

   private String format(double v) {
      return this.step >= (double)1.0F && v == Math.rint(v) ? String.valueOf((long)v) : String.format(Locale.ROOT, "%.1f", v);
   }

   public JsonElement save() {
      return new JsonPrimitive(this.value);
   }

   public void load(JsonElement el) {
      if (el != null && el.isJsonPrimitive()) {
         this.value = this.clamp(el.getAsDouble());
      }

   }
}
