package pl.easyeventowka.gui;

public final class Theme {
   public static final int HEADER = -266986974;
   public static final int HEADER_HOVER = -266394062;
   public static final int ROW = -535554015;
   public static final int ROW_HOVER = -534829518;
   public static final int SUB = -536080619;
   public static final int SUB_HOVER = -535553758;
   public static final int ACCENT = -11760129;
   public static final int ACCENT_DARK = -13934664;
   public static final int TEXT = -1643790;
   public static final int TEXT_DIM = -8090209;
   public static final int OFF = -13288632;
   public static final int KNOB_OFF = -6774350;
   public static final int OUTLINE = -13946302;

   private Theme() {
   }
}
