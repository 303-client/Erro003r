package pl.easyeventowka.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.fabricmc.loader.api.FabricLoader;
import pl.easyeventowka.gui.Category;
import pl.easyeventowka.gui.ModOption;
import pl.easyeventowka.gui.Panels;
import pl.easyeventowka.gui.Setting;

public final class ConfigManager {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();

   private ConfigManager() {
   }

   private static Path file() {
      return FabricLoader.getInstance().getConfigDir().resolve("easyeventowka.json");
   }

   public static void save() {
      JsonObject root = new JsonObject();
      JsonObject categories = new JsonObject();

      for(Category c : Panels.CATEGORIES) {
         JsonObject co = new JsonObject();
         co.addProperty("x", c.x);
         co.addProperty("y", c.y);
         co.addProperty("expanded", c.expanded);
         JsonObject options = new JsonObject();

         for(ModOption o : c.options) {
            JsonObject oo = new JsonObject();
            oo.addProperty("settingsOpen", o.settingsOpen);
            JsonObject settings = new JsonObject();

            for(Setting s : o.settings) {
               settings.add(s.id, s.save());
            }

            oo.add("settings", settings);
            options.add(o.id, oo);
         }

         co.add("options", options);
         categories.add(c.id, co);
      }

      root.add("categories", categories);

      try {
         Path path = file();
         Files.createDirectories(path.getParent());
         Writer writer = Files.newBufferedWriter(path, StandardCharsets.UTF_8);

         try {
            GSON.toJson(root, writer);
         } catch (Throwable var13) {
            if (writer != null) {
               try {
                  writer.close();
               } catch (Throwable var12) {
                  var13.addSuppressed(var12);
               }
            }

            throw var13;
         }

         if (writer != null) {
            writer.close();
         }
      } catch (IOException e) {
         System.err.println("[EasyEventowka] Nie udalo sie zapisac konfiguracji: " + e.getMessage());
      }

   }

   public static void load() {
      Path path = file();
      if (Files.exists(path, new LinkOption[0])) {
         try {
            Reader reader = Files.newBufferedReader(path, StandardCharsets.UTF_8);

            try {
               JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();
               loadCategories(root);
            } catch (Throwable var5) {
               if (reader != null) {
                  try {
                     reader.close();
                  } catch (Throwable var4) {
                     var5.addSuppressed(var4);
                  }
               }

               throw var5;
            }

            if (reader != null) {
               reader.close();
            }
         } catch (Exception e) {
            System.err.println("[EasyEventowka] Nie udalo sie wczytac konfiguracji: " + e.getMessage());
         }
      }

   }

   private static void loadCategories(JsonObject root) {
      if (root.has("categories")) {
         JsonObject categories = root.getAsJsonObject("categories");

         for(Category c : Panels.CATEGORIES) {
            if (categories.has(c.id)) {
               JsonObject co = categories.getAsJsonObject(c.id);
               if (co.has("x")) {
                  c.x = co.get("x").getAsInt();
               }

               if (co.has("y")) {
                  c.y = co.get("y").getAsInt();
               }

               if (co.has("expanded")) {
                  c.expanded = co.get("expanded").getAsBoolean();
               }

               if (co.has("options")) {
                  JsonObject options = co.getAsJsonObject("options");

                  for(ModOption o : c.options) {
                     if (options.has(o.id)) {
                        JsonObject oo = options.getAsJsonObject(o.id);
                        if (oo.has("settingsOpen")) {
                           o.settingsOpen = oo.get("settingsOpen").getAsBoolean();
                        }

                        if (oo.has("settings")) {
                           JsonObject settings = oo.getAsJsonObject("settings");

                           for(Setting s : o.settings) {
                              if (settings.has(s.id)) {
                                 s.load(settings.get(s.id));
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

   }
}
