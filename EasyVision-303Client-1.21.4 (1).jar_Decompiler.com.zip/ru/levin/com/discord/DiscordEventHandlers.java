package ru.levin.com.discord;

import com.sun.jna.Structure;
import java.util.Arrays;
import java.util.List;
import ru.levin.com.discord.callbacks.DisconnectedCallback;
import ru.levin.com.discord.callbacks.ErroredCallback;
import ru.levin.com.discord.callbacks.JoinGameCallback;
import ru.levin.com.discord.callbacks.JoinRequestCallback;
import ru.levin.com.discord.callbacks.ReadyCallback;
import ru.levin.com.discord.callbacks.SpectateGameCallback;

public class DiscordEventHandlers extends Structure {
   public DisconnectedCallback disconnected;
   public JoinRequestCallback joinRequest;
   public SpectateGameCallback spectateGame;
   public ReadyCallback ready;
   public ErroredCallback errored;
   public JoinGameCallback joinGame;

   protected List<String> getFieldOrder() {
      return Arrays.asList("ready", "disconnected", "errored", "joinGame", "spectateGame", "joinRequest");
   }
}
