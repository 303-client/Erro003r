package ru.levin.com.discord.callbacks;

import com.sun.jna.Callback;
import ru.levin.com.discord.DiscordUser;

public interface JoinRequestCallback extends Callback {
   void apply(DiscordUser var1);
}
