package ru.levin.events.impl;

import ru.levin.events.Event;

public class EventUpdate extends Event {
}
