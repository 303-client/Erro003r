package ru.levin.events.impl.player;

import net.minecraft.class_1792;
import ru.levin.events.Event;

public class EventCooldown extends Event {
   public class_1792 itemStack;
   public float cooldown;

   public EventCooldown(class_1792 item) {
      this.itemStack = item;
   }

   public class_1792 getItemStack() {
      return this.itemStack;
   }

   public float getCooldown() {
      return this.cooldown;
   }

   public void setItemStack(class_1792 itemStack) {
      this.itemStack = itemStack;
   }

   public void setCooldown(float cooldown) {
      this.cooldown = cooldown;
   }

   public String toString() {
      String var10000 = String.valueOf(this.getItemStack());
      return "EventCooldown(itemStack=" + var10000 + ", cooldown=" + this.getCooldown() + ")";
   }

   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof EventCooldown)) {
         return false;
      } else {
         EventCooldown other = (EventCooldown)o;
         if (!other.canEqual(this)) {
            return false;
         } else if (!super.equals(o)) {
            return false;
         } else if (Float.compare(this.getCooldown(), other.getCooldown()) != 0) {
            return false;
         } else {
            Object this$itemStack = this.getItemStack();
            Object other$itemStack = other.getItemStack();
            if (this$itemStack == null) {
               if (other$itemStack != null) {
                  return false;
               }
            } else if (!this$itemStack.equals(other$itemStack)) {
               return false;
            }

            return true;
         }
      }
   }

   protected boolean canEqual(Object other) {
      return other instanceof EventCooldown;
   }

   public int hashCode() {
      int PRIME = 59;
      int result = super.hashCode();
      result = result * 59 + Float.floatToIntBits(this.getCooldown());
      Object $itemStack = this.getItemStack();
      result = result * 59 + ($itemStack == null ? 43 : $itemStack.hashCode());
      return result;
   }
}
