package ru.levin.events.impl.player;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import ru.levin.events.Event;

public class EventAttack extends Event {
   private final class_1657 attacker;
   private final class_1297 target;

   public EventAttack(class_1657 attacker, class_1297 target) {
      this.attacker = attacker;
      this.target = target;
   }

   public class_1657 getAttacker() {
      return this.attacker;
   }

   public class_1297 getTarget() {
      return this.target;
   }
}
