package ru.levin.events.impl.player;

import net.minecraft.class_1268;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import ru.levin.events.Event;

public class EventUseBlock extends Event {
   private final class_2338 blockPos;
   private final class_1268 hand;
   private final class_3965 hitResult;
   private boolean cancel;

   public EventUseBlock(class_2338 blockPos, class_1268 hand, class_3965 hitResult) {
      this.blockPos = blockPos;
      this.hand = hand;
      this.hitResult = hitResult;
      this.cancel = false;
   }

   public class_2338 getBlockPos() {
      return this.blockPos;
   }

   public class_1268 getHand() {
      return this.hand;
   }

   public class_3965 getHitResult() {
      return this.hitResult;
   }

   public boolean isCancel() {
      return this.cancel;
   }

   public void setCancel(boolean cancel) {
      this.cancel = cancel;
   }
}
