package ru.levin.events.impl.player;

import ru.levin.events.Event;

public class EventSprint extends Event {
   private boolean sprinting;

   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof EventSprint)) {
         return false;
      } else {
         EventSprint other = (EventSprint)o;
         if (!other.canEqual(this)) {
            return false;
         } else if (!super.equals(o)) {
            return false;
         } else {
            return this.isSprinting() == other.isSprinting();
         }
      }
   }

   protected boolean canEqual(Object other) {
      return other instanceof EventSprint;
   }

   public int hashCode() {
      int PRIME = 59;
      int result = super.hashCode();
      result = result * 59 + (this.isSprinting() ? 79 : 97);
      return result;
   }

   public boolean isSprinting() {
      return this.sprinting;
   }

   public void setSprinting(boolean sprinting) {
      this.sprinting = sprinting;
   }

   public String toString() {
      return "EventSprint(sprinting=" + this.isSprinting() + ")";
   }

   public EventSprint(boolean sprinting) {
      this.sprinting = sprinting;
   }
}
