package ru.levin.events.impl.render;

import net.minecraft.class_1309;
import ru.levin.events.Event;

public class EventPlayerRender extends Event {
   private final class_1309 livingEntity;
   private float prevYaw;
   private float yaw;
   private float prevPitch;
   private float pitch;
   private float prevBodyYaw;
   private float bodyYaw;

   public EventPlayerRender(class_1309 entity) {
      this.livingEntity = entity;
      this.yaw = entity.field_6241;
      this.prevYaw = entity.field_6259;
      this.pitch = entity.method_36455();
      this.prevPitch = entity.field_6004;
      this.bodyYaw = entity.field_6283;
      this.prevBodyYaw = entity.field_6220;
   }

   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof EventPlayerRender)) {
         return false;
      } else {
         EventPlayerRender other = (EventPlayerRender)o;
         if (!other.canEqual(this)) {
            return false;
         } else if (!super.equals(o)) {
            return false;
         } else if (Float.compare(this.getPrevYaw(), other.getPrevYaw()) != 0) {
            return false;
         } else if (Float.compare(this.getYaw(), other.getYaw()) != 0) {
            return false;
         } else if (Float.compare(this.getPrevPitch(), other.getPrevPitch()) != 0) {
            return false;
         } else if (Float.compare(this.getPitch(), other.getPitch()) != 0) {
            return false;
         } else if (Float.compare(this.getPrevBodyYaw(), other.getPrevBodyYaw()) != 0) {
            return false;
         } else if (Float.compare(this.getBodyYaw(), other.getBodyYaw()) != 0) {
            return false;
         } else {
            Object this$livingEntity = this.getLivingEntity();
            Object other$livingEntity = other.getLivingEntity();
            if (this$livingEntity == null) {
               if (other$livingEntity != null) {
                  return false;
               }
            } else if (!this$livingEntity.equals(other$livingEntity)) {
               return false;
            }

            return true;
         }
      }
   }

   protected boolean canEqual(Object other) {
      return other instanceof EventPlayerRender;
   }

   public int hashCode() {
      int PRIME = 59;
      int result = super.hashCode();
      result = result * 59 + Float.floatToIntBits(this.getPrevYaw());
      result = result * 59 + Float.floatToIntBits(this.getYaw());
      result = result * 59 + Float.floatToIntBits(this.getPrevPitch());
      result = result * 59 + Float.floatToIntBits(this.getPitch());
      result = result * 59 + Float.floatToIntBits(this.getPrevBodyYaw());
      result = result * 59 + Float.floatToIntBits(this.getBodyYaw());
      Object $livingEntity = this.getLivingEntity();
      result = result * 59 + ($livingEntity == null ? 43 : $livingEntity.hashCode());
      return result;
   }

   public class_1309 getLivingEntity() {
      return this.livingEntity;
   }

   public float getPrevYaw() {
      return this.prevYaw;
   }

   public float getYaw() {
      return this.yaw;
   }

   public float getPrevPitch() {
      return this.prevPitch;
   }

   public float getPitch() {
      return this.pitch;
   }

   public float getPrevBodyYaw() {
      return this.prevBodyYaw;
   }

   public float getBodyYaw() {
      return this.bodyYaw;
   }

   public void setPrevYaw(float prevYaw) {
      this.prevYaw = prevYaw;
   }

   public void setYaw(float yaw) {
      this.yaw = yaw;
   }

   public void setPrevPitch(float prevPitch) {
      this.prevPitch = prevPitch;
   }

   public void setPitch(float pitch) {
      this.pitch = pitch;
   }

   public void setPrevBodyYaw(float prevBodyYaw) {
      this.prevBodyYaw = prevBodyYaw;
   }

   public void setBodyYaw(float bodyYaw) {
      this.bodyYaw = bodyYaw;
   }

   public String toString() {
      String var10000 = String.valueOf(this.getLivingEntity());
      return "EventPlayerRender(livingEntity=" + var10000 + ", prevYaw=" + this.getPrevYaw() + ", yaw=" + this.getYaw() + ", prevPitch=" + this.getPrevPitch() + ", pitch=" + this.getPitch() + ", prevBodyYaw=" + this.getPrevBodyYaw() + ", bodyYaw=" + this.getBodyYaw() + ")";
   }
}
