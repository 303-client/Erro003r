package ru.levin.events.impl.render;

import net.minecraft.class_4587;
import net.minecraft.class_9779;
import ru.levin.events.Event;

public class EventRender3D extends Event {
   private class_9779 deltatick;
   private class_4587 matrixStack;

   public EventRender3D(class_4587 matrixStack, class_9779 deltatick) {
      this.matrixStack = matrixStack;
      this.deltatick = deltatick;
   }

   public class_4587 getMatrixStack() {
      return this.matrixStack;
   }

   public class_9779 getDeltatick() {
      return this.deltatick;
   }
}
