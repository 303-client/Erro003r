package ru.levin.events.impl.render;

import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9779;
import ru.levin.events.Event;

public class EventRender2D extends Event {
   private class_332 drawContext;
   private class_4587 matrixStack;
   private class_9779 deltatick;

   public EventRender2D(class_332 drawContext, class_4587 matrixStack, class_9779 deltatick) {
      this.drawContext = drawContext;
      this.matrixStack = matrixStack;
      this.deltatick = deltatick;
   }

   public class_4587 getMatrixStack() {
      return this.matrixStack;
   }

   public class_332 getDrawContext() {
      return this.drawContext;
   }

   public class_9779 getDeltatick() {
      return this.deltatick;
   }
}
