package ru.levin.events.impl.world;

import net.minecraft.class_6854;
import ru.levin.events.Event;

public class EventFog extends Event {
   public boolean modified = false;
   public float r;
   public float g;
   public float b;
   public float alpha;
   public float start;
   public float end;
   public class_6854 shape;
}
