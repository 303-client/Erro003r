package ru.levin.events.impl.world;

import net.minecraft.class_2248;
import net.minecraft.class_2338;
import ru.levin.events.Event;

public class EventObsidianPlace extends Event {
   private final class_2248 block;
   private final class_2338 pos;

   public class_2248 getBlock() {
      return this.block;
   }

   public class_2338 getPos() {
      return this.pos;
   }

   public String toString() {
      String var10000 = String.valueOf(this.getBlock());
      return "EventObsidianPlace(block=" + var10000 + ", pos=" + String.valueOf(this.getPos()) + ")";
   }

   public boolean equals(Object o) {
      if (o == this) {
         return true;
      } else if (!(o instanceof EventObsidianPlace)) {
         return false;
      } else {
         EventObsidianPlace other = (EventObsidianPlace)o;
         if (!other.canEqual(this)) {
            return false;
         } else if (!super.equals(o)) {
            return false;
         } else {
            Object this$block = this.getBlock();
            Object other$block = other.getBlock();
            if (this$block == null) {
               if (other$block != null) {
                  return false;
               }
            } else if (!this$block.equals(other$block)) {
               return false;
            }

            Object this$pos = this.getPos();
            Object other$pos = other.getPos();
            if (this$pos == null) {
               if (other$pos != null) {
                  return false;
               }
            } else if (!this$pos.equals(other$pos)) {
               return false;
            }

            return true;
         }
      }
   }

   protected boolean canEqual(Object other) {
      return other instanceof EventObsidianPlace;
   }

   public int hashCode() {
      int PRIME = 59;
      int result = super.hashCode();
      Object $block = this.getBlock();
      result = result * 59 + ($block == null ? 43 : $block.hashCode());
      Object $pos = this.getPos();
      result = result * 59 + ($pos == null ? 43 : $pos.hashCode());
      return result;
   }

   public EventObsidianPlace(class_2248 block, class_2338 pos) {
      this.block = block;
      this.pos = pos;
   }
}
