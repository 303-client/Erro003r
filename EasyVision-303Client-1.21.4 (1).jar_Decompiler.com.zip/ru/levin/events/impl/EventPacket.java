package ru.levin.events.impl;

import net.minecraft.class_2596;
import ru.levin.events.Event;

public class EventPacket extends Event {
   private class_2596 packet;
   private final PacketType packetType;

   public EventPacket(class_2596 packet, PacketType packetType) {
      this.packet = packet;
      this.packetType = packetType;
   }

   public class_2596 getPacket() {
      return this.packet;
   }

   public void setPacket(class_2596 packet) {
      this.packet = packet;
   }

   public boolean isReceivePacket() {
      return this.packetType == EventPacket.PacketType.RECEIVE;
   }

   public boolean isSendPacket() {
      return this.packetType == EventPacket.PacketType.SEND;
   }

   public static enum PacketType {
      SEND,
      RECEIVE;

      // $FF: synthetic method
      private static PacketType[] $values() {
         return new PacketType[]{SEND, RECEIVE};
      }
   }
}
