package ru.levin.events.impl.move;

import net.minecraft.class_1297;
import ru.levin.events.Event;

public class EventEntitySpawn extends Event {
   private final class_1297 entity;

   public class_1297 getEntity() {
      return this.entity;
   }

   public EventEntitySpawn(class_1297 entity) {
      this.entity = entity;
   }
}
