package ru.levin.util.move;

import net.minecraft.class_2596;
import ru.levin.manager.IMinecraft;

public final class NetworkUtils implements IMinecraft {
   private static boolean sendingSilent = false;

   public static void sendSilentPacket(class_2596<?> packet) {
      try {
         sendingSilent = true;
         mc.field_1724.field_3944.method_52787(packet);
      } finally {
         sendingSilent = false;
      }

   }

   public static void sendPacket(class_2596<?> packet) {
      mc.field_1724.field_3944.method_52787(packet);
   }

   public static boolean isSendingSilent() {
      return sendingSilent;
   }

   private NetworkUtils() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }
}
