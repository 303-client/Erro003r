package ru.levin.util.move;

import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_3532;
import ru.levin.events.impl.input.EventKeyBoard;
import ru.levin.manager.IMinecraft;

public class MoveUtil implements IMinecraft {
   public static boolean isMoving() {
      return mc.field_1724 != null && mc.field_1687 != null && mc.field_1724.field_3913 != null && ((double)mc.field_1724.field_3913.field_3905 != (double)0.0F || (double)mc.field_1724.field_3913.field_3907 != (double)0.0F);
   }

   public static boolean isInWeb() {
      class_238 box = mc.field_1724.method_5829();

      for(int x = class_3532.method_15357(box.field_1323); x <= class_3532.method_15357(box.field_1320); ++x) {
         for(int y = class_3532.method_15357(box.field_1322); y <= class_3532.method_15357(box.field_1325); ++y) {
            for(int z = class_3532.method_15357(box.field_1321); z <= class_3532.method_15357(box.field_1324); ++z) {
               class_2338 blockPos = new class_2338(x, y, z);
               if (mc.field_1687.method_8320(blockPos).method_27852(class_2246.field_10343)) {
                  class_238 blockBox = new class_238(blockPos);
                  if (blockBox.method_994(box)) {
                     return true;
                  }
               }
            }
         }
      }

      return false;
   }

   public static void setSpeed(float motion) {
      float forward = mc.field_1724.field_3913.field_3905;
      float strafe = mc.field_1724.field_3913.field_3907;
      float yaw = mc.field_1724.method_36454();
      if (forward == 0.0F && strafe == 0.0F) {
         mc.field_1724.method_18800((double)0.0F, mc.field_1724.method_18798().field_1351, (double)0.0F);
      } else {
         if (forward != 0.0F) {
            if (strafe > 0.0F) {
               yaw += forward > 0.0F ? -45.0F : 45.0F;
            } else if (strafe < 0.0F) {
               yaw += forward > 0.0F ? 45.0F : -45.0F;
            }

            strafe = 0.0F;
            forward = forward > 0.0F ? 1.0F : -1.0F;
         }

         double rad = Math.toRadians((double)(yaw + 90.0F));
         double x = (double)(forward * motion) * Math.cos(rad) + (double)(strafe * motion) * Math.sin(rad);
         double z = (double)(forward * motion) * Math.sin(rad) - (double)(strafe * motion) * Math.cos(rad);
         mc.field_1724.method_18800(x, mc.field_1724.method_18798().field_1351, z);
      }

   }

   public static void fixMovement(EventKeyBoard event, float yaw) {
      float forward = event.getMovementForward();
      float strafe = event.getMovementStrafe();
      double angle = class_3532.method_15338(Math.toDegrees(direction(mc.field_1724.method_6128() ? yaw : mc.field_1724.method_36454(), (double)forward, (double)strafe)));
      if (forward != 0.0F || strafe != 0.0F) {
         float closestForward = 0.0F;
         float closestStrafe = 0.0F;
         float closestDifference = Float.MAX_VALUE;

         for(float predictedForward = -1.0F; predictedForward <= 1.0F; ++predictedForward) {
            for(float predictedStrafe = -1.0F; predictedStrafe <= 1.0F; ++predictedStrafe) {
               if (predictedStrafe != 0.0F || predictedForward != 0.0F) {
                  double predictedAngle = class_3532.method_15338(Math.toDegrees(direction(yaw, (double)predictedForward, (double)predictedStrafe)));
                  double difference = Math.abs(angle - predictedAngle);
                  if (difference < (double)closestDifference) {
                     closestDifference = (float)difference;
                     closestForward = predictedForward;
                     closestStrafe = predictedStrafe;
                  }
               }
            }
         }

         event.setMovementForward(closestForward);
         event.setMovementStrafe(closestStrafe);
      }
   }

   public static double direction(float rotationYaw, double moveForward, double moveStrafing) {
      if (moveForward < (double)0.0F) {
         rotationYaw += 180.0F;
      }

      float forward = 1.0F;
      if (moveForward < (double)0.0F) {
         forward = -0.5F;
      } else if (moveForward > (double)0.0F) {
         forward = 0.5F;
      }

      if (moveStrafing > (double)0.0F) {
         rotationYaw -= 90.0F * forward;
      }

      if (moveStrafing < (double)0.0F) {
         rotationYaw += 90.0F * forward;
      }

      return Math.toRadians((double)rotationYaw);
   }

   public static double getSpeed() {
      return Math.hypot(mc.field_1724.method_18798().field_1352, mc.field_1724.method_18798().field_1350);
   }

   public static double[] forward(double d) {
      float f = mc.field_1724.field_3913.field_3905;
      float f2 = mc.field_1724.field_3913.field_3907;
      float f3 = mc.field_1724.method_36454();
      if (f != 0.0F) {
         if (f2 > 0.0F) {
            f3 += (float)(f > 0.0F ? -45 : 45);
         } else if (f2 < 0.0F) {
            f3 += (float)(f > 0.0F ? 45 : -45);
         }

         f2 = 0.0F;
         if (f > 0.0F) {
            f = 1.0F;
         } else if (f < 0.0F) {
            f = -1.0F;
         }
      }

      double d2 = Math.sin(Math.toRadians((double)(f3 + 90.0F)));
      double d3 = Math.cos(Math.toRadians((double)(f3 + 90.0F)));
      double d4 = (double)f * d * d3 + (double)f2 * d * d2;
      double d5 = (double)f * d * d2 - (double)f2 * d * d3;
      return new double[]{d4, d5};
   }

   public static void setMotion(double speed) {
      double forward = (double)mc.field_1724.field_3913.field_3905;
      double strafe = (double)mc.field_1724.field_3913.field_3907;
      float yaw = mc.field_1724.method_36454();
      if (forward == (double)0.0F && strafe == (double)0.0F) {
         mc.field_1724.method_18800((double)0.0F, mc.field_1724.method_18798().field_1351, (double)0.0F);
      } else {
         if (forward != (double)0.0F) {
            if (strafe > (double)0.0F) {
               yaw += (float)(forward > (double)0.0F ? -45 : 45);
            } else if (strafe < (double)0.0F) {
               yaw += (float)(forward > (double)0.0F ? 45 : -45);
            }

            strafe = (double)0.0F;
            if (forward > (double)0.0F) {
               forward = (double)1.0F;
            } else if (forward < (double)0.0F) {
               forward = (double)-1.0F;
            }
         }

         double sin = (double)class_3532.method_15374((float)Math.toRadians((double)(yaw + 90.0F)));
         double cos = (double)class_3532.method_15362((float)Math.toRadians((double)(yaw + 90.0F)));
         mc.field_1724.method_18800(forward * speed * cos + strafe * speed * sin, mc.field_1724.method_18798().field_1351, forward * speed * sin - strafe * speed * cos);
      }

   }
}
