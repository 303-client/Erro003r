package ru.levin.util.animations.impl;

import ru.levin.util.animations.Animation;

public class EaseInOutQuad extends Animation {
   public EaseInOutQuad(int ms, double endPoint) {
      super(ms, endPoint);
   }

   protected double getEquation(double x1) {
      double x = x1 / (double)this.duration;
      return x < (double)0.5F ? (double)2.0F * Math.pow(x, (double)2.0F) : (double)1.0F - Math.pow((double)-2.0F * x + (double)2.0F, (double)2.0F) / (double)2.0F;
   }
}
