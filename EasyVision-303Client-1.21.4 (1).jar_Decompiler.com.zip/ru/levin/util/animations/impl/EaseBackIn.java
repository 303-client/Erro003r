package ru.levin.util.animations.impl;

import net.minecraft.class_2350;
import ru.levin.util.animations.Animation;

public class EaseBackIn extends Animation {
   private final float easeAmount;

   public EaseBackIn(int ms, double endPoint, float easeAmount) {
      super(ms, endPoint);
      this.easeAmount = easeAmount;
   }

   public EaseBackIn(int ms, double endPoint, float easeAmount, class_2350.class_2352 direction) {
      super(ms, endPoint, direction);
      this.easeAmount = easeAmount;
   }

   protected boolean correctOutput() {
      return true;
   }

   protected double getEquation(double x) {
      double x1 = x / (double)this.duration;
      float shrink = this.easeAmount + 1.0F;
      return Math.max((double)0.0F, (double)1.0F + (double)shrink * Math.pow(x1 - (double)1.0F, (double)3.0F) + (double)this.easeAmount * Math.pow(x1 - (double)1.0F, (double)2.0F));
   }
}
