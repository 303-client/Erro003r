package ru.levin.util.animations.impl;

import net.minecraft.class_2350;
import ru.levin.util.animations.Animation;

public class DecelerateAnimation extends Animation {
   public DecelerateAnimation(int ms, double endPoint) {
      super(ms, endPoint);
   }

   public DecelerateAnimation(int ms, double endPoint, class_2350.class_2352 direction) {
      super(ms, endPoint, direction);
   }

   protected double getEquation(double x) {
      double x1 = x / (double)this.duration;
      return (double)1.0F - (x1 - (double)1.0F) * (x1 - (double)1.0F);
   }
}
