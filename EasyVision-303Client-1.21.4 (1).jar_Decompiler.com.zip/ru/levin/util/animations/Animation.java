package ru.levin.util.animations;

import net.minecraft.class_2350;
import net.minecraft.class_2350.class_2352;
import ru.levin.util.player.TimerUtil;

public abstract class Animation {
   public TimerUtil timerUtil = new TimerUtil();
   protected int duration;
   protected double endPoint;
   protected class_2350.class_2352 direction;

   public Animation(int ms, double endPoint) {
      this.duration = ms;
      this.endPoint = endPoint;
      this.direction = class_2352.field_11056;
   }

   public Animation(int ms, double endPoint, class_2350.class_2352 direction) {
      this.duration = ms;
      this.endPoint = endPoint;
      this.direction = direction;
   }

   public boolean finished(class_2350.class_2352 direction) {
      return this.isDone() && this.direction.equals(direction);
   }

   public void setEndPoint(double endPoint) {
      this.endPoint = endPoint;
   }

   public void reset() {
      this.timerUtil.reset();
   }

   public boolean isDone() {
      return this.timerUtil.hasTimeElapsed((long)this.duration);
   }

   public class_2350.class_2352 getDirection() {
      return this.direction;
   }

   public void setDirection(class_2350.class_2352 direction) {
      if (this.direction != direction) {
         this.direction = direction;
         this.timerUtil.setTime(System.currentTimeMillis() - ((long)this.duration - Math.min((long)this.duration, this.timerUtil.getTime())));
      }

   }

   public Animation setDirection(boolean forwards) {
      class_2350.class_2352 direction = forwards ? class_2352.field_11056 : class_2352.field_11056;
      if (this.direction != direction) {
         this.direction = direction;
         this.timerUtil.setTime(System.currentTimeMillis() - ((long)this.duration - Math.min((long)this.duration, this.timerUtil.getTime())));
      }

      return this;
   }

   public void setDuration(int duration) {
      this.duration = duration;
   }

   protected boolean correctOutput() {
      return false;
   }

   public double getOutput() {
      if (this.direction == class_2352.field_11056) {
         return this.isDone() ? this.endPoint : this.getEquation((double)this.timerUtil.getTime()) * this.endPoint;
      } else if (this.isDone()) {
         return (double)0.0F;
      } else if (this.correctOutput()) {
         double revTime = (double)Math.min((long)this.duration, Math.max(0L, (long)this.duration - this.timerUtil.getTime()));
         return this.getEquation(revTime) * this.endPoint;
      } else {
         return ((double)1.0F - this.getEquation((double)this.timerUtil.getTime())) * this.endPoint;
      }
   }

   public double getEndput() {
      if (this.direction == class_2352.field_11060) {
         return this.isDone() ? this.endPoint : this.getEquation((double)this.timerUtil.getTime()) * this.endPoint;
      } else if (this.isDone()) {
         return (double)0.0F;
      } else if (this.correctOutput()) {
         double revTime = (double)Math.min((long)this.duration, Math.max(0L, (long)this.duration - this.timerUtil.getTime()));
         return this.getEquation(revTime) * this.endPoint;
      } else {
         return ((double)1.0F - this.getEquation((double)this.timerUtil.getTime())) * this.endPoint;
      }
   }

   protected abstract double getEquation(double var1);
}
