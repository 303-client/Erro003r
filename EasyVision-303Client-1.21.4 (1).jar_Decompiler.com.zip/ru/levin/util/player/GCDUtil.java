package ru.levin.util.player;

import ru.levin.manager.IMinecraft;

public class GCDUtil implements IMinecraft {
   public static float getSensitivity(float rotation) {
      float gcdValue = getGCDValue();
      return getDeltaMouse(rotation, gcdValue) * gcdValue;
   }

   public static float getGCDValue() {
      return getGCD() * 0.15F;
   }

   public static float getGCD() {
      float sens = (float)((Double)mc.field_1690.method_42495().method_41753() * 0.6 + 0.2);
      return sens * sens * sens * 8.0F;
   }

   public static float getDeltaMouse(float delta, float gcdValue) {
      return (float)Math.round(delta / gcdValue);
   }
}
