package ru.levin.util.player;

import java.util.Locale;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_2868;
import net.minecraft.class_8646;
import net.minecraft.class_9015;
import ru.levin.manager.IMinecraft;

public class ServerUtil implements IMinecraft {
   public static void selectCompass() {
      int slot = InventoryUtil.getHotBarSlot(class_1802.field_8251);
      if (slot != -1) {
         mc.field_1724.method_31548().field_7545 = slot;
         mc.field_1724.field_3944.method_52787(new class_2868(slot));
      }
   }

   public static float getHealth(class_1309 target) {
      if (mc.method_1558() == null) {
         return target.method_6032() / target.method_6063();
      } else {
         String serverAddress = mc.method_1558().field_3761.toLowerCase(Locale.ROOT);
         boolean isLocal = mc.method_47392();
         if (!isLocal && !serverAddress.isEmpty()) {
            if (target instanceof class_1308) {
               return target.method_6032() / target.method_6063();
            } else {
               if (serverAddress.contains("reallyworld") || serverAddress.contains("playrw") || serverAddress.contains("saturn-x") || serverAddress.contains("skytime") || serverAddress.contains("space-times")) {
                  class_269 scoreboard = target.method_37908().method_8428();
                  class_266 scoreObjective = scoreboard.method_1189(class_8646.field_45158);
                  if (scoreObjective != null) {
                     try {
                        int hp = scoreboard.method_1180(class_9015.method_55422(target.method_5820()), scoreObjective).method_55409();
                        if (hp >= 0 && (float)hp <= target.method_6063()) {
                           return (float)hp / target.method_6063();
                        }
                     } catch (NumberFormatException var6) {
                     }
                  }
               }

               return target.method_6032() / target.method_6063();
            }
         } else {
            return target.method_6032() / target.method_6063();
         }
      }
   }

   public static boolean isConnected(String ip) {
      if (mc.method_1558() == null) {
         return false;
      } else {
         String serverAddress = mc.method_1558().field_3761;
         return serverAddress != null && serverAddress.contains(ip);
      }
   }
}
