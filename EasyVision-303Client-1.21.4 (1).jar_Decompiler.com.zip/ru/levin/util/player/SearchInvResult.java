package ru.levin.util.player;

import net.minecraft.class_1799;

public record SearchInvResult(int slot, boolean found, class_1799 stack) {
   private static final SearchInvResult NOT_FOUND_RESULT = new SearchInvResult(-1, false, (class_1799)null);

   public static SearchInvResult notFound() {
      return NOT_FOUND_RESULT;
   }
}
