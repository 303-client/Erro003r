package ru.levin.util.player;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.util.Optional;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.FloatControl.Type;
import net.minecraft.class_2960;
import net.minecraft.class_3298;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;

public class AudioUtil implements IMinecraft {
   public static void playSound(String name) {
      class_2960 id = class_2960.method_60655("exosware", "sounds/" + name);
      mc.execute(() -> {
         try {
            Optional<class_3298> resourceOpt = mc.method_1478().method_14486(id);
            if (resourceOpt.isEmpty()) {
               System.err.println("Sound resource not found: " + String.valueOf(id));
               return;
            }

            class_3298 resource = (class_3298)resourceOpt.get();
            InputStream in = resource.method_14482();

            try {
               byte[] soundData = in.readAllBytes();
               float volume = (float)Manager.FUNCTION_MANAGER.clientSounds.volume.get().intValue() / 100.0F;
               (new Thread(() -> playSoundFromBytes(soundData, volume))).start();
            } catch (Throwable var7) {
               if (in != null) {
                  try {
                     in.close();
                  } catch (Throwable var6) {
                     var7.addSuppressed(var6);
                  }
               }

               throw var7;
            }

            if (in != null) {
               in.close();
            }
         } catch (Exception e) {
            System.err.println("Error loading sound: " + e.getMessage());
         }

      });
   }

   private static void playSoundFromBytes(byte[] soundData, float volume) {
      try {
         AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new ByteArrayInputStream(soundData));

         try {
            Clip clip = AudioSystem.getClip();
            clip.open(audioInputStream);
            FloatControl gainControl = (FloatControl)clip.getControl(Type.MASTER_GAIN);
            float dB = (float)((double)20.0F * Math.log10((double)volume));
            gainControl.setValue(Math.min(Math.max(dB, gainControl.getMinimum()), gainControl.getMaximum()));
            clip.start();
            clip.addLineListener((ex) -> {
               if (ex.getType() == javax.sound.sampled.LineEvent.Type.STOP) {
                  clip.close();
               }

            });
         } catch (Throwable var7) {
            if (audioInputStream != null) {
               try {
                  audioInputStream.close();
               } catch (Throwable var6) {
                  var7.addSuppressed(var6);
               }
            }

            throw var7;
         }

         if (audioInputStream != null) {
            audioInputStream.close();
         }
      } catch (Exception e) {
         System.err.println("Error playing sound: " + e.getMessage());
      }

   }
}
