package ru.levin.util.player;

import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_5134;
import org.joml.Vector3d;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;

public class AuraUtil implements IMinecraft {
   public static class_243 getVelocityTowards(class_1297 target, double speed, boolean defaultSpeed, boolean predict) {
      if (target != null && mc.field_1724 != null) {
         double finalSpeed = defaultSpeed ? mc.field_1724.method_5996(class_5134.field_23719).method_6194() : speed;
         class_243 look = target.method_5720();
         double predictDistance = predict ? (double)Manager.FUNCTION_MANAGER.targetStrafe.predict.get().floatValue() : (double)0.0F;
         double dx = target.method_23317() + look.field_1352 * predictDistance - mc.field_1724.method_23317();
         double dz = target.method_23321() + look.field_1350 * predictDistance - mc.field_1724.method_23321();
         double distance = Math.sqrt(dx * dx + dz * dz);
         if (distance == (double)0.0F) {
            return class_243.field_1353;
         } else {
            double vx = dx / distance * finalSpeed;
            double vz = dz / distance * finalSpeed;
            return new class_243(vx, (double)0.0F, vz);
         }
      } else {
         return class_243.field_1353;
      }
   }

   public static float getArmor(class_1309 entity) {
      if (entity instanceof class_1657 player) {
         return (float)player.method_6096();
      } else {
         return 0.0F;
      }
   }

   public static double getDistance(class_1309 entity) {
      return getVector(entity).length();
   }

   public static Vector3d getVector(class_1309 target) {
      class_243 basePos = target.method_19538();
      double wHalf = (double)target.method_17681() / (double)2.0F;
      double yMin = basePos.field_1351;
      double yMax = basePos.field_1351 + (double)target.method_17682();
      double playerEyeY = mc.field_1724.method_23320();
      int steps = 10;
      Vector3d bestVector = null;
      double bestDistance = Double.MAX_VALUE;

      for(int i = 0; i <= steps; ++i) {
         double y = yMin + (yMax - yMin) * ((double)i / (double)steps);
         double xOffset = Math.clamp(mc.field_1724.method_23317() - basePos.field_1352, -wHalf, wHalf);
         double zOffset = Math.clamp(mc.field_1724.method_23321() - basePos.field_1350, -wHalf, wHalf);
         Vector3d currentVector = new Vector3d(basePos.field_1352 - mc.field_1724.method_23317() + xOffset, y - playerEyeY, basePos.field_1350 - mc.field_1724.method_23321() + zOffset);
         double distance = currentVector.length();
         if (distance < bestDistance) {
            bestDistance = distance;
            bestVector = currentVector;
         }
      }

      if (bestVector == null) {
         bestVector = new Vector3d(basePos.field_1352 - mc.field_1724.method_23317(), (yMin + yMax) / (double)2.0F - playerEyeY, basePos.field_1350 - mc.field_1724.method_23321());
      }

      return bestVector;
   }
}
