package ru.levin.util.player;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1776;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2828;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_3532;
import net.minecraft.class_2848.class_2849;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;

public class InventoryUtil implements IMinecraft {
   public static void moveItemTest(int from, int to, boolean air) {
      if (from != to) {
         testPick(from, 0);
         testPick(to, 0);
         if (air) {
            testPick(from, 0);
         }

      }
   }

   public static void testPick(int slot, int button) {
      mc.field_1761.method_2906(0, slot, button, class_1713.field_7790, mc.field_1724);
   }

   public static void moveToOffhand(class_1792 item) {
      if (mc.field_1724 != null && mc.field_1761 != null) {
         class_1661 inventory = mc.field_1724.method_31548();
         if (((class_1799)inventory.field_7544.get(0)).method_7909() != item) {
            for(int i = 0; i < 9; ++i) {
               if (inventory.method_5438(i).method_7909() == item) {
                  mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, i + 36, 40, class_1713.field_7791, mc.field_1724);
                  return;
               }
            }

            for(int i = 9; i < 36; ++i) {
               if (inventory.method_5438(i).method_7909() == item) {
                  mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, i, 40, class_1713.field_7791, mc.field_1724);
                  return;
               }
            }

         }
      }
   }

   public static int getItem(Class<?> itemClass, boolean hotBarOnly) {
      class_1661 inventory = mc.field_1724.method_31548();
      int startSlot = hotBarOnly ? 0 : 9;
      int endSlot = hotBarOnly ? 9 : inventory.method_5439();

      for(int i = startSlot; i < endSlot; ++i) {
         if (i < inventory.method_5439()) {
            class_1799 itemStack = inventory.method_5438(i);
            if (!itemStack.method_7960() && itemClass.isInstance(itemStack.method_7909())) {
               return i;
            }
         }
      }

      return -1;
   }

   public static int getPearls() {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_7909().method_8389() instanceof class_1776) {
            return i;
         }
      }

      return -1;
   }

   public static void swapSlotsUniversal(int slot1, int slot2, boolean cursor, boolean conversion) {
      if (cursor) {
         mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, slot1, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, slot2, 0, class_1713.field_7790, mc.field_1724);
         mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, slot1, 0, class_1713.field_7790, mc.field_1724);
      } else if (slot1 < 9 && conversion) {
         mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, slot1 + 36, slot2, class_1713.field_7791, mc.field_1724);
      } else {
         mc.field_1761.method_2906(mc.field_1724.field_7498.field_7763, slot1, slot2, class_1713.field_7791, mc.field_1724);
      }

   }

   public static void swapSlots(int slot1, int slot2) {
      if (slot1 < 9 && slot2 < 9) {
         mc.field_1761.method_2906(0, slot1 + 36, slot2, class_1713.field_7791, mc.field_1724);
      } else if (slot1 < 9) {
         mc.field_1761.method_2906(0, slot2, slot1, class_1713.field_7791, mc.field_1724);
      } else if (slot2 < 9) {
         mc.field_1761.method_2906(0, slot1, slot2, class_1713.field_7791, mc.field_1724);
      }

   }

   public static SearchInvResult getAxe() {
      if (mc.field_1724 == null) {
         return SearchInvResult.notFound();
      } else {
         int slot = -1;
         float f = 1.0F;

         for(int b1 = 9; b1 < 45; ++b1) {
            class_1799 itemStack = mc.field_1724.method_31548().method_5438(b1 >= 36 ? b1 - 36 : b1);
            if (itemStack != null) {
               class_1792 var5 = itemStack.method_7909();
               if (var5 instanceof class_1743) {
                  class_1743 axe = (class_1743)var5;
                  slot = b1;
               }
            }
         }

         if (slot >= 36) {
            slot -= 36;
         }

         if (slot == -1) {
            return SearchInvResult.notFound();
         } else {
            return new SearchInvResult(slot, true, mc.field_1724.method_31548().method_5438(slot));
         }
      }
   }

   public static void moveItem(int from, int to, boolean air) {
      if (from != to) {
         pickupItem(from, 0);
         pickupItem(to, 0);
         if (air) {
            pickupItem(from, 0);
         }
      }

   }

   public static void pickupItem(int slot, int button) {
      mc.field_1761.method_2906(0, slot, button, class_1713.field_7790, mc.field_1724);
   }

   public static int getItemSlot(class_1792 input) {
      for(class_1799 stack : Manager.SYNC_MANAGER.getItems()) {
         if (stack.method_7909() == input) {
            return -2;
         }
      }

      int slot = -1;

      for(int i = 0; i < 36; ++i) {
         class_1799 s = mc.field_1724.method_31548().method_5438(i);
         if (s.method_7909() == input) {
            slot = i;
            break;
         }
      }

      if (slot < 9 && slot != -1) {
         slot += 36;
      }

      return slot;
   }

   public static int getHotBarSlot(class_1792 input) {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_7909() == input) {
            return i;
         }
      }

      return -1;
   }

   public static boolean doesHotbarHaveItem(class_1792 item) {
      for(int i = 0; i < 9; ++i) {
         mc.field_1724.method_31548().method_5438(i);
         if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
            return true;
         }
      }

      return false;
   }

   public static int getItemIndex(class_1792 item) {
      for(int i = 0; i < 45; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   public static void inventorySwapClick2(class_1792 item, boolean useFromInventory, boolean rotation) {
      int currentSlot = mc.field_1724.method_31548().field_7545;
      if (mc.field_1724.method_6115() && !mc.field_1724.method_6030().method_31574(class_1802.field_8255) && mc.field_1724.method_6058() == class_1268.field_5808) {
         for(int i = 0; i < 9; ++i) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
               swapSlotsUniversal(i, 40, false, true);
               if (rotation && Manager.FUNCTION_MANAGER.attackAura.target != null) {
                  mc.field_1724.field_3944.method_52787(new class_2828.class_2831(mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
               }

               mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5810, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
               swapSlotsUniversal(i, 40, false, true);
               return;
            }
         }

      } else {
         for(int i = 0; i < 9; ++i) {
            if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
               if (i != currentSlot) {
                  mc.field_1724.field_3944.method_52787(new class_2868(i));
               }

               if (rotation && Manager.FUNCTION_MANAGER.attackAura.target != null) {
                  mc.field_1724.field_3944.method_52787(new class_2828.class_2831(mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
               }

               mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
               if (i != currentSlot) {
                  mc.field_1724.field_3944.method_52787(new class_2868(currentSlot));
               }

               return;
            }
         }

         if (useFromInventory) {
            for(int i = 9; i < 36; ++i) {
               if (mc.field_1724.method_31548().method_5438(i).method_7909() == item) {
                  int nextSlot = (currentSlot + 1) % 9;
                  swapSlotsUniversal(i, nextSlot, false, true);
                  mc.field_1724.field_3944.method_52787(new class_2868(nextSlot));
                  if (rotation && Manager.FUNCTION_MANAGER.attackAura.target != null) {
                     mc.field_1724.field_3944.method_52787(new class_2828.class_2831(mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
                  }

                  mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
                  mc.field_1724.field_3944.method_52787(new class_2868(currentSlot));
                  swapSlotsUniversal(i, nextSlot, false, true);
                  return;
               }
            }
         }

      }
   }

   public static void windowClick(int conteinerId, int slot, int mouse, class_1713 type, class_1657 player) {
      mc.field_1761.method_2906(conteinerId, slot, mouse, type, player);
   }

   public static void startFly() {
      mc.field_1724.method_23669();
      mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12982));
   }

   public static void use(int hotbarSlot, int inventorySlot, boolean useFromInventory) {
      int currentItem = mc.field_1724.method_31548().field_7545;
      if (hotbarSlot != -1) {
         mc.field_1724.method_31548().field_7545 = hotbarSlot;
         mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
         mc.field_1724.method_31548().field_7545 = currentItem;
      } else if (useFromInventory && inventorySlot != -1) {
         windowClick(0, inventorySlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         mc.field_1761.method_2919(mc.field_1724, class_1268.field_5808);
         windowClick(0, inventorySlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
         mc.field_1724.method_31548().method_7381();
      }

   }

   public static class TotemUtil {
      public static class_2338 getBlock(float distance, class_2248 block) {
         return (class_2338)getSphere(getPlayerPosLocal(), distance, 6, false, true, 0).stream().filter((position) -> IMinecraft.mc.field_1687.method_8320(position).method_26204() == block).min(Comparator.comparing((blockPos) -> getDistanceOfEntityToBlock(IMinecraft.mc.field_1724, blockPos))).orElse((Object)null);
      }

      public static class_2338 getBlock(float distance) {
         return (class_2338)getSphere(getPlayerPosLocal(), distance, 6, false, true, 0).stream().filter((position) -> IMinecraft.mc.field_1687.method_8320(position).method_26204() != class_2246.field_10124).min(Comparator.comparing((blockPos) -> getDistanceOfEntityToBlock(IMinecraft.mc.field_1724, blockPos))).orElse((Object)null);
      }

      public static List<class_2338> getSphere(class_2338 blockPos, float n, int n2, boolean b, boolean b2, int n3) {
         ArrayList<class_2338> list = new ArrayList();
         int x = blockPos.method_10263();
         int y = blockPos.method_10264();
         int z = blockPos.method_10260();

         for(int n4 = x - (int)n; (float)n4 <= (float)x + n; ++n4) {
            for(int n5 = z - (int)n; (float)n5 <= (float)z + n; ++n5) {
               for(int n6 = b2 ? y - (int)n : y; (float)n6 < (b2 ? (float)y + n : (float)(y + n2)); ++n6) {
                  double n7 = (double)((x - n4) * (x - n4) + (z - n5) * (z - n5) + (b2 ? (y - n6) * (y - n6) : 0));
                  if (n7 < (double)(n * n) && (!b || n7 >= (double)((n - 1.0F) * (n - 1.0F)))) {
                     list.add(new class_2338(n4, n6 + n3, n5));
                  }
               }
            }
         }

         return list;
      }

      public static class_2338 getPlayerPosLocal() {
         return IMinecraft.mc.field_1724 == null ? (class_2338)class_2338.field_11176 : new class_2338((int)Math.floor(IMinecraft.mc.field_1724.method_23317()), (int)Math.floor(IMinecraft.mc.field_1724.method_23318()), (int)Math.floor(IMinecraft.mc.field_1724.method_23321()));
      }

      public static double getDistanceOfEntityToBlock(class_1297 entity, class_2338 blockPos) {
         return getDistance(entity.method_23317(), entity.method_23318(), entity.method_23321(), (double)blockPos.method_10263(), (double)blockPos.method_10264(), (double)blockPos.method_10260());
      }

      public static double getDistance(double n, double n2, double n3, double n4, double n5, double n6) {
         double n7 = n - n4;
         double n8 = n2 - n5;
         double n9 = n3 - n6;
         return (double)class_3532.method_15355((float)(n7 * n7 + n8 * n8 + n9 * n9));
      }
   }
}
