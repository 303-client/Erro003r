package ru.levin.util;

import java.util.List;
import net.minecraft.class_243;
import ru.levin.modules.render.Trails;

public interface IEntity {
   List<Trails.Trail> exosWareFabric1_21_4$getTrails();

   class_243 exosWareFabric1_21_4$getLastTrailPos();

   void exosWareFabric1_21_4$setLastTrailPos(class_243 var1);
}
