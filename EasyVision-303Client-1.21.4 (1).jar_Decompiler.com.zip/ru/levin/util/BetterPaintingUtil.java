package ru.levin.util;

import net.minecraft.class_1297;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2397;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.manager.Manager;

public final class BetterPaintingUtil {
   private BetterPaintingUtil() {
   }

   public static boolean shouldHandlePainting(class_310 client) {
      if (client != null && client.field_1724 != null) {
         return !isEnabled() ? false : client.field_1724.method_6047().method_31574(class_1802.field_8892);
      } else {
         return false;
      }
   }

   public static boolean isPassThroughBlock(class_2680 state) {
      if (state == null) {
         return false;
      } else {
         return state.method_27852(class_2246.field_10343) || state.method_27852(class_2246.field_10033) || state.method_27852(class_2246.field_10087) || state.method_27852(class_2246.field_10227) || state.method_27852(class_2246.field_10574) || state.method_27852(class_2246.field_10271) || state.method_27852(class_2246.field_10049) || state.method_27852(class_2246.field_10157) || state.method_27852(class_2246.field_10317) || state.method_27852(class_2246.field_10555) || state.method_27852(class_2246.field_9996) || state.method_27852(class_2246.field_10248) || state.method_27852(class_2246.field_10399) || state.method_27852(class_2246.field_10060) || state.method_27852(class_2246.field_10073) || state.method_27852(class_2246.field_10357) || state.method_27852(class_2246.field_10272) || state.method_27852(class_2246.field_9997) || state.method_27852(class_2246.field_27115) || state.method_26204() instanceof class_2397;
      }
   }

   public static boolean isCobweb(class_2680 state) {
      return state == null ? false : state.method_27852(class_2246.field_10343);
   }

   public static class_3965 raycastFromCamera(class_310 client, float tickDelta, class_243 startOverride) {
      if (client != null && client.field_1687 != null) {
         class_1297 cam = client.method_1560();
         if (cam == null) {
            return null;
         } else {
            class_243 start = startOverride != null ? startOverride : cam.method_19538();
            class_243 dir = cam.method_5828(tickDelta);
            double range = (double)4.5F;
            if (client.field_1724 != null) {
               range = client.field_1724.method_55754();
            }

            class_243 end = start.method_1019(dir.method_1021(range));
            class_239 hit = client.field_1687.method_17742(new class_3959(start, end, class_3960.field_17558, class_242.field_1348, cam));
            if (hit instanceof class_3965) {
               class_3965 bhr = (class_3965)hit;
               if (hit.method_17783() == class_240.field_1332) {
                  return bhr;
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public static class_3965 skipPassThrough(class_310 client, float tickDelta, class_3965 initial) {
      if (client != null && client.field_1687 != null && initial != null) {
         if (!isPassThroughBlock(client.field_1687.method_8320(initial.method_17777()))) {
            return initial;
         } else {
            class_243 start = offsetPastHit(initial, client, tickDelta);

            for(int i = 0; i < 8 && start != null; ++i) {
               class_3965 hit = raycastFromCamera(client, tickDelta, start);
               if (hit == null) {
                  return null;
               }

               if (!isPassThroughBlock(client.field_1687.method_8320(hit.method_17777()))) {
                  return hit;
               }

               start = offsetPastHit(hit, client, tickDelta);
            }

            return null;
         }
      } else {
         return null;
      }
   }

   public static class_3965 skipCobwebs(class_310 client, float tickDelta, class_3965 initial) {
      if (client != null && client.field_1687 != null && initial != null) {
         if (!isCobweb(client.field_1687.method_8320(initial.method_17777()))) {
            return initial;
         } else {
            class_243 start = advancePastHit(initial, client, tickDelta);

            for(int i = 0; i < 8 && start != null; ++i) {
               class_3965 hit = raycastFromCamera(client, tickDelta, start);
               if (hit == null) {
                  return null;
               }

               if (!isCobweb(client.field_1687.method_8320(hit.method_17777()))) {
                  return hit;
               }

               start = advancePastHit(hit, client, tickDelta);
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private static class_243 advancePastHit(class_3965 hit, class_310 client, float tickDelta) {
      if (hit != null && client != null) {
         class_1297 cam = client.method_1560();
         if (cam == null) {
            return null;
         } else {
            class_243 dir = cam.method_5828(tickDelta);
            if (dir == null) {
               return null;
            } else {
               class_243 start = hit.method_17784();
               class_2338 hitPos = hit.method_17777();
               class_243 step = dir.method_1029().method_1021(0.2);

               for(int i = 0; i < 10; ++i) {
                  start = start.method_1019(step);
                  class_2338 currentPos = class_2338.method_49638(start);
                  if (!currentPos.equals(hitPos)) {
                     break;
                  }
               }

               return start;
            }
         }
      } else {
         return null;
      }
   }

   public static class_3966 raycastPainting(class_310 client, class_243 start, class_243 dir, double range) {
      return null;
   }

   public static class_2350 horizontalFaceTowardCamera(class_243 blockCenter, class_243 cameraPos) {
      if (blockCenter != null && cameraPos != null) {
         class_243 toCam = cameraPos.method_1020(blockCenter);
         double ax = Math.abs(toCam.field_1352);
         double az = Math.abs(toCam.field_1350);
         if (ax >= az) {
            return toCam.field_1352 >= (double)0.0F ? class_2350.field_11034 : class_2350.field_11039;
         } else {
            return toCam.field_1350 >= (double)0.0F ? class_2350.field_11035 : class_2350.field_11043;
         }
      } else {
         return class_2350.field_11043;
      }
   }

   public static class_243 offsetPastHit(class_3965 hit, class_310 client, float tickDelta) {
      if (hit == null) {
         return null;
      } else {
         class_1297 cam = client == null ? null : client.method_1560();
         if (cam == null) {
            return null;
         } else {
            class_2350 travel = hit.method_17780().method_10153();
            class_243 center = class_243.method_24953(hit.method_17777());
            return center.method_1031((double)travel.method_10148() * 0.51, (double)travel.method_10164() * 0.51, (double)travel.method_10165() * 0.51);
         }
      }
   }

   private static boolean isEnabled() {
      try {
         return Manager.FUNCTION_MANAGER.fastBetterPainting != null && Manager.FUNCTION_MANAGER.fastBetterPainting.state;
      } catch (Exception var1) {
         return false;
      }
   }
}
