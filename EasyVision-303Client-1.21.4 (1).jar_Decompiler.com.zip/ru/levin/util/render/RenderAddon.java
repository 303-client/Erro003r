package ru.levin.util.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import net.minecraft.class_10017;
import net.minecraft.class_10042;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1739;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5944;
import net.minecraft.class_640;
import net.minecraft.class_742;
import net.minecraft.class_897;
import net.minecraft.class_898;
import net.minecraft.class_922;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.util.render.providers.ResourceProvider;

public class RenderAddon implements IMinecraft {
   private static class_742 fakePlayer;

   public static void renderFakePlayer(class_243 defensivePos, boolean fakelags, boolean isAccumulatingPackets, EventRender3D render) {
      if (defensivePos != null && fakelags && isAccumulatingPackets) {
         if (fakePlayer == null) {
            createFakePlayer();
         }

         double x = defensivePos.field_1352;
         double y = defensivePos.field_1351;
         double z = defensivePos.field_1350;
         fakePlayer.method_30634(x, y, z);
         fakePlayer.field_6014 = x;
         fakePlayer.field_6036 = y;
         fakePlayer.field_5969 = z;
         fakePlayer.field_6038 = x;
         fakePlayer.field_5971 = y;
         fakePlayer.field_5989 = z;
         fakePlayer.method_36456(mc.field_1724.method_36454());
         fakePlayer.method_36457(mc.field_1724.method_36455());
         fakePlayer.field_6241 = mc.field_1724.field_6241;
         fakePlayer.field_6283 = mc.field_1724.field_6283;
         class_898 dispatcher = mc.method_1561();
         class_897<? super class_742, ?> rawRenderer = dispatcher.method_3953(fakePlayer);
         class_10017 state = rawRenderer.method_55269();
         rawRenderer.method_62354(fakePlayer, state, render.getDeltatick().method_60637(true));
         class_4587 matrices = render.getMatrixStack();
         class_4597.class_4598 vertexConsumers = mc.method_22940().method_23000();
         matrices.method_22903();
         matrices.method_22904(state.field_53325 - dispatcher.field_4686.method_19326().field_1352, state.field_53326 - dispatcher.field_4686.method_19326().field_1351, state.field_53327 - dispatcher.field_4686.method_19326().field_1350);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 0.35F);
         rawRenderer.method_3936(state, matrices, vertexConsumers, 15728880);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         RenderSystem.disableBlend();
         vertexConsumers.method_22993();
         matrices.method_22909();
      }
   }

   public static void sizeAnimation(class_4587 matrix, double width, double height, double scale) {
      matrix.method_22904(width, height, (double)0.0F);
      matrix.method_22905((float)scale, (float)scale, (float)scale);
      matrix.method_22904(-width, -height, (double)0.0F);
   }

   public static void renderItem(class_332 drawContext, class_1799 item, float x, float y, float size, boolean stackOverlay) {
      drawContext.method_51448().method_22903();
      drawContext.method_51448().method_46416(x, y, 0.0F);
      drawContext.method_51448().method_22905(size, size, 1.0F);
      drawContext.method_51427(item, 0, 0);
      if (stackOverlay) {
         drawContext.method_51431(mc.field_1772, item, 0, 0);
      }

      drawContext.method_51448().method_22909();
   }

   public static void renderPlayerItems(class_332 e, float x, float y, class_1309 player, float scale, float offset) {
      List<class_1799> stacks = new ArrayList();
      stacks.add(player.method_6047());
      Iterable var10000 = player.method_5661();
      Objects.requireNonNull(stacks);
      var10000.forEach(stacks::add);
      stacks.add(player.method_6079());
      stacks.removeIf((i) -> i.method_7909() instanceof class_1739 || i.method_7960());
      float offset2 = 0.0F;

      for(class_1799 stack : stacks) {
         e.method_51448().method_22903();
         e.method_51448().method_46416(x + offset2, y, 0.0F);
         e.method_51448().method_22905(scale, scale, 1.0F);
         e.method_51429(stack, 0, 0, 7, 0);
         e.method_51431(mc.field_1772, stack, 0, 0);
         e.method_51448().method_22909();
         offset2 += offset;
      }

   }

   public static void drawHead(class_4587 matrix, class_1297 entity, float x, float y, float size, float round) {
      if (entity instanceof class_1309 living) {
         int color = -1;
         if (living.field_6235 > 0) {
            float hurtPercent = (float)living.field_6235 / (float)living.field_6254;
            int red = 255;
            int green = (int)(255.0F * (1.0F - hurtPercent));
            int blue = (int)(255.0F * (1.0F - hurtPercent));
            color = -16777216 | red << 16 | green << 8 | blue;
         }

         class_2960 texture = null;
         if (entity instanceof class_1657 player) {
            class_640 entry = (class_640)Optional.ofNullable(mc.method_1562()).map((handler) -> handler.method_2871(player.method_5667())).orElse((Object)null);
            if (entry != null) {
               texture = entry.method_52810().comp_1626();
            }
         }

         if (texture == null) {
            class_897<? super class_1309, ?> baseRenderer = mc.method_1561().method_3953(living);
            if (baseRenderer instanceof class_922) {
               class_922<class_1309, class_10042, ?> renderer = (class_922)baseRenderer;
               class_10042 state = (class_10042)renderer.method_62425(living, IMinecraft.tickCounter().method_60637(true));
               texture = renderer.method_3885(state);
            }
         }

         if (texture != null) {
            drawHeadInternal(matrix, texture, x, y, size, round, color);
         }

      }
   }

   private static void drawHeadInternal(class_4587 matrix, class_2960 texture, float x, float y, float size, float rounding, int color) {
      RenderUtil.enableRender();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.TEXTURE_SHADER_KEY);
      RenderSystem.setShaderTexture(0, texture);
      shader.method_34582("Size").method_1255(size, size);
      shader.method_34582("Radius").method_35657(rounding, rounding, rounding, rounding);
      shader.method_34582("Smoothness").method_1251(1.0F);
      float u1 = 0.125F;
      float v1 = 0.125F;
      float u2 = 0.25F;
      float v2 = 0.25F;
      Matrix4f matrix4f = matrix.method_23760().method_23761();
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);
      buffer.method_22918(matrix4f, x, y, 0.0F).method_22913(u1, v1).method_39415(color);
      buffer.method_22918(matrix4f, x + size, y, 0.0F).method_22913(u2, v1).method_39415(color);
      buffer.method_22918(matrix4f, x + size, y + size, 0.0F).method_22913(u2, v2).method_39415(color);
      buffer.method_22918(matrix4f, x, y + size, 0.0F).method_22913(u1, v2).method_39415(color);
      RenderUtil.render3D.endBuilding(buffer);
      RenderUtil.disableRender();
   }

   public static void drawStaffHead(class_4587 matrix, class_2960 texture, float x, float y, float size, float round) {
      if (texture != null) {
         drawHeadInternal(matrix, texture, x, y, size, round, -1);
      }

   }

   private static void createFakePlayer() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         fakePlayer = new class_742(mc.field_1687, mc.field_1724.method_7334()) {
            public boolean method_7325() {
               return false;
            }

            public boolean method_7337() {
               return false;
            }
         };
         fakePlayer.method_5878(mc.field_1724);
         fakePlayer.method_23327(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
         fakePlayer.field_6241 = mc.field_1724.field_6241;
         fakePlayer.field_6283 = mc.field_1724.field_6283;
      }
   }
}
