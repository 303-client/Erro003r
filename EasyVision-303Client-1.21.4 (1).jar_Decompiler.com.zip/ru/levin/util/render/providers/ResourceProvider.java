package ru.levin.util.render.providers;

import net.minecraft.class_10149;
import net.minecraft.class_10156;
import net.minecraft.class_290;
import net.minecraft.class_2960;

public final class ResourceProvider {
   public static final class_10156 TEXTURE_SHADER_KEY;
   public static final class_10156 RECTANGLE_SHADER_KEY;
   public static final class_10156 BLUR_SHADER_KEY;
   public static final class_10156 RECTANGLE_BORDER_SHADER_KEY;
   public static final class_10156 GLASS_SHADER_KEY;
   public static final class_2960 firefly;
   public static final class_2960 bloom;
   public static final class_2960 snowflake;
   public static final class_2960 dollar;
   public static final class_2960 heart;
   public static final class_2960 star;
   public static final class_2960 spark;
   public static final class_2960 crown;
   public static final class_2960 lightning;
   public static final class_2960 line;
   public static final class_2960 point;
   public static final class_2960 rhombus;
   public static final class_2960 marker;
   public static final class_2960 marker2;
   public static final class_2960 CUSTOM_CAPE;
   public static final class_2960 CUSTOM_ELYTRA;
   public static final class_2960 container;
   public static final class_2960 color_image;

   private static class_2960 getGlass(String name) {
      return class_2960.method_60655("exosware", "core/glass/" + name);
   }

   private static class_2960 getShaderIdentifier(String name) {
      return class_2960.method_60655("exosware", "core/" + name);
   }

   static {
      TEXTURE_SHADER_KEY = new class_10156(getShaderIdentifier("texture"), class_290.field_1575, class_10149.field_53930);
      RECTANGLE_SHADER_KEY = new class_10156(getShaderIdentifier("rectangle"), class_290.field_1576, class_10149.field_53930);
      BLUR_SHADER_KEY = new class_10156(getShaderIdentifier("blur"), class_290.field_1576, class_10149.field_53930);
      RECTANGLE_BORDER_SHADER_KEY = new class_10156(getShaderIdentifier("border"), class_290.field_1576, class_10149.field_53930);
      GLASS_SHADER_KEY = new class_10156(getGlass("data"), class_290.field_1575, class_10149.field_53930);
      firefly = class_2960.method_60655("exosware", "images/particles/firefly.png");
      bloom = class_2960.method_60655("exosware", "images/particles/bloom.png");
      snowflake = class_2960.method_60655("exosware", "images/particles/snowflake.png");
      dollar = class_2960.method_60655("exosware", "images/particles/dollar.png");
      heart = class_2960.method_60655("exosware", "images/particles/heart.png");
      star = class_2960.method_60655("exosware", "images/particles/star.png");
      spark = class_2960.method_60655("exosware", "images/particles/spark.png");
      crown = class_2960.method_60655("exosware", "images/particles/crown.png");
      lightning = class_2960.method_60655("exosware", "images/particles/lightning.png");
      line = class_2960.method_60655("exosware", "images/particles/line.png");
      point = class_2960.method_60655("exosware", "images/particles/point.png");
      rhombus = class_2960.method_60655("exosware", "images/particles/rhombus.png");
      marker = class_2960.method_60655("exosware", "images/targetesp/target.png");
      marker2 = class_2960.method_60655("exosware", "images/targetesp/target2.png");
      CUSTOM_CAPE = class_2960.method_60655("exosware", "cape/cape.png");
      CUSTOM_ELYTRA = class_2960.method_60655("exosware", "cape/elytra.png");
      container = class_2960.method_60655("exosware", "images/hud/container.png");
      color_image = class_2960.method_60655("exosware", "images/gui/pick.png");
   }
}
