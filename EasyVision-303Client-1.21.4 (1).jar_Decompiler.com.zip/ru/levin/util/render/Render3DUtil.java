package ru.levin.util.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import net.minecraft.class_10142;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_3545;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_4604;
import net.minecraft.class_293.class_5596;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4i;
import org.lwjgl.opengl.GL11;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;

public final class Render3DUtil implements IMinecraft {
   private static final Map<class_265, class_3545<List<class_238>, List<Line>>> SHAPE_OUTLINES = new HashMap();
   private static final Map<class_265, List<class_238>> SHAPE_BOXES = new HashMap();
   public static final List<Texture> TEXTURE_DEPTH = new ArrayList();
   public static final List<Texture> TEXTURE = new ArrayList();
   public static final List<Line> LINE_DEPTH = new ArrayList();
   public static final List<Line> LINE = new ArrayList();
   public static final List<Quad> QUAD_DEPTH = new ArrayList();
   public static final List<Quad> QUAD = new ArrayList();
   public static class_4587.class_4665 lastWorldSpaceMatrix = (new class_4587()).method_23760();
   public static Matrix4f lastProjMat = new Matrix4f();

   public static void onWorldRender(EventRender3D e) {
      if (!TEXTURE.isEmpty()) {
         Set<class_2960> identifiers = (Set)TEXTURE.stream().map((texture) -> texture.id).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_CONSTANT_ALPHA);
         identifiers.forEach((id) -> {
            RenderSystem.setShaderTexture(0, id);
            RenderSystem.setShader(class_10142.field_53880);
            class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
            TEXTURE.stream().filter((texture) -> texture.id.equals(id)).forEach((tex) -> quadTexture(tex.entry, buffer, tex.x, tex.y, tex.width, tex.height, tex.color));
            class_286.method_43433(buffer.method_60800());
         });
         RenderSystem.disableBlend();
         TEXTURE.clear();
      }

      if (!TEXTURE_DEPTH.isEmpty()) {
         Set<class_2960> identifiers = (Set)TEXTURE_DEPTH.stream().map((texture) -> texture.id).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_CONSTANT_ALPHA);
         identifiers.forEach((id) -> {
            RenderSystem.setShaderTexture(0, id);
            RenderSystem.setShader(class_10142.field_53880);
            class_287 buffer = class_289.method_1348().method_60827(class_5596.field_27382, class_290.field_1575);
            TEXTURE_DEPTH.stream().filter((texture) -> texture.id.equals(id)).forEach((tex) -> quadTexture(tex.entry, buffer, tex.x, tex.y, tex.width, tex.height, tex.color));
            class_286.method_43433(buffer.method_60800());
         });
         RenderSystem.depthMask(true);
         RenderSystem.disableBlend();
         TEXTURE_DEPTH.clear();
      }

      if (!LINE.isEmpty()) {
         GL11.glEnable(2881);
         Set<Float> widths = (Set)LINE.stream().map((line) -> line.width).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.disableDepthTest();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(class_10142.field_53864);
         widths.forEach((width) -> {
            RenderSystem.lineWidth(width);
            class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27377, class_290.field_29337);
            LINE.stream().filter((line) -> line.width == width).forEach((line) -> vertexLine((class_4587.class_4665)line.entry, buffer, (Vector3f)line.start.method_46409(), (Vector3f)line.end.method_46409(), line.colorStart, line.colorEnd));
            class_286.method_43433(buffer.method_60800());
         });
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         LINE.clear();
         GL11.glDisable(2881);
      }

      if (!QUAD.isEmpty()) {
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.disableDepthTest();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(class_10142.field_53876);
         class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1576);
         QUAD.forEach((quad) -> vertexQuad(quad.entry, buffer, (class_243)quad.x, (class_243)quad.y, (class_243)quad.w, (class_243)quad.z, quad.color));
         class_286.method_43433(buffer.method_60800());
         RenderSystem.enableDepthTest();
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         QUAD.clear();
      }

      if (!LINE_DEPTH.isEmpty()) {
         GL11.glEnable(2881);
         Set<Float> widths = (Set)LINE_DEPTH.stream().map((line) -> line.width).collect(Collectors.toCollection(LinkedHashSet::new));
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.depthMask(false);
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(class_10142.field_53864);
         widths.forEach((width) -> {
            RenderSystem.lineWidth(width);
            class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27377, class_290.field_29337);
            LINE_DEPTH.stream().filter((line) -> line.width == width).forEach((line) -> vertexLine((class_4587.class_4665)line.entry, buffer, (Vector3f)line.start.method_46409(), (Vector3f)line.end.method_46409(), line.colorStart, line.colorEnd));
            class_286.method_43433(buffer.method_60800());
         });
         RenderSystem.depthMask(true);
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         LINE_DEPTH.clear();
         GL11.glDisable(2881);
      }

      if (!QUAD_DEPTH.isEmpty()) {
         RenderSystem.enableBlend();
         RenderSystem.disableCull();
         RenderSystem.enableDepthTest();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_CONSTANT_ALPHA);
         RenderSystem.setShader(class_10142.field_53876);
         class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1576);
         QUAD_DEPTH.forEach((quad) -> vertexQuad(quad.entry, buffer, (class_243)quad.x, (class_243)quad.y, (class_243)quad.w, (class_243)quad.z, quad.color));
         class_286.method_43433(buffer.method_60800());
         RenderSystem.enableCull();
         RenderSystem.disableBlend();
         QUAD_DEPTH.clear();
      }

   }

   public static void drawShape(class_2338 blockPos, class_265 voxelShape, int color, float width) {
      drawShape(blockPos, voxelShape, color, width, true, false);
   }

   public static boolean canSee(class_238 box) {
      class_4604 frustum = mc.field_1769.method_62222();
      return box != null && frustum != null && frustum.method_23093(box);
   }

   public static void drawShape(class_2338 blockPos, class_265 voxelShape, int color, float width, boolean fill, boolean depth) {
      if (SHAPE_BOXES.containsKey(voxelShape)) {
         ((List)SHAPE_BOXES.get(voxelShape)).forEach((box) -> {
            box = box.method_996(blockPos);
            if (canSee(box)) {
               drawBox(box, color, width, true, fill, depth);
            }

         });
      } else {
         SHAPE_BOXES.put(voxelShape, voxelShape.method_1090());
      }
   }

   public static void drawShapeAlternative(class_2338 blockPos, class_265 voxelShape, int color, float width, boolean fill, boolean depth) {
      class_243 vec3d = class_243.method_24954(blockPos);
      if (SHAPE_OUTLINES.containsKey(voxelShape)) {
         class_3545<List<class_238>, List<Line>> pair = (class_3545)SHAPE_OUTLINES.get(voxelShape);
         if (fill) {
            ((List)pair.method_15442()).forEach((box) -> drawBox(box.method_997(vec3d), color, width, false, true, depth));
         }

         ((List)pair.method_15441()).forEach((line) -> drawLine(line.start.method_1019(vec3d), line.end.method_1019(vec3d), color, width, depth));
      } else {
         List<Line> lines = new ArrayList();
         voxelShape.method_1104((minX, minY, minZ, maxX, maxY, maxZ) -> lines.add(new Line((class_4587.class_4665)null, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), 0, 0, 0.0F)));
         SHAPE_OUTLINES.put(voxelShape, new class_3545(voxelShape.method_1090(), lines));
      }
   }

   public static void drawBox(class_238 box, int color, float width) {
      drawBox(box, color, width, true, true, false);
   }

   public static void drawBox(class_238 box, int color, float width, boolean line, boolean fill, boolean depth) {
      drawBox((class_4587.class_4665)null, box, color, width, line, fill, depth);
   }

   public static void drawBox(class_4587.class_4665 entry, class_238 box, int color, float width, boolean line, boolean fill, boolean depth) {
      box = box.method_1014(0.001);
      double x1 = box.field_1323;
      double y1 = box.field_1322;
      double z1 = box.field_1321;
      double x2 = box.field_1320;
      double y2 = box.field_1325;
      double z2 = box.field_1324;
      if (fill) {
         int fillColor = ColorUtilTest.multAlpha(color, 0.1F);
         drawQuad(entry, new class_243(x1, y1, z1), new class_243(x2, y1, z1), new class_243(x2, y1, z2), new class_243(x1, y1, z2), fillColor, depth);
         drawQuad(entry, new class_243(x1, y1, z1), new class_243(x1, y2, z1), new class_243(x2, y2, z1), new class_243(x2, y1, z1), fillColor, depth);
         drawQuad(entry, new class_243(x2, y1, z1), new class_243(x2, y2, z1), new class_243(x2, y2, z2), new class_243(x2, y1, z2), fillColor, depth);
         drawQuad(entry, new class_243(x1, y1, z2), new class_243(x2, y1, z2), new class_243(x2, y2, z2), new class_243(x1, y2, z2), fillColor, depth);
         drawQuad(entry, new class_243(x1, y1, z1), new class_243(x1, y1, z2), new class_243(x1, y2, z2), new class_243(x1, y2, z1), fillColor, depth);
         drawQuad(entry, new class_243(x1, y2, z1), new class_243(x1, y2, z2), new class_243(x2, y2, z2), new class_243(x2, y2, z1), fillColor, depth);
      }

      if (line) {
         drawLine(entry, x1, y1, z1, x2, y1, z1, color, width, depth);
         drawLine(entry, x2, y1, z1, x2, y1, z2, color, width, depth);
         drawLine(entry, x2, y1, z2, x1, y1, z2, color, width, depth);
         drawLine(entry, x1, y1, z2, x1, y1, z1, color, width, depth);
         drawLine(entry, x1, y1, z2, x1, y2, z2, color, width, depth);
         drawLine(entry, x1, y1, z1, x1, y2, z1, color, width, depth);
         drawLine(entry, x2, y1, z2, x2, y2, z2, color, width, depth);
         drawLine(entry, x2, y1, z1, x2, y2, z1, color, width, depth);
         drawLine(entry, x1, y2, z1, x2, y2, z1, color, width, depth);
         drawLine(entry, x2, y2, z1, x2, y2, z2, color, width, depth);
         drawLine(entry, x2, y2, z2, x1, y2, z2, color, width, depth);
         drawLine(entry, x1, y2, z2, x1, y2, z1, color, width, depth);
      }

   }

   public static void vertexLine(class_4587 matrices, class_4588 buffer, class_243 start, class_243 end, int startColor, int endColor) {
      vertexLine(matrices.method_23760(), buffer, start.method_46409(), end.method_46409(), startColor, endColor);
   }

   public static void vertexLine(class_4587.class_4665 entry, class_4588 buffer, Vector3f start, Vector3f end, int startColor, int endColor) {
      if (entry == null) {
         entry = lastWorldSpaceMatrix;
      }

      Vector3f vec = getNormal(start, end);
      buffer.method_61032(entry, start).method_39415(startColor).method_61959(entry, vec);
      buffer.method_61032(entry, end).method_39415(endColor).method_61959(entry, vec);
   }

   public static void vertexQuad(class_4587.class_4665 entry, class_4588 buffer, class_243 vec1, class_243 vec2, class_243 vec3, class_243 vec4, int color) {
      vertexQuad(entry, buffer, vec1.method_46409(), vec2.method_46409(), vec3.method_46409(), vec4.method_46409(), color);
   }

   public static void vertexQuad(class_4587.class_4665 entry, class_4588 buffer, Vector3f vec1, Vector3f vec2, Vector3f vec3, Vector3f vec4, int color) {
      if (entry == null) {
         entry = lastWorldSpaceMatrix;
      }

      buffer.method_61032(entry, vec1).method_39415(color);
      buffer.method_61032(entry, vec2).method_39415(color);
      buffer.method_61032(entry, vec3).method_39415(color);
      buffer.method_61032(entry, vec4).method_39415(color);
   }

   public static void quadTexture(class_4587.class_4665 entry, class_287 buffer, float x, float y, float width, float height, Vector4i color) {
      buffer.method_56824(entry, x, y + height, 0.0F).method_22913(0.0F, 0.0F).method_39415(color.x);
      buffer.method_56824(entry, x + width, y + height, 0.0F).method_22913(0.0F, 1.0F).method_39415(color.y);
      buffer.method_56824(entry, x + width, y, 0.0F).method_22913(1.0F, 1.0F).method_39415(color.w);
      buffer.method_56824(entry, x, y, 0.0F).method_22913(1.0F, 0.0F).method_39415(color.z);
   }

   public static @NotNull Vector3f getNormal(Vector3f start, Vector3f end) {
      Vector3f normal = (new Vector3f(start)).sub(end);
      float sqrt = class_3532.method_15355(normal.lengthSquared());
      return normal.div(sqrt);
   }

   public static void drawLine(class_4587.class_4665 entry, double minX, double minY, double minZ, double maxX, double maxY, double maxZ, int color, float width, boolean depth) {
      drawLine(entry, new class_243(minX, minY, minZ), new class_243(maxX, maxY, maxZ), color, color, width, depth);
   }

   public static void drawLine(class_243 start, class_243 end, int color, float width, boolean depth) {
      drawLine((class_4587.class_4665)null, start, end, color, color, width, depth);
   }

   public static void drawLine(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width, boolean depth) {
      Line line = new Line(entry, start, end, colorStart, colorEnd, width);
      if (depth) {
         LINE_DEPTH.add(line);
      } else {
         LINE.add(line);
      }

   }

   public static void drawQuad(class_243 x, class_243 y, class_243 w, class_243 z, int color, boolean depth) {
      drawQuad((class_4587.class_4665)null, x, y, w, z, color, depth);
   }

   public static void drawQuad(class_4587.class_4665 entry, class_243 x, class_243 y, class_243 w, class_243 z, int color, boolean depth) {
      Quad quad = new Quad(entry, x, y, w, z, color);
      if (depth) {
         QUAD_DEPTH.add(quad);
      } else {
         QUAD.add(quad);
      }

   }

   public static void drawTexture(class_4587.class_4665 entry, class_2960 id, float x, float y, float width, float height, Vector4i color, boolean depth) {
      Texture texture = new Texture(entry, id, x, y, width, height, color);
      if (depth) {
         TEXTURE_DEPTH.add(texture);
      } else {
         TEXTURE.add(texture);
      }

   }

   private Render3DUtil() {
      throw new UnsupportedOperationException("This is a utility class and cannot be instantiated");
   }

   public static void setLastWorldSpaceMatrix(class_4587.class_4665 lastWorldSpaceMatrix) {
      Render3DUtil.lastWorldSpaceMatrix = lastWorldSpaceMatrix;
   }

   public static void setLastProjMat(Matrix4f lastProjMat) {
      Render3DUtil.lastProjMat = lastProjMat;
   }

   public static record Texture(class_4587.class_4665 entry, class_2960 id, float x, float y, float width, float height, Vector4i color) {
   }

   public static record Line(class_4587.class_4665 entry, class_243 start, class_243 end, int colorStart, int colorEnd, float width) {
   }

   public static record Quad(class_4587.class_4665 entry, class_243 x, class_243 y, class_243 w, class_243 z, int color) {
   }
}
