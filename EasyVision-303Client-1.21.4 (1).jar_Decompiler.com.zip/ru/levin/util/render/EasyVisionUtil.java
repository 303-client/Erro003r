package ru.levin.util.render;

import java.util.HashSet;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7922;
import net.minecraft.class_7923;
import ru.levin.modules.misc.EasyVision;

public final class EasyVisionUtil {
   private static final Set<Object> VISIBLE_BLOCKS = new HashSet();
   private static String lastConfig;
   private static boolean lastEnabled;
   private static boolean initialized;

   private EasyVisionUtil() {
   }

   public static void refresh(EasyVision var0) {
      if (var0 != null) {
         String var1 = var0.getBlockIds();
         if (var1 == null) {
            var1 = "";
         }

         boolean var2 = var0.state;
         if (!initialized || var2 != lastEnabled || !Objects.equals(var1, lastConfig)) {
            VISIBLE_BLOCKS.clear();
            if (var2) {
               HashSet var3 = new HashSet();
               class_7922 var4 = class_7923.field_41175;

               for(String var8 : var1.split("[,;\\s]+")) {
                  String var9 = var8.trim().toLowerCase(Locale.ROOT);
                  if (!var9.isEmpty()) {
                     if (var9.indexOf(58) < 0) {
                        var9 = "minecraft:" + var9;
                     }

                     class_2960 var10 = class_2960.method_12829(var9);
                     if (var10 != null) {
                        Optional var11 = var4.method_17966(var10);
                        Objects.requireNonNull(var3);
                        var11.ifPresent(var3::add);
                     }
                  }
               }

               VISIBLE_BLOCKS.addAll(var3);
            }

            lastConfig = var1;
            lastEnabled = var2;
            initialized = true;
            class_310 var12 = class_310.method_1551();
            if (var12 != null && var12.field_1687 != null && var12.field_1769 != null) {
               var12.field_1769.method_3279();
            }

         }
      }
   }

   public static boolean shouldRender(class_2680 var0) {
      return var0 != null && VISIBLE_BLOCKS.contains(var0.method_26204());
   }
}
