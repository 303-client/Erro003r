package ru.levin.util.render;

import com.google.common.base.Supplier;
import com.google.common.base.Suppliers;
import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_10142;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_265;
import net.minecraft.class_276;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5944;
import net.minecraft.class_6367;
import net.minecraft.class_7833;
import net.minecraft.class_9801;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import ru.levin.manager.IMinecraft;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.render.providers.ResourceProvider;
import ru.levin.util.shader.ShaderManager;

public class RenderUtil implements IMinecraft {
   private static final Supplier<class_6367> TEMP_FBO_SUPPLIER = Suppliers.memoize(() -> new class_6367(mc.method_22683().method_4489(), mc.method_22683().method_4506(), false));

   private static class_276 getMainFbo() {
      return mc.method_1522();
   }

   public static boolean isHovered(int mouseX, int mouseY, double x, double y, double width, double height) {
      return (double)mouseX > x && (double)mouseX < x + width && (double)mouseY > y && (double)mouseY < y + height;
   }

   public static boolean isInRegion(double mouseX, double mouseY, double x, double y, double width, double height) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   public static boolean isInRegion(int mouseX, int mouseY, int x, int y, int width, int height) {
      return mouseX >= x && mouseX <= x + width && mouseY >= y && mouseY <= y + height;
   }

   public static int injectAlpha(int color, int alpha) {
      alpha = class_3532.method_15340(alpha, 0, 255);
      return alpha << 24 | color & 16777215;
   }

   public static class_243 interpolatePos(float prevX, float prevY, float prevZ, float x, float y, float z) {
      class_243 camPos = mc.method_1561().field_4686.method_19326();
      double delta = (double)IMinecraft.tickCounter().method_60637(true);
      return new class_243(MathUtil.interpolate((double)prevX, (double)x, delta) - camPos.field_1352, MathUtil.interpolate((double)prevY, (double)y, delta) - camPos.field_1351, MathUtil.interpolate((double)prevZ, (double)z, delta) - camPos.field_1350);
   }

   public static int applyOpacity(int color, float opacity) {
      opacity = class_3532.method_15363(opacity, 0.0F, 1.0F);
      int alpha = (int)((float)(color >>> 24 & 255) * opacity);
      return alpha << 24 | color & 16777215;
   }

   private static void setShaderUniforms(class_5944 shader, float width, float height, Vector4f radius, float smoothness) {
      shader.method_34582("Size").method_1255(width, height);
      shader.method_34582("Radius").method_35657(radius.x, radius.y, radius.z, radius.w);
      shader.method_34582("Smoothness").method_1251(smoothness);
   }

   private static void setShaderUniforms(class_5944 shader, float width, float height, float radius, float smoothness) {
      setShaderUniforms(shader, width, height, new Vector4f(radius, radius, radius, radius), smoothness);
   }

   public static void drawRoundedRect(class_4587 matrices, float x, float y, float width, float height, float rounding, int color) {
      drawRoundedRect(matrices, x, y, width, height, new Vector4f(rounding, rounding, rounding, rounding), color);
   }

   public static void drawRoundedRect(class_4587 matrices, float x, float y, float width, float height, Vector4f rounding, int color) {
      enableRender();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.RECTANGLE_SHADER_KEY);
      setShaderUniforms(shader, width, height, rounding, 1.0F);
      ShaderManager.vertexShader(matrices, x, y, width, height, color);
      disableRender();
   }

   public static void rectRGB(class_4587 matrices, float x, float y, float width, float height, float rounding, int color1, int color2, int color3, int color4) {
      rectRGB(matrices, x, y, width, height, new Vector4f(rounding, rounding, rounding, rounding), color1, color2, color3, color4);
   }

   public static void rectRGB(class_4587 matrices, float x, float y, float width, float height, Vector4f rounding, int color1, int color2, int color3, int color4) {
      enableRender();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.RECTANGLE_SHADER_KEY);
      setShaderUniforms(shader, width, height, rounding, 1.0F);
      ShaderManager.vertexShader(matrices, x, y, width, height, color1, color2, color3, color4);
      disableRender();
   }

   public static void drawRoundedBorder(class_4587 matrices, float x, float y, float width, float height, float rounding, float thickness, int color) {
      drawRoundedBorder(matrices, x, y, width, height, new Vector4f(rounding, rounding, rounding, rounding), thickness, color);
   }

   public static void drawRoundedBorder(class_4587 matrices, float x, float y, float width, float height, Vector4f rounding, float thickness, int color) {
      enableRender();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.RECTANGLE_BORDER_SHADER_KEY);
      shader.method_34582("Size").method_1255(width, height);
      shader.method_34582("Radius").method_35657(rounding.x, rounding.y, rounding.z, rounding.w);
      shader.method_34582("Thickness").method_1251(thickness);
      shader.method_34582("Smoothness").method_1251(1.0F);
      ShaderManager.vertexShader(matrices, x, y, width, height, color);
      disableRender();
   }

   public static void drawBlur(class_4587 matrices, float x, float y, float width, float height, float rounding, float blurRadius, int color) {
      drawBlur(matrices, x, y, width, height, new Vector4f(rounding, rounding, rounding, rounding), blurRadius, color);
   }

   public static void drawBlur(class_4587 matrices, float x, float y, float width, float height, Vector4f rounding, float blurRadius, int color) {
      class_6367 fbo = (class_6367)TEMP_FBO_SUPPLIER.get();
      class_276 mainFbo = getMainFbo();
      if (fbo.field_1482 != mainFbo.field_1482 || fbo.field_1481 != mainFbo.field_1481) {
         fbo.method_1234(mainFbo.field_1482, mainFbo.field_1481);
      }

      enableRender();
      fbo.method_1235(false);
      mainFbo.method_1237(fbo.field_1482, fbo.field_1481);
      mainFbo.method_1235(false);
      class_5944 shader = RenderSystem.setShader(ResourceProvider.BLUR_SHADER_KEY);
      RenderSystem.setShaderTexture(0, fbo.method_30277());
      shader.method_34582("Size").method_1255(width, height);
      shader.method_34582("Radius").method_35657(rounding.x, rounding.y, rounding.z, rounding.w);
      shader.method_34582("Smoothness").method_1251(1.0F);
      shader.method_34582("BlurRadius").method_1251(blurRadius);
      ShaderManager.vertexShader(matrices, x, y, width, height, color);
      RenderSystem.setShaderTexture(0, 0);
      disableRender();
   }

   public static void drawLiquidRect(class_4587 matrices, float x, float y, float width, float height, Vector4f rounding, float cornerSmoothness, float fresnelPower, float fresnelAlpha, float baseAlpha, boolean fresnelInvert, float fresnelMix, float distortStrength, ColorRGBA color) {
      matrices.method_22903();
      Matrix4f matrix4f = matrices.method_23760().method_23761();
      class_276 screenFBO = mc.method_1522();
      int screenTexture = screenFBO.method_30277();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.GLASS_SHADER_KEY);
      class_287 builder = RenderSystem.renderThreadTesselator().method_60827(class_5596.field_27382, class_290.field_1575);
      shader.method_34582("ModelViewMat").method_1250(matrix4f);
      shader.method_34582("ProjMat").method_1250(RenderSystem.getProjectionMatrix());
      shader.method_34582("Size").method_1255(width, height);
      shader.method_34582("Radius").method_35657(rounding.x, rounding.y, rounding.z, rounding.w);
      shader.method_34582("Smoothness").method_1251(1.0F);
      shader.method_34582("CornerSmoothness").method_1251(cornerSmoothness);
      shader.method_34582("GlobalAlpha").method_1251((float)color.getAlpha() / 255.0F);
      shader.method_34582("FresnelPower").method_1251(fresnelPower);
      shader.method_34582("FresnelColor").method_1249(1.0F, 1.0F, 1.0F);
      shader.method_34582("FresnelAlpha").method_1251(fresnelAlpha);
      shader.method_34582("BaseAlpha").method_1251(baseAlpha);
      shader.method_34582("FresnelInvert").method_35649(fresnelInvert ? 1 : 0);
      shader.method_34582("FresnelMix").method_1251(fresnelMix);
      shader.method_34582("DistortStrength").method_1251(distortStrength);
      RenderSystem.setShaderTexture(0, screenTexture);
      enableRender();
      float scaleX = (float)screenFBO.field_1482 / (float)mc.method_22683().method_4486();
      float scaleY = (float)screenFBO.field_1481 / (float)mc.method_22683().method_4502();
      float fx = x * scaleX;
      float fy = y * scaleY;
      float fwidth = width * scaleX;
      float fheight = height * scaleY;
      fy = (float)screenFBO.field_1481 - fy - fheight;
      float u0 = fx / (float)screenFBO.field_1482;
      float v0 = fy / (float)screenFBO.field_1481;
      float u1 = (fx + fwidth) / (float)screenFBO.field_1482;
      float v1 = (fy + fheight) / (float)screenFBO.field_1481;
      int r = color.getRed();
      int g = color.getGreen();
      int b = color.getBlue();
      int a = color.getAlpha();
      builder.method_22918(matrix4f, x, y, 0.0F).method_22913(u0, v1).method_1336(r, g, b, a);
      builder.method_22918(matrix4f, x, y + height, 0.0F).method_22913(u0, v0).method_1336(r, g, b, a);
      builder.method_22918(matrix4f, x + width, y + height, 0.0F).method_22913(u1, v0).method_1336(r, g, b, a);
      builder.method_22918(matrix4f, x + width, y, 0.0F).method_22913(u1, v1).method_1336(r, g, b, a);
      RenderUtil.render3D.endBuilding(builder);
      RenderSystem.setShaderTexture(0, 0);
      disableRender();
      RenderSystem.enableDepthTest();
      matrices.method_22909();
   }

   public static void drawTexture(class_4587 matrices, Object texture, float x, float y, float width, float height, float rounding, int color) {
      enableRender();
      class_2960 textureId;
      if (texture instanceof String path) {
         textureId = class_2960.method_60655("exosware", path);
      } else {
         if (!(texture instanceof class_2960)) {
            throw new IllegalArgumentException("Texture must be Identifier or String");
         }

         class_2960 id = (class_2960)texture;
         textureId = id;
      }

      int glTextureId = mc.method_1531().method_4619(textureId).method_4624();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.TEXTURE_SHADER_KEY);
      RenderSystem.setShaderTexture(0, glTextureId);
      shader.method_34582("Size").method_1255(width, height);
      shader.method_34582("Radius").method_35657(rounding, rounding, rounding, rounding);
      shader.method_34582("Smoothness").method_1251(1.0F);
      Matrix4f mat = matrices.method_23760().method_23761();
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);
      buffer.method_22918(mat, x, y, 0.0F).method_22913(0.0F, 0.0F).method_39415(color);
      buffer.method_22918(mat, x + width, y, 0.0F).method_22913(1.0F, 0.0F).method_39415(color);
      buffer.method_22918(mat, x + width, y + height, 0.0F).method_22913(1.0F, 1.0F).method_39415(color);
      buffer.method_22918(mat, x, y + height, 0.0F).method_22913(0.0F, 1.0F).method_39415(color);
      RenderUtil.render3D.endBuilding(buffer);
      disableRender();
   }

   public static void drawCircleBorder(class_4587 matrices, float centerX, float centerY, float diameter, float thickness, int color) {
      enableRender();
      class_5944 shader = RenderSystem.setShader(ResourceProvider.RECTANGLE_BORDER_SHADER_KEY);
      float radius = diameter / 2.0F;
      shader.method_34582("Size").method_1255(diameter, diameter);
      shader.method_34582("Radius").method_35657(radius, radius, radius, radius);
      shader.method_34582("Thickness").method_1251(thickness);
      shader.method_34582("Smoothness").method_1251(1.0F);
      ShaderManager.vertexShader(matrices, centerX - radius, centerY - radius, diameter, diameter, color);
      disableRender();
   }

   public static void drawLine(float x1, float y1, float x2, float y2, int color) {
      RenderSystem.setShader(class_10142.field_53876);
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_29345, class_290.field_1576);
      buffer.method_22912(x1, y1, 0.0F).method_39415(color);
      buffer.method_22912(x2, y2, 0.0F).method_39415(color);
      RenderUtil.render3D.endBuilding(buffer);
   }

   public static void drawCircle(class_4587 matrix, float x, float y, float radius, int color) {
      drawRoundedRect(matrix, x - radius / 2.0F, y - radius / 2.0F, radius, radius, radius / 2.0F - 1.0F, color);
   }

   public static void enableRender(GlStateManager.class_4535 srcFactor, GlStateManager.class_4534 dstFactor) {
      RenderSystem.enableBlend();
      RenderSystem.blendFunc(srcFactor, dstFactor);
   }

   public static void enableRender() {
      RenderSystem.enableBlend();
      RenderSystem.defaultBlendFunc();
      RenderSystem.disableCull();
   }

   public static void disableRender() {
      RenderSystem.enableCull();
      RenderSystem.disableBlend();
   }

   public class render3D {
      public static final Matrix4f lastProjMat = new Matrix4f();
      public static final Matrix4f lastModMat = new Matrix4f();
      public static final Matrix4f lastWorldSpaceMatrix = new Matrix4f();

      public static void setTranslation(class_4587 matrixStack) {
         lastProjMat.set(RenderSystem.getProjectionMatrix());
         lastModMat.set(RenderSystem.getModelViewMatrix());
         lastWorldSpaceMatrix.set(matrixStack.method_23760().method_23761());
      }

      public static class_243 worldSpaceToScreenSpace(class_243 pos) {
         class_4184 camera = IMinecraft.mc.method_1561().field_4686;
         int displayHeight = IMinecraft.mc.method_22683().method_4507();
         int[] viewport = new int[4];
         GL11.glGetIntegerv(2978, viewport);
         Vector3f target = new Vector3f();
         double deltaX = pos.field_1352 - camera.method_19326().field_1352;
         double deltaY = pos.field_1351 - camera.method_19326().field_1351;
         double deltaZ = pos.field_1350 - camera.method_19326().field_1350;
         Vector4f transformedCoordinates = (new Vector4f((float)deltaX, (float)deltaY, (float)deltaZ, 1.0F)).mul(lastWorldSpaceMatrix);
         Matrix4f matrixProj = new Matrix4f(lastProjMat);
         Matrix4f matrixModel = new Matrix4f(lastModMat);
         matrixProj.mul(matrixModel).project(transformedCoordinates.x(), transformedCoordinates.y(), transformedCoordinates.z(), viewport, target);
         return new class_243((double)target.x / IMinecraft.mc.method_22683().method_4495(), (double)((float)displayHeight - target.y) / IMinecraft.mc.method_22683().method_4495(), (double)target.z);
      }

      public static class_4587 matrixFrom(double x, double y, double z) {
         class_4587 matrices = new class_4587();
         class_4184 camera = IMinecraft.mc.field_1773.method_19418();
         matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
         matrices.method_22904(x - camera.method_19326().field_1352, y - camera.method_19326().field_1351, z - camera.method_19326().field_1350);
         return matrices;
      }

      public static void drawShape(class_2338 blockPos, class_265 shape, boolean depth, int color1, int color2, int color3, int color4) {
         class_243 offset = class_243.method_24954(blockPos);
         shape.method_1089((minX, minY, minZ, maxX, maxY, maxZ) -> {
            class_238 box = (new class_238(minX, minY, minZ, maxX, maxY, maxZ)).method_997(offset);
            class_4587 matrices = matrixFrom(box.field_1323, box.field_1322, box.field_1321);
            class_238 shiftedBox = box.method_997(new class_243(-box.field_1323, -box.field_1322, -box.field_1321));
            renderFillBox(matrices, shiftedBox, depth, color1, color2, color3, color4);
         });
      }

      public static void drawHoleOutline(class_238 box, int color, float lineWidth) {
         GL11.glEnable(2881);
         RenderUtil.enableRender();
         class_4587 matrices = matrixFrom(box.field_1323, box.field_1322, box.field_1321);
         class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27377, class_290.field_29337);
         RenderSystem.setShader(class_10142.field_53864);
         RenderSystem.lineWidth(lineWidth);
         box = box.method_997((new class_243(box.field_1323, box.field_1322, box.field_1321)).method_22882());
         float x1 = (float)box.field_1323;
         float y1 = (float)box.field_1322;
         float y2 = (float)box.field_1325;
         float z1 = (float)box.field_1321;
         float x2 = (float)box.field_1320;
         float z2 = (float)box.field_1324;
         ShaderManager.vertexLine(matrices, buffer, x1, y2, z1, x2, y2, z1, color);
         ShaderManager.vertexLine(matrices, buffer, x2, y2, z1, x2, y2, z2, color);
         ShaderManager.vertexLine(matrices, buffer, x2, y2, z2, x1, y2, z2, color);
         ShaderManager.vertexLine(matrices, buffer, x1, y2, z2, x1, y2, z1, color);
         ShaderManager.vertexLine(matrices, buffer, x1, y1, z1, x2, y1, z1, color);
         ShaderManager.vertexLine(matrices, buffer, x2, y1, z1, x2, y1, z2, color);
         ShaderManager.vertexLine(matrices, buffer, x2, y1, z2, x1, y1, z2, color);
         ShaderManager.vertexLine(matrices, buffer, x1, y1, z2, x1, y1, z1, color);
         ShaderManager.vertexLine(matrices, buffer, x1, y1, z1, x1, y2, z1, color);
         ShaderManager.vertexLine(matrices, buffer, x2, y1, z2, x2, y2, z2, color);
         ShaderManager.vertexLine(matrices, buffer, x1, y1, z2, x1, y2, z2, color);
         ShaderManager.vertexLine(matrices, buffer, x2, y1, z1, x2, y2, z1, color);
         endBuilding(buffer);
         RenderUtil.disableRender();
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glDisable(2881);
      }

      private static void renderFillBox(class_4587 stack, class_238 box, boolean depth, int color1, int color2, int color3, int color4) {
         class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1576);
         Matrix4f matrix = stack.method_23760().method_23761();
         float minX = (float)box.field_1323;
         float minY = (float)box.field_1322;
         float minZ = (float)box.field_1321;
         float maxX = (float)box.field_1320;
         float maxY = (float)box.field_1325;
         float maxZ = (float)box.field_1324;
         if (depth) {
            RenderSystem.disableDepthTest();
            RenderUtil.enableRender();
            RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE);
         }

         RenderSystem.setShader(class_10142.field_53876);
         buffer.method_22918(matrix, minX, minY, minZ).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
         buffer.method_22918(matrix, minX, minY, maxZ).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
         buffer.method_22918(matrix, maxX, minY, maxZ).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
         buffer.method_22918(matrix, maxX, minY, minZ).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
         buffer.method_22918(matrix, minX, maxY, minZ).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
         buffer.method_22918(matrix, maxX, maxY, minZ).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
         buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
         buffer.method_22918(matrix, minX, maxY, maxZ).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
         buffer.method_22918(matrix, minX, minY, minZ).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
         buffer.method_22918(matrix, minX, maxY, minZ).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
         buffer.method_22918(matrix, maxX, maxY, minZ).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
         buffer.method_22918(matrix, maxX, minY, minZ).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
         buffer.method_22918(matrix, minX, minY, maxZ).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
         buffer.method_22918(matrix, maxX, minY, maxZ).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
         buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
         buffer.method_22918(matrix, minX, maxY, maxZ).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
         buffer.method_22918(matrix, minX, minY, minZ).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
         buffer.method_22918(matrix, minX, minY, maxZ).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
         buffer.method_22918(matrix, minX, maxY, maxZ).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
         buffer.method_22918(matrix, minX, maxY, minZ).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
         buffer.method_22918(matrix, maxX, minY, minZ).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
         buffer.method_22918(matrix, maxX, minY, maxZ).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
         buffer.method_22918(matrix, maxX, maxY, maxZ).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
         buffer.method_22918(matrix, maxX, maxY, minZ).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
         endBuilding(buffer);
         if (depth) {
            RenderUtil.disableRender();
            RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         }

      }

      public static void setFilledBoxVertexes(class_287 bufferBuilder, Matrix4f m, class_238 box, Color c) {
         float minX = (float)(box.field_1323 - IMinecraft.mc.method_1561().field_4686.method_19326().method_10216());
         float minY = (float)(box.field_1322 - IMinecraft.mc.method_1561().field_4686.method_19326().method_10214());
         float minZ = (float)(box.field_1321 - IMinecraft.mc.method_1561().field_4686.method_19326().method_10215());
         float maxX = (float)(box.field_1320 - IMinecraft.mc.method_1561().field_4686.method_19326().method_10216());
         float maxY = (float)(box.field_1325 - IMinecraft.mc.method_1561().field_4686.method_19326().method_10214());
         float maxZ = (float)(box.field_1324 - IMinecraft.mc.method_1561().field_4686.method_19326().method_10215());
         bufferBuilder.method_22918(m, minX, minY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, minY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, minY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, minY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, minY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, maxY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, maxY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, minY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, minY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, maxY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, maxY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, minY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, minY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, minY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, maxY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, maxY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, minY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, minY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, maxY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, maxY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, maxY, minZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, minX, maxY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, maxY, maxZ).method_39415(c.getRGB());
         bufferBuilder.method_22918(m, maxX, maxY, minZ).method_39415(c.getRGB());
      }

      public static void endBuilding(class_287 bb) {
         class_9801 builtBuffer = bb.method_60794();
         if (builtBuffer != null) {
            class_286.method_43433(builtBuffer);
         }

      }
   }
}
