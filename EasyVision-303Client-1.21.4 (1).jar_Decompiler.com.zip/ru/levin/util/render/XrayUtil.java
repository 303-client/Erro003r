package ru.levin.util.render;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import ru.levin.modules.misc.Xray;

public final class XrayUtil {
   private static final Set<Object> VISIBLE_BLOCKS = new HashSet();
   private static boolean lastState;
   private static String lastConfig;

   private XrayUtil() {
   }

   public static void tick(Xray xray) {
      if (class_310.method_1551().field_1687 != null) {
         String config = xray.blockConfig();
         if (lastState != xray.state || !config.equals(lastConfig)) {
            lastState = xray.state;
            lastConfig = config;
            rebuild(xray);
            class_310.method_1551().field_1769.method_3279();
         }

      }
   }

   private static void rebuild(Xray xray) {
      VISIBLE_BLOCKS.clear();
      if (xray.state) {
         if (Xray.ancient.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_22109);
         }

         if (Xray.diamond.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10442);
         }

         if (Xray.emerald.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10013);
         }

         if (Xray.gold.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10571);
         }

         if (Xray.iron.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10212);
         }

         if (Xray.coal.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10418);
         }

         if (Xray.redstone.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10080);
         }

         if (Xray.lapise.get()) {
            VISIBLE_BLOCKS.add(class_2246.field_10090);
         }

      }
   }

   public static boolean shouldRender(class_2680 state) {
      return !lastState || VISIBLE_BLOCKS.contains(state.method_26204());
   }
}
