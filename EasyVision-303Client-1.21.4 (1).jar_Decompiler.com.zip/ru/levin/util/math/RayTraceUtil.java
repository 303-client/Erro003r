package ru.levin.util.math;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_1937;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.manager.IMinecraft;

public class RayTraceUtil implements IMinecraft {
   private static final Map<UUID, Long> lastHitTimes = new HashMap();
   private static final long EFFECT_DURATION = 200L;

   public static void markHit(class_1297 entity) {
      lastHitTimes.put(entity.method_5667(), System.currentTimeMillis());
   }

   public static float getHitProgress(class_1297 entity) {
      Long hitTime = (Long)lastHitTimes.get(entity.method_5667());
      if (hitTime == null) {
         return 0.0F;
      } else {
         long elapsed = System.currentTimeMillis() - hitTime;
         if (elapsed > 200L) {
            lastHitTimes.remove(entity.method_5667());
            return 0.0F;
         } else {
            return 1.0F - (float)elapsed / 200.0F;
         }
      }
   }

   private static class_243 getVector(float pitch, float yaw) {
      float yawRad = (float)Math.toRadians((double)yaw);
      float pitchRad = (float)Math.toRadians((double)pitch);
      float cosPitch = (float)Math.cos((double)(-pitchRad));
      return new class_243(-Math.sin((double)yawRad) * (double)cosPitch, -Math.sin((double)pitchRad), Math.cos((double)yawRad) * (double)cosPitch);
   }

   public static class_1297 getMouseOver(class_1297 target, float yaw, float pitch, double distance) {
      class_1297 entity = mc.method_1560();
      if (entity != null && mc.field_1687 != null && target != null) {
         class_238 playerBox = entity.method_5829();
         class_238 targetBox = target.method_5829();
         class_243 startVec = entity.method_33571();
         class_243 directionVec = getVector(pitch, yaw);
         class_243 endVec = startVec.method_1031(directionVec.field_1352 * distance, directionVec.field_1351 * distance, directionVec.field_1350 * distance);
         if (playerBox.method_994(targetBox)) {
            class_3966 hitResult = rayCastEntity(distance, yaw, pitch, (e) -> e == target && !e.method_7325() && e.method_49108());
            if (hitResult != null && hitResult.method_17782() == target) {
               return target;
            }
         }

         class_3966 entityHitResult = rayCastEntities(entity, startVec, endVec, targetBox, (e) -> e == target && !e.method_7325() && e.method_49108(), distance);
         return entityHitResult != null && startVec.method_1022(entityHitResult.method_17784()) <= distance ? entityHitResult.method_17782() : null;
      } else {
         return null;
      }
   }

   public static class_3966 rayCastEntity(double range, float yaw, float pitch, Predicate<class_1297> filter) {
      class_1297 entity = mc.method_1560();
      if (entity != null && mc.field_1687 != null) {
         class_243 cameraVec = entity.method_5836(1.0F);
         float pitchRad = pitch * ((float)Math.PI / 180F);
         float yawRad = -yaw * ((float)Math.PI / 180F);
         float cosPitch = (float)Math.cos((double)pitchRad);
         float sinPitch = (float)Math.sin((double)pitchRad);
         float cosYaw = (float)Math.cos((double)yawRad);
         float sinYaw = (float)Math.sin((double)yawRad);
         class_243 rotationVec = new class_243((double)(sinYaw * cosPitch), (double)(-sinPitch), (double)(cosYaw * cosPitch));
         class_243 end = cameraVec.method_1031(rotationVec.field_1352 * range, rotationVec.field_1351 * range, rotationVec.field_1350 * range);
         class_238 box = entity.method_5829().method_18804(rotationVec.method_1021(range)).method_1009((double)1.0F, (double)1.0F, (double)1.0F);
         return class_1675.method_18075(entity, cameraVec, end, box, filter, range * range);
      } else {
         return null;
      }
   }

   private static class_3966 rayCastEntities(class_1297 source, class_243 start, class_243 end, class_238 boundingBox, Predicate<class_1297> predicate, double maxDistance) {
      class_1937 world = source.method_37908();
      double closestDistance = maxDistance;
      class_1297 closestEntity = null;
      class_243 closestHitPos = null;

      for(class_1297 entity : world.method_8390(class_1297.class, boundingBox, predicate)) {
         if (entity != source) {
            class_238 entityBox = entity.method_5829();
            Optional<class_243> hit = entityBox.method_992(start, end);
            if (hit.isPresent()) {
               class_243 hitPos = (class_243)hit.get();
               double distance = start.method_1022(hitPos);
               if (distance < closestDistance) {
                  closestEntity = entity;
                  closestHitPos = hitPos;
                  closestDistance = distance;
               }
            }
         }
      }

      if (closestEntity != null) {
         return new class_3966(closestEntity, closestHitPos);
      } else {
         return null;
      }
   }

   public static class_3965 rayCast(double range, float yaw, float pitch, boolean includeFluids) {
      class_1297 entity = mc.method_1560();
      if (entity != null && mc.field_1687 != null) {
         class_243 start = entity.method_5836(1.0F);
         float pitchRad = pitch * ((float)Math.PI / 180F);
         float yawRad = -yaw * ((float)Math.PI / 180F);
         float cosPitch = (float)Math.cos((double)pitchRad);
         float sinPitch = (float)Math.sin((double)pitchRad);
         float cosYaw = (float)Math.cos((double)yawRad);
         float sinYaw = (float)Math.sin((double)yawRad);
         class_243 rotationVec = new class_243((double)(sinYaw * cosPitch), (double)(-sinPitch), (double)(cosYaw * cosPitch));
         class_243 end = start.method_1031(rotationVec.field_1352 * range, rotationVec.field_1351 * range, rotationVec.field_1350 * range);
         class_1937 world = mc.field_1687;
         class_3959.class_242 fluidHandling = includeFluids ? class_242.field_1347 : class_242.field_1348;
         class_3959 context = new class_3959(start, end, class_3960.field_17559, fluidHandling, entity);
         return world.method_17742(context);
      } else {
         return null;
      }
   }
}
