package ru.levin.util.math;

import java.util.concurrent.ThreadLocalRandom;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import ru.levin.manager.IMinecraft;

public class MathUtil implements IMinecraft {
   public static double deltaTick() {
      return mc.method_47599() > 0 ? (double)1.0F / (double)mc.method_47599() : (double)1.0F;
   }

   public static float fast(float end, float start, float multiple) {
      return (1.0F - class_3532.method_15363((float)(deltaTick() * (double)multiple), 0.0F, 1.0F)) * end + class_3532.method_15363((float)(deltaTick() * (double)multiple), 0.0F, 1.0F) * start;
   }

   public static float lerp(float end, float start, float multiple) {
      return (float)((double)end + (double)(start - end) * class_3532.method_15350(deltaTick() * (double)multiple, (double)0.0F, (double)1.0F));
   }

   public static double lerp(double end, double start, double multiple) {
      return end + (start - end) * class_3532.method_15350(deltaTick() * multiple, (double)0.0F, (double)1.0F);
   }

   public static float faster(float current, float target, float speed) {
      float diff = target - current;
      float deltaTime = 1.0F / (float)mc.method_47599();
      deltaTime = Math.min(deltaTime, 0.01F);
      float step = speed * deltaTime;
      return Math.abs(diff) <= step ? target : current + Math.copySign(step, diff);
   }

   public static double random(double min, double max) {
      return ThreadLocalRandom.current().nextDouble() * (max - min) + min;
   }

   public static float random(float min, float max) {
      return (float)(Math.random() * (double)(max - min) + (double)min);
   }

   public static int interpolateInt(int oldValue, int newValue, double interpolationValue) {
      return interpolate((double)oldValue, (double)newValue, (double)((float)interpolationValue)).intValue();
   }

   private static int interpolateInt(int start, int end, float amount) {
      return Math.round((float)start + (float)(end - start) * amount);
   }

   public static float interpolateFloat(float oldValue, float newValue, double delta) {
      return interpolate((double)oldValue, (double)newValue, delta).floatValue();
   }

   public static Double interpolate(double old, double value, double interpolation) {
      return old + (value - old) * interpolation;
   }

   public static float interpolateFloat(float old, float value, float interpolation) {
      return old + (value - old) * interpolation;
   }

   public static float interpolateAngle(float start, float end, float progress) {
      float difference = class_3532.method_15393(end - start);
      return start + difference * class_3532.method_15363(progress, 0.0F, 1.0F);
   }

   public static float smoothstep(float e0, float e1, float x) {
      float t = class_3532.method_15363((x - e0) / (e1 - e0), 0.0F, 1.0F);
      return t * t * (3.0F - 2.0F * t);
   }

   public static class_243 getClosestVec(class_1297 entity) {
      class_243 eyePosVec = mc.field_1724.method_33571();
      return getClosestVec(eyePosVec, entity).method_1020(eyePosVec);
   }

   public static class_243 getClosestVec(class_243 vec, class_1297 entity) {
      return getClosestVec(vec, entity.method_5829());
   }

   public static class_243 getClosestVec(class_243 vec, class_238 AABB) {
      return new class_243(clamp(vec.field_1352, AABB.field_1323, AABB.field_1320), clamp(vec.method_10214(), AABB.field_1322, AABB.field_1325), clamp(vec.method_10215(), AABB.field_1321, AABB.field_1324));
   }

   public static double getStrictDistance(class_1297 entity) {
      return getClosestVec(entity).method_1033();
   }

   public static int getRandom(int min, int max) {
      return (int)getRandom((float)min, (float)max + 1.0F);
   }

   private static float getRandom(float min, float max) {
      return (float)getRandom((double)min, (double)max);
   }

   private static double getRandom(double min, double max) {
      if (min == max) {
         return min;
      } else {
         if (min > max) {
            double d = min;
            min = max;
            max = d;
         }

         return ThreadLocalRandom.current().nextDouble(min, max);
      }
   }

   public static float interpolateSmooth(double smooth, float prev, float orig) {
      return (float)lerp((double)mc.method_61966().method_60638() / smooth, (double)prev, (double)orig);
   }

   public static float clamp(float value, float min, float max) {
      return Math.max(min, Math.min(max, value));
   }

   public static double clamp(double value, double min, double max) {
      return Math.max(min, Math.min(max, value));
   }

   public static int clamp(int value, int min, int max) {
      return Math.max(min, Math.min(max, value));
   }
}
