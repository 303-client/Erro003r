package ru.levin.util;

import net.minecraft.class_1268;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_2401;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import org.lwjgl.glfw.GLFW;
import ru.levin.manager.Manager;

public final class ErrorKillerUtil {
   private static int step = -1;
   private static long lastStepTime = 0L;
   private static boolean lastRightClickPressed = false;
   private static boolean moveFixSprint = false;
   private static int originalSlot = -1;
   private static class_3965 target = null;
   private static Mode currentMode;
   private static boolean useOriginalSlotForPlace;

   private ErrorKillerUtil() {
   }

   public static void requestAction(class_310 client) {
      requestAction(client, ErrorKillerUtil.Mode.COBWEB);
   }

   public static void requestAction(class_310 client, Mode mode) {
      if (client != null && client.field_1724 != null && client.field_1761 != null && isEnabled() && client.field_1755 == null && step == -1 && client.field_1765 != null && client.field_1765.method_17783() == class_240.field_1332) {
         originalSlot = client.field_1724.method_31548().field_7545;
         target = normalizeLeverTarget(client, (class_3965)client.field_1765);
         currentMode = mode == null ? ErrorKillerUtil.Mode.COBWEB : mode;
         useOriginalSlotForPlace = false;
         step = 0;
      }

   }

   public static void tick(class_310 client) {
      if (client != null && client.field_1724 != null && client.field_1761 != null) {
         if (!isEnabled()) {
            lastRightClickPressed = false;
            reset(client);
         } else if (client.field_1755 != null) {
            lastRightClickPressed = false;
         } else if (isHeadInCobweb(client)) {
            lastRightClickPressed = false;
            reset(client);
         } else if (step == -1) {
            detectAutoTrigger(client);
         } else {
            applyMoveFix(client);
            runMacro(client);
         }
      } else {
         lastRightClickPressed = false;
         reset(client);
      }

   }

   private static boolean isEnabled() {
      try {
         return Manager.FUNCTION_MANAGER.fastErrorKiller != null && Manager.FUNCTION_MANAGER.fastErrorKiller.state;
      } catch (Exception var1) {
         return false;
      }
   }

   private static void reset(class_310 client) {
      if (client != null && client.field_1724 != null && originalSlot != -1) {
         client.field_1724.method_31548().field_7545 = originalSlot;
      }

      step = -1;
      target = null;
      originalSlot = -1;
      currentMode = ErrorKillerUtil.Mode.COBWEB;
      useOriginalSlotForPlace = false;
      moveFixSprint = false;
   }

   private static void detectAutoTrigger(class_310 client) {
      boolean isRightClick = GLFW.glfwGetMouseButton(client.method_22683().method_4490(), 1) == 1;
      if (isRightClick && !lastRightClickPressed && step == -1) {
         class_1799 handStack = client.field_1724.method_6047();
         if (isValidTriggerItem(client, handStack)) {
            class_239 var4 = client.field_1765;
            if (var4 instanceof class_3965) {
               class_3965 bhr = (class_3965)var4;
               if (isTargetingPlacementOnTrigger(client, bhr)) {
                  originalSlot = client.field_1724.method_31548().field_7545;
                  target = normalizeLeverTarget(client, bhr);
                  if (handStack.method_31574(class_1802.field_8786)) {
                     currentMode = ErrorKillerUtil.Mode.COBWEB;
                     useOriginalSlotForPlace = false;
                  } else {
                     currentMode = ErrorKillerUtil.Mode.OBSIDIAN;
                     useOriginalSlotForPlace = true;
                  }

                  moveFixSprint = client.field_1690 != null && (client.field_1724.method_5624() || client.field_1690.field_1867.method_1434());
                  step = 0;
               }
            }
         }
      }

      lastRightClickPressed = isRightClick;
   }

   private static boolean isValidTriggerItem(class_310 client, class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         if (stack.method_31574(class_1802.field_8786)) {
            return true;
         } else {
            class_1792 var3 = stack.method_7909();
            if (var3 instanceof class_1747) {
               class_1747 blockItem = (class_1747)var3;
               if (client.field_1687 == null) {
                  return false;
               } else {
                  class_2248 block = blockItem.method_7711();
                  return block.method_9564().method_26212(client.field_1687, class_2338.field_10980);
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private static boolean isTargetingPlacementOnTrigger(class_310 client, class_3965 bhr) {
      if (client.field_1687 != null && client.field_1724 != null && bhr != null) {
         class_2338 pos = bhr.method_17777();
         if (pos == null) {
            return false;
         } else {
            class_2248 blockAtPos = client.field_1687.method_8320(pos).method_26204();
            if (!(blockAtPos instanceof class_2401) && !(blockAtPos instanceof class_2269)) {
               class_2338 offsetPos = pos.method_10093(bhr.method_17780());
               class_2248 blockAtOffset = client.field_1687.method_8320(offsetPos).method_26204();
               return blockAtOffset instanceof class_2401 || blockAtOffset instanceof class_2269;
            } else {
               return true;
            }
         }
      } else {
         return false;
      }
   }

   private static class_3965 normalizeLeverTarget(class_310 client, class_3965 bhr) {
      if (client != null && client.field_1687 != null && bhr != null) {
         class_2338 pos = bhr.method_17777();
         class_2248 blockAtPos = client.field_1687.method_8320(pos).method_26204();
         if (blockAtPos instanceof class_2401 || blockAtPos instanceof class_2269) {
            class_2338 supportPos = pos.method_10093(bhr.method_17780().method_10153());
            if (!client.field_1687.method_8320(supportPos).method_26212(client.field_1687, supportPos)) {
               return new class_3965(bhr.method_17784(), bhr.method_17780(), supportPos, false);
            }
         }

         return bhr;
      } else {
         return bhr;
      }
   }

   private static boolean isHeadInCobweb(class_310 client) {
      if (client != null && client.field_1724 != null && client.field_1687 != null) {
         class_2338 headPos = client.field_1724.method_24515().method_10084();
         return client.field_1687.method_8320(headPos).method_27852(class_2246.field_10343);
      } else {
         return false;
      }
   }

   private static void runMacro(class_310 client) {
      long now = System.currentTimeMillis();
      int fluidBucket = -1;
      int emptyBucket = -1;
      int placeSlot = -1;
      boolean placeCobweb = currentMode == ErrorKillerUtil.Mode.COBWEB;
      class_1792 placeItem = placeCobweb ? class_1802.field_8786 : class_1802.field_8281;

      for(int i = 0; i < 9; ++i) {
         class_1799 stack = client.field_1724.method_31548().method_5438(i);
         if (stack.method_31574(class_1802.field_8705) || stack.method_31574(class_1802.field_8187)) {
            fluidBucket = i;
         }

         if (stack.method_31574(class_1802.field_8550)) {
            emptyBucket = i;
         }

         if (stack.method_31574(placeItem)) {
            placeSlot = i;
         }
      }

      if (!placeCobweb && useOriginalSlotForPlace && originalSlot >= 0 && originalSlot <= 8) {
         placeSlot = originalSlot;
      }

      int delayMs = 1;
      class_3965 bhr = target;
      if (bhr == null) {
         class_239 var11 = client.field_1765;
         if (var11 instanceof class_3965) {
            class_3965 hit = (class_3965)var11;
            bhr = normalizeLeverTarget(client, hit);
         }
      }

      if (delayMs <= 1) {
         if (fluidBucket != -1 && placeSlot != -1 && bhr != null) {
            client.field_1724.method_31548().field_7545 = fluidBucket;
            client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
            applyMoveFix(client);
            int toPickUp = fluidBucket != -1 ? fluidBucket : emptyBucket;
            if (toPickUp != -1) {
               client.field_1724.method_31548().field_7545 = toPickUp;
               client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
               applyMoveFix(client);
            }

            client.field_1724.method_31548().field_7545 = placeSlot;
            client.field_1761.method_2896(client.field_1724, class_1268.field_5808, bhr);
            applyMoveFix(client);
         }

         reset(client);
      } else {
         switch (step) {
            case 0:
               if (fluidBucket != -1) {
                  client.field_1724.method_31548().field_7545 = fluidBucket;
                  client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                  applyMoveFix(client);
                  lastStepTime = now;
                  step = 1;
               } else {
                  reset(client);
               }
               break;
            case 1:
               if (now - lastStepTime >= (long)delayMs) {
                  step = 2;
               }
               break;
            case 2:
               int toPick = fluidBucket != -1 ? fluidBucket : emptyBucket;
               if (toPick != -1) {
                  client.field_1724.method_31548().field_7545 = toPick;
                  client.field_1761.method_2919(client.field_1724, class_1268.field_5808);
                  applyMoveFix(client);
               }

               step = 3;
               break;
            case 3:
               if (placeSlot != -1 && bhr != null) {
                  client.field_1724.method_31548().field_7545 = placeSlot;
                  client.field_1761.method_2896(client.field_1724, class_1268.field_5808, bhr);
                  applyMoveFix(client);
               }

               reset(client);
               break;
            default:
               reset(client);
         }
      }

   }

   private static void applyMoveFix(class_310 client) {
      if (moveFixSprint && client != null && client.field_1724 != null && client.field_1690 != null && !client.field_1724.method_5624() && client.field_1690.field_1867.method_1434()) {
         client.field_1724.method_5728(true);
      }

   }

   static {
      currentMode = ErrorKillerUtil.Mode.COBWEB;
      useOriginalSlotForPlace = false;
   }

   public static enum Mode {
      COBWEB,
      OBSIDIAN;

      // $FF: synthetic method
      private static Mode[] $values() {
         return new Mode[]{COBWEB, OBSIDIAN};
      }
   }
}
