package ru.levin.util.shader;

import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import ru.levin.manager.IMinecraft;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.render.RenderUtil;

public class ShaderManager implements IMinecraft {
   public static void vertexShader(class_4587 matrixStack, float x, float y, float width, float height, int color) {
      float[] rgba = ColorUtil.rgba(color);
      Matrix4f matrix = matrixStack.method_23760().method_23761();
      class_287 builder = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1576);
      builder.method_22918(matrix, x, y, 0.0F).method_22915(rgba[0], rgba[1], rgba[2], rgba[3]);
      builder.method_22918(matrix, x, y + height, 0.0F).method_22915(rgba[0], rgba[1], rgba[2], rgba[3]);
      builder.method_22918(matrix, x + width, y + height, 0.0F).method_22915(rgba[0], rgba[1], rgba[2], rgba[3]);
      builder.method_22918(matrix, x + width, y, 0.0F).method_22915(rgba[0], rgba[1], rgba[2], rgba[3]);
      RenderUtil.render3D.endBuilding(builder);
   }

   public static void vertexShader(class_4587 matrixStack, float x, float y, float width, float height, int color1, int color2, int color3, int color4) {
      Matrix4f matrix = matrixStack.method_23760().method_23761();
      class_287 builder = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1576);
      builder.method_22918(matrix, x, y, 0.0F).method_22915((float)ColorUtil.getRed(color1) / 255.0F, (float)ColorUtil.getGreen(color1) / 255.0F, (float)ColorUtil.getBlue(color1) / 255.0F, (float)ColorUtil.getAlpha(color1) / 255.0F);
      builder.method_22918(matrix, x, y + height, 0.0F).method_22915((float)ColorUtil.getRed(color2) / 255.0F, (float)ColorUtil.getGreen(color2) / 255.0F, (float)ColorUtil.getBlue(color2) / 255.0F, (float)ColorUtil.getAlpha(color2) / 255.0F);
      builder.method_22918(matrix, x + width, y + height, 0.0F).method_22915((float)ColorUtil.getRed(color3) / 255.0F, (float)ColorUtil.getGreen(color3) / 255.0F, (float)ColorUtil.getBlue(color3) / 255.0F, (float)ColorUtil.getAlpha(color3) / 255.0F);
      builder.method_22918(matrix, x + width, y, 0.0F).method_22915((float)ColorUtil.getRed(color4) / 255.0F, (float)ColorUtil.getGreen(color4) / 255.0F, (float)ColorUtil.getBlue(color4) / 255.0F, (float)ColorUtil.getAlpha(color4) / 255.0F);
      RenderUtil.render3D.endBuilding(builder);
   }

   public static void vertexLine(class_4587 matrices, class_4588 buffer, float x1, float y1, float z1, float x2, float y2, float z2, int lineColor) {
      Matrix4f model = matrices.method_23760().method_23761();
      class_4587.class_4665 entry = matrices.method_23760();
      Vector3f normalVec = getNormal(x1, y1, z1, x2, y2, z2);
      buffer.method_22918(model, x1, y1, z1).method_22915((float)ColorUtil.getRed(lineColor) / 255.0F, (float)ColorUtil.getGreen(lineColor) / 255.0F, (float)ColorUtil.getBlue(lineColor) / 255.0F, (float)ColorUtil.getAlpha(lineColor) / 255.0F).method_60831(entry, normalVec.x(), normalVec.y(), normalVec.z());
      buffer.method_22918(model, x2, y2, z2).method_22915((float)ColorUtil.getRed(lineColor) / 255.0F, (float)ColorUtil.getGreen(lineColor) / 255.0F, (float)ColorUtil.getBlue(lineColor) / 255.0F, (float)ColorUtil.getAlpha(lineColor) / 255.0F).method_60831(entry, normalVec.x(), normalVec.y(), normalVec.z());
   }

   public static Vector3f getNormal(float x1, float y1, float z1, float x2, float y2, float z2) {
      float xNormal = x2 - x1;
      float yNormal = y2 - y1;
      float zNormal = z2 - z1;
      float normalSqrt = class_3532.method_15355(xNormal * xNormal + yNormal * yNormal + zNormal * zNormal);
      return new Vector3f(xNormal / normalSqrt, yNormal / normalSqrt, zNormal / normalSqrt);
   }
}
