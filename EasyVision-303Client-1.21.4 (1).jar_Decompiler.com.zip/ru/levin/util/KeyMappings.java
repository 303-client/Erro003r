package ru.levin.util;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.glfw.GLFW;

public class KeyMappings {
   public static List<String> getAllKeys() {
      List<String> keys = new ArrayList();

      for(int i = 1; i <= 8; ++i) {
         keys.add("MOUSE" + i);
      }

      for(int key = 32; key <= 348; ++key) {
         String name = keyMappings(key);
         if (!name.equals("NONE") && !keys.contains(name)) {
            keys.add(name);
         }
      }

      for(int i = 0; i <= 9; ++i) {
         keys.add("NUM" + i);
      }

      keys.add("NUM.");
      keys.add("NUM/");
      keys.add("NUM*");
      keys.add("NUM-");
      keys.add("NUM+");
      keys.add("NUMENTER");
      keys.add("NUM=");
      keys.add("LSHIFT");
      keys.add("LCONTROL");
      keys.add("LALT");
      keys.add("LSUPER");
      keys.add("RSHIFT");
      keys.add("RCONTROL");
      keys.add("RALT");
      keys.add("RSUPER");
      keys.add("MENU");

      for(int i = 1; i <= 12; ++i) {
         keys.add("F" + i);
      }

      return keys;
   }

   public static String keyMappings(int keyCode) {
      if (keyCode < -1) {
         int mouseButton = -keyCode - 2;
         String var2;
         switch (mouseButton) {
            case 0 -> var2 = "MOUSE1";
            case 1 -> var2 = "MOUSE2";
            case 2 -> var2 = "MOUSE3";
            case 3 -> var2 = "MOUSE4";
            case 4 -> var2 = "MOUSE5";
            case 5 -> var2 = "MOUSE6";
            case 6 -> var2 = "MOUSE7";
            case 7 -> var2 = "MOUSE8";
            default -> var2 = "NONE";
         }

         return var2;
      } else {
         String var10000;
         switch (keyCode) {
            case 32:
               var10000 = "SPACE";
               break;
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 40:
            case 41:
            case 42:
            case 43:
            case 58:
            case 60:
            case 62:
            case 63:
            case 64:
            case 94:
            case 95:
            case 97:
            case 98:
            case 99:
            case 100:
            case 101:
            case 102:
            case 103:
            case 104:
            case 105:
            case 106:
            case 107:
            case 108:
            case 109:
            case 110:
            case 111:
            case 112:
            case 113:
            case 114:
            case 115:
            case 116:
            case 117:
            case 118:
            case 119:
            case 120:
            case 121:
            case 122:
            case 123:
            case 124:
            case 125:
            case 126:
            case 127:
            case 128:
            case 129:
            case 130:
            case 131:
            case 132:
            case 133:
            case 134:
            case 135:
            case 136:
            case 137:
            case 138:
            case 139:
            case 140:
            case 141:
            case 142:
            case 143:
            case 144:
            case 145:
            case 146:
            case 147:
            case 148:
            case 149:
            case 150:
            case 151:
            case 152:
            case 153:
            case 154:
            case 155:
            case 156:
            case 157:
            case 158:
            case 159:
            case 160:
            case 161:
            case 162:
            case 163:
            case 164:
            case 165:
            case 166:
            case 167:
            case 168:
            case 169:
            case 170:
            case 171:
            case 172:
            case 173:
            case 174:
            case 175:
            case 176:
            case 177:
            case 178:
            case 179:
            case 180:
            case 181:
            case 182:
            case 183:
            case 184:
            case 185:
            case 186:
            case 187:
            case 188:
            case 189:
            case 190:
            case 191:
            case 192:
            case 193:
            case 194:
            case 195:
            case 196:
            case 197:
            case 198:
            case 199:
            case 200:
            case 201:
            case 202:
            case 203:
            case 204:
            case 205:
            case 206:
            case 207:
            case 208:
            case 209:
            case 210:
            case 211:
            case 212:
            case 213:
            case 214:
            case 215:
            case 216:
            case 217:
            case 218:
            case 219:
            case 220:
            case 221:
            case 222:
            case 223:
            case 224:
            case 225:
            case 226:
            case 227:
            case 228:
            case 229:
            case 230:
            case 231:
            case 232:
            case 233:
            case 234:
            case 235:
            case 236:
            case 237:
            case 238:
            case 239:
            case 240:
            case 241:
            case 242:
            case 243:
            case 244:
            case 245:
            case 246:
            case 247:
            case 248:
            case 249:
            case 250:
            case 251:
            case 252:
            case 253:
            case 254:
            case 255:
            case 270:
            case 271:
            case 272:
            case 273:
            case 274:
            case 275:
            case 276:
            case 277:
            case 278:
            case 279:
            case 285:
            case 286:
            case 287:
            case 288:
            case 289:
            case 302:
            case 303:
            case 304:
            case 305:
            case 306:
            case 307:
            case 308:
            case 309:
            case 310:
            case 311:
            case 312:
            case 313:
            case 314:
            case 315:
            case 316:
            case 317:
            case 318:
            case 319:
            case 337:
            case 338:
            case 339:
            default:
               var10000 = "NONE";
               break;
            case 39:
               var10000 = "'";
               break;
            case 44:
               var10000 = ",";
               break;
            case 45:
               var10000 = "-";
               break;
            case 46:
               var10000 = ".";
               break;
            case 47:
               var10000 = "/";
               break;
            case 48:
               var10000 = "0";
               break;
            case 49:
               var10000 = "1";
               break;
            case 50:
               var10000 = "2";
               break;
            case 51:
               var10000 = "3";
               break;
            case 52:
               var10000 = "4";
               break;
            case 53:
               var10000 = "5";
               break;
            case 54:
               var10000 = "6";
               break;
            case 55:
               var10000 = "7";
               break;
            case 56:
               var10000 = "8";
               break;
            case 57:
               var10000 = "9";
               break;
            case 59:
               var10000 = ";";
               break;
            case 61:
               var10000 = "=";
               break;
            case 65:
               var10000 = "A";
               break;
            case 66:
               var10000 = "B";
               break;
            case 67:
               var10000 = "C";
               break;
            case 68:
               var10000 = "D";
               break;
            case 69:
               var10000 = "E";
               break;
            case 70:
               var10000 = "F";
               break;
            case 71:
               var10000 = "G";
               break;
            case 72:
               var10000 = "H";
               break;
            case 73:
               var10000 = "I";
               break;
            case 74:
               var10000 = "J";
               break;
            case 75:
               var10000 = "K";
               break;
            case 76:
               var10000 = "L";
               break;
            case 77:
               var10000 = "M";
               break;
            case 78:
               var10000 = "N";
               break;
            case 79:
               var10000 = "O";
               break;
            case 80:
               var10000 = "P";
               break;
            case 81:
               var10000 = "Q";
               break;
            case 82:
               var10000 = "R";
               break;
            case 83:
               var10000 = "S";
               break;
            case 84:
               var10000 = "T";
               break;
            case 85:
               var10000 = "U";
               break;
            case 86:
               var10000 = "V";
               break;
            case 87:
               var10000 = "W";
               break;
            case 88:
               var10000 = "X";
               break;
            case 89:
               var10000 = "Y";
               break;
            case 90:
               var10000 = "Z";
               break;
            case 91:
               var10000 = "[";
               break;
            case 92:
               var10000 = "\\";
               break;
            case 93:
               var10000 = "]";
               break;
            case 96:
               var10000 = "`";
               break;
            case 256:
               var10000 = "ESCAPE";
               break;
            case 257:
               var10000 = "ENTER";
               break;
            case 258:
               var10000 = "TAB";
               break;
            case 259:
               var10000 = "BACKSPACE";
               break;
            case 260:
               var10000 = "INSERT";
               break;
            case 261:
               var10000 = "DELETE";
               break;
            case 262:
               var10000 = "RIGHT";
               break;
            case 263:
               var10000 = "LEFT";
               break;
            case 264:
               var10000 = "DOWN";
               break;
            case 265:
               var10000 = "UP";
               break;
            case 266:
               var10000 = "PAGEUP";
               break;
            case 267:
               var10000 = "PAGEDOWN";
               break;
            case 268:
               var10000 = "HOME";
               break;
            case 269:
               var10000 = "END";
               break;
            case 280:
               var10000 = "CAPSLOCK";
               break;
            case 281:
               var10000 = "SCROLLLOCK";
               break;
            case 282:
               var10000 = "NUMLOCK";
               break;
            case 283:
               var10000 = "PRINTSCREEN";
               break;
            case 284:
               var10000 = "PAUSE";
               break;
            case 290:
               var10000 = "F1";
               break;
            case 291:
               var10000 = "F2";
               break;
            case 292:
               var10000 = "F3";
               break;
            case 293:
               var10000 = "F4";
               break;
            case 294:
               var10000 = "F5";
               break;
            case 295:
               var10000 = "F6";
               break;
            case 296:
               var10000 = "F7";
               break;
            case 297:
               var10000 = "F8";
               break;
            case 298:
               var10000 = "F9";
               break;
            case 299:
               var10000 = "F10";
               break;
            case 300:
               var10000 = "F11";
               break;
            case 301:
               var10000 = "F12";
               break;
            case 320:
               var10000 = "NUM0";
               break;
            case 321:
               var10000 = "NUM1";
               break;
            case 322:
               var10000 = "NUM2";
               break;
            case 323:
               var10000 = "NUM3";
               break;
            case 324:
               var10000 = "NUM4";
               break;
            case 325:
               var10000 = "NUM5";
               break;
            case 326:
               var10000 = "NUM6";
               break;
            case 327:
               var10000 = "NUM7";
               break;
            case 328:
               var10000 = "NUM8";
               break;
            case 329:
               var10000 = "NUM9";
               break;
            case 330:
               var10000 = "NUM.";
               break;
            case 331:
               var10000 = "NUM/";
               break;
            case 332:
               var10000 = "NUM*";
               break;
            case 333:
               var10000 = "NUM-";
               break;
            case 334:
               var10000 = "NUM+";
               break;
            case 335:
               var10000 = "NUMENTER";
               break;
            case 336:
               var10000 = "NUM=";
               break;
            case 340:
               var10000 = "LSHIFT";
               break;
            case 341:
               var10000 = "LCONTROL";
               break;
            case 342:
               var10000 = "LALT";
               break;
            case 343:
               var10000 = "LSUPER";
               break;
            case 344:
               var10000 = "RSHIFT";
               break;
            case 345:
               var10000 = "RCONTROL";
               break;
            case 346:
               var10000 = "RALT";
               break;
            case 347:
               var10000 = "RSUPER";
               break;
            case 348:
               var10000 = "MENU";
         }

         return var10000;
      }
   }

   public static int keyCode(String name) {
      int var10000;
      switch (name.toUpperCase()) {
         case "MOUSE1":
            byte var118 = -2;
            var10000 = var118;
            break;
         case "MOUSE2":
            byte var117 = -3;
            var10000 = var117;
            break;
         case "MOUSE3":
            byte var116 = -4;
            var10000 = var116;
            break;
         case "MOUSE4":
            byte var115 = -5;
            var10000 = var115;
            break;
         case "MOUSE5":
            byte var114 = -6;
            var10000 = var114;
            break;
         case "MOUSE6":
            byte var113 = -7;
            var10000 = var113;
            break;
         case "MOUSE7":
            byte var112 = -8;
            var10000 = var112;
            break;
         case "MOUSE8":
            byte var111 = -9;
            var10000 = var111;
            break;
         case "SPACE":
            byte var110 = 32;
            var10000 = var110;
            break;
         case "'":
            byte var109 = 39;
            var10000 = var109;
            break;
         case ",":
            byte var108 = 44;
            var10000 = var108;
            break;
         case "-":
            byte var107 = 45;
            var10000 = var107;
            break;
         case ".":
            byte var106 = 46;
            var10000 = var106;
            break;
         case "/":
            byte var105 = 47;
            var10000 = var105;
            break;
         case "0":
            byte var104 = 48;
            var10000 = var104;
            break;
         case "1":
            byte var103 = 49;
            var10000 = var103;
            break;
         case "2":
            byte var102 = 50;
            var10000 = var102;
            break;
         case "3":
            byte var101 = 51;
            var10000 = var101;
            break;
         case "4":
            byte var100 = 52;
            var10000 = var100;
            break;
         case "5":
            byte var99 = 53;
            var10000 = var99;
            break;
         case "6":
            byte var98 = 54;
            var10000 = var98;
            break;
         case "7":
            byte var97 = 55;
            var10000 = var97;
            break;
         case "8":
            byte var96 = 56;
            var10000 = var96;
            break;
         case "9":
            byte var95 = 57;
            var10000 = var95;
            break;
         case ";":
            byte var94 = 59;
            var10000 = var94;
            break;
         case "=":
            byte var93 = 61;
            var10000 = var93;
            break;
         case "A":
            byte var92 = 65;
            var10000 = var92;
            break;
         case "B":
            byte var91 = 66;
            var10000 = var91;
            break;
         case "C":
            byte var90 = 67;
            var10000 = var90;
            break;
         case "D":
            byte var89 = 68;
            var10000 = var89;
            break;
         case "E":
            byte var88 = 69;
            var10000 = var88;
            break;
         case "F":
            byte var87 = 70;
            var10000 = var87;
            break;
         case "G":
            byte var86 = 71;
            var10000 = var86;
            break;
         case "H":
            byte var85 = 72;
            var10000 = var85;
            break;
         case "I":
            byte var84 = 73;
            var10000 = var84;
            break;
         case "J":
            byte var83 = 74;
            var10000 = var83;
            break;
         case "K":
            byte var82 = 75;
            var10000 = var82;
            break;
         case "L":
            byte var81 = 76;
            var10000 = var81;
            break;
         case "M":
            byte var80 = 77;
            var10000 = var80;
            break;
         case "N":
            byte var79 = 78;
            var10000 = var79;
            break;
         case "O":
            byte var78 = 79;
            var10000 = var78;
            break;
         case "P":
            byte var77 = 80;
            var10000 = var77;
            break;
         case "Q":
            byte var76 = 81;
            var10000 = var76;
            break;
         case "R":
            byte var75 = 82;
            var10000 = var75;
            break;
         case "S":
            byte var74 = 83;
            var10000 = var74;
            break;
         case "T":
            byte var73 = 84;
            var10000 = var73;
            break;
         case "U":
            byte var72 = 85;
            var10000 = var72;
            break;
         case "V":
            byte var71 = 86;
            var10000 = var71;
            break;
         case "W":
            byte var70 = 87;
            var10000 = var70;
            break;
         case "X":
            byte var69 = 88;
            var10000 = var69;
            break;
         case "Y":
            byte var68 = 89;
            var10000 = var68;
            break;
         case "Z":
            byte var67 = 90;
            var10000 = var67;
            break;
         case "[":
            byte var66 = 91;
            var10000 = var66;
            break;
         case "\\":
            byte var65 = 92;
            var10000 = var65;
            break;
         case "]":
            byte var64 = 93;
            var10000 = var64;
            break;
         case "`":
            byte var63 = 96;
            var10000 = var63;
            break;
         case "ESCAPE":
            short var62 = 256;
            var10000 = var62;
            break;
         case "ENTER":
            short var61 = 257;
            var10000 = var61;
            break;
         case "TAB":
            short var60 = 258;
            var10000 = var60;
            break;
         case "BACKSPACE":
            short var59 = 259;
            var10000 = var59;
            break;
         case "INSERT":
            short var58 = 260;
            var10000 = var58;
            break;
         case "DELETE":
            short var57 = 261;
            var10000 = var57;
            break;
         case "RIGHT":
            short var56 = 262;
            var10000 = var56;
            break;
         case "LEFT":
            short var55 = 263;
            var10000 = var55;
            break;
         case "DOWN":
            short var54 = 264;
            var10000 = var54;
            break;
         case "UP":
            short var53 = 265;
            var10000 = var53;
            break;
         case "PAGEUP":
            short var52 = 266;
            var10000 = var52;
            break;
         case "PAGEDOWN":
            short var51 = 267;
            var10000 = var51;
            break;
         case "HOME":
            short var50 = 268;
            var10000 = var50;
            break;
         case "END":
            short var49 = 269;
            var10000 = var49;
            break;
         case "CAPSLOCK":
            short var48 = 280;
            var10000 = var48;
            break;
         case "SCROLLLOCK":
            short var47 = 281;
            var10000 = var47;
            break;
         case "NUMLOCK":
            short var46 = 282;
            var10000 = var46;
            break;
         case "PRINTSCREEN":
            short var45 = 283;
            var10000 = var45;
            break;
         case "PAUSE":
            short var44 = 284;
            var10000 = var44;
            break;
         case "F1":
            short var43 = 290;
            var10000 = var43;
            break;
         case "F2":
            short var42 = 291;
            var10000 = var42;
            break;
         case "F3":
            short var41 = 292;
            var10000 = var41;
            break;
         case "F4":
            short var40 = 293;
            var10000 = var40;
            break;
         case "F5":
            short var39 = 294;
            var10000 = var39;
            break;
         case "F6":
            short var38 = 295;
            var10000 = var38;
            break;
         case "F7":
            short var37 = 296;
            var10000 = var37;
            break;
         case "F8":
            short var36 = 297;
            var10000 = var36;
            break;
         case "F9":
            short var35 = 298;
            var10000 = var35;
            break;
         case "F10":
            short var34 = 299;
            var10000 = var34;
            break;
         case "F11":
            short var33 = 300;
            var10000 = var33;
            break;
         case "F12":
            short var32 = 301;
            var10000 = var32;
            break;
         case "NUM0":
            short var31 = 320;
            var10000 = var31;
            break;
         case "NUM1":
            short var30 = 321;
            var10000 = var30;
            break;
         case "NUM2":
            short var29 = 322;
            var10000 = var29;
            break;
         case "NUM3":
            short var28 = 323;
            var10000 = var28;
            break;
         case "NUM4":
            short var27 = 324;
            var10000 = var27;
            break;
         case "NUM5":
            short var26 = 325;
            var10000 = var26;
            break;
         case "NUM6":
            short var25 = 326;
            var10000 = var25;
            break;
         case "NUM7":
            short var24 = 327;
            var10000 = var24;
            break;
         case "NUM8":
            short var23 = 328;
            var10000 = var23;
            break;
         case "NUM9":
            short var22 = 329;
            var10000 = var22;
            break;
         case "NUM.":
            short var21 = 330;
            var10000 = var21;
            break;
         case "NUM/":
            short var20 = 331;
            var10000 = var20;
            break;
         case "NUM*":
            short var19 = 332;
            var10000 = var19;
            break;
         case "NUM-":
            short var18 = 333;
            var10000 = var18;
            break;
         case "NUM+":
            short var17 = 334;
            var10000 = var17;
            break;
         case "NUMENTER":
            short var16 = 335;
            var10000 = var16;
            break;
         case "NUM=":
            short var15 = 336;
            var10000 = var15;
            break;
         case "LSHIFT":
            short var14 = 340;
            var10000 = var14;
            break;
         case "LCONTROL":
            short var13 = 341;
            var10000 = var13;
            break;
         case "LALT":
            short var12 = 342;
            var10000 = var12;
            break;
         case "LSUPER":
            short var11 = 343;
            var10000 = var11;
            break;
         case "RSHIFT":
            short var10 = 344;
            var10000 = var10;
            break;
         case "RCONTROL":
            short var9 = 345;
            var10000 = var9;
            break;
         case "RALT":
            short var8 = 346;
            var10000 = var8;
            break;
         case "RSUPER":
            short var7 = 347;
            var10000 = var7;
            break;
         case "MENU":
            short var3 = 348;
            var10000 = var3;
            break;
         default:
            int var120;
            try {
               Field field = GLFW.class.getDeclaredField("GLFW_KEY_" + name);
               var120 = field.getInt((Object)null);
            } catch (Exception var5) {
               var120 = -1;
               var10000 = var120;
               return var10000;
            }

            var10000 = var120;
      }

      return var10000;
   }
}
