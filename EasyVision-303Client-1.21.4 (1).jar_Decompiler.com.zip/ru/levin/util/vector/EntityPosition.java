package ru.levin.util.vector;

import net.minecraft.class_1297;
import org.joml.Vector3d;
import ru.levin.util.math.MathUtil;

public class EntityPosition extends Vector3d {
   protected EntityPosition(class_1297 entity, float height, float pt) {
      super(MathUtil.interpolate(entity.field_6038, entity.method_23317(), (double)pt), MathUtil.interpolate(entity.field_5971, entity.method_23318(), (double)pt) + (double)height, MathUtil.interpolate(entity.field_5989, entity.method_23321(), (double)pt));
   }

   public static Vector3d get(class_1297 entity, float height, float pt) {
      return new EntityPosition(entity, height, pt);
   }

   public static Vector3d get(class_1297 entity, float pt) {
      return get(entity, 0.0F, pt);
   }
}
