package ru.levin.util.vector;

import net.minecraft.class_1041;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_5611;
import org.joml.Matrix4f;
import org.joml.Quaternionf;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL11;
import ru.levin.manager.IMinecraft;
import ru.levin.mixin.iface.GameRendererAccessor;

public class VectorUtil implements IMinecraft {
   private static final float MIN_DISTANCE_SQ = 1.0F;
   public static Matrix4f previousProjectionMatrix = new Matrix4f();
   public static class_4587.class_4665 lastWorldSpaceMatrix = (new class_4587()).method_23760();

   public static Vector3d toScreen(Vector3d vec) {
      return toScreen(vec.x, vec.y, vec.z);
   }

   public static Vector3d toScreen(double x, double y, double z) {
      if (lastWorldSpaceMatrix != null && previousProjectionMatrix != null) {
         Vector3f vector3f = new Vector3f((float)x, (float)y, (float)z);
         int[] viewport = new int[4];
         GL11.glGetIntegerv(2978, viewport);
         Vector4f vector4f = (new Vector4f(vector3f.x, vector3f.y, vector3f.z, 1.0F)).mul(lastWorldSpaceMatrix.method_23761());
         if (vector4f.z > 0.0F) {
            return new Vector3d((double)-1.0F, (double)-1.0F, (double)-1.0F);
         } else {
            Vector3f target = new Vector3f();
            (new Matrix4f(previousProjectionMatrix)).project(vector4f.x, vector4f.y, vector4f.z, viewport, target);
            double scale = mc.method_22683().method_4495();
            return new Vector3d((double)target.x / scale, (double)((float)mc.method_22683().method_4507() - target.y) / scale, (double)target.z);
         }
      } else {
         return new Vector3d((double)-1.0F, (double)-1.0F, (double)-1.0F);
      }
   }

   public static class_5611 project(double x, double y, double z) {
      class_4184 camera = mc.method_1561().field_4686;
      if (camera == null) {
         return new class_5611(Float.MAX_VALUE, Float.MAX_VALUE);
      } else {
         class_243 camPos = camera.method_19326();
         Vector3f pos = new Vector3f((float)(x - camPos.field_1352), (float)(y - camPos.field_1351), (float)(z - camPos.field_1350));
         Quaternionf rotation = (new Quaternionf(mc.method_1561().method_24197())).conjugate();
         pos.rotate(rotation);
         if ((Boolean)mc.field_1690.method_42448().method_41753()) {
            class_1297 var11 = mc.method_1560();
            if (var11 instanceof class_1657) {
               class_1657 player = (class_1657)var11;
               applyViewBobbing(player, pos);
            }
         }

         double fov = (double)((GameRendererAccessor)mc.field_1773).invokeGetFov(camera, mc.method_61966().method_60637(true), true);
         return calculateScreenPosition(pos, fov);
      }
   }

   private static void applyViewBobbing(class_1657 player, Vector3f pos) {
      float delta = mc.method_61966().method_60637(true);
      float speed = class_3532.method_16439(delta, player.field_7505, player.field_7483);
      float bob = player.field_6227 - player.field_6212;
      if (bob != 0.0F) {
         float roll = class_3532.method_15374((float)((double)bob * Math.PI)) * speed * 3.0F;
         pos.rotateZ(roll * ((float)Math.PI / 180F));
         float pitch = Math.abs(class_3532.method_15362((float)((double)bob * Math.PI - (double)0.2F)) * speed) * 5.0F;
         pos.rotateX(pitch * ((float)Math.PI / 180F));
      }

      pos.add(class_3532.method_15374((float)((double)bob * Math.PI)) * speed * 0.5F, -Math.abs(class_3532.method_15362((float)((double)bob * Math.PI)) * speed), 0.0F);
   }

   private static class_5611 calculateScreenPosition(Vector3f pos, double fov) {
      if (pos.z >= 0.0F) {
         return new class_5611(Float.MAX_VALUE, Float.MAX_VALUE);
      } else {
         class_1041 w = mc.method_22683();
         float halfW = (float)w.method_4486() * 0.5F;
         float halfH = (float)w.method_4502() * 0.5F;
         float factor = (float)((double)halfH / Math.tan(Math.toRadians(fov) * (double)0.5F)) / -pos.z;
         return new class_5611(halfW + pos.x * factor, halfH - pos.y * factor);
      }
   }

   public static class_243 getInterpolatedPos(class_1297 entity, float tickDelta) {
      return new class_243(class_3532.method_16436((double)tickDelta, entity.field_6014, entity.method_23317()), class_3532.method_16436((double)tickDelta, entity.field_6036, entity.method_23318()), class_3532.method_16436((double)tickDelta, entity.field_5969, entity.method_23321()));
   }

   public static class_243 getInterpolatedPos(class_243 prev, class_243 pos, float tickDelta) {
      return new class_243(class_3532.method_16436((double)tickDelta, prev.field_1352, pos.method_10216()), class_3532.method_16436((double)tickDelta, prev.field_1351, pos.method_10214()), class_3532.method_16436((double)tickDelta, prev.field_1350, pos.method_10215()));
   }
}
