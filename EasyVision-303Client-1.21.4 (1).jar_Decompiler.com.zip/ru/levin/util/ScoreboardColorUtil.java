package ru.levin.util;

import java.util.Locale;
import java.util.Optional;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_5251;

public final class ScoreboardColorUtil {
   private static final String LEGACY_COLORS = "0123456789abcdef";
   private static final int[] LEGACY_COLOR_RGB = new int[]{0, 170, 43520, 43690, 11141120, 11141290, 16755200, 11184810, 5592405, 5592575, 5635925, 5636095, 16733525, 16733695, 16777045, 16777215};

   private ScoreboardColorUtil() {
   }

   public static String toHex(class_2561 text) {
      return text == null ? "#FFFFFF" : (String)text.method_27658((style, content) -> {
         String inlineColor = colorCodeAtStart(content);
         if (inlineColor != null) {
            return Optional.of(inlineColor);
         } else {
            class_5251 color = style.method_10973();
            return color != null && !content.isEmpty() ? Optional.of(String.format(Locale.ROOT, "#%06X", color.method_27716() & 16777215)) : Optional.empty();
         }
      }, class_2583.field_24360).orElse("#FFFFFF");
   }

   public static String normalizeHex(String value, String fallback) {
      if (value == null) {
         return fallback;
      } else {
         String hex = value.trim();
         if (hex.startsWith("#")) {
            hex = hex.substring(1);
         }

         if (hex.length() != 6) {
            return fallback;
         } else {
            for(int i = 0; i < hex.length(); ++i) {
               if (Character.digit(hex.charAt(i), 16) < 0) {
                  return fallback;
               }
            }

            return "#" + hex.toUpperCase(Locale.ROOT);
         }
      }
   }

   public static String stripLegacyFormattingCodes(String text) {
      if (text != null && !text.isEmpty()) {
         StringBuilder visible = new StringBuilder(text.length());

         for(int i = 0; i < text.length(); ++i) {
            if (text.charAt(i) == 167 && i + 1 < text.length()) {
               if (readHexColor(text, i) != null) {
                  i += 13;
                  continue;
               }

               if (isLegacyFormatCode(text.charAt(i + 1))) {
                  ++i;
                  continue;
               }
            }

            visible.append(text.charAt(i));
         }

         return visible.toString();
      } else {
         return "";
      }
   }

   public static class_2561 coloredText(String text, String value) {
      String hex = normalizeHex(value, "#FFFFFF");
      int rgb = Integer.parseInt(hex.substring(1), 16);
      return class_2561.method_43470(stripLegacyFormattingCodes(text)).method_10862(class_2583.field_24360.method_36139(rgb));
   }

   public static class_2561 applyColor(class_2561 text, String value) {
      String hex = normalizeHex(value, "#FFFFFF");
      int rgb = Integer.parseInt(hex.substring(1), 16);
      return text.method_27661().method_10862(text.method_10866().method_36139(rgb));
   }

   private static String colorCodeAtStart(String text) {
      int activeColor = -1;

      for(int i = 0; i < text.length(); ++i) {
         if (text.charAt(i) == 167 && i + 1 < text.length()) {
            String hexColor = readHexColor(text, i);
            if (hexColor != null) {
               activeColor = Integer.parseInt(hexColor.substring(1), 16);
               i += 13;
               continue;
            }

            char code = Character.toLowerCase(text.charAt(i + 1));
            int colorIndex = "0123456789abcdef".indexOf(code);
            if (colorIndex >= 0) {
               activeColor = LEGACY_COLOR_RGB[colorIndex];
               ++i;
               continue;
            }

            if (code == 'r') {
               activeColor = -1;
               ++i;
               continue;
            }

            if ("klmno".indexOf(code) >= 0) {
               ++i;
               continue;
            }
         }

         if (!Character.isWhitespace(text.charAt(i))) {
            return activeColor < 0 ? null : formatRgb(activeColor);
         }
      }

      return activeColor < 0 ? null : formatRgb(activeColor);
   }

   private static String readHexColor(String text, int start) {
      if (start + 13 < text.length() && Character.toLowerCase(text.charAt(start + 1)) == 'x') {
         StringBuilder hex = new StringBuilder(6);

         for(int digit = 0; digit < 6; ++digit) {
            int marker = start + 2 + digit * 2;
            if (text.charAt(marker) != 167) {
               return null;
            }

            char value = text.charAt(marker + 1);
            if (Character.digit(value, 16) < 0) {
               return null;
            }

            hex.append(value);
         }

         String var10000 = hex.toString();
         return "#" + var10000.toUpperCase(Locale.ROOT);
      } else {
         return null;
      }
   }

   private static boolean isLegacyFormatCode(char value) {
      char code = Character.toLowerCase(value);
      return "0123456789abcdef".indexOf(code) >= 0 || "klmnor".indexOf(code) >= 0;
   }

   private static String formatRgb(int rgb) {
      return String.format(Locale.ROOT, "#%06X", rgb & 16777215);
   }
}
