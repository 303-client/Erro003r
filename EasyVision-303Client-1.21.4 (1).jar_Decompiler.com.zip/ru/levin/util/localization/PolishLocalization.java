package ru.levin.util.localization;

import java.util.LinkedHashMap;
import java.util.Map;

public final class PolishLocalization {
   private static final Map<String, String> PHRASES = new LinkedHashMap();

   private PolishLocalization() {
   }

   private static void put(String source, String target) {
      PHRASES.put(source, target);
   }

   public static String translate(String text) {
      if (text != null && !text.isEmpty()) {
         String translated = (String)PHRASES.get(text);
         if (translated != null) {
            return translated;
         } else {
            for(Map.Entry<String, String> entry : PHRASES.entrySet()) {
               translated = text.replace((CharSequence)entry.getKey(), (CharSequence)entry.getValue());
            }

            return translated;
         }
      } else {
         return text;
      }
   }

   static {
      put("Игроки", "Gracze");
      put("Игрок", "Gracz");
      put("Мобы", "Moby");
      put("Монстры", "Potwory");
      put("Друзья", "Znajomi");
      put("Жители", "Wieśniacy");
      put("Голые", "Bez zbroi");
      put("Режим", "Tryb");
      put("Тип", "Typ");
      put("Мод", "Tryb");
      put("Настройки", "Ustawienia");
      put("Радиус", "Zasięg");
      put("Скорость", "Prędkość");
      put("Задержка", "Opóźnienie");
      put("Дистанция", "Dystans");
      put("Здоровье", "Zdrowie");
      put("Сила", "Siła");
      put("Чаты", "Czaty");
      put("Чат", "Czat");
      put("Локальный", "Lokalny");
      put("Глобальный", "Globalny");
      put("Обычный", "Zwykły");
      put("Продвинутый", "Zaawansowany");
      put("Кастомное", "Własne");
      put("День", "Dzień");
      put("Ночь", "Noc");
      put("Утро", "Poranek");
      put("Восход", "Wschód słońca");
      put("Показывать предметы", "Pokazuj przedmioty");
      put("Показывать эффекты", "Pokazuj efekty");
      put("Показывать чары", "Pokazuj enchanty");
      put("Показывать lore", "Pokazuj lore");
      put("Показывать содержимое шалкеров", "Pokazuj zawartość shulkerów");
      put("Предметы на земле", "Przedmioty na ziemi");
      put("Энтити", "Encje");
      put("Только друзей", "Tylko znajomi");
      put("Вода", "Woda");
      put("Лава", "Lawa");
      put("Играть на деньги", "Graj o pieniądze");
      put("Монет", "Monety");
      put("Щит", "Tarcza");
      put("Тотем", "Totem");
      put("Тотемы", "Totemy");
      put("Обсидиан", "Obsydian");
      put("Якорь", "Kotwica odrodzenia");
      put("Падение", "Upadek");
      put("Вагонетка", "Wagonik");
      put("Сундуки", "Skrzynie");
      put("Печки", "Piece");
      put("Спавнеры", "Spawnery");
      put("Алмазы", "Diamenty");
      put("Изумруды", "Szmaragdy");
      put("Незерит", "Netheryt");
      put("Прозрачность", "Przezroczystość");
      put("Размытие", "Rozmycie");
      put("Тема", "Motyw");
      put("Светло-чёрная", "Jasno-czarny");
      put("Тёмная", "Ciemny");
      put("Зависит от темы", "Zależny od motywu");
      put("Слева направо", "Od lewej do prawej");
      put("Справа налево", "Od prawej do lewej");
      put("Урон", "Obrażenia");
      put("Мир", "Świat");
      put("Звезда", "Gwiazda");
      put("Корона", "Korona");
      put("Сердце", "Serce");
      put("Молния", "Błyskawica");
      put("Линия", "Linia");
      put("Точка", "Punkt");
      put("Ромб", "Romb");
      put("Ничего", "Nic");
      put("После лута", "Po loocie");
      put("Отправляющий", "Wysyłający");
      put("Получающий", "Odbierający");
      put("Кнопка", "Przycisk");
      put("Не взрывать себя", "Nie wysadzaj siebie");
      put("Коррекция движения", "Korekta ruchu");
      put("Игрок в падении", "Gracz w powietrzu");
      put("Подсветка блока", "Podświetlenie bloku");
      put("Мало здоровья", "Mało zdrowia");
      put("При исп. предмета", "Przy użyciu przedmiotu");
      put("Отжим щита", "Zbijanie tarczy");
      put("Отключить", "Wyłącz");
      put("Включить", "Włącz");
      put("Автоматически", "Automatycznie");
      put("Позволяет", "Pozwala");
      put("Позволит", "Pozwala");
      put("Показывает", "Pokazuje");
      put("Показывать", "Pokazuj");
      put("Убирает", "Usuwa");
      put("Отключает", "Wyłącza");
      put("Предотвращает", "Zapobiega");
      put("Увеличивает", "Zwiększa");
      put("Изменение", "Zmiana");
      put("Изменять", "Zmieniaj");
      put("Настраивает", "Dostosowuje");
      put("Застраивает", "Zabudowuje");
      put("Кидает", "Rzuca");
      put("Берёт", "Bierze");
      put("Возвращать", "Zwracaj");
      put("Сохранять", "Zachowuj");
      put("Только", "Tylko");
      put("Рядом", "W pobliżu");
      put("Мало", "Mało");
      put("При", "Przy");
      put("После", "Po");
      put("Включает", "Włącza");
      put("Ливает", "Wychodzi");
      put("Улетать", "Odleć");
      put("Отлёт", "Odlot");
      put("Время", "Czas");
      put("Сила", "Siła");
      put("Держать", "Trzymaj");
      put("Урон", "Obrażenia");
      put("Блок", "Blok");
      put("Блоки", "Bloki");
      put("Кнопка", "Przycisk");
      put("Предмет", "Przedmiot");
      put("Предметы", "Przedmioty");
      put("Эффекты", "Efekty");
      put("Чары", "Enchanty");
      put("Кристалл", "Kryształ");
      put("Кристаллы", "Kryształy");
      put("Лук", "Łuk");
      put("Меч", "Miecz");
      put("Броня", "Zbroja");
      put("Мир", "Świat");
      put("Игры", "Gry");
      put("Проверка", "Sprawdzanie");
      put("Содержимое", "Zawartość");
      put("Сундук", "Skrzynia");
      put("Дискорд", "Discord");
      put("Клиент", "Klient");
      put("Сервер", "Serwer");
      put("Движение", "Ruch");
      put("Прыжок", "Skok");
      put("Падение", "Upadek");
      put("Летать", "Lataj");
      put("Полёт", "Lot");
      put("Плавность", "Płynność");
      put("Кастомное время", "Własny czas");
      put("Авто отключение", "Automatyczne wyłączenie");
   }
}
