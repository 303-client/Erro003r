package ru.levin.util;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2760;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_2848.class_2849;
import ru.levin.manager.Manager;

public final class AutoDripUtil {
   private static final ThreadLocal<Boolean> IN_INTERNAL_INTERACT = ThreadLocal.withInitial(() -> Boolean.FALSE);

   private AutoDripUtil() {
   }

   public static boolean isEnabled() {
      try {
         return Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.fastDripstone != null && Manager.FUNCTION_MANAGER.fastDripstone.state;
      } catch (Exception var1) {
         return false;
      }
   }

   public static class_1269 onUseBlock(class_746 var0, class_1937 var1, class_1268 var2, class_3965 var3) {
      if (var1 != null && var1.field_9236) {
         if (!(var0 instanceof class_746)) {
            return class_1269.field_5811;
         } else if ((Boolean)IN_INTERNAL_INTERACT.get()) {
            return class_1269.field_5811;
         } else if (!isEnabled()) {
            return class_1269.field_5811;
         } else if (var2 != class_1268.field_5808) {
            return class_1269.field_5811;
         } else {
            class_310 var4 = class_310.method_1551();
            if (var4 != null && var4.field_1724 != null && var4.field_1687 != null && var4.field_1761 != null) {
               if (var4.method_1562() == null) {
                  return class_1269.field_5811;
               } else {
                  class_746 var5 = var4.field_1724;
                  if (!var5.method_6047().method_31574(class_1802.field_28042)) {
                     return class_1269.field_5811;
                  } else {
                     class_2338 var6 = var3.method_17777();
                     class_2680 var7 = var1.method_8320(var6);
                     if (!(var7.method_26204() instanceof class_2533)) {
                        return class_1269.field_5811;
                     } else if ((Boolean)var7.method_11654(class_2533.field_11631)) {
                        return class_1269.field_5811;
                     } else {
                        class_2338 var8 = var6.method_10074();
                        if (!var1.method_8320(var8).method_26215()) {
                           return class_1269.field_5811;
                        } else {
                           IN_INTERNAL_INTERACT.set(Boolean.TRUE);

                           class_1269.class_9860 var9;
                           try {
                              boolean var10 = false;
                              if (!var5.method_5715()) {
                                 var4.method_1562().method_52787(new class_2848(var5, class_2849.field_12979));
                                 var5.method_5660(true);
                                 var10 = true;
                              }

                              double var11 = var7.method_11654(class_2533.field_11625) == class_2760.field_12619 ? (double)var6.method_10264() + (double)1.0F - 0.001 : (double)var6.method_10264() + 0.001;
                              class_243 var13 = new class_243((double)var6.method_10263() + (double)0.5F, var11, (double)var6.method_10260() + (double)0.5F);
                              class_3965 var14 = new class_3965(var13, class_2350.field_11033, var6, false);
                              class_1269 var15 = var4.field_1761.method_2896(var5, var2, var14);
                              if (var10) {
                                 var4.method_1562().method_52787(new class_2848(var5, class_2849.field_12984));
                                 var5.method_5660(false);
                              }

                              class_1269 var16 = var4.field_1761.method_2896(var5, var2, var3);
                              if (var15.method_23665() || var16.method_23665()) {
                                 var5.method_6104(var2);
                              }

                              var9 = class_1269.field_5812;
                           } finally {
                              IN_INTERNAL_INTERACT.set(Boolean.FALSE);
                           }

                           return var9;
                        }
                     }
                  }
               }
            } else {
               return class_1269.field_5811;
            }
         }
      } else {
         return class_1269.field_5811;
      }
   }
}
