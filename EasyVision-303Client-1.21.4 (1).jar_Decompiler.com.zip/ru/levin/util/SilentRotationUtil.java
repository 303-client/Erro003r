package ru.levin.util;

import net.minecraft.class_310;
import net.minecraft.class_3532;

public final class SilentRotationUtil {
   private static boolean active = false;
   private static float yaw = 0.0F;
   private static float pitch = 0.0F;
   private static long lastUpdateMs = 0L;

   private SilentRotationUtil() {
   }

   public static boolean isActive() {
      return active;
   }

   public static float yaw() {
      return yaw;
   }

   public static float pitch() {
      return pitch;
   }

   public static void clear() {
      active = false;
      lastUpdateMs = 0L;
   }

   public static boolean update(class_310 client, float targetYaw, float targetPitch, int durationMs) {
      if (client != null && client.field_1724 != null) {
         long now = System.currentTimeMillis();
         if (!active) {
            active = true;
            yaw = client.field_1724.method_36454();
            pitch = client.field_1724.method_36455();
            lastUpdateMs = now;
         }

         long dtMs = now - lastUpdateMs;
         if (dtMs < 1L) {
            dtMs = 1L;
         }

         lastUpdateMs = now;
         float speed = rotationSpeedDegPerMs(durationMs);
         float maxStep = speed * (float)dtMs;
         yaw = approachAngle(yaw, targetYaw, maxStep);
         pitch = approach(pitch, targetPitch, maxStep);
         pitch = class_3532.method_15363(pitch, -90.0F, 90.0F);
         client.field_1724.method_36456(yaw);
         client.field_1724.method_36457(pitch);
         float yawDiff = Math.abs(class_3532.method_15393(targetYaw - yaw));
         float pitchDiff = Math.abs(targetPitch - pitch);
         return yawDiff <= 1.0F && pitchDiff <= 1.0F;
      } else {
         clear();
         return false;
      }
   }

   private static float rotationSpeedDegPerMs(int durationMs) {
      int d = Math.max(1, durationMs);
      return 90.0F / (float)d;
   }

   private static float approach(float current, float target, float maxStep) {
      float diff = target - current;
      return Math.abs(diff) <= maxStep ? target : current + Math.copySign(maxStep, diff);
   }

   private static float approachAngle(float current, float target, float maxStep) {
      float diff = class_3532.method_15393(target - current);
      return Math.abs(diff) <= maxStep ? class_3532.method_15393(current + diff) : class_3532.method_15393(current + Math.copySign(maxStep, diff));
   }
}
