package ru.levin.util;

import [Ljava.lang.Object;;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;
import java.util.function.UnaryOperator;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import net.minecraft.class_640;
import net.minecraft.class_642;
import net.minecraft.class_7417;
import net.minecraft.class_8828;
import ru.levin.manager.Manager;
import ru.levin.modules.misc.NameProtect;

public final class NameProtectUtil {
   private static long lastTick = Long.MIN_VALUE;
   private static NameProtectMode lastMode = null;
   private static int lastListSize = -1;
   private static UUID lastSelfId = null;
   private static List<String> lastTargets = List.of();
   private static final String ANARCHIA_HOST = "anarchia.gg";
   private static String lastServerAddress = null;
   private static boolean lastServerMatch = false;
   private static final String LABEL_TIME = "Czas gry:";
   private static final String LABEL_MONEY = "Pieniądze:";
   private static final String LABEL_KILLS = "Zabójstwa:";
   private static final String LABEL_DEATHS = "Śmierci:";
   private static final int LINE_KILLS = 3;
   private static final int LINE_DEATHS = 4;
   private static final int LINE_MONEY = 5;
   private static final int LINE_TIME = 6;
   private static final String LABEL_TIME_N;
   private static final String LABEL_MONEY_N;
   private static final String LABEL_KILLS_N;
   private static final String LABEL_DEATHS_N;

   private NameProtectUtil() {
   }

   public static boolean isEnabled() {
      if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
         return true;
      } else {
         NameProtect mod = Manager.FUNCTION_MANAGER.nameProtect;
         return mod != null && mod.state;
      }
   }

   public static String replaceString(String text) {
      if (text != null && !text.isEmpty() && isEnabled()) {
         String alias = getAlias();
         if (alias.isEmpty()) {
            return text;
         } else {
            class_310 client = class_310.method_1551();
            List<String> targets = getTargets(client, getMode());
            return targets.isEmpty() ? text : replaceAll(text, targets, alias);
         }
      } else {
         return text;
      }
   }

   public static class_5348 replaceVisitable(class_5348 text) {
      if (text != null && isEnabled()) {
         if (text instanceof class_2561) {
            class_2561 t = (class_2561)text;
            return replaceText(t);
         } else {
            String alias = getAlias();
            if (alias.isEmpty()) {
               return text;
            } else {
               class_310 client = class_310.method_1551();
               List<String> targets = getTargets(client, getMode());
               if (targets.isEmpty()) {
                  return text;
               } else {
                  String original = text.getString();
                  String replaced = replaceAll(original, targets, alias);
                  return (class_5348)(original.equals(replaced) ? text : class_2561.method_30163(replaced));
               }
            }
         }
      } else {
         return text;
      }
   }

   public static String getDisplayName(class_1657 player) {
      if (player != null && isEnabled()) {
         String alias = getAlias();
         if (alias.isEmpty()) {
            return null;
         } else {
            NameProtectMode mode = getMode();
            if (mode == NameProtectUtil.NameProtectMode.EVERYONE) {
               return alias;
            } else {
               class_310 client = class_310.method_1551();
               return client != null && client.field_1724 != null && player.method_7334().getId().equals(client.field_1724.method_7334().getId()) ? alias : null;
            }
         }
      } else {
         return null;
      }
   }

   public static class_2561 replaceText(class_2561 text) {
      if (text != null && isEnabled()) {
         String alias = getAlias();
         if (alias.isEmpty()) {
            return text;
         } else {
            class_310 client = class_310.method_1551();
            List<String> targets = getTargets(client, getMode());
            return targets.isEmpty() ? text : replaceTextInternal(text, targets, alias);
         }
      } else {
         return text;
      }
   }

   public static class_2561 replaceScoreboardText(class_2561 text, int score) {
      if (text == null) {
         return null;
      } else if (!isOnAnarchiaServer()) {
         return text;
      } else {
         class_2561 base = replaceText(text);
         if (shouldUseCustomScoreboard()) {
            return base;
         } else if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
            if (!Manager.FUNCTION_MANAGER.fastNameProtect.shouldChangeStats()) {
               return base;
            } else {
               String time = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatTime());
               String money = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatMoney());
               String kills = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatKills());
               String deaths = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatDeaths());
               return time.isEmpty() && money.isEmpty() && kills.isEmpty() && deaths.isEmpty() ? base : replaceTextBy(base, (s) -> replaceStatsLine(s, time, money, kills, deaths));
            }
         } else {
            NameProtect mod = Manager.FUNCTION_MANAGER.nameProtect;
            if (mod != null && mod.changeStats != null && mod.changeStats.get()) {
               String time = cleanStat(mod.statTime.getValue());
               String money = cleanStat(mod.statMoney.getValue());
               String kills = cleanStat(mod.statKills.getValue());
               String deaths = cleanStat(mod.statDeaths.getValue());
               return time.isEmpty() && money.isEmpty() && kills.isEmpty() && deaths.isEmpty() ? base : replaceTextBy(base, (s) -> replaceStatsLine(s, time, money, kills, deaths));
            } else {
               return base;
            }
         }
      }
   }

   public static class_2561 replaceScoreboardTextByLine(class_2561 text, int lineFromBottom) {
      if (text == null) {
         return null;
      } else if (!isOnAnarchiaServer()) {
         return text;
      } else {
         String rawOriginal = text.getString();
         if (isLikelySeparatorLine(rawOriginal)) {
            return class_2561.method_43473();
         } else {
            class_2561 base = replaceText(text);
            if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
               if (Manager.FUNCTION_MANAGER.fastNameProtect.shouldChangeStats()) {
                  String time = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatTime());
                  String money = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatMoney());
                  String kills = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatKills());
                  String deaths = cleanStat(Manager.FUNCTION_MANAGER.fastNameProtect.getStatDeaths());
                  if (time.isEmpty() && money.isEmpty() && kills.isEmpty() && deaths.isEmpty()) {
                     return base;
                  } else {
                     String value = null;
                     String raw = base.getString();
                     String normalized = normalizeAscii(raw).toLowerCase(Locale.ROOT);
                     if (!time.isEmpty() && normalized.contains(LABEL_TIME_N)) {
                        value = time;
                     } else if (!money.isEmpty() && normalized.contains(LABEL_MONEY_N)) {
                        value = money;
                     } else if (!kills.isEmpty() && normalized.contains(LABEL_KILLS_N)) {
                        value = kills;
                     } else if ((!deaths.isEmpty() || !kills.isEmpty()) && normalized.contains(LABEL_DEATHS_N)) {
                        value = deaths.isEmpty() ? kills : deaths;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 3) {
                        value = kills;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 4) {
                        value = deaths.isEmpty() ? kills : deaths;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 5) {
                        value = money;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 6) {
                        value = time;
                     }

                     return value != null && !value.isEmpty() ? replaceLineValuePreservingStyle(base, value) : base;
                  }
               } else {
                  return base;
               }
            } else {
               NameProtect mod = Manager.FUNCTION_MANAGER.nameProtect;
               if (mod != null && mod.changeStats != null && mod.changeStats.get()) {
                  String time = cleanStat(mod.statTime.getValue());
                  String money = cleanStat(mod.statMoney.getValue());
                  String kills = cleanStat(mod.statKills.getValue());
                  String deaths = cleanStat(mod.statDeaths.getValue());
                  if (time.isEmpty() && money.isEmpty() && kills.isEmpty() && deaths.isEmpty()) {
                     return base;
                  } else {
                     String value = null;
                     String raw = base.getString();
                     String normalized = normalizeAscii(raw).toLowerCase(Locale.ROOT);
                     if (!time.isEmpty() && normalized.contains(LABEL_TIME_N)) {
                        value = time;
                     } else if (!money.isEmpty() && normalized.contains(LABEL_MONEY_N)) {
                        value = money;
                     } else if (!kills.isEmpty() && normalized.contains(LABEL_KILLS_N)) {
                        value = kills;
                     } else if ((!deaths.isEmpty() || !kills.isEmpty()) && normalized.contains(LABEL_DEATHS_N)) {
                        value = deaths.isEmpty() ? kills : deaths;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 3) {
                        value = kills;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 4) {
                        value = deaths.isEmpty() ? kills : deaths;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 5) {
                        value = money;
                     } else if (shouldUseFallbackLine(raw, normalized) && lineFromBottom == 6) {
                        value = time;
                     }

                     return value != null && !value.isEmpty() ? replaceLineValuePreservingStyle(base, value) : base;
                  }
               } else {
                  return base;
               }
            }
         }
      }
   }

   private static boolean isLikelySeparatorLine(String raw) {
      if (raw == null) {
         return false;
      } else {
         String trimmed = raw.trim();
         if (trimmed.isEmpty()) {
            return true;
         } else if (trimmed.length() > 2) {
            return false;
         } else {
            boolean hasLetter = false;
            boolean hasColon = false;

            for(int i = 0; i < trimmed.length(); ++i) {
               char c = trimmed.charAt(i);
               if (Character.isLetter(c)) {
                  hasLetter = true;
               }

               if (c == ':') {
                  hasColon = true;
               }
            }

            return !hasLetter && !hasColon;
         }
      }
   }

   private static boolean shouldUseFallbackLine(String raw, String normalized) {
      if (raw != null && !raw.isBlank()) {
         if (!normalized.contains(LABEL_TIME_N) && !normalized.contains(LABEL_MONEY_N) && !normalized.contains(LABEL_KILLS_N) && !normalized.contains(LABEL_DEATHS_N)) {
            if (raw.indexOf(58) >= 0) {
               return true;
            } else {
               for(int i = 0; i < normalized.length(); ++i) {
                  if (Character.isLetter(normalized.charAt(i))) {
                     return true;
                  }
               }

               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   public static boolean shouldUseCustomScoreboard() {
      return isOnAnarchiaServer();
   }

   public static boolean isOnAnarchiaServer() {
      class_310 client = class_310.method_1551();
      if (client == null) {
         return false;
      } else {
         class_642 info = client.method_1558();
         String address = info != null ? info.field_3761 : null;
         if (address != null && !address.isBlank()) {
            if (address.equals(lastServerAddress)) {
               return lastServerMatch;
            } else {
               lastServerAddress = address;
               lastServerMatch = isAddressMatch(address, "anarchia.gg");
               return lastServerMatch;
            }
         } else {
            return false;
         }
      }
   }

   private static boolean isAddressMatch(String address, String host) {
      String normalized = address.trim().toLowerCase(Locale.ROOT);
      if (normalized.isEmpty()) {
         return false;
      } else {
         String hostPart = normalized;
         if (normalized.startsWith("[")) {
            int end = normalized.indexOf(93);
            if (end > 0) {
               hostPart = normalized.substring(1, end);
            }
         } else {
            int colon = normalized.indexOf(58);
            if (colon > 0) {
               hostPart = normalized.substring(0, colon);
            }
         }

         while(hostPart.endsWith(".")) {
            hostPart = hostPart.substring(0, hostPart.length() - 1);
         }

         return hostPart.equals(host) || hostPart.endsWith("." + host);
      }
   }

   public static class_5481 replaceOrderedText(class_5481 text) {
      if (text != null && isEnabled()) {
         String alias = getAlias();
         if (alias.isEmpty()) {
            return text;
         } else {
            class_310 client = class_310.method_1551();
            List<String> targets = getTargets(client, getMode());
            if (targets.isEmpty()) {
               return text;
            } else {
               List<Integer> codePoints = new ArrayList();
               List<class_2583> styles = new ArrayList();
               StringBuilder sb = new StringBuilder();
               text.accept((index, style, codePoint) -> {
                  codePoints.add(codePoint);
                  styles.add(style);
                  sb.appendCodePoint(codePoint);
                  return true;
               });
               String original = sb.toString();
               if (original.isEmpty()) {
                  return text;
               } else {
                  class_2583[] stylesByChar = buildStylesByChar(original, codePoints, styles);
                  List<StyledChar> out = replaceWithStyles(original, stylesByChar, targets, alias);
                  return out == null ? text : (visitor) -> {
                     int charIndex = 0;

                     for(StyledChar sc : out) {
                        if (!visitor.accept(charIndex, sc.style, sc.codePoint)) {
                           return false;
                        }

                        charIndex += Character.charCount(sc.codePoint);
                     }

                     return true;
                  };
               }
            }
         }
      } else {
         return text;
      }
   }

   private static class_2561 replaceTextInternal(class_2561 text, List<String> targets, String alias) {
      class_7417 content = text.method_10851();
      class_7417 newContent = content;
      boolean changed = false;
      if (content instanceof class_8828 plain) {
         String original = plain.comp_737();
         String replaced = replaceAll(original, targets, alias);
         if (!original.equals(replaced)) {
            newContent = class_8828.method_54232(replaced);
            changed = true;
         }
      } else if (content instanceof class_2588 translatable) {
         Object[] args = translatable.method_11023();
         Object[] newArgs = null;

         for(int i = 0; i < args.length; ++i) {
            Object arg = args[i];
            Object next = arg;
            if (arg instanceof class_2561 t) {
               class_2561 replaced = replaceTextInternal(t, targets, alias);
               if (replaced != t) {
                  next = replaced;
               }
            } else if (arg instanceof String s) {
               String replaced = replaceAll(s, targets, alias);
               if (!s.equals(replaced)) {
                  next = replaced;
               }
            }

            if (next != arg) {
               if (newArgs == null) {
                  newArgs = ((Object;)args).clone();
               }

               newArgs[i] = next;
            }
         }

         if (newArgs != null) {
            newContent = new class_2588(translatable.method_11022(), translatable.method_48323(), newArgs);
            changed = true;
         }
      }

      class_5250 out = class_5250.method_43477(newContent).method_10862(text.method_10866());
      if (!text.method_10855().isEmpty()) {
         for(class_2561 sibling : text.method_10855()) {
            class_2561 replacedSibling = replaceTextInternal(sibling, targets, alias);
            out.method_10852(replacedSibling);
            if (replacedSibling != sibling) {
               changed = true;
            }
         }
      }

      return (class_2561)(!changed && newContent == content && text.method_10855().isEmpty() ? text : out);
   }

   private static class_2561 replaceTextBy(class_2561 text, UnaryOperator<String> replacer) {
      class_7417 content = text.method_10851();
      class_7417 newContent = content;
      boolean changed = false;
      if (content instanceof class_8828 plain) {
         String original = plain.comp_737();
         String replaced = (String)replacer.apply(original);
         if (!Objects.equals(original, replaced)) {
            newContent = class_8828.method_54232(replaced);
            changed = true;
         }
      } else if (content instanceof class_2588 translatable) {
         Object[] args = translatable.method_11023();
         Object[] newArgs = null;

         for(int i = 0; i < args.length; ++i) {
            Object arg = args[i];
            Object next = arg;
            if (arg instanceof class_2561 t) {
               class_2561 replaced = replaceTextBy(t, replacer);
               if (replaced != t) {
                  next = replaced;
               }
            } else if (arg instanceof String s) {
               String replaced = (String)replacer.apply(s);
               if (!Objects.equals(s, replaced)) {
                  next = replaced;
               }
            }

            if (next != arg) {
               if (newArgs == null) {
                  newArgs = ((Object;)args).clone();
               }

               newArgs[i] = next;
            }
         }

         if (newArgs != null) {
            newContent = new class_2588(translatable.method_11022(), translatable.method_48323(), newArgs);
            changed = true;
         }
      }

      class_5250 out = class_5250.method_43477(newContent).method_10862(text.method_10866());
      if (!text.method_10855().isEmpty()) {
         for(class_2561 sibling : text.method_10855()) {
            class_2561 replacedSibling = replaceTextBy(sibling, replacer);
            out.method_10852(replacedSibling);
            if (replacedSibling != sibling) {
               changed = true;
            }
         }
      }

      return (class_2561)(!changed && newContent == content && text.method_10855().isEmpty() ? text : out);
   }

   private static List<String> getTargets(class_310 client, NameProtectMode mode) {
      if (client == null) {
         return List.of();
      } else {
         long tick = client.field_1687 != null ? client.field_1687.method_8510() : Long.MIN_VALUE;
         int listSize = client.method_1562() != null ? client.method_1562().method_2880().size() : -1;
         UUID selfId = client.field_1724 != null ? client.field_1724.method_7334().getId() : null;
         if (tick == lastTick && mode == lastMode && listSize == lastListSize && Objects.equals(selfId, lastSelfId)) {
            return lastTargets;
         } else {
            lastTick = tick;
            lastMode = mode;
            lastListSize = listSize;
            lastSelfId = selfId;
            List<String> built = collectTargets(client, mode);
            lastTargets = built.isEmpty() ? List.of() : built;
            return lastTargets;
         }
      }
   }

   private static List<String> collectTargets(class_310 client, NameProtectMode mode) {
      List<String> out = new ArrayList();
      if (client == null) {
         return out;
      } else if (mode == NameProtectUtil.NameProtectMode.SELF) {
         if (client.field_1724 != null) {
            String name = client.field_1724.method_5477().getString();
            if (!name.isBlank()) {
               out.add(name);
            }
         }

         return out;
      } else {
         Set<String> names = new LinkedHashSet();
         if (client.method_1562() != null) {
            for(class_640 entry : client.method_1562().method_2880()) {
               String name = entry.method_2966().getName();
               if (name != null && !name.isBlank()) {
                  names.add(name);
               }
            }
         }

         if (client.field_1687 != null) {
            for(class_1657 p : client.field_1687.method_18456()) {
               if (p != null) {
                  String name = p.method_5477().getString();
                  if (!name.isBlank()) {
                     names.add(name);
                  }
               }
            }
         }

         out.addAll(names);
         return out;
      }
   }

   private static String getAlias() {
      if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
         String name = Manager.FUNCTION_MANAGER.fastNameProtect.getAlias();
         return name == null ? "" : name.trim();
      } else {
         NameProtect mod = Manager.FUNCTION_MANAGER.nameProtect;
         String name = mod != null ? mod.text.getValue() : "";
         return name == null ? "" : name.trim();
      }
   }

   private static NameProtectMode getMode() {
      if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
         String mode = Manager.FUNCTION_MANAGER.fastNameProtect.getModeValue();
         return mode.equals("Ja") ? NameProtectUtil.NameProtectMode.SELF : NameProtectUtil.NameProtectMode.EVERYONE;
      } else {
         NameProtect mod = Manager.FUNCTION_MANAGER.nameProtect;
         return NameProtectUtil.NameProtectMode.SELF;
      }
   }

   private static String replaceAll(String text, List<String> targets, String alias) {
      String out = text;

      for(String target : targets) {
         if (target != null && !target.isBlank()) {
            out = replaceWholeWord(out, target, alias);
         }
      }

      return out;
   }

   private static String replaceWholeWord(String text, String target, String replacement) {
      if (text != null && !text.isEmpty() && !target.isEmpty()) {
         int idx = 0;
         int last = 0;

         StringBuilder sb;
         int end;
         for(sb = null; (idx = text.indexOf(target, idx)) >= 0; idx = end) {
            end = idx + target.length();
            if (isBoundary(text, idx - 1) && isBoundary(text, end)) {
               if (sb == null) {
                  sb = new StringBuilder(text.length());
               }

               sb.append(text, last, idx);
               sb.append(replacement);
               last = end;
            }
         }

         if (sb == null) {
            return text;
         } else {
            sb.append(text, last, text.length());
            return sb.toString();
         }
      } else {
         return text;
      }
   }

   private static class_2561 replaceLineValuePreservingStyle(class_2561 text, String value) {
      if (text != null && value != null) {
         List<Integer> codePoints = new ArrayList();
         List<class_2583> styles = new ArrayList();
         StringBuilder sb = new StringBuilder();
         text.method_30937().accept((index, stylex, codePoint) -> {
            codePoints.add(codePoint);
            styles.add(stylex);
            sb.appendCodePoint(codePoint);
            return true;
         });
         String original = sb.toString();
         if (original.isEmpty()) {
            return text;
         } else {
            int digitIndex = -1;

            for(int i = 0; i < original.length(); ++i) {
               if (Character.isDigit(original.charAt(i))) {
                  digitIndex = i;
                  break;
               }
            }

            if (digitIndex < 0) {
               return text;
            } else {
               class_2583[] stylesByChar = buildStylesByChar(original, codePoints, styles);
               class_5250 out = class_2561.method_43473();

               int runEnd;
               for(int idx = 0; idx < digitIndex; idx = runEnd) {
                  class_2583 style = stylesByChar[idx];
                  if (style == null) {
                     style = class_2583.field_24360;
                  }

                  for(runEnd = idx + 1; runEnd < digitIndex && Objects.equals(stylesByChar[runEnd], style); ++runEnd) {
                  }

                  String run = original.substring(idx, runEnd);
                  if (!run.isEmpty()) {
                     out.method_10852(class_2561.method_43470(run).method_10862(style));
                  }
               }

               class_2583 digitStyle = stylesByChar[digitIndex];
               if (digitStyle == null) {
                  digitStyle = class_2583.field_24360;
               }

               out.method_10852(class_2561.method_43470(value).method_10862(digitStyle));
               return out;
            }
         }
      } else {
         return text;
      }
   }

   private static String cleanStat(String value) {
      if (value == null) {
         return "";
      } else {
         String trimmed = value.trim();
         if (trimmed.length() > 64) {
            trimmed = trimmed.substring(0, 64);
         }

         return trimmed;
      }
   }

   private static String replaceStatsLine(String input, String time, String money, String kills, String deaths) {
      if (input != null && !input.isEmpty()) {
         String normalized = normalizeAscii(input).toLowerCase(Locale.ROOT);
         if (!time.isEmpty() && normalized.contains(LABEL_TIME_N)) {
            return "Czas gry: " + time;
         } else if (!money.isEmpty() && normalized.contains(LABEL_MONEY_N)) {
            return "Pieniądze: " + money;
         } else if (!kills.isEmpty() && normalized.contains(LABEL_KILLS_N)) {
            return "Zabójstwa: " + kills;
         } else {
            return !deaths.isEmpty() && normalized.contains(LABEL_DEATHS_N) ? "Śmierci: " + deaths : input;
         }
      } else {
         return input;
      }
   }

   private static String normalizeAscii(String s) {
      StringBuilder out = new StringBuilder(s.length());

      for(int i = 0; i < s.length(); ++i) {
         char c = s.charAt(i);
         switch (c) {
            case 'Ó':
            case 'ó':
               out.append('o');
               break;
            case 'Ą':
            case 'ą':
               out.append('a');
               break;
            case 'Ć':
            case 'ć':
               out.append('c');
               break;
            case 'Ę':
            case 'ę':
               out.append('e');
               break;
            case 'Ł':
            case 'ł':
               out.append('l');
               break;
            case 'Ń':
            case 'ń':
               out.append('n');
               break;
            case 'Ś':
            case 'ś':
               out.append('s');
               break;
            case 'Ź':
            case 'ź':
               out.append('z');
               break;
            case 'Ż':
            case 'ż':
               out.append('z');
               break;
            default:
               out.append(c);
         }
      }

      return out.toString();
   }

   private static boolean isBoundary(String text, int index) {
      if (index >= 0 && index < text.length()) {
         char c = text.charAt(index);
         return !isNameChar(c);
      } else {
         return true;
      }
   }

   private static boolean isNameChar(char c) {
      return c >= '0' && c <= '9' || c >= 'A' && c <= 'Z' || c >= 'a' && c <= 'z' || c == '_';
   }

   private static class_2583[] buildStylesByChar(String original, List<Integer> codePoints, List<class_2583> styles) {
      class_2583[] stylesByChar = new class_2583[original.length()];
      int charIndex = 0;

      for(int i = 0; i < codePoints.size() && i < styles.size(); ++i) {
         int cp = (Integer)codePoints.get(i);
         class_2583 style = (class_2583)styles.get(i);
         int len = Character.charCount(cp);

         for(int j = 0; j < len && charIndex + j < stylesByChar.length; ++j) {
            stylesByChar[charIndex + j] = style;
         }

         charIndex += len;
         if (charIndex >= stylesByChar.length) {
            break;
         }
      }

      return stylesByChar;
   }

   private static List<StyledChar> replaceWithStyles(String original, class_2583[] stylesByChar, List<String> targets, String alias) {
      int len = original.length();
      int idx = 0;
      boolean changed = false;

      List<StyledChar> out;
      for(out = new ArrayList(len); idx < len; changed = true) {
         Match match = findNextMatch(original, targets, idx);
         if (match == null) {
            appendSegment(original, stylesByChar, idx, len, out);
            break;
         }

         if (match.start > idx) {
            appendSegment(original, stylesByChar, idx, match.start, out);
         }

         class_2583 style = stylesByChar[match.start];
         if (style == null) {
            style = class_2583.field_24360;
         }

         appendAlias(alias, style, out);
         idx = match.start + match.target.length();
      }

      return !changed ? null : out;
   }

   private static void appendSegment(String original, class_2583[] stylesByChar, int start, int end, List<StyledChar> out) {
      int cp;
      for(int i = start; i < end; i += Character.charCount(cp)) {
         cp = original.codePointAt(i);
         class_2583 style = stylesByChar[i];
         if (style == null) {
            style = class_2583.field_24360;
         }

         out.add(new StyledChar(cp, style));
      }

   }

   private static void appendAlias(String alias, class_2583 style, List<StyledChar> out) {
      int cp;
      for(int i = 0; i < alias.length(); i += Character.charCount(cp)) {
         cp = alias.codePointAt(i);
         out.add(new StyledChar(cp, style));
      }

   }

   private static Match findNextMatch(String text, List<String> targets, int fromIndex) {
      int bestStart = -1;
      String bestTarget = null;
      int bestLen = -1;

      for(String target : targets) {
         int end;
         if (target != null && !target.isBlank()) {
            for(int idx = text.indexOf(target, fromIndex); idx >= 0; idx = text.indexOf(target, end)) {
               end = idx + target.length();
               if (isBoundary(text, idx - 1) && isBoundary(text, end)) {
                  if (bestStart == -1 || idx < bestStart || idx == bestStart && target.length() > bestLen) {
                     bestStart = idx;
                     bestTarget = target;
                     bestLen = target.length();
                  }
                  break;
               }
            }
         }
      }

      if (bestStart < 0) {
         return null;
      } else {
         return new Match(bestStart, bestTarget);
      }
   }

   static {
      LABEL_TIME_N = normalizeAscii("Czas gry:").toLowerCase(Locale.ROOT);
      LABEL_MONEY_N = normalizeAscii("Pieniądze:").toLowerCase(Locale.ROOT);
      LABEL_KILLS_N = normalizeAscii("Zabójstwa:").toLowerCase(Locale.ROOT);
      LABEL_DEATHS_N = normalizeAscii("Śmierci:").toLowerCase(Locale.ROOT);
   }

   private static final class Match {
      final int start;
      final String target;

      private Match(int start, String target) {
         this.start = start;
         this.target = target;
      }
   }

   private static final class StyledChar {
      final int codePoint;
      final class_2583 style;

      private StyledChar(int codePoint, class_2583 style) {
         this.codePoint = codePoint;
         this.style = style;
      }
   }

   public static enum NameProtectMode {
      SELF,
      EVERYONE;

      // $FF: synthetic method
      private static NameProtectMode[] $values() {
         return new NameProtectMode[]{SELF, EVERYONE};
      }
   }
}
