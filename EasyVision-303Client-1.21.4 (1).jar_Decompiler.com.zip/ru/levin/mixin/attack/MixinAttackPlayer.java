package ru.levin.mixin.attack;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.player.EventAttack;
import ru.levin.manager.Manager;
import ru.levin.util.math.RayTraceUtil;

@Mixin({class_636.class})
public class MixinAttackPlayer {
   @Inject(
      method = {"attackEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void attackEntity(class_1657 player, class_1297 target, CallbackInfo ci) {
      if (Manager.FUNCTION_MANAGER.noFriendDamage.state && Manager.FRIEND_MANAGER.isFriend(target.method_5477().getString())) {
         ci.cancel();
      }

   }

   @Inject(
      method = {"attackEntity"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V",
   shift = Shift.AFTER,
   ordinal = 0
)}
   )
   private void afterSendPacket(class_1657 player, class_1297 target, CallbackInfo ci) {
      Event.call(new EventAttack(player, target));
      RayTraceUtil.markHit(target);
   }
}
