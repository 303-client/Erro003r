package ru.levin.mixin.client;

import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.ExosWare;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.render.BetterPainting;

@Environment(EnvType.CLIENT)
@Mixin({class_310.class})
public abstract class MixinMinecraftClient implements IMinecraft {
   @Inject(
      method = {"doItemUse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$fastBetterPainting(CallbackInfo callbackInfo) {
      class_310 client = (class_310)this;
      if (client.field_1724 != null && client.field_1761 != null && client.field_1724.method_6047().method_31574(class_1802.field_8892) && Manager.FUNCTION_MANAGER != null) {
         BetterPainting betterPainting = Manager.FUNCTION_MANAGER.betterPainting;
         class_3965 target = betterPainting.findFastTarget();
         if (target != null) {
            class_1269 result = client.field_1761.method_2896(client.field_1724, class_1268.field_5808, target);
            if (result.method_23665()) {
               client.field_1724.method_6104(class_1268.field_5808);
               callbackInfo.cancel();
            }

         }
      }
   }

   @Inject(
      method = {"isMultiplayerEnabled"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void isMultiplayerEnabled(CallbackInfoReturnable<Boolean> cir) {
      cir.setReturnValue(true);
   }

   @Inject(
      method = {"getWindowTitle"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getWindowTitle(CallbackInfoReturnable<String> cir) {
      if (!ClientManager.legitMode) {
         cir.setReturnValue("303 Client | " + Manager.USER_PROFILE.getName());
      }

   }

   @Inject(
      at = {@At("HEAD")},
      method = {"stop"}
   )
   private void stop(CallbackInfo ci) {
      ExosWare.getInstance().shutDown();
   }

   @Inject(
      method = {"<init>"},
      at = {@At("TAIL")}
   )
   private void init(CallbackInfo callbackInfo) {
      ExosWare.getInstance().init();
   }
}
