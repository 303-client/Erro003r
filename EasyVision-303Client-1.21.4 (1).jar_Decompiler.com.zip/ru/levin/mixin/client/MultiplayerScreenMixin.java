package ru.levin.mixin.client;

import net.minecraft.class_2561;
import net.minecraft.class_4185;
import net.minecraft.class_500;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;
import ru.levin.manager.proxyManager.GuiProxy;
import ru.levin.manager.proxyManager.Proxy;
import ru.levin.manager.proxyManager.ProxyManager;
import ru.levin.mixin.iface.ScreenAccessor;

@Mixin({class_500.class})
public class MultiplayerScreenMixin {
   @Inject(
      method = {"init()V"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/screen/multiplayer/MultiplayerScreen;updateButtonActivationStates()V"
)}
   )
   public void multiplayerGuiOpen(CallbackInfo ci) {
      ProxyManager pm = Manager.PROXY_MANAGER;
      String playerName = ProxyManager.mc.method_1548().method_1676();
      if (!playerName.equals(pm.lastPlayerName)) {
         pm.lastPlayerName = playerName;
         ProxyManager.proxy = (Proxy)pm.accounts.getOrDefault(playerName, (Proxy)pm.accounts.getOrDefault("", new Proxy()));
      }

      class_500 screen = (class_500)this;
      ProxyManager.proxyMenuButton = class_4185.method_46430(class_2561.method_43470("Proxy: " + ProxyManager.getLastUsedProxyIp()), (b) -> ProxyManager.mc.method_1507(new GuiProxy(screen))).method_46434(screen.field_22789 - 320, 479, 100, 20).method_46431();
      ScreenAccessor sa = (ScreenAccessor)screen;
      sa.getDrawables().add(ProxyManager.proxyMenuButton);
      sa.getSelectables().add(ProxyManager.proxyMenuButton);
      sa.getChildren().add(ProxyManager.proxyMenuButton);
   }
}
