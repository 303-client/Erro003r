package ru.levin.mixin.client;

import net.minecraft.class_1799;
import net.minecraft.class_310;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;
import ru.levin.modules.player.FastPlace;

@Mixin({class_310.class})
public abstract class MixinFastPlace {
   @Shadow
   private int field_1752;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void exosware$fastPlaceTick(CallbackInfo callbackInfo) {
      if (Manager.FUNCTION_MANAGER != null) {
         FastPlace fastPlace = Manager.FUNCTION_MANAGER.fastPlace;
         if (fastPlace != null && fastPlace.state && fastPlace.shouldHandle(this.getHeldStack())) {
            this.field_1752 = 0;
         }

      }
   }

   @Inject(
      method = {"doItemUse"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$fastPlaceGate(CallbackInfo callbackInfo) {
      if (Manager.FUNCTION_MANAGER != null) {
         FastPlace fastPlace = Manager.FUNCTION_MANAGER.fastPlace;
         if (fastPlace != null && fastPlace.state && fastPlace.shouldHandle(this.getHeldStack()) && !fastPlace.allowUse()) {
            callbackInfo.cancel();
         }

      }
   }

   private class_1799 getHeldStack() {
      class_310 client = (class_310)this;
      return client.field_1724 == null ? class_1799.field_8037 : client.field_1724.method_6047();
   }
}
