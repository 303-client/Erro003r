package ru.levin.mixin.world;

import net.minecraft.class_10039;
import net.minecraft.class_1542;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_7833;
import net.minecraft.class_916;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.render.ItemPhysic;

@Mixin({class_916.class})
public abstract class MixinItemEntityRenderer implements IMinecraft {
   @Unique
   private boolean isOnGround = false;
   @Unique
   private float entityAge = 0.0F;
   @Unique
   private float uniqueOffset = 0.0F;

   @Inject(
      method = {"updateRenderState"},
      at = {@At("HEAD")}
   )
   private void onUpdateRenderState(class_1542 entity, class_10039 state, float tickDelta, CallbackInfo ci) {
      this.isOnGround = entity.method_24828();
      this.entityAge = state.field_53328;
      this.uniqueOffset = state.field_53435;
   }

   @ModifyVariable(
      method = {"render"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/entity/ItemEntityRenderer;renderStack(Lnet/minecraft/client/util/math/MatrixStack;Lnet/minecraft/client/render/VertexConsumerProvider;ILnet/minecraft/client/render/entity/state/ItemStackEntityRenderState;Lnet/minecraft/util/math/random/Random;)V"
),
      ordinal = 0
   )
   private class_4587 modifyMatrixStack(class_4587 matrices, class_10039 state, class_4587 original, class_4597 vertexConsumers, int light) {
      ItemPhysic itemPhysic = Manager.FUNCTION_MANAGER.itemPhysic;
      if (itemPhysic.state) {
         if (itemPhysic.mode.is("Обычная")) {
            matrices.method_22909();
            matrices.method_22903();
            float rotation = class_1542.method_27314(this.entityAge, this.uniqueOffset);
            if (this.isOnGround) {
               matrices.method_22907(class_7833.field_40714.rotationDegrees(90.0F));
            } else {
               matrices.method_22907(class_7833.field_40714.rotationDegrees(rotation * 300.0F));
            }
         } else if (itemPhysic.mode.is("2D")) {
            matrices.method_22909();
            matrices.method_22903();
            matrices.method_46416(0.0F, 0.1F, 0.0F);
            matrices.method_22907(mc.method_1561().method_24197());
            matrices.method_22905(1.1F, 1.1F, 0.0F);
            state.field_55310.method_65604(matrices, vertexConsumers, 15728880, class_4608.field_21444);
         }
      }

      return matrices;
   }
}
