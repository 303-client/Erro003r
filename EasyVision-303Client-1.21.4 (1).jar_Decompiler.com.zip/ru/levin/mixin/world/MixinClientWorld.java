package ru.levin.mixin.world;

import net.minecraft.class_1297;
import net.minecraft.class_638;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.move.EventEntitySpawn;

@Mixin({class_638.class})
public class MixinClientWorld {
   @Inject(
      method = {"addEntity"},
      at = {@At("TAIL")}
   )
   private void onAddEntity(class_1297 entity, CallbackInfo ci) {
      Event.call(new EventEntitySpawn(entity));
   }
}
