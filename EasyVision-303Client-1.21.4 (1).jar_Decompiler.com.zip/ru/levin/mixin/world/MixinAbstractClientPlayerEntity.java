package ru.levin.mixin.world;

import net.minecraft.class_742;
import net.minecraft.class_8685;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.util.render.providers.ResourceProvider;

@Mixin({class_742.class})
public class MixinAbstractClientPlayerEntity implements IMinecraft {
   private String cachedPlayerName;

   @Inject(
      method = {"getSkinTextures"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void injectGetSkinTextures(CallbackInfoReturnable<class_8685> cir) {
      if (!ClientManager.legitMode) {
         class_742 player = (class_742)this;
         String playerName = player.method_5477().getString();
         if (this.cachedPlayerName == null) {
            this.cachedPlayerName = mc.field_1724.method_5477().getString();
         }

         if (Manager.FRIEND_MANAGER.isFriend(playerName) || playerName.equalsIgnoreCase(this.cachedPlayerName)) {
            class_8685 original = (class_8685)cir.getReturnValue();
            class_8685 newTextures = new class_8685(original.comp_1626(), original.comp_1911(), ResourceProvider.CUSTOM_CAPE, ResourceProvider.CUSTOM_ELYTRA, original.comp_1629(), original.comp_1630());
            cir.setReturnValue(newTextures);
         }

      }
   }
}
