package ru.levin.mixin.world;

import net.minecraft.class_1309;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.world.EventObsidianPlace;

@Mixin({class_2248.class})
public class MixinBlock {
   @Inject(
      method = {"onPlaced"},
      at = {@At("HEAD")}
   )
   private void onPlaced(class_1937 world, class_2338 pos, class_2680 state, class_1309 placer, class_1799 itemStack, CallbackInfo ci) {
      if (state.method_26204() == class_2246.field_10540) {
         Event.call(new EventObsidianPlace(state.method_26204(), pos));
      }

   }
}
