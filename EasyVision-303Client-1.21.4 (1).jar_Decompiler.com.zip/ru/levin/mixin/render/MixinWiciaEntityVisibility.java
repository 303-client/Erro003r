package ru.levin.mixin.render;

import net.minecraft.class_1297;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;

@Mixin({class_1297.class})
public class MixinWiciaEntityVisibility {
   @Inject(
      method = {"isCollidable"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onIsCollidable(CallbackInfoReturnable<Boolean> cir) {
      if (Manager.FUNCTION_MANAGER != null) {
         if (Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.state) {
            class_1297 entity = (class_1297)this;
            if (Manager.FUNCTION_MANAGER.wiciaEntityVisibility.shouldRemoveCollision(entity)) {
               cir.setReturnValue(false);
            }
         }

      }
   }

   @Inject(
      method = {"isPushable"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onIsPushable(CallbackInfoReturnable<Boolean> cir) {
      if (Manager.FUNCTION_MANAGER != null) {
         if (Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.state) {
            class_1297 entity = (class_1297)this;
            if (Manager.FUNCTION_MANAGER.wiciaEntityVisibility.shouldRemoveCollision(entity)) {
               cir.setReturnValue(false);
            }
         }

      }
   }
}
