package ru.levin.mixin.display;

import com.llamalad7.mixinextras.sugar.Local;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_757;
import net.minecraft.class_7833;
import net.minecraft.class_9779;
import net.minecraft.class_9958;
import org.joml.Matrix4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.combat.CrystalAura;
import ru.levin.modules.combat.SelfTrap;
import ru.levin.modules.combat.rotation.RotationController;
import ru.levin.modules.render.AspectRatio;
import ru.levin.modules.render.BetterPainting;
import ru.levin.modules.render.EntityVisibility;
import ru.levin.modules.render.WiciaEntityVisibility;
import ru.levin.util.math.RayTraceUtil;
import ru.levin.util.render.Render3DUtil;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.vector.VectorUtil;

@Mixin({class_757.class})
public abstract class MixinGameRenderer implements IMinecraft {
   @Shadow
   public abstract float method_3193();

   @Inject(
      method = {"renderWorld"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z",
   opcode = 180,
   ordinal = 0
)}
   )
   private void renderWorld(class_9779 tickCounter, CallbackInfo callbackInfo, @Local(ordinal = 2) Matrix4f matrix4f) {
      class_4587 matrixStack = new class_4587();
      matrixStack.method_34425(matrix4f);
      matrixStack.method_61958(mc.method_1561().field_4686.method_19326().method_22882());
      VectorUtil.previousProjectionMatrix = RenderSystem.getProjectionMatrix();
      VectorUtil.lastWorldSpaceMatrix = matrixStack.method_23760();
      Render3DUtil.setLastProjMat(RenderSystem.getProjectionMatrix());
      Render3DUtil.setLastWorldSpaceMatrix(matrixStack.method_23760());
      EventRender3D event = new EventRender3D(matrixStack, tickCounter);
      Event.call(event);
      Render3DUtil.onWorldRender(event);
   }

   @Inject(
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/render/GameRenderer;renderHand:Z",
   opcode = 180,
   ordinal = 0
)},
      method = {"renderWorld"}
   )
   private void render3dHook(class_9779 tickCounter, CallbackInfo ci) {
      class_4587 matrixStack = new class_4587();
      class_4184 camera = mc.field_1773.method_19418();
      RenderSystem.getModelViewStack().pushMatrix().mul(matrixStack.method_23760().method_23761());
      matrixStack.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
      matrixStack.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
      RenderSystem.setShaderFog(class_9958.field_53065);
      RenderUtil.render3D.setTranslation(matrixStack);
      Event.call(new EventRender3D(matrixStack, tickCounter));
      RenderSystem.getModelViewStack().popMatrix();
      RenderSystem.getModelViewMatrix();
   }

   @Inject(
      method = {"getBasicProjectionMatrix"},
      at = {@At("TAIL")},
      cancellable = true
   )
   private void getBasicProjectionMatrixHook(float fov, CallbackInfoReturnable<Matrix4f> cir) {
      AspectRatio aspectRatio = Manager.FUNCTION_MANAGER.aspectRatio;
      if (aspectRatio.state) {
         float aspect = 1.0F;
         String mode = aspectRatio.mods.get();
         byte var7 = -1;
         switch (mode.hashCode()) {
            case -1463517642:
               if (mode.equals("Własny")) {
                  var7 = 4;
               }
               break;
            case 48936:
               if (mode.equals("1:1")) {
                  var7 = 2;
               }
               break;
            case 51821:
               if (mode.equals("4:3")) {
                  var7 = 0;
               }
               break;
            case 1513508:
               if (mode.equals("16:9")) {
                  var7 = 1;
               }
               break;
            case 46918548:
               if (mode.equals("16:10")) {
                  var7 = 3;
               }
         }

         switch (var7) {
            case 0 -> aspect = 1.3333334F;
            case 1 -> aspect = 1.7777778F;
            case 2 -> aspect = 1.0F;
            case 3 -> aspect = 1.6F;
            case 4 -> aspect = aspectRatio.slider.get().floatValue();
         }

         class_4587 matrixStack = new class_4587();
         matrixStack.method_23760().method_23761().identity();
         matrixStack.method_23760().method_23761().mul((new Matrix4f()).setPerspective((float)((double)fov * (Math.PI / 180D)), aspect, 0.05F, this.method_3193() * 4.0F));
         cir.setReturnValue(matrixStack.method_23760().method_23761());
      }

   }

   @Inject(
      method = {"findCrosshairTarget"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onFindCrosshairTarget(class_1297 camera, double blockRange, double entityRange, float tickDelta, CallbackInfoReturnable<class_239> cir) {
      AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
      CrystalAura crystalAura = Manager.FUNCTION_MANAGER.crystalAura;
      SelfTrap selfTrap = Manager.FUNCTION_MANAGER.selfTrap;
      RotationController rotation = Manager.ROTATION;
      float yaw;
      float pitch;
      if (!attackAura.state && !rotation.isControlling()) {
         if (crystalAura.state && crystalAura.rotate != null && crystalAura.closestCrystal != null) {
            yaw = crystalAura.rotate.x;
            pitch = crystalAura.rotate.y;
         } else if (selfTrap.state && selfTrap.active) {
            yaw = selfTrap.rotate.x;
            pitch = crystalAura.rotate.y;
         } else {
            yaw = mc.field_1724.method_36454();
            pitch = mc.field_1724.method_36455();
         }
      } else {
         yaw = rotation.getYaw();
         pitch = rotation.getPitch();
      }

      double maxRange = Math.max(blockRange, entityRange);
      class_243 cameraPos = camera.method_5836(tickDelta);
      EntityVisibility entityVisibility = Manager.FUNCTION_MANAGER.entityVisibility;
      WiciaEntityVisibility wiciaEntityVisibility = Manager.FUNCTION_MANAGER.wiciaEntityVisibility;
      class_3966 entityHit = RayTraceUtil.rayCastEntity(maxRange, yaw, pitch, (e) -> !e.method_7325() && e.method_5863() && !entityVisibility.shouldHideEntity(e) && (wiciaEntityVisibility == null || !wiciaEntityVisibility.shouldHideEntity(e)));
      class_3965 blockHit = Manager.FUNCTION_MANAGER.freeCamera.isFastMode() ? Manager.FUNCTION_MANAGER.freeCamera.fastRaycast(maxRange, false) : RayTraceUtil.rayCast(maxRange, yaw, pitch, false);
      BetterPainting betterPainting = Manager.FUNCTION_MANAGER.betterPainting;
      if (betterPainting.state && blockHit != null) {
         blockHit = betterPainting.skipCobweb(blockHit);
      }

      if (entityHit != null) {
         double entityDistSq = entityHit.method_17784().method_1025(cameraPos);
         double blockDistSq = blockHit != null ? blockHit.method_17784().method_1025(cameraPos) : Double.MAX_VALUE;
         if (entityDistSq <= entityRange * entityRange && entityDistSq < blockDistSq) {
            cir.setReturnValue(entityHit);
            return;
         }
      }

      if (blockHit != null && blockHit.method_17784().method_1025(cameraPos) <= blockRange * blockRange) {
         cir.setReturnValue(blockHit);
      } else {
         cir.setReturnValue(class_3965.method_17778(cameraPos, (class_2350)null, (class_2338)null));
      }

   }

   @Redirect(
      method = {"findCrosshairTarget"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/projectile/ProjectileUtil;raycast(Lnet/minecraft/entity/Entity;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Vec3d;Lnet/minecraft/util/math/Box;Ljava/util/function/Predicate;D)Lnet/minecraft/util/hit/EntityHitResult;"
)
   )
   private class_3966 findCrosshairTarget(class_1297 entity, class_243 start, class_243 end, class_238 box, Predicate<class_1297> predicate, double maxDistance) {
      return !Manager.FUNCTION_MANAGER.noRayTrace.state ? class_1675.method_18075(entity, start, end, box, predicate, maxDistance) : null;
   }

   @Inject(
      method = {"tiltViewWhenHurt"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void tiltViewWhenHurtHook(class_4587 matrices, float tickDelta, CallbackInfo ci) {
      if (Manager.FUNCTION_MANAGER.noRender.state && Manager.FUNCTION_MANAGER.noRender.mods.get("Drgania kamery")) {
         ci.cancel();
      }

   }

   @Redirect(
      method = {"renderWorld"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/util/math/MathHelper;lerp(FFF)F"
)
   )
   private float badEffects(float delta, float first, float second) {
      return Manager.FUNCTION_MANAGER.noRender.state && Manager.FUNCTION_MANAGER.noRender.mods.get("Negatywne efekty") ? 0.0F : class_3532.method_16439(delta, first, second);
   }
}
