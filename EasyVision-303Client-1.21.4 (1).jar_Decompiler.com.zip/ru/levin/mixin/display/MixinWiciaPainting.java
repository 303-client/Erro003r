package ru.levin.mixin.display;

import net.minecraft.class_1297;
import net.minecraft.class_1534;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_761;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;

@Mixin({class_761.class})
public class MixinWiciaPainting {
   @Inject(
      method = {"renderEntity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onRenderEntity(class_1297 entity, double cameraX, double cameraY, double cameraZ, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, CallbackInfo ci) {
      if (Manager.FUNCTION_MANAGER.wiciaPainting != null && Manager.FUNCTION_MANAGER.wiciaPainting.state && entity instanceof class_1534 && Manager.FUNCTION_MANAGER.wiciaPainting.throughPainting.get()) {
         ci.cancel();
      }

   }
}
