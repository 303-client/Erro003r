package ru.levin.mixin.display;

import net.minecraft.class_1297;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;

@Mixin({class_898.class})
public class MixinWiciaEntityRender {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onRender(class_1297 entity, double x, double y, double z, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo callbackInfo) {
      if (Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.state && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.shouldHideEntity(entity)) {
         callbackInfo.cancel();
      }

   }
}
