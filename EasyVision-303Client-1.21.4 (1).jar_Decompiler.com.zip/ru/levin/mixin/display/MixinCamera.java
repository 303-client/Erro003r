package ru.levin.mixin.display;

import net.minecraft.class_1297;
import net.minecraft.class_1922;
import net.minecraft.class_4184;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.movement.freelook.CameraOverriddenEntity;
import ru.levin.modules.movement.freelook.FreeLookState;

@Mixin({class_4184.class})
public abstract class MixinCamera implements IMinecraft {
   @Unique
   private boolean initialized = false;
   @Shadow
   private boolean field_18719;

   @Shadow
   protected abstract void method_19325(float var1, float var2);

   @Inject(
      method = {"update"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V",
   shift = Shift.AFTER
)}
   )
   private void onUpdate(CallbackInfo ci) {
      if (FreeLookState.active) {
         class_746 var3 = mc.field_1724;
         if (var3 instanceof CameraOverriddenEntity) {
            CameraOverriddenEntity entity = (CameraOverriddenEntity)var3;
            if (!this.initialized) {
               entity.setCameraPitch(mc.field_1724.method_36455());
               entity.setCameraYaw(mc.field_1724.method_36454());
               this.initialized = true;
            }

            this.method_19325(entity.getCameraYaw(), entity.getCameraPitch());
            return;
         }
      }

   }

   @Inject(
      method = {"update"},
      at = {@At("TAIL")}
   )
   private void updateHook(class_1922 area, class_1297 focusedEntity, boolean thirdPerson, boolean inverseView, float tickDelta, CallbackInfo ci) {
      if (Manager.FUNCTION_MANAGER.freeCamera.state) {
         this.field_18719 = true;
      }

   }

   @ModifyArgs(
      method = {"update"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/Camera;setRotation(FF)V"
)
   )
   private void setRotationHook(Args args) {
      if (Manager.FUNCTION_MANAGER.freeCamera.state) {
         args.setAll(new Object[]{Manager.FUNCTION_MANAGER.freeCamera.getFakeYaw(), Manager.FUNCTION_MANAGER.freeCamera.getFakePitch()});
      }

   }

   @ModifyArgs(
      method = {"update"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/render/Camera;setPos(DDD)V"
)
   )
   private void setPosHook(Args args) {
      if (Manager.FUNCTION_MANAGER.freeCamera.state) {
         args.setAll(new Object[]{Manager.FUNCTION_MANAGER.freeCamera.getFakeX(), Manager.FUNCTION_MANAGER.freeCamera.getFakeY(), Manager.FUNCTION_MANAGER.freeCamera.getFakeZ()});
      }

   }
}
