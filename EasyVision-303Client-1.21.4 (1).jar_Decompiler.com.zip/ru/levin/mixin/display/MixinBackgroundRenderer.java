package ru.levin.mixin.display;

import com.llamalad7.mixinextras.injector.ModifyReturnValue;
import net.minecraft.class_1297;
import net.minecraft.class_4184;
import net.minecraft.class_758;
import net.minecraft.class_9958;
import org.joml.Vector4f;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.events.Event;
import ru.levin.events.impl.world.EventFog;
import ru.levin.manager.Manager;

@Mixin({class_758.class})
public class MixinBackgroundRenderer {
   @Inject(
      method = {"getFogModifier(Lnet/minecraft/entity/Entity;F)Lnet/minecraft/client/render/BackgroundRenderer$StatusEffectFogModifier;"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private static void onGetFogModifier(class_1297 entity, float tickDelta, CallbackInfoReturnable<Object> info) {
      if (Manager.FUNCTION_MANAGER.noRender.state && Manager.FUNCTION_MANAGER.noRender.mods.get("Negatywne efekty")) {
         info.setReturnValue((Object)null);
      }

   }

   @ModifyReturnValue(
      method = {"applyFog"},
      at = {@At("RETURN")}
   )
   private static class_9958 modifyFog(class_9958 original, class_4184 camera, class_758.class_4596 fogType, Vector4f color, float viewDistance, boolean thickenFog, float tickDelta) {
      EventFog fogEvent = new EventFog();
      Event.call(fogEvent);
      return fogEvent.modified ? new class_9958(fogEvent.start, fogEvent.end, fogEvent.shape, fogEvent.r, fogEvent.g, fogEvent.b, fogEvent.alpha) : original;
   }
}
