package ru.levin.mixin.display;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1297;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.impl.GpsCommand;
import ru.levin.manager.commandManager.impl.WayPointCommand;
import ru.levin.modules.render.CrossHair;

@Mixin({class_329.class})
public class MixinInGameHud {
   @Inject(
      at = {@At("HEAD")},
      method = {"render"}
   )
   public void renderHook(class_332 drawContext, class_9779 tickCounter, CallbackInfo ci) {
      RenderSystem.enableDepthTest();
      class_4587 matrices = drawContext.method_51448();
      if (!ClientManager.legitMode) {
         GpsCommand.render(matrices);
         WayPointCommand.render(matrices);
      }

      Event.call(new EventRender2D(drawContext, matrices, tickCounter));
      if (Manager.FUNCTION_MANAGER.hud.state && Manager.FUNCTION_MANAGER.hud.setting.get("Notifications")) {
         Manager.NOTIFICATION_MANAGER.draw(drawContext);
      }

      RenderSystem.disableDepthTest();
   }

   @Inject(
      method = {"renderVignetteOverlay"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cancelVignette(class_332 context, class_1297 entity, CallbackInfo ci) {
      ci.cancel();
   }

   @Inject(
      method = {"renderCrosshair"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/gui/hud/InGameHud;CROSSHAIR_TEXTURE:Lnet/minecraft/util/Identifier;"
)},
      cancellable = true
   )
   public void renderCrosshairHook(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      CrossHair crossHair = Manager.FUNCTION_MANAGER.crossHair;
      if (crossHair.state) {
         crossHair.render(context);
         ci.cancel();
      }

   }

   @Inject(
      at = {@At("HEAD")},
      method = {"renderStatusEffectOverlay"},
      cancellable = true
   )
   public void renderStatusEffectOverlay(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
      if (!ClientManager.legitMode) {
         ci.cancel();
      }

   }
}
