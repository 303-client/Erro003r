package ru.levin.mixin.display;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import net.minecraft.class_1934;
import net.minecraft.class_268;
import net.minecraft.class_355;
import net.minecraft.class_640;
import net.minecraft.class_8144;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;

@Mixin({class_355.class})
public class MixinPlayerListHud {
   private static final Comparator<class_640> ENTRY_ORDERING = Comparator.comparingInt((entry) -> entry.method_2958() == class_1934.field_9219 ? 1 : 0).thenComparing((entry) -> (String)class_8144.method_49078(entry.method_2955(), class_268::method_1197, "")).thenComparing((entry) -> entry.method_2966().getName(), String::compareToIgnoreCase);

   @Inject(
      method = {"collectPlayerEntries"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void collectPlayerEntriesHook(CallbackInfoReturnable<List<class_640>> cir) {
      if (IMinecraft.mc.field_1724 != null && IMinecraft.mc.field_1724.field_3944 != null) {
         int limit = Manager.FUNCTION_MANAGER.extraTab.state ? 200 : 80;
         List<class_640> list = new ArrayList(IMinecraft.mc.field_1724.field_3944.method_45732());
         list.sort(ENTRY_ORDERING);
         if (list.size() > limit) {
            list = list.subList(0, limit);
         }

         cir.setReturnValue(list);
      }
   }
}
