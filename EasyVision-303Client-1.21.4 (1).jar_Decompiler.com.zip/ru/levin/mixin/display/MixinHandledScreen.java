package ru.levin.mixin.display;

import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_1735;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3675;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.minecraft.class_465;
import org.jetbrains.annotations.Nullable;
import org.lwjgl.glfw.GLFW;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.util.player.TimerUtil;

@Mixin({class_465.class})
public abstract class MixinHandledScreen<T extends class_1703> extends class_437 implements class_3936<T>, IMinecraft {
   @Unique
   private final TimerUtil timerUtil = new TimerUtil();
   @Shadow
   protected @Nullable class_1735 field_2787;

   protected MixinHandledScreen(class_2561 title) {
      super(title);
   }

   @Shadow
   protected abstract void method_2383(class_1735 var1, int var2, int var3, class_1713 var4);

   @Inject(
      method = {"drawMouseoverTooltip"},
      at = {@At("HEAD")}
   )
   private void onDrawMouseoverTooltip(class_332 context, int x, int y, CallbackInfo ci) {
      if (this.field_2787 != null && this.field_2787.method_7681()) {
         long windowHandle = mc.method_22683().method_4490();
         boolean leftMousePressed = GLFW.glfwGetMouseButton(windowHandle, 0) == 1;
         boolean shiftPressed = class_3675.method_15987(windowHandle, 340) || class_3675.method_15987(windowHandle, 344);
         if (Manager.FUNCTION_MANAGER.itemScroller != null && Manager.FUNCTION_MANAGER.itemScroller.state && leftMousePressed && shiftPressed && this.field_22787.field_1755 != null && this.timerUtil.hasTimeElapsed(Manager.FUNCTION_MANAGER.itemScroller.scroll.get().longValue()) && this.field_2787.method_7681()) {
            this.method_2383(this.field_2787, this.field_2787.field_7874, 0, class_1713.field_7794);
            this.timerUtil.reset();
         }

      }
   }
}
