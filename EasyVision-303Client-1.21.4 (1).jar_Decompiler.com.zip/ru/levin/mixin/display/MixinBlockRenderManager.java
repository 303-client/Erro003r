package ru.levin.mixin.display;

import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_5819;
import net.minecraft.class_776;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;
import ru.levin.modules.misc.EasyVision;
import ru.levin.modules.misc.Xray;
import ru.levin.util.render.EasyVisionUtil;
import ru.levin.util.render.XrayUtil;

@Mixin({class_776.class})
public class MixinBlockRenderManager {
   @Inject(
      method = {"renderBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$xray(class_2680 var1, class_2338 var2, class_1920 var3, class_4587 var4, class_4588 var5, boolean var6, class_5819 var7, CallbackInfo var8) {
      if (Manager.FUNCTION_MANAGER != null) {
         EasyVision var9 = Manager.FUNCTION_MANAGER.easyVision;
         if (var9 != null && var9.state) {
            if (!EasyVisionUtil.shouldRender(var1)) {
               var8.cancel();
            }

         } else {
            Xray var10 = Manager.FUNCTION_MANAGER.xray;
            if (var10 != null && var10.isFastMode() && var10.state && !XrayUtil.shouldRender(var1)) {
               var8.cancel();
            }

         }
      }
   }
}
