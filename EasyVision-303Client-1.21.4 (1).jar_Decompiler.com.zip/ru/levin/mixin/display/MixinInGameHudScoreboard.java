package ru.levin.mixin.display;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.class_9779;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;
import ru.levin.modules.render.ScoreBoardStealer;
import ru.levin.modules.render.ScoreboardEditor;

@Mixin({class_329.class})
public abstract class MixinInGameHudScoreboard {
   @Shadow
   @Final
   private class_310 field_2035;

   @Shadow
   public abstract class_327 method_1756();

   @Inject(
      method = {"renderScoreboardSidebar"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$renderScoreboard(class_332 context, class_9779 tickCounter, CallbackInfo callbackInfo) {
      if (Manager.FUNCTION_MANAGER != null) {
         ScoreboardEditor editor = Manager.FUNCTION_MANAGER.scoreboardEditor;
         ScoreBoardStealer stealer = Manager.FUNCTION_MANAGER.scoreBoardStealer;
         if (stealer != null && stealer.state) {
            this.renderWithStealer(context, tickCounter, callbackInfo, stealer);
         } else if (editor.state && this.field_2035.field_1687 != null) {
            class_266 objective = this.field_2035.field_1687.method_8428().method_1189(class_8646.field_45157);
            if (objective != null) {
               class_269 scoreboard = objective.method_1117();
               List<class_9011> entries = new ArrayList(scoreboard.method_1184(objective));
               entries.removeIf(class_9011::method_55385);
               entries.sort(Comparator.comparingInt(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER));
               if (entries.size() > 15) {
                  entries = entries.subList(0, 15);
               }

               List<class_2561> lines = new ArrayList(entries.size());

               for(int index = 0; index < entries.size(); ++index) {
                  class_9011 entry = (class_9011)entries.get(index);
                  class_268 team = scoreboard.method_1164(entry.comp_2127());
                  class_2561 decorated = class_268.method_1142(team, exosware$safeDisplayName(entry));
                  lines.add(editor.editLine(decorated, entries.size() - index));
               }

               class_2561 title = editor.editTitle(objective.method_1114());
               class_327 renderer = this.method_1756();
               int maxWidth = renderer.method_27525(title);

               for(class_2561 line : lines) {
                  maxWidth = Math.max(maxWidth, renderer.method_27525(line));
               }

               int lineCount = lines.size();
               int y = context.method_51443() / 2 + lineCount * 9 / 3;
               int left = context.method_51421() - maxWidth - 3;
               int right = context.method_51421() - 1;
               int headerColor = this.field_2035.field_1690.method_19345(0.4F);
               int lineColor = this.field_2035.field_1690.method_19345(0.3F);
               context.method_25294(left - 2, y - lineCount * 9 - 10, right, y - lineCount * 9 - 1, headerColor);
               context.method_25294(left - 2, y - lineCount * 9 - 1, right, y, lineColor);
               context.method_27535(renderer, title, left + (maxWidth - renderer.method_27525(title)) / 2, y - lineCount * 9 - 9, -1);

               for(int index = 0; index < lines.size(); ++index) {
                  context.method_27535(renderer, (class_2561)lines.get(index), left, y - (lineCount - index) * 9, -1);
               }

               callbackInfo.cancel();
            }
         }
      }
   }

   private void renderWithStealer(class_332 context, class_9779 tickCounter, CallbackInfo callbackInfo, ScoreBoardStealer stealer) {
      if (this.field_2035.field_1687 != null) {
         class_266 objective = this.field_2035.field_1687.method_8428().method_1189(class_8646.field_45157);
         if (objective != null) {
            class_269 scoreboard = objective.method_1117();
            List<class_9011> entries = new ArrayList(scoreboard.method_1184(objective));
            entries.removeIf(class_9011::method_55385);
            entries.sort(Comparator.comparingInt(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER));
            if (entries.size() > 15) {
               entries = entries.subList(0, 15);
            }

            List<class_2561> textLines = new ArrayList();
            textLines.add(objective.method_1114());

            for(class_9011 entry : entries) {
               class_268 team = scoreboard.method_1164(entry.comp_2127());
               class_2561 decorated = class_268.method_1142(team, exosware$safeDisplayName(entry));
               textLines.add(decorated);
            }

            stealer.updateScoreboardTextLines(textLines);
            List<class_2561> lines = new ArrayList(entries.size());

            for(int index = 0; index < entries.size(); ++index) {
               class_9011 entry = (class_9011)entries.get(index);
               class_268 team = scoreboard.method_1164(entry.comp_2127());
               class_2561 decorated = class_268.method_1142(team, exosware$safeDisplayName(entry));
               lines.add(stealer.editLine(decorated, entries.size() - index));
            }

            class_2561 title = stealer.editTitle(objective.method_1114());
            class_327 renderer = this.method_1756();
            int maxWidth = renderer.method_27525(title);

            for(class_2561 line : lines) {
               maxWidth = Math.max(maxWidth, renderer.method_27525(line));
            }

            int lineCount = lines.size();
            int y = context.method_51443() / 2 + lineCount * 9 / 3;
            int left = context.method_51421() - maxWidth - 3;
            int right = context.method_51421() - 1;
            int headerColor = this.field_2035.field_1690.method_19345(0.4F);
            int lineColor = this.field_2035.field_1690.method_19345(0.3F);
            context.method_25294(left - 2, y - lineCount * 9 - 10, right, y - lineCount * 9 - 1, headerColor);
            context.method_25294(left - 2, y - lineCount * 9 - 1, right, y, lineColor);
            context.method_27535(renderer, title, left + (maxWidth - renderer.method_27525(title)) / 2, y - lineCount * 9 - 9, -1);

            for(int index = 0; index < lines.size(); ++index) {
               context.method_27535(renderer, (class_2561)lines.get(index), left, y - (lineCount - index) * 9, -1);
            }

            callbackInfo.cancel();
         }
      }
   }

   // $FF: synthetic method
   private static class_2561 exosware$safeDisplayName(class_9011 var0) {
      return (class_2561)Objects.requireNonNullElse(var0.comp_2129(), class_2561.method_43470(Objects.toString(var0.comp_2127(), "")));
   }
}
