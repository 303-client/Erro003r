package ru.levin.mixin.display;

import java.util.function.Predicate;
import net.minecraft.class_1297;
import net.minecraft.class_1675;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3966;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;

@Mixin({class_1675.class})
public class MixinWiciaEntityRaycast {
   @Inject(
      method = {"raycast"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private static void wicia$onRaycast(class_1297 entity, class_243 start, class_243 end, class_238 box, Predicate<class_1297> predicate, double maxDistance, CallbackInfoReturnable<class_3966> cir) {
      try {
         if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.state) {
            class_3966 result = (class_3966)cir.getReturnValue();
            if (result != null && result.method_17782() != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.shouldBlockProjectile(result.method_17782())) {
               cir.setReturnValue((Object)null);
            }
         }
      } catch (Exception var9) {
      }

   }
}
