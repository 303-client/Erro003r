package ru.levin.mixin.display;

import net.minecraft.class_2586;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_824;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;
import ru.levin.util.render.EasyVisionUtil;

@Mixin({class_824.class})
public abstract class MixinBlockEntityRenderDispatcher {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$hideBlockEntity(class_2586 var1, float var2, class_4587 var3, class_4597 var4, CallbackInfo var5) {
      try {
         if (Manager.FUNCTION_MANAGER != null) {
            if (Manager.FUNCTION_MANAGER.easyVision != null && Manager.FUNCTION_MANAGER.easyVision.state && !EasyVisionUtil.shouldRender(var1.method_11010())) {
               var5.cancel();
               return;
            }

            if (Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.shouldHideBlockEntity(var1)) {
               var5.cancel();
            }
         }
      } catch (Exception var7) {
      }

   }
}
