package ru.levin.mixin.display;

import net.minecraft.class_1297;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_898;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;

@Mixin({class_898.class})
public abstract class MixinEntityRenderDispatcher {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$hideEntity(class_1297 entity, double x, double y, double z, float tickDelta, class_4587 matrices, class_4597 vertexConsumers, int light, CallbackInfo callbackInfo) {
      try {
         if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.entityVisibility != null && Manager.FUNCTION_MANAGER.entityVisibility.shouldHideEntity(entity)) {
            callbackInfo.cancel();
         }

         if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.shouldHideEntity(entity)) {
            callbackInfo.cancel();
         }

         if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.freeCamera != null && entity == class_310.method_1551().field_1724 && Manager.FUNCTION_MANAGER.freeCamera.isFastMode()) {
            callbackInfo.cancel();
         }
      } catch (Exception e) {
         System.err.println("[ExosWare] EntityRender error: " + e.getMessage());
      }

   }
}
