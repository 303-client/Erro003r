package ru.levin.mixin.fastclient;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5689;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;
import ru.levin.util.AutoDripUtil;
import ru.levin.util.BetterPaintingUtil;

@Mixin({class_636.class})
public class MixinClientPlayerInteractionManager {
   private long lastTrapdoorToggle = 0L;
   private static final long TOGGLE_DELAY = 50L;

   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exos$betterPaintingNoWeb(class_746 player, class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> cir) {
      if (Manager.FUNCTION_MANAGER != null) {
         class_310 client = class_310.method_1551();
         if (client != null && client.field_1687 != null) {
            if (hand == class_1268.field_5808 && Manager.FUNCTION_MANAGER.fastBetterPainting != null && Manager.FUNCTION_MANAGER.fastBetterPainting.state && hit != null && player.method_6047().method_31574(class_1802.field_8892) && BetterPaintingUtil.isPassThroughBlock(client.field_1687.method_8320(hit.method_17777()))) {
               float tickDelta = client.method_61966().method_60637(client.method_1493());
               class_3965 replaced = BetterPaintingUtil.skipPassThrough(client, tickDelta, hit);
               if (replaced != null && !replaced.method_17777().equals(hit.method_17777())) {
                  class_1269 result = client.field_1761.method_2896(player, hand, replaced);
                  cir.setReturnValue(result);
                  return;
               }
            }

            if (hand == class_1268.field_5808) {
               class_1269 autoDripResult = AutoDripUtil.onUseBlock(player, client.field_1687, hand, hit);
               if (autoDripResult != class_1269.field_5811) {
                  cir.setReturnValue(autoDripResult);
                  return;
               }
            }

         }
      }
   }

   @Inject(
      method = {"interactBlock"},
      at = {@At("RETURN")}
   )
   private void exos$fastDripstoneTrapdoor(class_746 player, class_1268 hand, class_3965 hit, CallbackInfoReturnable<class_1269> cir) {
      if (Manager.FUNCTION_MANAGER != null) {
         if (Manager.FUNCTION_MANAGER.fastDripstone != null && Manager.FUNCTION_MANAGER.fastDripstone.state) {
            class_1269 result = (class_1269)cir.getReturnValue();
            if (result != null && result.method_23665()) {
               class_310 client = class_310.method_1551();
               if (client != null && client.field_1687 != null && hit != null) {
                  class_2338 placedPos = hit.method_17777();
                  if (client.field_1687.method_8320(placedPos).method_26204() instanceof class_5689) {
                     class_2338 downPos = placedPos.method_10074();
                     if (client.field_1687.method_8320(downPos).method_26204() instanceof class_2533) {
                        long now = System.currentTimeMillis();
                        if (now - this.lastTrapdoorToggle > 50L) {
                           class_243 hitPos = class_243.method_24953(downPos);
                           class_3965 trapdoorHit = new class_3965(hitPos, class_2350.field_11036, downPos, false);
                           client.field_1761.method_2896(player, hand, trapdoorHit);
                           this.lastTrapdoorToggle = now;
                        }
                     }
                  }
               }
            }
         }

      }
   }
}
