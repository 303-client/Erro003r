package ru.levin.mixin.fastclient;

import net.minecraft.class_2561;
import net.minecraft.class_9011;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;

@Mixin({class_9011.class})
public class MixinScoreboardEntry {
   @Inject(
      method = {"name"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void exos$nameProtectScoreboard(CallbackInfoReturnable<class_2561> cir) {
      if (Manager.FUNCTION_MANAGER != null) {
         if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
            cir.setReturnValue((class_2561)cir.getReturnValue());
         }

      }
   }
}
