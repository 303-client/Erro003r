package ru.levin.mixin.fastclient;

import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_5348;
import net.minecraft.class_5481;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import ru.levin.manager.Manager;
import ru.levin.util.NameProtectUtil;

@Mixin({class_327.class})
public class MixinTextRenderer {
   @ModifyVariable(
      method = {"draw(Ljava/lang/String;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private String exos$nameProtectDrawString(String text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceString(text) : text;
      }
   }

   @ModifyVariable(
      method = {"draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_2561 exos$nameProtectDrawText(class_2561 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceText(text) : text;
      }
   }

   @ModifyVariable(
      method = {"draw(Lnet/minecraft/text/Text;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;IIZ)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_2561 exos$nameProtectDrawTextZ(class_2561 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceText(text) : text;
      }
   }

   @ModifyVariable(
      method = {"draw(Lnet/minecraft/text/OrderedText;FFIZLorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;Lnet/minecraft/client/font/TextRenderer$TextLayerType;II)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5481 exos$nameProtectDrawOrdered(class_5481 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceOrderedText(text) : text;
      }
   }

   @ModifyVariable(
      method = {"drawWithOutline(Lnet/minecraft/text/OrderedText;FFIILorg/joml/Matrix4f;Lnet/minecraft/client/render/VertexConsumerProvider;I)V"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5481 exos$nameProtectDrawOutline(class_5481 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceOrderedText(text) : text;
      }
   }

   @ModifyVariable(
      method = {"getWidth(Ljava/lang/String;)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private String exos$nameProtectWidthString(String text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceString(text) : text;
      }
   }

   @ModifyVariable(
      method = {"getWidth(Lnet/minecraft/text/StringVisitable;)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5348 exos$nameProtectWidthVisitable(class_5348 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceVisitable(text) : text;
      }
   }

   @ModifyVariable(
      method = {"getWidth(Lnet/minecraft/text/OrderedText;)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5481 exos$nameProtectWidthOrdered(class_5481 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceOrderedText(text) : text;
      }
   }

   @ModifyVariable(
      method = {"trimToWidth(Ljava/lang/String;IZ)Ljava/lang/String;"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private String exos$nameProtectTrimString(String text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceString(text) : text;
      }
   }

   @ModifyVariable(
      method = {"trimToWidth(Ljava/lang/String;I)Ljava/lang/String;"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private String exos$nameProtectTrimString2(String text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceString(text) : text;
      }
   }

   @ModifyVariable(
      method = {"trimToWidth(Lnet/minecraft/text/StringVisitable;I)Lnet/minecraft/text/StringVisitable;"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5348 exos$nameProtectTrimVisitable(class_5348 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceVisitable(text) : text;
      }
   }

   @ModifyVariable(
      method = {"getWrappedLinesHeight(Ljava/lang/String;I)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private String exos$nameProtectWrappedHeightString(String text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceString(text) : text;
      }
   }

   @ModifyVariable(
      method = {"getWrappedLinesHeight(Lnet/minecraft/text/StringVisitable;I)I"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5348 exos$nameProtectWrappedHeightVisitable(class_5348 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceVisitable(text) : text;
      }
   }

   @ModifyVariable(
      method = {"wrapLines(Lnet/minecraft/text/StringVisitable;I)Ljava/util/List;"},
      at = @At("HEAD"),
      argsOnly = true
   )
   private class_5348 exos$nameProtectWrapLines(class_5348 text) {
      if (Manager.FUNCTION_MANAGER == null) {
         return text;
      } else {
         return Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state ? NameProtectUtil.replaceVisitable(text) : text;
      }
   }
}
