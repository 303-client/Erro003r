package ru.levin.mixin.fastclient;

import net.minecraft.class_2561;
import net.minecraft.class_355;
import net.minecraft.class_640;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;
import ru.levin.util.NameProtectUtil;

@Mixin({class_355.class})
public class MixinPlayerListHud {
   @Inject(
      method = {"getPlayerName"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void exos$nameProtectPlayerList(class_640 entry, CallbackInfoReturnable<class_2561> cir) {
      if (Manager.FUNCTION_MANAGER != null) {
         if (Manager.FUNCTION_MANAGER.fastNameProtect != null && Manager.FUNCTION_MANAGER.fastNameProtect.state) {
            class_2561 replaced = NameProtectUtil.replaceText((class_2561)cir.getReturnValue());
            cir.setReturnValue(replaced);
         }

      }
   }
}
