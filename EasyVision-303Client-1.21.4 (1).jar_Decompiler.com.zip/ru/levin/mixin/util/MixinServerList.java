package ru.levin.mixin.util;

import com.llamalad7.mixinextras.sugar.Local;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_641;
import net.minecraft.class_642;
import net.minecraft.class_642.class_8678;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.ClientManager;

@Mixin({class_641.class})
public class MixinServerList {
   @Unique
   private final List<class_642> serverTop;
   @Shadow
   @Final
   private List<class_642> field_3749;
   @Shadow
   @Final
   private List<class_642> field_39438;

   public MixinServerList() {
      this.serverTop = List.of(new class_642("Лучший HvH сервер!", "mc.furryhvh.ru", class_8678.field_45611));
   }

   @Inject(
      method = {"loadFile"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/option/ServerList;hiddenServers:Ljava/util/List;",
   ordinal = 0
)}
   )
   private void loadFileHook(CallbackInfo ci) {
      if (ClientManager.legitMode) {
         this.field_3749.removeIf((si) -> this.serverTop.stream().anyMatch((top) -> top.field_3761.equals(si.field_3761)));
      } else {
         for(class_642 top : this.serverTop) {
            boolean exists = this.field_3749.stream().anyMatch((si) -> si.field_3761.equals(top.field_3761));
            if (!exists) {
               this.field_3749.add(top);
            }
         }
      }

      this.removeDuplicates();
   }

   @Unique
   private void removeDuplicates() {
      this.removeDuplicatesFromList(this.field_3749);
      this.removeDuplicatesFromList(this.field_39438);
   }

   @Unique
   private void removeDuplicatesFromList(List<class_642> list) {
      Set<String> seen = new HashSet();
      list.removeIf((si) -> !seen.add(si.field_3761));
   }

   @Redirect(
      method = {"saveFile"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/nbt/NbtList;add(Ljava/lang/Object;)Z",
   ordinal = 0
)
   )
   private boolean saveFileHook(class_2499 instance, Object o, @Local(ordinal = 0) class_642 info) {
      return !ClientManager.legitMode && this.serverTop.stream().anyMatch((top) -> top.field_3761.equals(info.field_3761)) ? true : instance.add((class_2520)o);
   }
}
