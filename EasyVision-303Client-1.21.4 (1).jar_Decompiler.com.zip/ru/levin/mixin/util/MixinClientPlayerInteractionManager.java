package ru.levin.mixin.util;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2480;
import net.minecraft.class_2533;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.player.CustomCoolDown;

@Mixin({class_636.class})
public class MixinClientPlayerInteractionManager {
   @Inject(
      method = {"interactItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void cancelUseItem(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      class_1799 stack = player.method_5998(hand);
      CustomCoolDown coolDown = Manager.FUNCTION_MANAGER.customCoolDown;
      if (coolDown.state) {
         if (!coolDown.PVPonly.get() || ClientManager.playerIsPVP()) {
            if (coolDown.isItemEnabled(stack.method_7909()) && coolDown.lastUseMap.containsKey(stack.method_7909())) {
               cir.setReturnValue(class_1269.field_5814);
               cir.cancel();
            }

         }
      }
   }

   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void interactBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
      class_2248 bs = IMinecraft.mc.field_1687.method_8320(hitResult.method_17777()).method_26204();
      if (Manager.FUNCTION_MANAGER.noInteract.state && (bs == class_2246.field_10034 || bs == class_2246.field_10380 || bs == class_2246.field_10181 || bs == class_2246.field_10535 || bs == class_2246.field_9980 || bs == class_2246.field_10312 || bs == class_2246.field_10223 || bs == class_2246.field_10179 || bs == class_2246.field_10443 || bs == class_2246.field_10200 || bs == class_2246.field_10228 || bs == class_2246.field_10083 || bs == class_2246.field_10327 || bs == class_2246.field_16329 || bs instanceof class_2480 || bs instanceof class_2354 || bs instanceof class_2349 || bs instanceof class_2533) && (Manager.FUNCTION_MANAGER.attackAura.state || !Manager.FUNCTION_MANAGER.noInteract.onlyAura.get())) {
         cir.setReturnValue(class_1269.field_5811);
      }

   }
}
