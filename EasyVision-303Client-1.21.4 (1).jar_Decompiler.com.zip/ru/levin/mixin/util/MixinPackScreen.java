package ru.levin.mixin.util;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import net.minecraft.class_5375;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.ClientManager;
import ru.levin.manager.commandManager.impl.UnHookCommand;

@Mixin({class_5375.class})
public abstract class MixinPackScreen {
   @Shadow
   @Final
   @Mutable
   private Path field_25474;

   @Inject(
      method = {"init"},
      at = {@At("HEAD")}
   )
   private void onInit(CallbackInfo ci) {
      if (ClientManager.legitMode) {
         try {
            File customFile = UnHookCommand.CUSTOM_PATH_FILE;
            if (customFile.exists()) {
               String content = Files.readString(customFile.toPath()).trim();
               if (!content.isEmpty()) {
                  Path customPath = Path.of(content);
                  if (Files.exists(customPath, new LinkOption[0])) {
                     this.field_25474 = customPath;
                     System.out.println("Tryb legit: ścieżka do paczek zasobów zmieniona na " + String.valueOf(customPath));
                  } else {
                     System.err.println("Ścieżka z pliku nie istnieje: " + String.valueOf(customPath));
                  }
               }
            }
         } catch (Exception e) {
            System.err.println("Nie udało się zmienić ścieżki do paczek zasobów: " + e.getMessage());
         }
      }

   }
}
