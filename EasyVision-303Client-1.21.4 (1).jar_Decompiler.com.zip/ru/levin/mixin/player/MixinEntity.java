package ru.levin.mixin.player;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.combat.AutoExplosion;
import ru.levin.modules.combat.CrystalAura;
import ru.levin.modules.combat.HitBox;
import ru.levin.modules.combat.TargetStrafe;
import ru.levin.modules.combat.rotation.RotationController;
import ru.levin.modules.movement.freelook.CameraOverriddenEntity;
import ru.levin.modules.movement.freelook.FreeLookState;
import ru.levin.modules.player.NoPush;
import ru.levin.modules.render.Trails;
import ru.levin.util.IEntity;
import ru.levin.util.player.AuraUtil;

@Mixin({class_1297.class})
public abstract class MixinEntity implements IEntity, CameraOverriddenEntity, IMinecraft {
   @Unique
   private float cameraYaw;
   @Unique
   private float cameraPitch;
   @Unique
   private List<Trails.Trail> trails = new ArrayList();
   @Unique
   private class_243 lastTrailPos;
   @Shadow
   private class_238 field_6005;

   @Shadow
   protected static class_243 method_18795(class_243 movementInput, float speed, float yaw) {
      double d = movementInput.method_1027();
      if (d < 1.0E-7) {
         return class_243.field_1353;
      } else {
         class_243 vec3d = (d > (double)1.0F ? movementInput.method_1029() : movementInput).method_1021((double)speed);
         float sin = class_3532.method_15374(yaw * ((float)Math.PI / 180F));
         float cos = class_3532.method_15362(yaw * ((float)Math.PI / 180F));
         return new class_243(vec3d.field_1352 * (double)cos - vec3d.field_1350 * (double)sin, vec3d.field_1351, vec3d.field_1350 * (double)cos + vec3d.field_1352 * (double)sin);
      }
   }

   @Inject(
      method = {"changeLookDirection"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onChangeLookDirection(double deltaX, double deltaY, CallbackInfo ci) {
      class_1297 self = (class_1297)this;
      if (self instanceof class_746 && Manager.FUNCTION_MANAGER.freeCamera.isFastMode()) {
         Manager.FUNCTION_MANAGER.freeCamera.handleFastLook(deltaX, deltaY);
         ci.cancel();
      } else {
         if (FreeLookState.active && self instanceof class_746) {
            this.cameraYaw += (float)deltaX * 0.15F;
            this.cameraPitch = class_3532.method_15363(this.cameraPitch + (float)deltaY * 0.15F, -90.0F, 90.0F);
            ci.cancel();
         }

      }
   }

   public float getCameraPitch() {
      return this.cameraPitch;
   }

   public float getCameraYaw() {
      return this.cameraYaw;
   }

   public void setCameraPitch(float pitch) {
      this.cameraPitch = pitch;
   }

   public void setCameraYaw(float yaw) {
      this.cameraYaw = yaw;
   }

   @ModifyArgs(
      method = {"pushAwayFrom"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;addVelocity(DDD)V"
)
   )
   private void pushAwayFromHook(Args args) {
      class_1297 self = (class_1297)this;
      NoPush noPush = Manager.FUNCTION_MANAGER.noPush;
      if (self == mc.field_1724 && noPush.state && noPush.playersEnabled()) {
         args.set(0, (double)0.0F);
         args.set(1, (double)0.0F);
         args.set(2, (double)0.0F);
      }

   }

   public List<Trails.Trail> exosWareFabric1_21_4$getTrails() {
      return this.trails;
   }

   public class_243 exosWareFabric1_21_4$getLastTrailPos() {
      return this.lastTrailPos;
   }

   public void exosWareFabric1_21_4$setLastTrailPos(class_243 pos) {
      this.lastTrailPos = pos;
   }

   @ModifyExpressionValue(
      method = {"move"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/Entity;isControlledByPlayer()Z"
)}
   )
   private boolean fixFallDistanceCalculation(boolean original) {
      class_1297 self = (class_1297)this;
      return self != mc.field_1724 && original;
   }

   @Inject(
      method = {"getBoundingBox"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void getBoundingBox(CallbackInfoReturnable<class_238> cir) {
      class_1297 self = (class_1297)this;
      HitBox hitBox = Manager.FUNCTION_MANAGER.xbox;
      if (hitBox.state && mc != null && mc.field_1724 != null && self.method_5628() != mc.field_1724.method_5628()) {
         float halfSize = hitBox.size.get().floatValue() / 2.0F;
         class_238 expanded = new class_238(this.field_6005.field_1323 - (double)halfSize, this.field_6005.field_1322 - (double)halfSize, this.field_6005.field_1321 - (double)halfSize, this.field_6005.field_1320 + (double)halfSize, this.field_6005.field_1325 + (double)halfSize, this.field_6005.field_1324 + (double)halfSize);
         cir.setReturnValue(expanded);
      }

   }

   @Inject(
      method = {"updateVelocity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onUpdateVelocity(float speed, class_243 movementInput, CallbackInfo ci) {
      class_1297 self = (class_1297)this;
      if (self == mc.field_1724) {
         class_243 customVelocity = null;
         AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
         AutoExplosion autoExplosion = Manager.FUNCTION_MANAGER.autoExplosion;
         CrystalAura crystalAura = Manager.FUNCTION_MANAGER.crystalAura;
         TargetStrafe targetStrafe = Manager.FUNCTION_MANAGER.targetStrafe;
         RotationController rotationController = Manager.ROTATION;
         boolean correcting = attackAura.state && attackAura.correction.get() || rotationController.isControlling();
         if (correcting) {
            float yaw = rotationController.getYaw();
            if (targetStrafe.state && attackAura.target != null) {
               class_1297 target = attackAura.target;
               boolean nearTarget = mc.field_1724.method_5829().method_1014((double)targetStrafe.blocks.get().floatValue()).method_994(target.method_5829());
               boolean insideHitbox = mc.field_1724.method_5829().method_1014((double)targetStrafe.hitbox.get().floatValue()).method_994(target.method_5829());
               if (nearTarget) {
                  if (insideHitbox) {
                     customVelocity = AuraUtil.getVelocityTowards(target, (double)targetStrafe.speedSlider.get().floatValue(), false, targetStrafe.predictView.get());
                  } else if (targetStrafe.ptytag.is("Motion / Velocity")) {
                     mc.field_1690.field_1894.method_23481(true);
                     customVelocity = method_18795(movementInput, speed, yaw);
                  } else {
                     customVelocity = AuraUtil.getVelocityTowards(target, (double)0.08F, false, targetStrafe.predictView.get());
                  }
               } else {
                  customVelocity = method_18795(movementInput, speed, yaw);
               }
            } else {
               customVelocity = method_18795(movementInput, speed, yaw);
            }
         } else if (autoExplosion.check()) {
            customVelocity = method_18795(movementInput, speed, autoExplosion.serverRot.x);
         } else if (crystalAura.check()) {
            customVelocity = method_18795(movementInput, speed, crystalAura.rotate.x);
         }

         if (customVelocity != null) {
            self.method_18799(self.method_18798().method_1019(customVelocity));
            ci.cancel();
         }

      }
   }
}
