package ru.levin.mixin.player;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;

@Mixin({class_1297.class})
public class MixinWiciaEntityCollision {
   @Inject(
      method = {"collidesWith"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onCollidesWith(class_1297 entity, CallbackInfoReturnable<Boolean> cir) {
      try {
         if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility != null && Manager.FUNCTION_MANAGER.wiciaEntityVisibility.state && entity instanceof class_1657 && entity != null) {
            cir.setReturnValue(false);
         }
      } catch (Exception var4) {
      }

   }
}
