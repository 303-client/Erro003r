package ru.levin.mixin.player;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArgs;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import org.spongepowered.asm.mixin.injection.invoke.arg.Args;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.combat.AutoExplosion;
import ru.levin.modules.combat.CrystalAura;
import ru.levin.modules.combat.rotation.RotationController;
import ru.levin.modules.render.SwingAnimations;

@Mixin({class_1309.class})
public abstract class MixinLivingEntity implements IMinecraft {
   @ModifyArgs(
      method = {"takeKnockback"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;setVelocity(DDD)V"
)
   )
   private void exosware$reverseKnockback(Args args) {
      if (Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.striker.state && this != mc.field_1724) {
         double multiplier = Manager.FUNCTION_MANAGER.striker.strength.get().doubleValue();
         args.set(0, -(Double)args.get(0) * multiplier);
         args.set(2, -(Double)args.get(2) * multiplier);
      }
   }

   @Inject(
      method = {"getHandSwingDuration"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void getArmSwingAnimationEnd(CallbackInfoReturnable<Integer> info) {
      SwingAnimations swingAnimations = Manager.FUNCTION_MANAGER.swingAnimations;
      if (swingAnimations.state && swingAnimations.slowAnimation.get()) {
         info.setReturnValue(swingAnimations.slowAnimationSpeed.get().intValue());
      }

   }

   @Shadow
   public abstract float method_6106();

   @Shadow
   protected abstract double method_7490();

   @Inject(
      method = {"jump"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onJump(CallbackInfo ci) {
      if (this == mc.field_1724) {
         AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
         AutoExplosion autoExplosion = Manager.FUNCTION_MANAGER.autoExplosion;
         RotationController rotationController = Manager.ROTATION;
         CrystalAura crystalAura = Manager.FUNCTION_MANAGER.crystalAura;
         Float yaw = null;
         if ((!attackAura.state || !attackAura.correction.get()) && !rotationController.isControlling()) {
            if (autoExplosion.check()) {
               yaw = autoExplosion.serverRot.x;
            } else if (crystalAura.check()) {
               yaw = crystalAura.rotate.x;
            }
         } else {
            yaw = rotationController.getYaw();
         }

         if (yaw != null) {
            float jumpVelocity = this.method_6106();
            if (jumpVelocity <= 1.0E-5F) {
               ci.cancel();
            } else {
               class_243 currentVelocity = mc.field_1724.method_18798();
               mc.field_1724.method_18800(currentVelocity.field_1352, Math.max((double)jumpVelocity, currentVelocity.field_1351), currentVelocity.field_1350);
               if (mc.field_1724.method_5624()) {
                  float yawRad = yaw * ((float)Math.PI / 180F);
                  double x = (double)(-class_3532.method_15374(yawRad)) * 0.2;
                  double z = (double)class_3532.method_15362(yawRad) * 0.2;
                  mc.field_1724.method_45319(new class_243(x, (double)0.0F, z));
               }

               mc.field_1724.field_6007 = true;
               ci.cancel();
            }
         }
      }
   }

   @Inject(
      method = {"calcGlidingVelocity"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onCalcGlidingVelocity(class_243 oldVelocity, CallbackInfoReturnable<class_243> cir) {
      if (this == mc.field_1724) {
         AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
         RotationController rotationController = Manager.ROTATION;
         if (attackAura.state && attackAura.correction.get() || rotationController.isControlling()) {
            float customYaw = rotationController.getYaw();
            float customPitch = rotationController.getPitch();
            class_243 rotationVec = class_243.method_1030(customPitch, customYaw);
            float pitchRad = customPitch * ((float)Math.PI / 180F);
            double horizontalLength = Math.sqrt(rotationVec.field_1352 * rotationVec.field_1352 + rotationVec.field_1350 * rotationVec.field_1350);
            double oldHorizontalLength = oldVelocity.method_37267();
            double gravity = this.method_7490();
            double cosSquared = class_3532.method_33723(Math.cos((double)pitchRad));
            class_243 newVelocity = oldVelocity.method_1031((double)0.0F, gravity * ((double)-1.0F + cosSquared * (double)0.75F), (double)0.0F);
            if (newVelocity.field_1351 < (double)0.0F && horizontalLength > (double)0.0F) {
               double lift = newVelocity.field_1351 * -0.1 * cosSquared;
               newVelocity = newVelocity.method_1031(rotationVec.field_1352 * lift / horizontalLength, lift, rotationVec.field_1350 * lift / horizontalLength);
            }

            if (pitchRad < 0.0F && horizontalLength > (double)0.0F) {
               double acceleration = oldHorizontalLength * (double)(-class_3532.method_15374(pitchRad)) * 0.04;
               newVelocity = newVelocity.method_1031(-rotationVec.field_1352 * acceleration / horizontalLength, acceleration * 3.2, -rotationVec.field_1350 * acceleration / horizontalLength);
            }

            if (horizontalLength > (double)0.0F) {
               newVelocity = newVelocity.method_1031((rotationVec.field_1352 / horizontalLength * oldHorizontalLength - newVelocity.field_1352) * 0.1, (double)0.0F, (rotationVec.field_1350 / horizontalLength * oldHorizontalLength - newVelocity.field_1350) * 0.1);
            }

            newVelocity = newVelocity.method_18805(0.99, 0.98, 0.99);
            cir.setReturnValue(newVelocity);
            cir.cancel();
         }

      }
   }
}
