package ru.levin.mixin.player;

import net.minecraft.class_312;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.ExosWare;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventMouse;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.dragManager.DragManager;

@Mixin({class_312.class})
public class MixinMouse implements IMinecraft {
   @Inject(
      method = {"onMouseButton"},
      at = {@At(
   value = "FIELD",
   target = "Lnet/minecraft/client/MinecraftClient;player:Lnet/minecraft/client/network/ClientPlayerEntity;",
   ordinal = 0
)}
   )
   private void beforeSpectatorCheck(long window, int button, int action, int mods, CallbackInfo ci) {
      boolean bl = action == 1;
      if (bl) {
         ExosWare main = new ExosWare();
         main.keyPress(-100 + button);
         Event.call(new EventMouse(button));
      }
   }

   @Inject(
      method = {"onMouseButton"},
      at = {@At("HEAD")}
   )
   private void onMouseButton(long window, int button, int action, int mods, CallbackInfo ci) {
      if (mc.field_1755 instanceof class_408) {
         DragManager var10000 = Manager.DRAG_MANAGER;
         DragManager.draggables.values().forEach((dragging) -> {
            if (dragging.getModule() != null && dragging.getModule().state) {
               dragging.onRelease(button);
            }

         });
      }

   }
}
