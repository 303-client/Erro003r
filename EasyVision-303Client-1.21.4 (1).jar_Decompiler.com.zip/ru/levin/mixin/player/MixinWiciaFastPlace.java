package ru.levin.mixin.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;

@Mixin({class_636.class})
public class MixinWiciaFastPlace {
   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onInteractBlock(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> cir) {
      if (Manager.FUNCTION_MANAGER.wiciaFastPlace != null && Manager.FUNCTION_MANAGER.wiciaFastPlace.state && !Manager.FUNCTION_MANAGER.wiciaFastPlace.shouldPlaceBlock()) {
         cir.setReturnValue(class_1269.field_5814);
      }

   }
}
