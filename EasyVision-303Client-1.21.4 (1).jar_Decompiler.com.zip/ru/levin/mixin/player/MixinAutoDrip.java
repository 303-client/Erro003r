package ru.levin.mixin.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.modules.player.AutoDripUtil;
import ru.levin.modules.player.FastDripstoneUtil;
import ru.levin.modules.player.WiciaDripstoneUtil;

@Mixin({class_636.class})
public abstract class MixinAutoDrip {
   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$autoDrip(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> callbackInfo) {
      class_310 mc = class_310.method_1551();
      class_1269 result = WiciaDripstoneUtil.onUseBlock(player, mc.field_1687, hand, hitResult);
      if (result == null) {
         result = FastDripstoneUtil.onUseBlock(player, hand, hitResult);
      }

      if (result == null) {
         result = AutoDripUtil.onUseBlock(player, hand, hitResult);
      }

      if (result != null) {
         callbackInfo.setReturnValue(result);
      }

   }
}
