package ru.levin.mixin.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.modules.player.CustomCoolDown;

@Mixin({class_1792.class})
public class MixinItem {
   @Inject(
      method = {"use"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void use(class_1937 world, class_1657 user, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      if (user instanceof class_746) {
         CustomCoolDown coolDown = Manager.FUNCTION_MANAGER.customCoolDown;
         if (coolDown.state) {
            if (!coolDown.PVPonly.get() || ClientManager.playerIsPVP()) {
               class_1799 stack = user.method_5998(hand);
               if (coolDown.isItemEnabled(stack.method_7909()) && coolDown.lastUseMap.containsKey(stack.method_7909())) {
                  cir.setReturnValue(class_1269.field_5814);
                  cir.cancel();
               }

            }
         }
      }
   }

   @Inject(
      method = {"finishUsing"},
      at = {@At("RETURN")}
   )
   public void finishUsing(class_1799 stack, class_1937 world, class_1309 user, CallbackInfoReturnable<class_1799> cir) {
      if (user instanceof class_746 player) {
         CustomCoolDown coolDown = Manager.FUNCTION_MANAGER.customCoolDown;
         if (coolDown.state) {
            if (!coolDown.PVPonly.get() || ClientManager.playerIsPVP()) {
               if (coolDown.isItemEnabled(stack.method_7909())) {
                  coolDown.setCooldown(stack.method_7909());
                  int cooldownTicks = (int)(coolDown.getCooldownForItem(stack.method_7909()) * 20.0F);
                  player.method_7357().method_62835(stack, cooldownTicks);
               }

            }
         }
      }
   }

   @Inject(
      method = {"getMaxUseTime"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void getMaxUseTime(class_1799 stack, class_1309 user, CallbackInfoReturnable<Integer> cir) {
      if (user instanceof class_746) {
         CustomCoolDown coolDown = Manager.FUNCTION_MANAGER.customCoolDown;
         if (coolDown.state) {
            if (!coolDown.PVPonly.get() || ClientManager.playerIsPVP()) {
               if (coolDown.isItemEnabled(stack.method_7909()) && coolDown.lastUseMap.containsKey(stack.method_7909())) {
                  cir.setReturnValue(0);
                  cir.cancel();
               }

            }
         }
      }
   }

   @Inject(
      method = {"isUsedOnRelease"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void isUsedOnRelease(class_1799 stack, CallbackInfoReturnable<Boolean> cir) {
      CustomCoolDown coolDown = Manager.FUNCTION_MANAGER.customCoolDown;
      if (coolDown.state) {
         if (!coolDown.PVPonly.get() || ClientManager.playerIsPVP()) {
            if (coolDown.isItemEnabled(stack.method_7909()) && coolDown.lastUseMap.containsKey(stack.method_7909())) {
               cir.setReturnValue(false);
               cir.cancel();
            }

         }
      }
   }
}
