package ru.levin.mixin.player;

import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1671;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.combat.rotation.RotationController;
import ru.levin.modules.movement.SuperFirework;

@Mixin({class_1671.class})
public abstract class MixinFireworkRocketEntity implements IMinecraft {
   @Redirect(
      method = {"tick"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/LivingEntity;setVelocity(Lnet/minecraft/util/math/Vec3d;)V"
)
   )
   private void tick(class_1309 shooter, class_243 originalVelocity) {
      if (shooter.method_6128() && shooter == mc.field_1724) {
         SuperFirework superFirework = Manager.FUNCTION_MANAGER.superFirework;
         AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
         RotationController rotationController = Manager.ROTATION;
         class_243 rotationVector;
         if ((!attackAura.state || attackAura.target == null || !attackAura.correction.get()) && !rotationController.isControlling()) {
            rotationVector = shooter.method_5663();
         } else {
            rotationVector = class_243.method_1030(Manager.ROTATION.getPitch(), Manager.ROTATION.getYaw());
         }

         double speedXZ = (double)1.5F;
         double speedY = (double)1.5F;
         if (superFirework.state) {
            float yaw = (!attackAura.state || attackAura.target == null) && !rotationController.isControlling() ? mc.field_1724.method_36454() % 360.0F : Manager.ROTATION.getYaw() % 360.0F;
            boolean isDiagonal = false;
            boolean nearPlayer = false;
            if (yaw < 0.0F) {
               yaw += 360.0F;
            }

            if (superFirework.mode.is("ReallyWorld")) {
               float[] diagonals = new float[]{45.0F, 135.0F, 225.0F, 315.0F};
               float closestDiff = 180.0F;

               for(float d : diagonals) {
                  float diff = Math.abs(yaw - d);
                  diff = Math.min(diff, 360.0F - diff);
                  if (diff < closestDiff) {
                     closestDiff = diff;
                  }
               }

               if (closestDiff <= superFirework.diag1) {
                  speedXZ = (double)superFirework.speedD_1;
               } else if (closestDiff <= superFirework.diag2) {
                  speedXZ = (double)superFirework.speedD_2;
               } else if (closestDiff <= superFirework.diag3) {
                  speedXZ = (double)superFirework.speedD_3;
               } else if (closestDiff <= superFirework.diag4) {
                  speedXZ = (double)superFirework.speedD_4;
               } else if (closestDiff <= superFirework.diag5) {
                  speedXZ = (double)superFirework.speedD_5;
               } else if (closestDiff <= superFirework.diag6) {
                  speedXZ = (double)superFirework.speedD_6;
               } else if (closestDiff <= superFirework.diag7) {
                  speedXZ = (double)superFirework.speedD_7;
               } else if (closestDiff <= superFirework.diag8) {
                  speedXZ = (double)superFirework.speedD_8;
               } else if (closestDiff <= superFirework.diag9) {
                  speedXZ = (double)superFirework.speedD_9;
               } else {
                  speedXZ = (double)superFirework.speedXZ;
                  speedY = (double)superFirework.speedY;
               }
            }

            if (superFirework.mode.is("BravoHvH")) {
               for(float d : new float[]{45.0F, 135.0F, 225.0F, 315.0F}) {
                  float diff = Math.abs(yaw - d);
                  diff = Math.min(diff, 360.0F - diff);
                  if (diff <= 16.0F) {
                     isDiagonal = true;
                     break;
                  }
               }

               if (superFirework.nearBoost.get()) {
                  for(class_1657 p : Manager.SYNC_MANAGER.getPlayers()) {
                     if (p != mc.field_1724 && p.method_5739(mc.field_1724) <= 4.0F) {
                        nearPlayer = true;
                        break;
                     }
                  }
               }

               if (isDiagonal) {
                  speedXZ = 1.963;
               } else if (superFirework.nearBoost.get() && nearPlayer) {
                  speedXZ = 1.82;
                  speedY = 1.67;
               } else {
                  speedXZ = 1.675;
                  speedY = 1.66;
               }
            }

            if (superFirework.mode.is("PulseHVH")) {
               for(float d : new float[]{45.0F, 135.0F, 225.0F, 315.0F}) {
                  float diff = Math.abs(yaw - d);
                  diff = Math.min(diff, 360.0F - diff);
                  if (diff <= 16.0F) {
                     isDiagonal = true;
                     break;
                  }
               }

               if (superFirework.nearBoost.get()) {
                  for(class_1657 p : Manager.SYNC_MANAGER.getPlayers()) {
                     if (p != mc.field_1724 && p.method_5739(mc.field_1724) <= 5.0F) {
                        nearPlayer = true;
                        break;
                     }
                  }
               }

               if (isDiagonal) {
                  speedXZ = 1.963;
               } else if (superFirework.nearBoost.get() && nearPlayer) {
                  speedXZ = 1.82;
                  speedY = 1.67;
               } else {
                  speedXZ = 1.675;
                  speedY = 1.66;
               }
            }

            if (superFirework.mode.is("Custom")) {
               for(float d : new float[]{45.0F, 135.0F, 225.0F, 315.0F}) {
                  float diff = Math.abs(yaw - d);
                  diff = Math.min(diff, 360.0F - diff);
                  if (diff <= 16.0F) {
                     isDiagonal = true;
                     break;
                  }
               }

               if (superFirework.nearBoost.get()) {
                  for(class_1657 p : Manager.SYNC_MANAGER.getPlayers()) {
                     if (p != mc.field_1724 && p.method_5739(mc.field_1724) <= 5.0F) {
                        nearPlayer = true;
                        break;
                     }
                  }
               }

               if (isDiagonal) {
                  speedXZ = (double)superFirework.speed.get().floatValue();
               } else if (superFirework.nearBoost.get() && nearPlayer) {
                  speedXZ = (double)(superFirework.speed.get().floatValue() - 0.1F);
                  speedY = 1.67;
               } else {
                  speedXZ = 1.675;
                  speedY = 1.66;
               }
            }
         }

         class_243 vec3d = shooter.method_18798();
         shooter.method_18799(vec3d.method_1031(rotationVector.field_1352 * 0.1 + (rotationVector.field_1352 * speedXZ - vec3d.field_1352) * (double)0.5F, rotationVector.field_1351 * 0.1 + (rotationVector.field_1351 * speedY - vec3d.field_1351) * (double)0.5F, rotationVector.field_1350 * 0.1 + (rotationVector.field_1350 * speedXZ - vec3d.field_1350) * (double)0.5F));
      } else {
         shooter.method_18799(originalVelocity);
      }

   }
}
