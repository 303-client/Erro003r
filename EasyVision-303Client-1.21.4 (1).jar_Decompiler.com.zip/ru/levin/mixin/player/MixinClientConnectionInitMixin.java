package ru.levin.mixin.player;

import io.netty.channel.Channel;
import io.netty.channel.ChannelHandler;
import io.netty.handler.proxy.Socks4ProxyHandler;
import io.netty.handler.proxy.Socks5ProxyHandler;
import java.net.InetSocketAddress;
import net.minecraft.class_2561;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;
import ru.levin.manager.proxyManager.Proxy;
import ru.levin.manager.proxyManager.ProxyManager;

@Mixin(
   targets = {"net.minecraft.network.ClientConnection$1"}
)
public class MixinClientConnectionInitMixin {
   @Inject(
      method = {"initChannel(Lio/netty/channel/Channel;)V"},
      at = {@At("HEAD")}
   )
   private void connect(Channel channel, CallbackInfo ci) {
      ProxyManager proxyManager = Manager.PROXY_MANAGER;
      Proxy proxy = ProxyManager.proxy;
      if (ProxyManager.proxyEnabled && proxy != null) {
         ProxyManager.lastUsedProxy = proxy;
         if (proxy.type == Proxy.ProxyType.SOCKS5) {
            channel.pipeline().addFirst(new ChannelHandler[]{new Socks5ProxyHandler(new InetSocketAddress(proxy.getIp(), proxy.getPort()), proxy.username.isEmpty() ? null : proxy.username, proxy.password.isEmpty() ? null : proxy.password)});
         } else if (proxy.type == Proxy.ProxyType.SOCKS4) {
            channel.pipeline().addFirst(new ChannelHandler[]{new Socks4ProxyHandler(new InetSocketAddress(proxy.getIp(), proxy.getPort()), proxy.username.isEmpty() ? null : proxy.username)});
         }
      } else {
         ProxyManager.lastUsedProxy = new Proxy();
      }

      ProxyManager.proxyMenuButton.method_25355(class_2561.method_43470("Proxy: " + ProxyManager.getLastUsedProxyIp()));
   }
}
