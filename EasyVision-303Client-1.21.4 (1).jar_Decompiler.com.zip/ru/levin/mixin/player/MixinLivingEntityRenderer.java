package ru.levin.mixin.player;

import net.minecraft.class_10042;
import net.minecraft.class_1309;
import net.minecraft.class_490;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventPlayerRender;
import ru.levin.manager.IMinecraft;

@Mixin({class_922.class})
public abstract class MixinLivingEntityRenderer<T extends class_1309, S extends class_10042> implements IMinecraft {
   @Unique
   private float originalPrevHeadYaw;
   @Unique
   private float originalHeadYaw;
   @Unique
   private float originalPrevHeadPitch;
   @Unique
   private float originalHeadPitch;
   @Unique
   private float originalBodyYaw;
   @Unique
   private float originalPrevBodyYaw;
   @Unique
   private boolean replaced;

   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("HEAD")}
   )
   private void onUpdateRenderStatePre(T livingEntity, S state, float tickDelta, CallbackInfo ci) {
      if (mc != null && mc.field_1724 != null && livingEntity == mc.field_1724) {
         if (!(mc.field_1755 instanceof class_490)) {
            EventPlayerRender playerRender = new EventPlayerRender(livingEntity);
            Event.call(playerRender);
            this.originalPrevHeadYaw = livingEntity.field_6259;
            this.originalHeadYaw = livingEntity.field_6241;
            this.originalPrevHeadPitch = livingEntity.field_6004;
            this.originalHeadPitch = livingEntity.method_36455();
            this.originalBodyYaw = livingEntity.field_6283;
            this.originalPrevBodyYaw = livingEntity.field_6220;
            livingEntity.field_6259 = playerRender.getPrevYaw();
            livingEntity.field_6241 = playerRender.getYaw();
            livingEntity.field_6004 = playerRender.getPrevPitch();
            livingEntity.method_36457(playerRender.getPitch());
            livingEntity.field_6220 = playerRender.getPrevBodyYaw();
            livingEntity.field_6283 = playerRender.getBodyYaw();
            this.replaced = true;
         }
      }
   }

   @Inject(
      method = {"updateRenderState(Lnet/minecraft/entity/LivingEntity;Lnet/minecraft/client/render/entity/state/LivingEntityRenderState;F)V"},
      at = {@At("TAIL")}
   )
   private void onUpdateRenderStatePost(T livingEntity, S state, float tickDelta, CallbackInfo ci) {
      if (this.replaced && mc != null && mc.field_1724 != null && livingEntity == mc.field_1724) {
         livingEntity.field_6259 = this.originalPrevHeadYaw;
         livingEntity.field_6241 = this.originalHeadYaw;
         livingEntity.field_6004 = this.originalPrevHeadPitch;
         livingEntity.method_36457(this.originalHeadPitch);
         livingEntity.field_6220 = this.originalPrevBodyYaw;
         livingEntity.field_6283 = this.originalBodyYaw;
         this.replaced = false;
      }
   }
}
