package ru.levin.mixin.player;

import net.minecraft.class_1313;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.player.EventPlayerTravel;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.mixin.iface.MixinEntityAccessor;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.combat.rotation.RotationController;

@Mixin({class_1657.class})
public class MixinPlayerEntity implements IMinecraft {
   @Redirect(
      method = {"travel"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/entity/player/PlayerEntity;getRotationVector()Lnet/minecraft/util/math/Vec3d;"
)
   )
   private class_243 redirectGetRotationVector(class_1657 instance) {
      AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
      RotationController rotationController = Manager.ROTATION;
      if ((!attackAura.state || attackAura.target == null || !attackAura.correction.get()) && (!rotationController.isControlling() || instance != mc.field_1724)) {
         return ((MixinEntityAccessor)instance).invokeGetRotationVector(instance.method_36455(), instance.method_36454());
      } else {
         float pitch = rotationController.getPitch();
         float yaw = rotationController.getYaw();
         return ((MixinEntityAccessor)instance).invokeGetRotationVector(pitch, yaw);
      }
   }

   @Inject(
      method = {"travel"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onTravelhookPre(class_243 movementInput, CallbackInfo ci) {
      if (mc.field_1724 != null) {
         EventPlayerTravel event = new EventPlayerTravel(movementInput, true);
         Event.call(event);
         if (event.isCancel()) {
            mc.field_1724.method_5784(class_1313.field_6308, mc.field_1724.method_18798());
            ci.cancel();
         }

      }
   }

   @Inject(
      method = {"travel"},
      at = {@At("RETURN")},
      cancellable = true
   )
   private void onTravelhookPost(class_243 movementInput, CallbackInfo ci) {
      if (mc.field_1724 != null) {
         EventPlayerTravel event = new EventPlayerTravel(movementInput, false);
         Event.call(event);
         if (event.isCancel()) {
            mc.field_1724.method_5784(class_1313.field_6308, mc.field_1724.method_18798());
            ci.cancel();
         }

      }
   }
}
