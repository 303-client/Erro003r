package ru.levin.mixin.player;

import net.minecraft.class_10042;
import net.minecraft.class_1007;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_922;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;

@Mixin(
   value = {class_922.class},
   remap = false
)
public class MixinPlayerEntityRendererCrownHat implements IMinecraft {
   @Inject(
      method = {"method_4054"},
      at = {@At("RETURN")},
      remap = false
   )
   private void crownhat$renderAttached(class_10042 var1, class_4587 var2, class_4597 var3, int var4, CallbackInfo var5) {
      if (this instanceof class_1007 && Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.crownHat != null && Manager.FUNCTION_MANAGER.crownHat.isEnabled()) {
         Manager.FUNCTION_MANAGER.crownHat.renderHatAttached(var2, var3, mc.field_1724, 1.0F);
      }
   }
}
