package ru.levin.mixin.player;

import net.minecraft.class_10185;
import net.minecraft.class_315;
import net.minecraft.class_743;
import net.minecraft.class_744;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventKeyBoard;

@Mixin({class_743.class})
public abstract class MixinKeyboardInput extends class_744 {
   @Shadow
   @Final
   private class_315 field_3902;

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onTick(CallbackInfo ci) {
      boolean forwardKey = this.field_3902.field_1894.method_1434();
      boolean backwardKey = this.field_3902.field_1881.method_1434();
      boolean leftKey = this.field_3902.field_1913.method_1434();
      boolean rightKey = this.field_3902.field_1849.method_1434();
      boolean jumpKey = this.field_3902.field_1903.method_1434();
      boolean sneakKey = this.field_3902.field_1832.method_1434();
      boolean sprintKey = this.field_3902.field_1867.method_1434();
      float movementForward = this.calculateMovement(forwardKey, backwardKey);
      float movementSideways = this.calculateMovement(leftKey, rightKey);
      EventKeyBoard event = new EventKeyBoard(movementForward, movementSideways, jumpKey, sneakKey, sprintKey);
      Event.call(event);
      this.field_3905 = event.getMovementForward();
      this.field_3907 = event.getMovementStrafe();
      this.field_54155 = new class_10185(event.getMovementForward() > 0.0F, event.getMovementForward() < 0.0F, event.getMovementStrafe() > 0.0F, event.getMovementStrafe() < 0.0F, event.isJump(), event.isSneak(), event.isSprint());
      ci.cancel();
   }

   private float calculateMovement(boolean positive, boolean negative) {
      if (positive == negative) {
         return 0.0F;
      } else {
         return positive ? 1.0F : -1.0F;
      }
   }
}
