package ru.levin.mixin.player;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import net.minecraft.class_1313;
import net.minecraft.class_243;
import net.minecraft.class_744;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.events.impl.move.EventNoSlow;
import ru.levin.events.impl.player.EventSprint;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;

@Mixin({class_746.class})
public abstract class MixinClientPlayerEntity implements IMinecraft {
   @Unique
   private float preYaw;
   @Unique
   private float prePitch;
   @Unique
   private float packetYaw;
   @Unique
   private float packetPitch;

   @Shadow
   public abstract void method_5784(class_1313 var1, class_243 var2);

   @Inject(
      method = {"tick"},
      at = {@At("HEAD")}
   )
   private void onTickHead(CallbackInfo ci) {
      Event.call(new EventUpdate());
      this.preYaw = mc.field_1724.method_36454();
      this.prePitch = mc.field_1724.method_36455();
   }

   @Inject(
      method = {"sendMovementPackets"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onSendMovementPacketsHead(CallbackInfo ci) {
      EventMotion event = new EventMotion(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828());
      Event.call(event);
      if (event.isCancel()) {
         ci.cancel();
      } else {
         mc.field_1724.method_36456(event.getYaw());
         mc.field_1724.method_36457(event.getPitch());
      }
   }

   @Inject(
      method = {"tick"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;sendMovementPackets()V",
   shift = Shift.AFTER
)}
   )
   private void afterSendMovementPackets(CallbackInfo ci) {
      this.packetYaw = mc.field_1724.method_36454();
      this.packetPitch = mc.field_1724.method_36455();
      mc.field_1724.method_36456(this.preYaw);
      mc.field_1724.method_36457(this.prePitch);
   }

   @Inject(
      method = {"pushOutOfBlocks"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void onPushOutOfBlocksHook(double x, double d, CallbackInfo ci) {
      if (Manager.FUNCTION_MANAGER.noPush.state && Manager.FUNCTION_MANAGER.noPush.blocksEnabled()) {
         ci.cancel();
      }

   }

   private boolean checkNoSlowCancel() {
      EventNoSlow eventNoSlow = new EventNoSlow();
      Event.call(eventNoSlow);
      return eventNoSlow.isCancel();
   }

   @Redirect(
      method = {"tickMovement"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/input/Input;movementSideways:F",
   opcode = 181,
   ordinal = 0
)
   )
   private void redirectMovementSideways(class_744 input, float value) {
      if (!this.checkNoSlowCancel()) {
         input.field_3907 = value;
      }

   }

   @Redirect(
      method = {"tickMovement"},
      at = @At(
   value = "FIELD",
   target = "Lnet/minecraft/client/input/Input;movementForward:F",
   opcode = 181,
   ordinal = 0
)
   )
   private void redirectMovementForward(class_744 input, float value) {
      if (!this.checkNoSlowCancel()) {
         input.field_3905 = value;
      }

   }

   @Redirect(
      method = {"tickMovement"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;setSprinting(Z)V",
   ordinal = 0
)
   )
   private void redirectSetSprinting(class_746 player, boolean sprinting) {
      if (!this.checkNoSlowCancel()) {
         player.method_5728(sprinting);
      }

   }

   @ModifyExpressionValue(
      method = {"tickMovement"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/option/KeyBinding;isPressed()Z"
)}
   )
   private boolean hookSprintStart(boolean original) {
      EventSprint event = new EventSprint(original);
      return event.isSprinting();
   }

   @ModifyExpressionValue(
      method = {"tickMovement"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayerEntity;canSprint()Z"
)}
   )
   private boolean hookSprintStop(boolean original) {
      EventSprint event = new EventSprint(original);
      Event.call(event);
      return event.isSprinting();
   }
}
