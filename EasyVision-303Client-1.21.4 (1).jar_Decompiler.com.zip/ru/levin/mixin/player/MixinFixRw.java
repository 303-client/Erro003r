package ru.levin.mixin.player;

import net.minecraft.class_268;
import net.minecraft.class_269;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin({class_269.class})
public class MixinFixRw {
   @Inject(
      method = {"removeScoreHolderFromTeam"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void removeScoreHolderFromTeam(String scoreHolderName, class_268 team, CallbackInfo ci) {
      ci.cancel();
   }
}
