package ru.levin.mixin.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;

@Mixin({class_636.class})
public class MixinWiciaNielota {
   @Inject(
      method = {"interactItem"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void wicia$onInteractItem(class_1657 player, class_1268 hand, CallbackInfoReturnable<class_1269> cir) {
      if (Manager.FUNCTION_MANAGER.wiciaNielota != null && Manager.FUNCTION_MANAGER.wiciaNielota.state && Manager.FUNCTION_MANAGER.wiciaNielota.shouldThrowThisTick() && hand == Manager.FUNCTION_MANAGER.wiciaNielota.getThrowingHand()) {
         float oldYaw = player.method_36454();
         float oldPitch = player.method_36455();

         try {
            player.method_36456(Manager.FUNCTION_MANAGER.wiciaNielota.getTargetYaw());
            player.method_36457(Manager.FUNCTION_MANAGER.wiciaNielota.getTargetPitch());
            Manager.FUNCTION_MANAGER.wiciaNielota.setThrowingInProgress(true);
         } finally {
            player.method_36456(oldYaw);
            player.method_36457(oldPitch);
         }
      }

   }
}
