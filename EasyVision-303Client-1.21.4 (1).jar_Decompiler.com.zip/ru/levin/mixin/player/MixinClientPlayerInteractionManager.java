package ru.levin.mixin.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2596;
import net.minecraft.class_2813;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_465;
import net.minecraft.class_634;
import net.minecraft.class_636;
import net.minecraft.class_746;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.Manager;
import ru.levin.modules.misc.AutoDrain;
import ru.levin.modules.render.BetterPainting;
import ru.levin.util.move.MoveUtil;

@Mixin({class_636.class})
public class MixinClientPlayerInteractionManager {
   @Shadow
   @Final
   private class_310 field_3712;

   @Inject(
      method = {"attackBlock"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$protectCobweb(class_2338 pos, class_2350 direction, CallbackInfoReturnable<Boolean> callbackInfo) {
      BetterPainting betterPainting = Manager.FUNCTION_MANAGER.betterPainting;
      if (betterPainting.state && betterPainting.shouldProtect(this.field_3712.field_1687.method_8320(pos))) {
         callbackInfo.setReturnValue(false);
      }

   }

   @Inject(
      method = {"interactBlock"},
      at = {@At("HEAD")}
   )
   private void exosware$recordWaterPlacement(class_746 player, class_1268 hand, class_3965 hitResult, CallbackInfoReturnable<class_1269> callbackInfo) {
      AutoDrain.recordBucketPlacement(player, hand, hitResult);
   }

   @Redirect(
      method = {"clickSlot"},
      at = @At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/packet/Packet;)V"
)
   )
   private void redirectSendPacket(class_634 networkHandler, class_2596<?> packet) {
      if (packet instanceof class_2813 clickPacket) {
         if (Manager.FUNCTION_MANAGER.guiWalk.state && Manager.FUNCTION_MANAGER.guiWalk.bypass.is("FunTime") && clickPacket.method_12194() == 0 && MoveUtil.isMoving() && this.field_3712.field_1755 instanceof class_465) {
            Manager.FUNCTION_MANAGER.guiWalk.queuePacket(clickPacket);
            return;
         }
      }

      networkHandler.method_52787(packet);
   }
}
