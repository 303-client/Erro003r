package ru.levin.mixin.player;

import net.minecraft.class_309;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.ExosWare;
import ru.levin.manager.IMinecraft;

@Mixin({class_309.class})
public class MixinKeyBoard implements IMinecraft {
   @Inject(
      method = {"onKey"},
      at = {@At("HEAD")}
   )
   private void onKey(long window, int key, int scancode, int action, int modifiers, CallbackInfo ci) {
      if (action == 1 && !(mc.field_1755 instanceof class_437)) {
         ExosWare main = new ExosWare();
         main.keyPress(key);
      }

   }
}
