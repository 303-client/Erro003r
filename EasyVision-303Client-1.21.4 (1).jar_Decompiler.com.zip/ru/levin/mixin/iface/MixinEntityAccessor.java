package ru.levin.mixin.iface;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin({class_1297.class})
public interface MixinEntityAccessor {
   @Invoker("getRotationVector")
   class_243 invokeGetRotationVector(float var1, float var2);
}
