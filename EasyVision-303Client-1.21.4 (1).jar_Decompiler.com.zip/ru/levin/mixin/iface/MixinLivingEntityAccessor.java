package ru.levin.mixin.iface;

import net.minecraft.class_1309;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin({class_1309.class})
public interface MixinLivingEntityAccessor {
   @Accessor("jumpingCooldown")
   void setLastJumpCooldown(int var1);
}
