package ru.levin.mixin.chat;

import net.minecraft.class_332;
import net.minecraft.class_408;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.At.Shift;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.dragManager.DragManager;

@Mixin({class_408.class})
public abstract class MixinChatScreen implements IMinecraft {
   @Inject(
      method = {"render"},
      at = {@At("HEAD")},
      cancellable = true
   )
   public void render(class_332 context, int mouseX, int mouseY, float delta, CallbackInfo ci) {
      DragManager var10000 = Manager.DRAG_MANAGER;
      DragManager.draggables.values().forEach((dragging) -> {
         if (dragging.getModule() != null && dragging.getModule().state) {
            dragging.onDraw((double)mouseX, (double)mouseY, mc.method_22683());
            dragging.renderGuides(mc.method_22683());
         }

      });
   }

   @Inject(
      method = {"mouseClicked"},
      at = {@At(
   value = "INVOKE",
   target = "Lnet/minecraft/client/gui/screen/ChatInputSuggestor;mouseClicked(DDI)Z",
   shift = Shift.AFTER
)},
      cancellable = true
   )
   private void afterSuggestionsClick(double mouseX, double mouseY, int button, CallbackInfoReturnable<Boolean> cir) {
      if (!cir.getReturnValueZ()) {
         DragManager var10000 = Manager.DRAG_MANAGER;
         DragManager.draggables.values().forEach((dragging) -> {
            if (dragging.getModule() != null && dragging.getModule().state) {
               dragging.onClick(mouseX, mouseY, button);
            }

         });
      }

   }
}
