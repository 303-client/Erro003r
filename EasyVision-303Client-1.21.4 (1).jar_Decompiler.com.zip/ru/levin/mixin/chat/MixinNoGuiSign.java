package ru.levin.mixin.chat;

import net.minecraft.class_310;
import net.minecraft.class_437;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import ru.levin.manager.Manager;

@Mixin({class_634.class})
public abstract class MixinNoGuiSign {
   @Inject(
      method = {"onSignEditorOpen"},
      at = {@At("HEAD")},
      cancellable = true
   )
   private void exosware$noGuiSign(CallbackInfo callbackInfo) {
      if (Manager.FUNCTION_MANAGER.noGuiSign.state) {
         class_310 client = class_310.method_1551();
         if (client.field_1755 != null) {
            client.method_1507((class_437)null);
         }

         callbackInfo.cancel();
      }
   }
}
