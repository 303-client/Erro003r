package ru.levin.screens.dropdown.impl;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_332;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.screens.dropdown.SettingRenderer;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.localization.PolishLocalization;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.Scissor;

public class ModeSettingRenderer implements SettingRenderer<ModeSetting>, IMinecraft {
   private static final int TITLE_HEIGHT = 14;
   private static final int MODS_Y_OFFSET = 1;
   private static final int BOX_HEIGHT = 12;
   private static final int LINE_SPACING = 2;
   private static final int PADDING_HORIZONTAL = 3;
   private static final int START_X_OFFSET = 0;
   private final Map<String, Float> scrollOffsets = new HashMap();
   private final Map<String, Float> hoverProgress = new HashMap();

   public int getHeight(ModeSetting setting, int width) {
      int lineHeight = 14;
      int currentX = 0;
      int lines = 1;

      for(String mode : setting.getModes()) {
         int textWidth = (int)FontUtils.durman[13].getWidth(PolishLocalization.translate(mode));
         int boxWidth = textWidth + 6;
         if (currentX + boxWidth > width) {
            currentX = 0;
            ++lines;
         }

         currentX += boxWidth + 4;
      }

      return 14 + lines * lineHeight;
   }

   public int getHeight() {
      return 28;
   }

   public void render(class_332 ctx, ModeSetting setting, int x, int y, int width, int height) {
      double mouseX = mc.field_1729.method_1603() / mc.method_22683().method_4495();
      double mouseY = mc.field_1729.method_1604() / mc.method_22683().method_4495();
      FontUtils.durman[13].drawLeftAligned(ctx.method_51448(), PolishLocalization.translate(setting.getName()), (float)x, (float)y, Color.WHITE.getRGB());
      int startX = x + 0;
      int spacing = 4;
      int lineHeight = 14;
      int currentX = startX;
      int currentY = y + 14 - 1;

      for(String mode : setting.getModes()) {
         String displayMode = PolishLocalization.translate(mode);
         int textWidth = (int)FontUtils.durman[13].getWidth(displayMode);
         int boxWidth = textWidth + 6;
         if (currentX + boxWidth > x + width) {
            currentX = startX;
            currentY += lineHeight;
         }

         boolean selected = mode.equals(setting.get());
         boolean hovered = RenderUtil.isInRegion(mouseX, mouseY, (double)currentX, (double)currentY, (double)boxWidth, (double)12.0F);
         float hoverProg = (Float)this.hoverProgress.getOrDefault(mode, 0.0F);
         if (selected) {
            hoverProg = 1.0F;
         } else {
            hoverProg += (hovered ? 1.0F : 0.0F - hoverProg) * 0.08F;
         }

         this.hoverProgress.put(mode, hoverProg);
         Color baseColor = new Color(30, 30, 30, 180);
         int selectedColor = Manager.STYLE_MANAGER.getFirstColor();
         int bgColor;
         if (selected) {
            bgColor = selectedColor;
         } else {
            bgColor = ColorUtil.interpolateColor(baseColor.getRGB(), baseColor.getRGB(), hoverProg);
         }

         Color baseTextColor = new Color(200, 200, 200);
         Color hoverTextColor = Color.WHITE;
         int textColor = ColorUtil.interpolateColor(baseTextColor.getRGB(), hoverTextColor.getRGB(), hoverProg);
         RenderUtil.drawRoundedRect(ctx.method_51448(), (float)currentX, (float)currentY, (float)boxWidth, 12.0F, 1.0F, bgColor);
         float maxTextWidth = (float)(boxWidth - 6);
         float overflow = (float)textWidth - maxTextWidth;
         float offset = (Float)this.scrollOffsets.getOrDefault(mode, 0.0F);
         if (hovered && overflow > 0.0F) {
            offset = Math.min(offset + 0.5F, overflow);
         } else {
            offset = Math.max(offset - 0.5F, 0.0F);
         }

         this.scrollOffsets.put(mode, offset);
         Scissor.push();
         Scissor.setFromComponentCoordinates((double)(currentX + 3), (double)currentY, (double)maxTextWidth, (double)12.0F);
         FontUtils.durman[13].drawLeftAligned(ctx.method_51448(), displayMode, (float)(currentX + 3) - offset, (float)currentY + (12.0F - FontUtils.durman[13].getHeight()) / 2.0F, textColor);
         Scissor.pop();
         currentX += boxWidth + spacing;
      }

   }

   public boolean mouseClicked(ModeSetting setting, double mouseX, double mouseY, int button, int x, int y, int width, int height) {
      if (button != 0) {
         return false;
      } else {
         int startX = x + 0;
         int spacing = 4;
         int lineHeight = 14;
         int currentX = startX;
         int currentY = y + 14 - 1;

         for(String mode : setting.getModes()) {
            int textWidth = (int)FontUtils.durman[13].getWidth(PolishLocalization.translate(mode));
            int boxWidth = textWidth + 6;
            if (currentX + boxWidth > x + width) {
               currentX = startX;
               currentY += lineHeight;
            }

            if (RenderUtil.isInRegion((int)mouseX, (int)mouseY, currentX, currentY, boxWidth, 12)) {
               setting.set(mode);
               return true;
            }

            currentX += boxWidth + spacing;
         }

         return false;
      }
   }
}
