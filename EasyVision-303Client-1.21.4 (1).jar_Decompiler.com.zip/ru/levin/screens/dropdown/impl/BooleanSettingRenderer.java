package ru.levin.screens.dropdown.impl;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_332;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.manager.fontManager.RenderFonts;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.screens.dropdown.DescriptionRenderQueue;
import ru.levin.screens.dropdown.SettingRenderer;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.localization.PolishLocalization;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.Scissor;

public class BooleanSettingRenderer implements SettingRenderer<BooleanSetting>, IMinecraft {
   private static final int HEIGHT = 16;
   private static final int WIDTH = 22;
   private static final int SWITCH_HEIGHT = 12;
   private static final int KNOB_RADIUS = 8;
   private final Map<BooleanSetting, Float> toggleMap = new HashMap();
   private final Map<BooleanSetting, Float> scrollMap = new HashMap();

   public int getHeight() {
      return 16;
   }

   public void render(class_332 ctx, BooleanSetting setting, int x, int y, int width, int height) {
      float progress = (Float)this.toggleMap.getOrDefault(setting, setting.get() ? 1.0F : 0.0F);
      progress += ((setting.get() ? 1.0F : 0.0F) - progress) * 0.15F;
      this.toggleMap.put(setting, progress);
      int switchX = x + width - 22 + 4;
      int switchY = y + 2 - 2;
      Color offColor = new Color(50, 50, 50, 200);
      int onColor = Manager.STYLE_MANAGER.getFirstColor();
      int bgColor = ColorUtil.interpolateColor(offColor.getRGB(), onColor, progress);
      RenderUtil.drawRoundedRect(ctx.method_51448(), (float)switchX, (float)switchY, 22.0F, 12.0F, 5.0F, bgColor);
      RenderUtil.drawCircle(ctx.method_51448(), (float)(switchX + 3) + 9.0F * progress + 4.0F, (float)switchY + 2.0F + 4.0F, 8.0F, Color.WHITE.getRGB());
      RenderFonts font = FontUtils.durman[13];
      String text = PolishLocalization.translate(setting.getName());
      int textY = (int)((float)y + (16.0F - font.getHeight()) / 2.0F) - 2;
      float maxTextWidth = (float)(switchX - x - 4);
      float textWidth = font.getWidth(text);
      double scale = mc.method_22683().method_4495();
      double mX = mc.field_1729.method_1603() / scale;
      double mY = mc.field_1729.method_1604() / scale;
      float overflow = textWidth - maxTextWidth;
      float offset = (Float)this.scrollMap.getOrDefault(setting, 0.0F);
      boolean textHovered = RenderUtil.isHovered((int)mX, (int)mY, (double)x, (double)(textY - 1), (double)maxTextWidth, (double)(font.getHeight() + 2.0F));
      if (textHovered && overflow > 0.0F) {
         offset = Math.min(offset + 0.5F, overflow);
      } else {
         offset = Math.max(offset - 0.5F, 0.0F);
      }

      this.scrollMap.put(setting, offset);
      Scissor.push();
      Scissor.setFromComponentCoordinates((double)x, (double)(textY - 1), (double)maxTextWidth, (double)(font.getHeight() + 2.0F));
      font.drawLeftAligned(ctx.method_51448(), text, (float)x - offset, (float)textY, Color.WHITE.getRGB());
      Scissor.pop();
      boolean isHovered = mX >= (double)switchX && mX <= (double)(switchX + 22) && mY >= (double)switchY && mY <= (double)(switchY + 12);
      if (isHovered && setting.getDesc() != null && !setting.getDesc().isEmpty()) {
         DescriptionRenderQueue.add(PolishLocalization.translate(setting.getDesc()), (float)mX + 6.0F, (float)mY + 6.0F);
      }

   }

   public boolean mouseClicked(BooleanSetting setting, double mouseX, double mouseY, int button, int x, int y, int width, int height) {
      if (button != 0) {
         return false;
      } else {
         int switchX = x + width - 22 + 4;
         int switchY = y + 2 - 2;
         if (mouseX >= (double)switchX && mouseX <= (double)(switchX + 22) && mouseY >= (double)switchY && mouseY <= (double)(switchY + 12)) {
            setting.set(!setting.get());
            return true;
         } else {
            return false;
         }
      }
   }
}
