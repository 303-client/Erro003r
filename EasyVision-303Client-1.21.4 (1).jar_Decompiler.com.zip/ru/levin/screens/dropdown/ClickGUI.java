package ru.levin.screens.dropdown;

import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_437;
import net.minecraft.class_2350.class_2352;
import org.joml.Quaternionf;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.joml.Vector4i;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.manager.themeManager.Style;
import ru.levin.modules.Function;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.screens.dropdown.impl.BindBooleanSettingRenderer;
import ru.levin.screens.dropdown.impl.BindSettingRenderer;
import ru.levin.screens.dropdown.impl.BooleanSettingRenderer;
import ru.levin.screens.dropdown.impl.ModeSettingRenderer;
import ru.levin.screens.dropdown.impl.MultiSettingRenderer;
import ru.levin.screens.dropdown.impl.SliderSettingRenderer;
import ru.levin.screens.dropdown.impl.TextSettingRenderer;
import ru.levin.screens.dropdown.search.SearchState;
import ru.levin.util.animations.impl.EaseInOutQuad;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.Scissor;
import ru.levin.util.render.providers.ResourceProvider;

public class ClickGUI extends class_437 implements IMinecraft {
   private boolean isClose;
   private final int PANEL_WIDTH = 125;
   private final int PANEL_HEIGHT = 280;
   private final int PANEL_MARGIN = 8;
   private final Color GUI_COLOR;
   private final int TITLE_MARGIN_TOP;
   private final int TITLE_HEIGHT;
   private final int FUNCTION_HEIGHT;
   private final int SCROLL_AREA_Y_OFFSET;
   private final int SCROLL_AREA_HEIGHT;
   private final Set<Type> renderCategories;
   private static final Map<Type, Float> scrollOffsets = new HashMap();
   private static final Map<Type, Float> scrollTargets = new HashMap();
   private final Map<Function, Float> arrowRotationProgress;
   private final EaseInOutQuad animationOpen;
   private double animation;
   private final Map<Function, Float> expandProgress;
   private final SearchState searchState;
   private boolean functionBinding;
   private Function functions;
   private SliderSetting draggingSlider;
   private int draggingSliderX;
   private int draggingSliderWidth;
   private final BooleanSettingRenderer booleanSettingRenderer;
   private final BindBooleanSettingRenderer bindbooleanSettingRenderer;
   private final BindSettingRenderer bindSettingRenderer;
   private final ModeSettingRenderer modeSettingRenderer;
   private final MultiSettingRenderer multiSettingRenderer;
   private final SliderSettingRenderer sliderSettingRenderer;
   private final TextSettingRenderer textSettingRenderer;
   private final int SEARCH_HEIGHT;
   private final int SEARCH_MARGIN_BOTTOM;
   private final int SEARCH_MAX_WIDTH;
   private final int THEME_HEIGHT;
   private final int THEME_MARGIN_BOTTOM;
   private final int THEME_MAX_WIDTH;
   private static float themeScrollOffset = 0.0F;
   private static float themeScrollTarget = 0.0F;
   private final int VISIBLE_THEMES;
   private float themeMenuAnim;
   private float themeMenuTarget;
   private float themeAlphaAnim;
   private static final float THEME_ANIM_SPEED = 0.2F;
   private static boolean themeMenu;
   private float themeNameAnim;
   private final float SCROLL_SPEED;
   private final float SCROLL_LERP_FACTOR;
   private final float SCROLL_SMOOTH_FACTOR;
   private final float THEME_SCROLL_SPEED;
   private final float THEME_SCROLL_LERP_FACTOR;
   private static boolean colorPickerOpen = false;
   private static int selectedColor1;
   private static int selectedColor2;
   private float picker1CursorX;
   private float picker1CursorY;
   private float picker2CursorX;
   private float picker2CursorY;
   private boolean draggingPicker1;
   private boolean draggingPicker2;
   private float colorPickerAnim;

   public ClickGUI() {
      super(class_2561.method_43470("ClickGUI"));
      this.GUI_COLOR = Manager.FUNCTION_MANAGER.clickGUI.getGuiColor();
      this.TITLE_MARGIN_TOP = 5;
      this.TITLE_HEIGHT = 20;
      this.FUNCTION_HEIGHT = 20;
      this.SCROLL_AREA_Y_OFFSET = 25;
      this.SCROLL_AREA_HEIGHT = 250;
      this.renderCategories = EnumSet.of(Type.Combat, Type.Move, Type.Render, Type.Player, Type.Misc);
      this.arrowRotationProgress = new HashMap();
      this.animationOpen = new EaseInOutQuad(250, (double)1.0F);
      this.expandProgress = new HashMap();
      this.functionBinding = false;
      this.functions = null;
      this.draggingSlider = null;
      this.draggingSliderX = 0;
      this.draggingSliderWidth = 0;
      this.booleanSettingRenderer = new BooleanSettingRenderer();
      this.bindbooleanSettingRenderer = new BindBooleanSettingRenderer();
      this.bindSettingRenderer = new BindSettingRenderer();
      this.modeSettingRenderer = new ModeSettingRenderer();
      this.multiSettingRenderer = new MultiSettingRenderer();
      this.sliderSettingRenderer = new SliderSettingRenderer();
      this.textSettingRenderer = new TextSettingRenderer();
      this.SEARCH_HEIGHT = 20;
      this.SEARCH_MARGIN_BOTTOM = 10;
      this.SEARCH_MAX_WIDTH = 180;
      this.THEME_HEIGHT = 16;
      this.THEME_MARGIN_BOTTOM = 40;
      this.THEME_MAX_WIDTH = 180;
      this.VISIBLE_THEMES = 11;
      this.themeMenuAnim = 0.0F;
      this.themeMenuTarget = 0.0F;
      this.themeAlphaAnim = 0.0F;
      this.themeNameAnim = 0.0F;
      this.SCROLL_SPEED = 12.0F;
      this.SCROLL_LERP_FACTOR = 20.0F;
      this.SCROLL_SMOOTH_FACTOR = 12.0F;
      this.THEME_SCROLL_SPEED = 15.0F;
      this.THEME_SCROLL_LERP_FACTOR = 15.0F;
      this.picker1CursorX = 0.5F;
      this.picker1CursorY = 0.5F;
      this.picker2CursorX = 0.5F;
      this.picker2CursorY = 0.5F;
      this.draggingPicker1 = false;
      this.draggingPicker2 = false;
      this.colorPickerAnim = 0.0F;
      this.searchState = new SearchState();
      if (scrollOffsets.isEmpty() && scrollTargets.isEmpty()) {
         this.renderCategories.forEach((cat) -> {
            scrollOffsets.put(cat, 0.0F);
            scrollTargets.put(cat, 0.0F);
         });
      }

   }

   public void method_25426() {
      super.method_25426();
      this.isClose = false;
      this.animationOpen.setDirection(class_2352.field_11056);
      this.animationOpen.reset();
   }

   public void method_25394(class_332 ctx, int mouseX, int mouseY, float delta) {
      this.animation = this.animationOpen.getOutput();
      if (this.isClose && this.animationOpen.finished(class_2352.field_11060)) {
         super.method_25419();
      } else if (!(this.animation <= 0.01)) {
         super.method_25394(ctx, mouseX, mouseY, delta);
         ctx.method_51448().method_22903();

         for(Type category : this.renderCategories) {
            float target = (Float)scrollTargets.get(category);
            float current = (Float)scrollOffsets.get(category);
            float newOffset = MathUtil.lerp(current, target, 20.0F);
            scrollOffsets.put(category, newOffset);
         }

         int totalWidth = this.renderCategories.size() * 133 - 8;
         int startX = (this.field_22789 - totalWidth) / 2;
         int startY = (this.field_22790 - 280) / 2;
         RenderAddon.sizeAnimation(ctx.method_51448(), (double)(this.field_22789 / 2), (double)(this.field_22790 / 2), this.animation);
         int idx = 0;

         for(Type category : this.renderCategories) {
            this.renderPanel(ctx, startX + idx++ * 133, startY, category, mouseX, mouseY);
         }

         Function hoveredFunction = this.getHoveredFunction(mouseX, mouseY, startX, startY);
         if (hoveredFunction != null && hoveredFunction.getDisplayDescription() != null && !hoveredFunction.getDisplayDescription().isEmpty()) {
            this.drawDescription(ctx, hoveredFunction.getDisplayDescription(), startY);
         }

         DescriptionRenderQueue.renderAll(ctx);
         this.renderSearchField(ctx);
         this.renderButtomTheme(ctx, (double)mouseX, (double)mouseY);
         this.renderTheme(ctx, mouseX, mouseY);
         this.renderExpiryText(ctx);
         ctx.method_51448().method_22909();
      }
   }

   private Function getHoveredFunction(int mouseX, int mouseY, int startX, int startY) {
      int idx = 0;

      for(Type category : this.renderCategories) {
         int panelX = startX + idx++ * 133;
         if (mouseX >= panelX && mouseX <= panelX + 125 && mouseY >= startY && mouseY <= startY + 280) {
            float offset = (Float)scrollOffsets.get(category);
            float currentY = (float)(startY + 25) - offset;

            for(Function function : Manager.FUNCTION_MANAGER.getFunctions(category)) {
               if (this.isFunctionVisible(function)) {
                  int functionHeight = 20;
                  int fullSettingsHeight = this.computeSettingsHeight(function);
                  float progress = (Float)this.expandProgress.getOrDefault(function, function.expanded ? 1.0F : 0.0F);
                  int animatedSettingsHeight = Math.round((float)fullSettingsHeight * progress);
                  int totalHeight = functionHeight + animatedSettingsHeight;
                  if (mouseX >= panelX && mouseX <= panelX + 125 && (float)mouseY >= currentY && (float)mouseY <= currentY + (float)functionHeight && mouseY >= startY + 25 && mouseY <= startY + 25 + 250) {
                     return function;
                  }

                  if (animatedSettingsHeight > 0) {
                     float settingY = currentY + (float)functionHeight;
                     int remaining = animatedSettingsHeight;

                     for(Setting setting : function.getSettings()) {
                        if (setting.isVisible()) {
                           int settingHeight = this.getSettingRendererHeight(setting, 105);
                           if (settingHeight > 0) {
                              int visible = Math.max(0, Math.min(settingHeight, remaining));
                              if (visible <= 0) {
                                 break;
                              }

                              if (mouseX >= panelX && mouseX <= panelX + 125 && (float)mouseY >= settingY && (float)mouseY <= settingY + (float)visible && mouseY >= startY + 25 && mouseY <= startY + 25 + 250) {
                                 return function;
                              }

                              settingY += (float)(settingHeight + 1);
                              remaining -= settingHeight + 1;
                              if (remaining <= 0) {
                                 break;
                              }
                           }
                        }
                     }
                  }

                  currentY += (float)totalHeight;
               }
            }
         }
      }

      return null;
   }

   private void drawDescription(class_332 ctx, String desc, int startY) {
      int descWidth = (int)FontUtils.durman[19].getWidth(desc);
      int descHeight = 20;
      int descX = (this.field_22789 - descWidth) / 2;
      int descY = startY - descHeight - 10;
      if (Manager.FUNCTION_MANAGER.clickGUI.blur.get() && Manager.FUNCTION_MANAGER.clickGUI.blurSetting.get("Opis")) {
         RenderUtil.drawBlur(ctx.method_51448(), (float)(descX - 6), (float)descY - 3.5F, (float)(descWidth + 12), (float)descHeight, 12.0F, 8.0F, -1);
      }

      RenderUtil.drawRoundedRect(ctx.method_51448(), (float)(descX - 6), (float)descY - 3.5F, (float)(descWidth + 12), (float)descHeight, 6.0F, this.GUI_COLOR.getRGB());
      FontUtils.durman[19].drawLeftAligned(ctx.method_51448(), desc, (float)descX, (float)descY, Color.WHITE.getRGB());
   }

   private float updateExpandAnimation(Function f) {
      float target = f.expanded ? 1.0F : 0.0F;
      float prog = (Float)this.expandProgress.getOrDefault(f, target);
      prog = MathUtil.lerp(prog, target, 15.0F);
      if (Math.abs(target - prog) < 0.001F) {
         prog = target;
      }

      this.expandProgress.put(f, prog);
      return prog;
   }

   private void renderPanel(class_332 ctx, int x, int y, Type category, int mouseX, int mouseY) {
      if (Manager.FUNCTION_MANAGER.clickGUI.blur.get() && Manager.FUNCTION_MANAGER.clickGUI.blurSetting.get("Panele")) {
         RenderUtil.drawBlur(ctx.method_51448(), (float)x, (float)y, 125.0F, 280.0F, 12.0F, 8.0F, -1);
      }

      RenderUtil.drawRoundedRect(ctx.method_51448(), (float)x, (float)y, 125.0F, 280.0F, 12.0F, this.GUI_COLOR.getRGB());
      String title = category.name();
      String icon = category.icon;
      FontUtils.sf_bold[20].drawLeftAligned(ctx.method_51448(), title, (float)(x + (125 - (int)FontUtils.sf_bold[20].getWidth(title)) / 2), (float)(y + 5 + 2), Color.WHITE.getRGB());
      FontUtils.icomoon[20].drawLeftAligned(ctx.method_51448(), icon, (float)(x + (125 - (int)FontUtils.sf_bold[20].getWidth(icon)) / 2 - 50), (float)(y + 5 + 2), Color.WHITE.getRGB());
      int maxBefore = this.calculateMaxScroll(category);
      float clampedTarget = class_3532.method_15363((Float)scrollTargets.get(category), 0.0F, (float)maxBefore);
      float clampedOffset = class_3532.method_15363((Float)scrollOffsets.get(category), 0.0F, (float)maxBefore);
      scrollTargets.put(category, clampedTarget);
      scrollOffsets.put(category, clampedOffset);
      float offset = (Float)scrollOffsets.compute(category, (k, v) -> {
         float target = (Float)scrollTargets.get(k);
         float current = v;
         float lerped = MathUtil.lerp(current, target, 20.0F);
         float smoothed = MathUtil.lerp(current, lerped, 12.0F);
         return smoothed;
      });
      this.renderScrollbar(ctx, x, y, category, offset);
      ctx.method_51448().method_22903();
      Scissor.push();
      Scissor.setFromComponentCoordinates((double)x, (double)(y + 25), (double)125.0F, (double)250.0F);
      clampedTarget = (float)(y + 25) - offset;

      for(Function f : Manager.FUNCTION_MANAGER.getFunctions(category)) {
         if (this.isFunctionVisible(f)) {
            int functionHeight = 20;
            float prog = this.updateExpandAnimation(f);
            int fullSettingsHeight = this.computeSettingsHeight(f);
            int animatedSettingsHeight = (int)((float)fullSettingsHeight * prog);
            int totalHeight = functionHeight + animatedSettingsHeight;
            if (!(clampedTarget + (float)totalHeight < (float)(y + 25)) && !(clampedTarget > (float)(y + 280))) {
               ru.levin.modules.render.ClickGUI clickGUI = Manager.FUNCTION_MANAGER.clickGUI;
               int col1 = f.state ? ColorUtil.getColorStyle(30.0F) : (new Color(198, 198, 198)).getRGB();
               int col2 = f.state ? ColorUtil.getColorStyle(120.0F) : col1;
               int colorModule = f.state ? ColorUtil.getColorStyle(30.0F, (float)clickGUI.alphaModules.get().intValue()) : (new Color(198, 198, 198, clickGUI.alphaModules.get().intValue())).getRGB();
               int colorModule2 = f.state ? ColorUtil.getColorStyle(120.0F, (float)clickGUI.alphaModules.get().intValue()) : colorModule;
               if (clickGUI.filling.get()) {
                  RenderUtil.rectRGB(ctx.method_51448(), (float)(x + 4), clampedTarget - 1.0F, 117.0F, (float)(totalHeight - 1), (float)clickGUI.rounding.get().intValue(), colorModule2, colorModule2, colorModule2, colorModule2);
               }

               if (clickGUI.strike.get()) {
                  RenderUtil.drawRoundedBorder(ctx.method_51448(), (float)(x + 4), clampedTarget - 1.0F, 117.0F, (float)(totalHeight - 1), (float)clickGUI.rounding.get().intValue(), 0.0F, colorModule2);
               }

               String textToRender;
               if (this.functionBinding && this.functions == f) {
                  int bindCode = f.getBindCode();
                  String keyName = bindCode != 0 ? ClientManager.getKey(bindCode) : "";
                  textToRender = bindCode == 0 ? "Binding..." : "Binding... [" + keyName + "]";
               } else {
                  textToRender = f.getDisplayName();
               }

               FontUtils.sf_medium[16].renderGradientText(ctx.method_51448(), textToRender, (float)(x + 10), clampedTarget + 3.0F, col1, col2);
               if (animatedSettingsHeight > 0) {
                  float settingY = clampedTarget + (float)functionHeight;
                  ctx.method_51448().method_22903();
                  Scissor.push();
                  Scissor.setFromComponentCoordinates((double)(x + 1), (double)((int)settingY), (double)123.0F, (double)animatedSettingsHeight);

                  for(Setting setting : f.getSettings()) {
                     if (setting.isVisible()) {
                        int settingHeight = 0;
                        if (setting instanceof BooleanSetting) {
                           BooleanSetting booleanSetting = (BooleanSetting)setting;
                           settingHeight = this.booleanSettingRenderer.getHeight();
                           this.booleanSettingRenderer.render(ctx, (BooleanSetting)booleanSetting, x + 10, (int)settingY, 105, settingHeight);
                        } else if (setting instanceof BindBooleanSetting) {
                           BindBooleanSetting bindBooleanSetting = (BindBooleanSetting)setting;
                           settingHeight = this.bindbooleanSettingRenderer.getHeight();
                           this.bindbooleanSettingRenderer.render(ctx, (BindBooleanSetting)bindBooleanSetting, x + 10, (int)settingY, 105, settingHeight);
                        } else if (setting instanceof BindSetting) {
                           BindSetting bindSetting = (BindSetting)setting;
                           settingHeight = this.bindSettingRenderer.getHeight();
                           this.bindSettingRenderer.render(ctx, (BindSetting)bindSetting, x + 10, (int)settingY - 2, 105, settingHeight);
                        } else if (setting instanceof ModeSetting) {
                           ModeSetting modeSetting = (ModeSetting)setting;
                           settingHeight = this.modeSettingRenderer.getHeight(modeSetting, 105);
                           this.modeSettingRenderer.render(ctx, (ModeSetting)modeSetting, x + 10, (int)settingY, 105, settingHeight);
                        } else if (setting instanceof MultiSetting) {
                           MultiSetting multiSetting = (MultiSetting)setting;
                           settingHeight = this.multiSettingRenderer.getHeight(multiSetting, 105);
                           this.multiSettingRenderer.render(ctx, (MultiSetting)multiSetting, x + 10, (int)settingY, 105, settingHeight);
                        } else if (setting instanceof SliderSetting) {
                           SliderSetting sliderSetting = (SliderSetting)setting;
                           settingHeight = this.sliderSettingRenderer.getHeight();
                           this.sliderSettingRenderer.render(ctx, (SliderSetting)sliderSetting, x + 10, (int)settingY - 2, 105, settingHeight);
                        } else if (setting instanceof TextSetting) {
                           TextSetting textSetting = (TextSetting)setting;
                           settingHeight = this.textSettingRenderer.getHeight();
                           this.textSettingRenderer.render(ctx, (TextSetting)textSetting, x + 10, (int)settingY, 105, settingHeight);
                        }

                        settingY += (float)(settingHeight + 1);
                     }
                  }

                  Scissor.pop();
                  ctx.method_51448().method_22909();
               }

               boolean hasSettings = !f.getSettings().isEmpty();
               if (hasSettings) {
                  float currentProgress = (Float)this.arrowRotationProgress.getOrDefault(f, f.expanded ? 1.0F : 0.0F);
                  currentProgress = MathUtil.lerp(currentProgress, f.expanded ? 1.0F : 0.0F, 15.0F);
                  if (Math.abs((f.expanded ? 1.0F : 0.0F) - currentProgress) < 0.001F) {
                     currentProgress = f.expanded ? 1.0F : 0.0F;
                  }

                  this.arrowRotationProgress.put(f, currentProgress);
                  int arrowX = x + 125 - 15;
                  int arrowY = (int)(clampedTarget + 10.0F - 2.0F);
                  ctx.method_51448().method_22903();
                  ctx.method_51448().method_46416((float)arrowX, (float)arrowY, 0.0F);
                  float angleRad = (float)Math.toRadians((double)(90.0F * currentProgress));
                  Quaternionf rotation = (new Quaternionf()).fromAxisAngleRad(new Vector3f(0.0F, 0.0F, 1.0F), angleRad);
                  ctx.method_51448().method_22907(rotation);
                  FontUtils.sf_medium[16].drawLeftAligned(ctx.method_51448(), "→", -4.0F, -FontUtils.sf_medium[16].getHeight() / 2.0F, col1);
                  ctx.method_51448().method_22909();
               }

               clampedTarget += (float)totalHeight;
            } else {
               clampedTarget += (float)totalHeight;
            }
         }
      }

      this.clampScrollForCategory(category);
      Scissor.pop();
      ctx.method_51448().method_22909();
   }

   private void renderScrollbar(class_332 ctx, int x, int y, Type category, float offset) {
      int maxScroll = this.calculateMaxScroll(category);
      if (maxScroll > 0) {
         int scrollbarWidth = 3;
         int scrollbarX = x + 125 - scrollbarWidth - 1;
         int scrollbarHeight = 220;
         int scrollbarY = y + 25 + 15;
         int scrollbarBgColor = (new Color(0, 0, 0, 50)).getRGB();
         RenderUtil.drawRoundedRect(ctx.method_51448(), (float)scrollbarX, (float)scrollbarY, (float)scrollbarWidth, (float)scrollbarHeight, 1.0F, scrollbarBgColor);
         float scrollProgress = offset / (float)maxScroll;
         int thumbHeight = Math.max(6, (int)((float)scrollbarHeight * (250.0F / (float)(250 + maxScroll))));
         int thumbY = scrollbarY + (int)(scrollProgress * (float)(scrollbarHeight - thumbHeight));
         int thumbColor = (new Color(255, 255, 255, 150)).getRGB();
         RenderUtil.drawRoundedRect(ctx.method_51448(), (float)scrollbarX, (float)thumbY, (float)scrollbarWidth, (float)thumbHeight, 1.0F, thumbColor);
      }
   }

   public boolean method_25401(double mouseX, double mouseY, double scrollX, double scrollY) {
      int themeWidth = this.getThemeWidth();
      int themeX = this.getThemeX(themeWidth);
      int themeY = this.getThemeY();
      if (mouseX >= (double)themeX && mouseX <= (double)(themeX + themeWidth) && mouseY >= (double)themeY && mouseY <= (double)(themeY + 16)) {
         themeScrollTarget += (float)(-scrollY * (double)15.0F);
         return true;
      } else {
         int totalWidth = this.renderCategories.size() * 133 - 8;
         int startX = (this.field_22789 - totalWidth) / 2;
         int startY = (this.field_22790 - 280) / 2;
         int i = 0;

         for(Type category : this.renderCategories) {
            int px = startX + i++ * 133;
            if (mouseX >= (double)px && mouseX <= (double)(px + 125) && mouseY >= (double)(startY + 25) && mouseY <= (double)(startY + 25 + 250)) {
               int maxScroll = this.calculateMaxScroll(category);
               if (maxScroll > 0) {
                  scrollTargets.compute(category, (k, v) -> Math.max(0.0F, Math.min(v - (float)scrollY * 12.0F, (float)maxScroll)));
                  return true;
               }

               return false;
            }
         }

         return super.method_25401(mouseX, mouseY, scrollX, scrollY);
      }
   }

   private int calculateMaxScroll(Type category) {
      int totalHeight = 0;

      for(Function f : Manager.FUNCTION_MANAGER.getFunctions(category)) {
         if (this.isFunctionVisible(f)) {
            int functionHeight = 20;
            int fullSettingsHeight = this.computeSettingsHeight(f);
            float prog = (Float)this.expandProgress.getOrDefault(f, f.expanded ? 1.0F : 0.0F);
            int animated = Math.round((float)fullSettingsHeight * prog);
            totalHeight += functionHeight + animated;
         }
      }

      int maxScroll = totalHeight - 250;
      return Math.max(0, maxScroll);
   }

   public boolean method_25400(char c, int keyCode) {
      if (this.searchState.focused) {
         String prevText = this.searchState.text;
         if (this.searchState.text.length() < 30) {
            String before = this.searchState.text.substring(0, this.searchState.cursorPosition);
            String after = this.searchState.text.substring(this.searchState.cursorPosition);
            this.searchState.text = before + c + after;
            ++this.searchState.cursorPosition;
         }

         if (!prevText.equals(this.searchState.text)) {
            this.resetScrollForAllCategories();
         }

         return true;
      } else {
         for(Type category : this.renderCategories) {
            for(Function function : Manager.FUNCTION_MANAGER.getFunctions(category)) {
               if (function.expanded) {
                  for(Setting setting : function.getSettings()) {
                     if (setting instanceof TextSetting) {
                        TextSetting textSetting = (TextSetting)setting;
                        if (textSetting.isFocused() && this.textSettingRenderer.charTyped(textSetting, c, keyCode)) {
                           return true;
                        }
                     }
                  }
               }
            }
         }

         return super.method_25400(c, keyCode);
      }
   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      if (this.isClose) {
         return true;
      } else {
         for(Type category : this.renderCategories) {
            for(Function function : Manager.FUNCTION_MANAGER.getFunctions(category)) {
               if (this.isFunctionVisible(function) && function.expanded) {
                  for(Setting setting : function.getSettings()) {
                     if (setting.isVisible()) {
                        if (setting instanceof BindBooleanSetting) {
                           BindBooleanSetting bindBooleanSetting = (BindBooleanSetting)setting;
                           if (bindBooleanSetting.isListeningForBind()) {
                              if (keyCode != 256 && keyCode != 261) {
                                 bindBooleanSetting.setKey(keyCode);
                              } else {
                                 bindBooleanSetting.setKey(0);
                              }

                              bindBooleanSetting.setListeningForBind(false);
                              return true;
                           }
                        }

                        if (setting instanceof BindSetting) {
                           BindSetting bindSetting = (BindSetting)setting;
                           if (bindSetting.isBinding()) {
                              if (keyCode != 256 && keyCode != 261) {
                                 bindSetting.setKey(keyCode);
                              } else {
                                 bindSetting.setKey(-1);
                              }

                              bindSetting.setBinding(false);
                              return true;
                           }
                        }

                        if (setting instanceof TextSetting) {
                           TextSetting textSetting = (TextSetting)setting;
                           if (textSetting.isFocused() && this.textSettingRenderer.keyPressed(textSetting, keyCode, scanCode, modifiers)) {
                              return true;
                           }
                        }
                     }
                  }
               }
            }
         }

         if (this.functionBinding && this.functions != null) {
            if (keyCode != 256 && keyCode != 261) {
               this.functions.setBindCode(keyCode);
            } else {
               this.functions.setBindCode(0);
            }

            this.functionBinding = false;
            this.functions = null;
            return true;
         } else {
            if (this.searchState.focused) {
               String prevText = this.searchState.text;
               switch (keyCode) {
                  case 256:
                  case 257:
                     this.searchState.focused = false;
                     return true;
                  case 258:
                  case 260:
                  default:
                     break;
                  case 259:
                     if (this.searchState.cursorPosition > 0 && !this.searchState.text.isEmpty()) {
                        SearchState var16 = this.searchState;
                        String var18 = this.searchState.text.substring(0, this.searchState.cursorPosition - 1);
                        var16.text = var18 + this.searchState.text.substring(this.searchState.cursorPosition);
                        --this.searchState.cursorPosition;
                     }

                     if (!prevText.equals(this.searchState.text)) {
                        this.resetScrollForAllCategories();
                     }

                     return true;
                  case 261:
                     if (this.searchState.cursorPosition < this.searchState.text.length()) {
                        SearchState var15 = this.searchState;
                        String var10001 = this.searchState.text.substring(0, this.searchState.cursorPosition);
                        var15.text = var10001 + this.searchState.text.substring(this.searchState.cursorPosition + 1);
                     }

                     if (!prevText.equals(this.searchState.text)) {
                        this.resetScrollForAllCategories();
                     }

                     return true;
                  case 262:
                     if (this.searchState.cursorPosition < this.searchState.text.length()) {
                        ++this.searchState.cursorPosition;
                     }

                     return true;
                  case 263:
                     if (this.searchState.cursorPosition > 0) {
                        --this.searchState.cursorPosition;
                     }

                     return true;
               }
            }

            return super.method_25404(keyCode, scanCode, modifiers);
         }
      }
   }

   private void resetScrollForAllCategories() {
      for(Type category : this.renderCategories) {
         scrollTargets.put(category, 0.0F);
         scrollOffsets.put(category, 0.0F);
      }

   }

   public void method_25393() {
      super.method_25393();
      long currentTime = System.currentTimeMillis();
      if (currentTime - this.searchState.lastCursorBlink >= 500L) {
         this.searchState.cursorVisible = !this.searchState.cursorVisible;
         this.searchState.lastCursorBlink = currentTime;
      }

   }

   public void method_25419() {
      if (!this.isClose) {
         this.draggingPicker1 = false;
         this.draggingPicker2 = false;
         this.isClose = true;
         this.animationOpen.setDirection(class_2352.field_11060);
         this.animationOpen.reset();
      }
   }

   private int getSearchWidth() {
      return 180;
   }

   private int getSearchX(int searchWidth) {
      return (this.field_22789 - searchWidth) / 2;
   }

   private int getSearchY() {
      return (this.field_22790 + 280) / 2 + 10;
   }

   private void renderSearchField(class_332 ctx) {
      int searchWidth = this.getSearchWidth();
      int searchX = this.getSearchX(searchWidth);
      int searchY = this.getSearchY();
      ru.levin.modules.render.ClickGUI clickGUI = Manager.FUNCTION_MANAGER.clickGUI;
      if (clickGUI.blur.get() && clickGUI.blurSetting.get("Szukaj")) {
         RenderUtil.drawBlur(ctx.method_51448(), (float)searchX, (float)searchY, (float)searchWidth, 20.0F, 6.0F, 12.0F, -1);
      }

      RenderUtil.drawRoundedRect(ctx.method_51448(), (float)searchX, (float)searchY, (float)searchWidth, 20.0F, 6.0F, this.GUI_COLOR.getRGB());
      String displayText;
      int textColor;
      int textX;
      if (this.searchState.text.isEmpty() && !this.searchState.focused) {
         displayText = "Szukaj...";
         textColor = (new Color(255, 255, 255, 120)).getRGB();
         int textWidth = (int)FontUtils.sf_medium[18].getWidth(displayText);
         textX = searchX + (searchWidth - textWidth) / 2;
      } else {
         String text = this.searchState.text;
         if (this.searchState.focused && this.searchState.cursorVisible) {
            int pos = Math.min(this.searchState.cursorPosition, text.length());
            String var10000 = text.substring(0, pos);
            text = var10000 + "|" + text.substring(pos);
         }

         displayText = text;
         textColor = Color.WHITE.getRGB();
         textX = searchX + 6;
      }

      int textY = (int)((float)searchY + (20.0F - FontUtils.sf_medium[18].getHeight()) / 2.0F);
      FontUtils.sf_medium[18].drawLeftAligned(ctx.method_51448(), displayText, (float)textX, (float)textY, textColor);
   }

   private int getThemeWidth() {
      return 180;
   }

   private int getThemeX(int searchWidth) {
      return (this.field_22789 - searchWidth) / 2;
   }

   private int getThemeY() {
      return (this.field_22790 + 280) / 2 + 40;
   }

   private void renderButtomTheme(class_332 ctx, double mouseX, double mouseY) {
      int searchWidth = this.getSearchWidth();
      int searchX = this.getSearchX(searchWidth);
      int searchY = this.getSearchY();
      int buttonX = searchX + 185;
      int buttonY = searchY + 2;
      int buttonWidth = 16;
      int buttonHeight = 16;
      boolean hovered = mouseX >= (double)buttonX && mouseX <= (double)(buttonX + buttonWidth) && mouseY >= (double)buttonY && mouseY <= (double)(buttonY + buttonHeight);
      int color = hovered ? this.GUI_COLOR.brighter().getRGB() : this.GUI_COLOR.getRGB();
      RenderUtil.drawRoundedRect(ctx.method_51448(), (float)buttonX, (float)buttonY, (float)buttonWidth, (float)buttonHeight, 2.0F, color);
      RenderUtil.drawTexture(ctx.method_51448(), "images/gui/colors2.png", (float)(buttonX + 3), (float)buttonY + 2.5F, 10.0F, 10.0F, 0.0F, Color.white.getRGB());
   }

   private void renderTheme(class_332 ctx, int mouseX, int mouseY) {
      float targetAlpha = this.themeMenuTarget > 0.01F ? 1.0F : 0.0F;
      this.themeAlphaAnim += (targetAlpha - this.themeAlphaAnim) * 0.15F;
      if (!(this.themeAlphaAnim < 0.01F)) {
         this.themeMenuAnim += (this.themeMenuTarget - this.themeMenuAnim) * 0.2F;
         if (!(this.themeMenuAnim < 0.01F)) {
            int themeWidth = this.getThemeWidth();
            int themeX = this.getThemeX(themeWidth);
            int themeY = this.getThemeY();
            float offsetY = (1.0F - this.themeMenuAnim) * 10.0F;
            themeScrollOffset = MathUtil.lerp(themeScrollOffset, themeScrollTarget, 15.0F);
            int panelColor = ColorUtil.applyAlpha(this.GUI_COLOR.getRGB(), this.themeAlphaAnim);
            if (Manager.FUNCTION_MANAGER.clickGUI.blur.get() && Manager.FUNCTION_MANAGER.clickGUI.blurSetting.get("Motywy")) {
               RenderUtil.drawBlur(ctx.method_51448(), (float)themeX, (float)themeY + offsetY, (float)themeWidth, 16.0F, 3.0F, 12.0F, -1);
            }

            RenderUtil.drawRoundedRect(ctx.method_51448(), (float)themeX, (float)themeY + offsetY, (float)themeWidth, 16.0F, 3.0F, panelColor);
            int circleSize = 11;
            int padding = 5;
            int totalThemes = Manager.STYLE_MANAGER.getStyles().size() + 1;
            float maxScroll = (float)Math.max(0, (totalThemes - 11) * (circleSize + padding));
            themeScrollTarget = class_3532.method_15363(themeScrollTarget, 0.0F, maxScroll);
            themeScrollOffset = class_3532.method_15363(themeScrollOffset, 0.0F, maxScroll);
            if (totalThemes > 11) {
               int arrowColor = ColorUtil.applyAlpha(Color.WHITE.getRGB(), this.themeAlphaAnim * 0.6F);
               if (themeScrollTarget > 0.0F) {
                  int arrowY = themeY + 8;
                  FontUtils.sf_medium[16].drawLeftAligned(ctx.method_51448(), "←", (float)(themeX - 10), (float)(arrowY - 5), arrowColor);
               }

               if (themeScrollTarget < maxScroll) {
                  int arrowY = themeY + 8;
                  int arrowX = themeX + themeWidth + 4;
                  FontUtils.sf_medium[16].drawLeftAligned(ctx.method_51448(), "→", (float)arrowX, (float)(arrowY - 5), arrowColor);
               }
            }

            ctx.method_51448().method_22903();
            Scissor.push();
            Scissor.setFromComponentCoordinates((double)(themeX + 1), (double)((float)themeY + offsetY), (double)(themeWidth - 2), (double)16.0F);
            float startX = (float)(themeX + padding) - themeScrollOffset;
            int centerY = (int)((float)(themeY + (16 - circleSize) / 2) + 0.9F + offsetY);
            String hoveredTheme = null;
            int x = (int)startX;
            if (selectedColor1 != -1 && selectedColor2 != -1) {
               Vector4i vec = new Vector4i(ColorUtil.gradient(5, 0, selectedColor1, selectedColor2), ColorUtil.gradient(5, 180, selectedColor1, selectedColor2), ColorUtil.gradient(5, 90, selectedColor1, selectedColor2), ColorUtil.gradient(5, 360, selectedColor1, selectedColor2));
               RenderUtil.rectRGB(ctx.method_51448(), (float)x, (float)centerY + 0.5F, (float)circleSize, (float)circleSize, 5.0F, ColorUtil.applyAlpha(vec.w, this.themeAlphaAnim), ColorUtil.applyAlpha(vec.x, this.themeAlphaAnim), ColorUtil.applyAlpha(vec.y, this.themeAlphaAnim), ColorUtil.applyAlpha(vec.z, this.themeAlphaAnim));
            } else {
               RenderUtil.drawTexture(ctx.method_51448(), "images/gui/pips.png", (float)x, (float)centerY + 0.5F, (float)circleSize, (float)circleSize, 5.0F, ColorUtil.applyAlpha(Color.WHITE.getRGB(), this.themeAlphaAnim));
            }

            if (RenderUtil.isHovered(mouseX, mouseY, (double)x, (double)centerY, (double)circleSize, (double)circleSize)) {
               RenderUtil.drawRoundedBorder(ctx.method_51448(), (float)(x - 1), (float)centerY - 0.5F, (float)(circleSize + 2), (float)(circleSize + 2), 5.0F, 0.1F, ColorUtil.applyAlpha(Color.WHITE.getRGB(), this.themeAlphaAnim));
               hoveredTheme = "LPM — utwórz własny motyw";
            }

            startX += (float)(circleSize + padding);

            for(Style style : Manager.STYLE_MANAGER.getStyles()) {
               int[] colors = style.colors;
               int c1 = colors[0];
               int c2 = colors.length > 1 ? colors[1] : colors[0];
               Vector4i vec = new Vector4i(ColorUtil.gradient(5, 0, c1, c2), ColorUtil.gradient(5, 180, c1, c2), ColorUtil.gradient(5, 90, c1, c2), ColorUtil.gradient(5, 360, c1, c2));
               x = (int)startX;
               RenderUtil.rectRGB(ctx.method_51448(), (float)x, (float)centerY + 0.5F, (float)circleSize, (float)circleSize, 5.0F, ColorUtil.applyAlpha(vec.w, this.themeAlphaAnim), ColorUtil.applyAlpha(vec.x, this.themeAlphaAnim), ColorUtil.applyAlpha(vec.y, this.themeAlphaAnim), ColorUtil.applyAlpha(vec.z, this.themeAlphaAnim));
               if (RenderUtil.isHovered(mouseX, mouseY, (double)x, (double)centerY, (double)circleSize, (double)circleSize)) {
                  hoveredTheme = style.name;
               }

               startX += (float)(circleSize + padding);
            }

            Scissor.pop();
            ctx.method_51448().method_22909();
            float animSpeed = 0.2F;
            float targetAnim = colorPickerOpen ? 1.0F : 0.0F;
            this.colorPickerAnim += (targetAnim - this.colorPickerAnim) * animSpeed;
            if (this.colorPickerAnim > 0.01F) {
               int fixedX = themeX + padding;
               this.renderColorPickers(ctx, fixedX, centerY, mouseX, mouseY);
            }

            if (hoveredTheme != null) {
               this.themeNameAnim += (1.0F - this.themeNameAnim) * 0.2F;
            } else {
               this.themeNameAnim += (0.0F - this.themeNameAnim) * 0.2F;
            }

            if (this.themeNameAnim > 0.01F && hoveredTheme != null) {
               int screenWidth = ctx.method_51421();
               int textWidth = (int)FontUtils.sf_medium[18].getWidth(hoveredTheme);
               int textX = (screenWidth - textWidth) / 2;
               int textColor = ColorUtil.applyAlpha(Color.WHITE.getRGB(), this.themeNameAnim * this.themeAlphaAnim);
               FontUtils.sf_medium[18].drawLeftAligned(ctx.method_51448(), hoveredTheme, (float)textX, (float)(centerY + 18), textColor);
               if (hoveredTheme.toLowerCase().contains("custom")) {
                  int tipColor = ColorUtil.applyAlpha(Color.WHITE.getRGB(), this.themeNameAnim * this.themeAlphaAnim * 0.7F);
                  String tipText = "PPM — usuń";
                  int tipWidth = (int)FontUtils.sf_medium[14].getWidth(tipText);
                  int tipX = (screenWidth - tipWidth) / 2;
                  FontUtils.sf_medium[14].drawLeftAligned(ctx.method_51448(), tipText, (float)tipX, (float)(centerY + 32), tipColor);
               }
            }

         }
      }
   }

   private void renderColorPickers(class_332 ctx, int x, int y, int mouseX, int mouseY) {
      int panelWidth = 85;
      int panelHeight = 51;
      float animOffsetX = (1.0F - this.colorPickerAnim) * 30.0F;
      float animScale = 0.95F + 0.05F * this.colorPickerAnim;
      float alphaMult = this.colorPickerAnim;
      int panelX = (int)((float)(x - panelWidth - 20) + animOffsetX);
      int panelY = y - panelHeight / 2 - 12;
      ctx.method_51448().method_22903();
      ctx.method_51448().method_46416((float)panelX + (float)panelWidth / 2.0F, (float)panelY + (float)panelHeight / 2.0F, 0.0F);
      ctx.method_51448().method_22905(animScale, animScale, 1.0F);
      ctx.method_51448().method_46416((float)(-panelWidth) / 2.0F, (float)(-panelHeight) / 2.0F, 0.0F);
      int baseColor = this.GUI_COLOR.getRGB();
      if (Manager.FUNCTION_MANAGER.clickGUI.blur.get() && Manager.FUNCTION_MANAGER.clickGUI.blurSetting.get("Tworzenie motywu")) {
         RenderUtil.drawBlur(ctx.method_51448(), 0.0F, 0.0F, (float)panelWidth, (float)panelHeight, 4.0F, 12.0F, -1);
      }

      RenderUtil.drawRoundedRect(ctx.method_51448(), 0.0F, 0.0F, (float)panelWidth, (float)panelHeight, 4.0F, ColorUtil.applyAlpha(baseColor, alphaMult));
      int picker1Size = 30;
      int picker1X = 5;
      int picker1Y = 5;
      RenderUtil.drawTexture(ctx.method_51448(), "images/gui/pick.png", (float)picker1X, (float)picker1Y, (float)picker1Size, (float)picker1Size, 14.0F, ColorUtil.applyAlpha(Color.WHITE.getRGB(), alphaMult));
      RenderUtil.drawRoundedBorder(ctx.method_51448(), (float)picker1X, (float)picker1Y, (float)picker1Size, (float)picker1Size, 14.0F, 0.1F, ColorUtil.applyAlpha(Color.WHITE.getRGB(), alphaMult));
      int dotX1 = (int)((float)picker1X + this.picker1CursorX * (float)picker1Size);
      int dotY1 = (int)((float)picker1Y + this.picker1CursorY * (float)picker1Size);
      RenderUtil.drawCircle(ctx.method_51448(), (float)dotX1, (float)dotY1, 4.0F, ColorUtil.applyAlpha(Color.BLACK.getRGB(), alphaMult));
      int picker2Size = 30;
      int picker2X = 50;
      int picker2Y = 5;
      RenderUtil.drawTexture(ctx.method_51448(), "images/gui/pick.png", (float)picker2X, (float)picker2Y, (float)picker2Size, (float)picker2Size, 14.0F, ColorUtil.applyAlpha(Color.WHITE.getRGB(), alphaMult));
      RenderUtil.drawRoundedBorder(ctx.method_51448(), (float)picker2X, (float)picker2Y, (float)picker2Size, (float)picker2Size, 14.0F, 0.1F, ColorUtil.applyAlpha(Color.WHITE.getRGB(), alphaMult));
      int dotX2 = (int)((float)picker2X + this.picker2CursorX * (float)picker2Size);
      int dotY2 = (int)((float)picker2Y + this.picker2CursorY * (float)picker2Size);
      RenderUtil.drawCircle(ctx.method_51448(), (float)dotX2, (float)dotY2, 4.0F, ColorUtil.applyAlpha(Color.BLACK.getRGB(), alphaMult));
      int closeButtonSize = 10;
      int closeButtonX = panelWidth - closeButtonSize;
      int closeButtonY = 0;
      RenderUtil.drawRoundedRect(ctx.method_51448(), (float)closeButtonX, (float)closeButtonY, (float)closeButtonSize, (float)closeButtonSize, new Vector4f(0.0F, 4.0F, 0.0F, 4.0F), ColorUtil.applyAlpha(Color.WHITE.getRGB(), alphaMult));
      FontUtils.sf_medium[20].drawLeftAligned(ctx.method_51448(), "×", (float)(closeButtonX + 2), (float)closeButtonY - 1.5F, ColorUtil.applyAlpha(Color.RED.getRGB(), alphaMult));
      RenderUtil.drawRoundedRect(ctx.method_51448(), 14.0F, 39.0F, 56.0F, 8.0F, new Vector4f(1.0F, 1.0F, 1.0F, 1.0F), ColorUtil.applyAlpha(Color.WHITE.getRGB(), alphaMult));
      FontUtils.durman[12].drawLeftAligned(ctx.method_51448(), "Dodaj motyw", 18.0F, 39.0F, ColorUtil.applyAlpha(Color.BLACK.getRGB(), alphaMult));
      ctx.method_51448().method_22909();
   }

   public boolean method_25403(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
      if (button == 0 && colorPickerOpen) {
         int panelWidth = 85;
         int panelHeight = 51;
         int panelX = this.getThemeX(this.getThemeWidth()) - panelWidth - 20;
         int panelY = this.getThemeY() - panelHeight / 2 - 12;
         int picker1Size = 30;
         int picker1X = panelX + 5;
         int picker1Y = panelY + 5;
         int picker2Size = 30;
         int picker2X = panelX + 50;
         int picker2Y = panelY + 5;
         if (this.draggingPicker1) {
            float nx = (float)(mouseX - (double)picker1X) / (float)picker1Size;
            float ny = (float)(mouseY - (double)picker1Y) / (float)picker1Size;
            this.picker1CursorX = class_3532.method_15363(nx, 0.0F, 1.0F);
            this.picker1CursorY = class_3532.method_15363(ny, 0.0F, 1.0F);
            selectedColor1 = ColorUtil.getPixelColor(ResourceProvider.color_image, this.picker1CursorX, this.picker1CursorY);
            return true;
         }

         if (this.draggingPicker2) {
            float nx = (float)(mouseX - (double)picker2X) / (float)picker2Size;
            float ny = (float)(mouseY - (double)picker2Y) / (float)picker2Size;
            this.picker2CursorX = class_3532.method_15363(nx, 0.0F, 1.0F);
            this.picker2CursorY = class_3532.method_15363(ny, 0.0F, 1.0F);
            selectedColor2 = ColorUtil.getPixelColor(ResourceProvider.color_image, this.picker2CursorX, this.picker2CursorY);
            return true;
         }
      }

      if (this.draggingSlider != null && button == 0) {
         this.sliderSettingRenderer.mouseDragged(this.draggingSlider, mouseX, this.draggingSliderX, this.draggingSliderWidth);
         return true;
      } else {
         return super.method_25403(mouseX, mouseY, button, deltaX, deltaY);
      }
   }

   public boolean method_25406(double mouseX, double mouseY, int button) {
      this.draggingPicker1 = false;
      this.draggingPicker2 = false;
      if (this.draggingSlider != null) {
         this.sliderSettingRenderer.mouseReleased(this.draggingSlider);
         this.draggingSlider = null;
         return true;
      } else {
         return super.method_25406(mouseX, mouseY, button);
      }
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      int totalWidth = this.renderCategories.size() * 133 - 8;
      int startX = (this.field_22789 - totalWidth) / 2;
      int startY = (this.field_22790 - 280) / 2;
      int searchWidth = this.getSearchWidth();
      int searchX = this.getSearchX(searchWidth);
      int searchY = this.getSearchY();
      if (colorPickerOpen) {
         int themeWidth = this.getThemeWidth();
         int themeX = this.getThemeX(themeWidth);
         int themeY = this.getThemeY();
         int circleSize = 11;
         int padding = 5;
         float offsetY = (1.0F - this.themeMenuAnim) * 10.0F;
         int centerY = (int)((float)(themeY + (16 - circleSize) / 2) + 0.9F + offsetY);
         int fixedX = themeX + padding;
         int panelWidth = 85;
         int panelHeight = 51;
         int panelX = fixedX - panelWidth - 20;
         int panelY = centerY - panelHeight / 2 - 12;
         int picker1Size = 30;
         int picker1X = panelX + 5;
         int picker1Y = panelY + 5;
         int picker2Size = 30;
         int picker2X = panelX + 50;
         int picker2Y = panelY + 5;
         int closeButtonSize = 10;
         int closeButtonX = panelX + panelWidth - closeButtonSize;
         if (mouseX >= (double)closeButtonX && mouseX <= (double)(closeButtonX + closeButtonSize) && mouseY >= (double)panelY && mouseY <= (double)(panelY + closeButtonSize)) {
            colorPickerOpen = false;
            return true;
         }

         if (mouseX >= (double)picker1X && mouseX <= (double)(picker1X + picker1Size) && mouseY >= (double)picker1Y && mouseY <= (double)(picker1Y + picker1Size)) {
            float nx = (float)(mouseX - (double)picker1X) / (float)picker1Size;
            float ny = (float)(mouseY - (double)picker1Y) / (float)picker1Size;
            this.draggingPicker1 = true;
            this.picker1CursorX = Math.max(0.0F, Math.min(1.0F, nx));
            this.picker1CursorY = Math.max(0.0F, Math.min(1.0F, ny));
            selectedColor1 = ColorUtil.getPixelColor(ResourceProvider.color_image, this.picker1CursorX, this.picker1CursorY);
            return true;
         }

         if (mouseX >= (double)picker2X && mouseX <= (double)(picker2X + picker2Size) && mouseY >= (double)picker2Y && mouseY <= (double)(picker2Y + picker2Size)) {
            float nx = (float)(mouseX - (double)picker2X) / (float)picker2Size;
            float ny = (float)(mouseY - (double)picker2Y) / (float)picker2Size;
            this.draggingPicker2 = true;
            this.picker2CursorX = Math.max(0.0F, Math.min(1.0F, nx));
            this.picker2CursorY = Math.max(0.0F, Math.min(1.0F, ny));
            selectedColor2 = ColorUtil.getPixelColor(ResourceProvider.color_image, this.picker2CursorX, this.picker2CursorY);
            return true;
         }

         int addButtonX = panelX + 14;
         int addButtonY = panelY + 39;
         int addButtonWidth = 56;
         int addButtonHeight = 8;
         if (mouseX >= (double)addButtonX && mouseX <= (double)(addButtonX + addButtonWidth) && mouseY >= (double)addButtonY && mouseY <= (double)(addButtonY + addButtonHeight)) {
            String baseName = "Custom";
            String candidate = baseName;
            int index = 2;

            boolean exists;
            do {
               exists = false;

               for(Style s : Manager.STYLE_MANAGER.getStyles()) {
                  if (s.name.equals(candidate)) {
                     exists = true;
                     candidate = baseName + "-" + index++;
                     break;
                  }
               }
            } while(exists);

            int[] colors = new int[]{selectedColor1, selectedColor2};
            Style newStyle = new Style(candidate, colors);
            Manager.STYLE_MANAGER.addCustomTheme(candidate, selectedColor1, selectedColor2);
            Manager.STYLE_MANAGER.setTheme(newStyle);
            colorPickerOpen = false;
            return true;
         }
      }

      if (mouseX >= (double)searchX && mouseX <= (double)(searchX + searchWidth) && mouseY >= (double)searchY && mouseY <= (double)(searchY + 20)) {
         this.searchState.focused = true;
         this.searchState.cursorPosition = this.searchState.text.length();
         return true;
      } else {
         this.searchState.focused = false;
         int buttonX = searchX + 185;
         int buttonY = searchY + 2;
         int buttonWidth = 16;
         int buttonHeight = 16;
         if (mouseX >= (double)buttonX && mouseX <= (double)(buttonX + buttonWidth) && mouseY >= (double)buttonY && mouseY <= (double)(buttonY + buttonHeight)) {
            themeMenu = !themeMenu;
            this.themeMenuTarget = themeMenu ? 1.0F : 0.0F;
         }

         if (themeMenu) {
            int themeWidth = this.getThemeWidth();
            int themeX = this.getThemeX(themeWidth);
            int themeY = this.getThemeY();
            int circleSize = 11;
            int padding = 5;
            int totalThemes = Manager.STYLE_MANAGER.getStyles().size() + 1;
            float maxScroll = (float)Math.max(0, (totalThemes - 11) * (circleSize + padding));
            if (themeScrollTarget > 0.0F && mouseX >= (double)(themeX - 15) && mouseX <= (double)(themeX - 5) && mouseY >= (double)themeY && mouseY <= (double)(themeY + 16)) {
               themeScrollTarget -= (float)((circleSize + padding) * 3);
               return true;
            }

            if (themeScrollTarget < maxScroll && mouseX >= (double)(themeX + themeWidth + 5) && mouseX <= (double)(themeX + themeWidth + 15) && mouseY >= (double)themeY && mouseY <= (double)(themeY + 16)) {
               themeScrollTarget += (float)((circleSize + padding) * 3);
               return true;
            }

            float currentX = (float)(themeX + padding) - themeScrollTarget;
            int centerY = themeY + (16 - circleSize) / 2;
            int visibleAreaEndX = themeX + themeWidth;
            if (currentX + (float)circleSize >= (float)themeX && currentX <= (float)visibleAreaEndX && mouseX >= (double)currentX && mouseX <= (double)(currentX + (float)circleSize) && mouseY >= (double)centerY && mouseY <= (double)(centerY + circleSize)) {
               colorPickerOpen = !colorPickerOpen;
               return true;
            }

            currentX += (float)(circleSize + padding);
            if (button == 0) {
               for(Style style : Manager.STYLE_MANAGER.getStyles()) {
                  if (!(currentX + (float)circleSize < (float)themeX) && !(currentX > (float)visibleAreaEndX)) {
                     if (mouseX >= (double)currentX && mouseX <= (double)(currentX + (float)circleSize) && mouseY >= (double)centerY && mouseY <= (double)(centerY + circleSize)) {
                        Manager.STYLE_MANAGER.setTheme(style);
                        return true;
                     }

                     currentX += (float)(circleSize + padding);
                  } else {
                     currentX += (float)(circleSize + padding);
                  }
               }
            }

            if (button == 1) {
               currentX = (float)(themeX + padding + circleSize + padding) - themeScrollTarget;

               for(Style style : new ArrayList(Manager.STYLE_MANAGER.getStyles())) {
                  if (!(currentX + (float)circleSize < (float)themeX) && !(currentX > (float)visibleAreaEndX)) {
                     if (mouseX >= (double)currentX && mouseX <= (double)(currentX + (float)circleSize) && mouseY >= (double)centerY && mouseY <= (double)(centerY + circleSize)) {
                        if (style.name.startsWith("Custom")) {
                           Manager.STYLE_MANAGER.removeStyle(style);
                           return true;
                        }

                        return true;
                     }

                     currentX += (float)(circleSize + padding);
                  } else {
                     currentX += (float)(circleSize + padding);
                  }
               }
            }
         }

         if (this.functionBinding && this.functions != null) {
            int code = -(button + 2);
            this.functions.setBindCode(code);
            this.functionBinding = false;
            this.functions = null;
            return true;
         } else {
            for(Type category : this.renderCategories) {
               for(Function function : Manager.FUNCTION_MANAGER.getFunctions(category)) {
                  if (function.expanded) {
                     for(Setting setting : function.getSettings()) {
                        if (setting.isVisible()) {
                           if (setting instanceof BindBooleanSetting) {
                              BindBooleanSetting bindBooleanSetting = (BindBooleanSetting)setting;
                              if (bindBooleanSetting.isListeningForBind()) {
                                 int code = -(button + 2);
                                 bindBooleanSetting.setKey(code);
                                 bindBooleanSetting.setListeningForBind(false);
                                 return true;
                              }
                           }

                           if (setting instanceof BindSetting) {
                              BindSetting bindSetting = (BindSetting)setting;
                              if (bindSetting.isBinding()) {
                                 int code = -(button + 2);
                                 bindSetting.setKey(code);
                                 bindSetting.setBinding(false);
                                 return true;
                              }
                           }
                        }
                     }
                  }
               }
            }

            int idx = 0;

            for(Type category : this.renderCategories) {
               int panelX = startX + idx++ * 133;
               float offset = (Float)scrollOffsets.get(category);
               float currentY = (float)(startY + 25) - offset;

               for(Function function : Manager.FUNCTION_MANAGER.getFunctions(category)) {
                  if (this.isFunctionVisible(function)) {
                     int functionHeight = 20;
                     int fullSettingsHeight = this.computeSettingsHeight(function);
                     float prog = (Float)this.expandProgress.getOrDefault(function, function.expanded ? 1.0F : 0.0F);
                     int animatedSettingsHeight = Math.round((float)fullSettingsHeight * prog);
                     int totalHeight = functionHeight + animatedSettingsHeight;
                     if (currentY + (float)totalHeight < (float)(startY + 25)) {
                        currentY += (float)totalHeight;
                     } else {
                        if (currentY > (float)(startY + 25 + 250)) {
                           break;
                        }

                        if (mouseX >= (double)panelX && mouseX <= (double)(panelX + 125) && mouseY >= (double)currentY && mouseY <= (double)(currentY + (float)functionHeight) && mouseY >= (double)(startY + 25) && mouseY <= (double)(startY + 25 + 250)) {
                           if (button == 0) {
                              function.toggle();
                              return true;
                           }

                           if (button == 1) {
                              function.expanded = !function.expanded;
                              this.clampScrollForCategory(category);
                              return true;
                           }

                           if (button == 2) {
                              this.functionBinding = true;
                              this.functions = function;
                              return true;
                           }
                        }

                        if (animatedSettingsHeight > 0) {
                           float settingY = currentY + (float)functionHeight;
                           int remaining = animatedSettingsHeight;

                           for(Setting setting : function.getSettings()) {
                              if (setting.isVisible()) {
                                 int settingHeight = this.getSettingRendererHeight(setting, 105);
                                 if (settingHeight > 0) {
                                    int visible = Math.max(0, Math.min(settingHeight, remaining));
                                    if (visible <= 0) {
                                       break;
                                    }

                                    if (mouseX >= (double)panelX && mouseX <= (double)(panelX + 125) && mouseY >= (double)settingY && mouseY <= (double)(settingY + (float)visible) && mouseY >= (double)(startY + 25) && mouseY <= (double)(startY + 25 + 250)) {
                                       int settingX = panelX + 10;
                                       int settingWidth = 105;
                                       if (setting instanceof BooleanSetting) {
                                          BooleanSetting booleanSetting = (BooleanSetting)setting;
                                          if (this.booleanSettingRenderer.mouseClicked(booleanSetting, mouseX, mouseY, button, settingX, (int)settingY, settingWidth, visible)) {
                                             return true;
                                          }
                                       } else if (setting instanceof BindBooleanSetting) {
                                          BindBooleanSetting bindBooleanSetting = (BindBooleanSetting)setting;
                                          if (this.bindbooleanSettingRenderer.mouseClicked(bindBooleanSetting, mouseX, mouseY, button, settingX, (int)settingY, settingWidth, visible)) {
                                             return true;
                                          }
                                       } else if (setting instanceof BindSetting) {
                                          BindSetting bindSetting = (BindSetting)setting;
                                          if (this.bindSettingRenderer.mouseClicked(bindSetting, mouseX, mouseY, button, settingX, (int)settingY - 2, settingWidth, visible)) {
                                             return true;
                                          }
                                       } else if (setting instanceof ModeSetting) {
                                          ModeSetting modeSetting = (ModeSetting)setting;
                                          if (this.modeSettingRenderer.mouseClicked(modeSetting, mouseX, mouseY, button, settingX, (int)settingY, settingWidth, visible)) {
                                             return true;
                                          }
                                       } else if (setting instanceof MultiSetting) {
                                          MultiSetting multiSetting = (MultiSetting)setting;
                                          if (this.multiSettingRenderer.mouseClicked(multiSetting, mouseX, mouseY, button, settingX, (int)settingY, settingWidth, visible)) {
                                             return true;
                                          }
                                       } else if (setting instanceof SliderSetting) {
                                          SliderSetting sliderSetting = (SliderSetting)setting;
                                          if (this.sliderSettingRenderer.mouseClicked(sliderSetting, mouseX, mouseY, button, settingX, (int)settingY - 2, settingWidth, visible)) {
                                             this.draggingSlider = sliderSetting;
                                             this.draggingSliderX = settingX;
                                             this.draggingSliderWidth = settingWidth;
                                             return true;
                                          }
                                       } else if (setting instanceof TextSetting) {
                                          TextSetting textSetting = (TextSetting)setting;
                                          if (this.textSettingRenderer.mouseClicked(textSetting, mouseX, mouseY, button, settingX, (int)settingY, settingWidth, visible)) {
                                             return true;
                                          }
                                       }
                                    }

                                    settingY += (float)(settingHeight + 1);
                                    remaining -= settingHeight + 1;
                                    if (remaining <= 0) {
                                       break;
                                    }
                                 }
                              }
                           }
                        }

                        currentY += (float)totalHeight;
                     }
                  }
               }
            }

            for(Type category : this.renderCategories) {
               for(Function function : Manager.FUNCTION_MANAGER.getFunctions(category)) {
                  if (function.expanded) {
                     for(Setting setting : function.getSettings()) {
                        if (setting instanceof TextSetting) {
                           TextSetting textSetting = (TextSetting)setting;
                           textSetting.setFocused(false);
                        }
                     }
                  }
               }
            }

            return super.method_25402(mouseX, mouseY, button);
         }
      }
   }

   private void renderExpiryText(class_332 context) {
      String text = Manager.USER_PROFILE.getExpiry();
      int margin = 5;
      int textHeight = (int)FontUtils.durman[18].getHeight();
      int screenHeight = mc.method_22683().method_4502();
      FontUtils.durman[18].drawLeftAligned(context.method_51448(), "Koniec — " + text, (float)(margin + 4), (float)(screenHeight - textHeight - margin), Color.WHITE.getRGB());
   }

   private boolean isFunctionVisible(Function function) {
      String searchTextLower = this.searchState.text.toLowerCase();
      return searchTextLower.isEmpty() || function.name.toLowerCase().contains(searchTextLower) || function.keywords.toLowerCase().contains(searchTextLower);
   }

   public void method_25420(class_332 drawContext, int mouseX, int mouseY, float delta) {
   }

   public boolean method_25421() {
      return false;
   }

   private int computeSettingsHeight(Function f) {
      int settingsHeight = 0;

      for(Setting setting : f.getSettings()) {
         if (setting.isVisible()) {
            if (setting instanceof BooleanSetting) {
               settingsHeight += this.booleanSettingRenderer.getHeight() + 1;
            } else if (setting instanceof BindBooleanSetting) {
               settingsHeight += this.bindbooleanSettingRenderer.getHeight() + 1;
            } else if (setting instanceof BindSetting) {
               settingsHeight += this.bindSettingRenderer.getHeight() + 1;
            } else if (setting instanceof ModeSetting) {
               settingsHeight += this.modeSettingRenderer.getHeight((ModeSetting)setting, 105) + 2;
            } else if (setting instanceof MultiSetting) {
               settingsHeight += this.multiSettingRenderer.getHeight((MultiSetting)setting, 105) + 2;
            } else if (setting instanceof SliderSetting) {
               settingsHeight += this.sliderSettingRenderer.getHeight() + 1;
            } else if (setting instanceof TextSetting) {
               settingsHeight += this.textSettingRenderer.getHeight() + 1;
            }
         }
      }

      return Math.max(0, settingsHeight);
   }

   private int getSettingRendererHeight(Setting setting, int width) {
      if (!setting.isVisible()) {
         return 0;
      } else if (setting instanceof BooleanSetting) {
         return this.booleanSettingRenderer.getHeight();
      } else if (setting instanceof BindBooleanSetting) {
         return this.bindbooleanSettingRenderer.getHeight();
      } else if (setting instanceof BindSetting) {
         return this.bindSettingRenderer.getHeight();
      } else if (setting instanceof ModeSetting) {
         ModeSetting modeSetting = (ModeSetting)setting;
         return this.modeSettingRenderer.getHeight(modeSetting, width);
      } else if (setting instanceof MultiSetting) {
         MultiSetting multiSetting = (MultiSetting)setting;
         return this.multiSettingRenderer.getHeight(multiSetting, width);
      } else if (setting instanceof SliderSetting) {
         return this.sliderSettingRenderer.getHeight();
      } else {
         return setting instanceof TextSetting ? this.textSettingRenderer.getHeight() : 0;
      }
   }

   private void clampScrollForCategory(Type category) {
      int maxScroll = this.calculateMaxScroll(category);
      float clampedTarget = class_3532.method_15363((Float)scrollTargets.get(category), 0.0F, (float)maxScroll);
      float clampedOffset = class_3532.method_15363((Float)scrollOffsets.get(category), 0.0F, (float)maxScroll);
      scrollTargets.put(category, clampedTarget);
      scrollOffsets.put(category, clampedOffset);
   }

   static {
      selectedColor1 = Color.WHITE.getRGB();
      selectedColor2 = Color.WHITE.getRGB();
   }
}
