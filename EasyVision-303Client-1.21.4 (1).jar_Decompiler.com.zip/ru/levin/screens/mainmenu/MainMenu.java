package ru.levin.screens.mainmenu;

import java.awt.Color;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_429;
import net.minecraft.class_437;
import net.minecraft.class_500;
import net.minecraft.class_526;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.screens.altmanager.AltManager;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.render.RenderUtil;

public class MainMenu extends class_437 {
   private Button singleplayerButton;
   private Button multiplayerButton;
   private Button altmanagerButton;
   private CombinedButton optionsQuitButton;
   private final String title = "303 Client";
   private int shakeTime = 0;
   private float shakeOffsetY = 0.0F;

   public MainMenu() {
      super(class_2561.method_43470("Custom Main Menu"));
   }

   protected void method_25426() {
      int buttonWidth = 200;
      int buttonHeight = 30;
      this.singleplayerButton = new Button("Singleplayer", 0, 0, buttonWidth, buttonHeight);
      this.multiplayerButton = new Button("Multiplayer", 0, 0, buttonWidth, buttonHeight);
      this.altmanagerButton = new Button("AltManager", 0, 0, buttonWidth, buttonHeight);
      this.optionsQuitButton = new CombinedButton(0, 0, buttonWidth, buttonHeight, "Options", "Quit");
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      RenderUtil.drawRoundedRect(context.method_51448(), -1.0F, -1.0F, (float)(this.field_22789 + 2), (float)(this.field_22790 + 2), 4.0F, (new Color(27, 27, 27, 255)).getRGB());
      if (this.shakeTime > 0) {
         --this.shakeTime;
         this.shakeOffsetY = (float)(Math.sin((double)this.shakeTime * (double)0.5F) * (double)3.0F);
      } else {
         this.shakeOffsetY = 0.0F;
      }

      int titleWidth = (int)FontUtils.sf_bold[54].getWidth("303 Client");
      float titleX = (float)(this.field_22789 - titleWidth) / 2.0F;
      float titleBaseY = (float)this.field_22790 / 5.0F;
      float titleY = titleBaseY + this.shakeOffsetY;
      float time = (float)(System.currentTimeMillis() % 4000L) / 1500.0F;
      FontUtils.sf_bold[54].renderAnimatedGradientText(context.method_51448(), "303 Client", titleX, titleY, ColorUtil.getColorStyle(30.0F), ColorUtil.getColorStyle(260.0F), time);
      float titleHeight = 54.0F;
      int spacing = 12;
      int buttonWidth = 200;
      int buttonHeight = 30;
      float buttonsStartY = titleBaseY + titleHeight + (float)(spacing * 2);
      int centerX = this.field_22789 / 2 - buttonWidth / 2;
      this.singleplayerButton.x = centerX;
      this.singleplayerButton.y = (int)buttonsStartY;
      this.multiplayerButton.x = centerX;
      this.multiplayerButton.y = (int)(buttonsStartY + (float)buttonHeight + (float)spacing);
      this.altmanagerButton.x = centerX;
      this.altmanagerButton.y = (int)(buttonsStartY + (float)(2 * (buttonHeight + spacing)));
      this.optionsQuitButton.x = centerX;
      this.optionsQuitButton.y = (int)(buttonsStartY + (float)(3 * (buttonHeight + spacing)));
      this.optionsQuitButton.width = buttonWidth;
      this.singleplayerButton.render(context, mouseX, mouseY, delta);
      this.multiplayerButton.render(context, mouseX, mouseY, delta);
      this.altmanagerButton.render(context, mouseX, mouseY, delta);
      this.optionsQuitButton.render(context, mouseX, mouseY, delta);
   }

   public boolean method_25402(double mouseX, double mouseY, int button) {
      int titleWidth = (int)FontUtils.sf_bold[54].getWidth("303 Client");
      float titleX = (float)(this.field_22789 - titleWidth) / 2.0F;
      float titleY = (float)this.field_22790 / 5.0F;
      if (mouseX >= (double)titleX && mouseX <= (double)(titleX + (float)titleWidth) && mouseY >= (double)titleY && mouseY <= (double)(titleY + 54.0F)) {
         this.shakeTime = 20;
         return true;
      } else if (this.singleplayerButton.isHovered(mouseX, mouseY)) {
         this.field_22787.method_1507(new class_526(this));
         return true;
      } else if (this.multiplayerButton.isHovered(mouseX, mouseY)) {
         this.field_22787.method_1507(new class_500(this));
         return true;
      } else if (this.altmanagerButton.isHovered(mouseX, mouseY)) {
         this.field_22787.method_1507(new AltManager(this));
         return true;
      } else if (this.optionsQuitButton.isOptionHovered(mouseX, mouseY)) {
         this.field_22787.method_1507(new class_429(this, this.field_22787.field_1690));
         return true;
      } else if (this.optionsQuitButton.isQuitHovered(mouseX, mouseY)) {
         this.field_22787.method_1592();
         return true;
      } else {
         return super.method_25402(mouseX, mouseY, button);
      }
   }

   public boolean method_25422() {
      return false;
   }

   private class Button {
      final String name;
      int x;
      int y;
      int width;
      int height;
      private float hoverAnim = 0.0F;
      private float scale = 1.0F;

      Button(String name, int x, int y, int width, int height) {
         this.name = name;
         this.x = x;
         this.y = y;
         this.width = width;
         this.height = height;
      }

      void render(class_332 context, int mouseX, int mouseY, float delta) {
         boolean hovered = this.isHovered((double)mouseX, (double)mouseY);
         float animSpeed = 0.04F;
         if (hovered) {
            this.hoverAnim = Math.min(1.0F, this.hoverAnim + animSpeed);
            this.scale = Math.min(1.02F, this.scale + animSpeed * 0.5F);
         } else {
            this.hoverAnim = Math.max(0.0F, this.hoverAnim - animSpeed);
            this.scale = Math.max(1.0F, this.scale - animSpeed * 0.5F);
         }

         int baseColor = (new Color(35, 35, 35)).getRGB();
         int hoverColor = (new Color(55, 55, 55)).getRGB();
         int bgColor = ColorUtil.blendColorsInt(baseColor, hoverColor, this.hoverAnim);
         int outlineColor = (new Color(60, 60, 60, 180)).getRGB();
         float textHeight = 20.0F;
         float textY = (float)this.y + ((float)this.height - textHeight) / 2.0F + 3.0F;
         context.method_51448().method_22903();
         context.method_51448().method_46416((float)this.x + (float)this.width / 2.0F, (float)this.y + (float)this.height / 2.0F, 0.0F);
         context.method_51448().method_22905(this.scale, this.scale, 1.0F);
         context.method_51448().method_46416(-((float)this.x + (float)this.width / 2.0F), -((float)this.y + (float)this.height / 2.0F), 0.0F);
         RenderUtil.drawRoundedRect(context.method_51448(), (float)this.x, (float)this.y, (float)this.width, (float)this.height, 4.0F, bgColor);
         RenderUtil.drawRoundedBorder(context.method_51448(), (float)this.x, (float)this.y, (float)this.width, (float)this.height, 4.0F, 1.0F, outlineColor);
         FontUtils.sf_medium[20].centeredDraw(context.method_51448(), this.name, (float)this.x + (float)this.width / 2.0F, textY, Color.WHITE.getRGB());
         context.method_51448().method_22909();
      }

      boolean isHovered(double mouseX, double mouseY) {
         return mouseX >= (double)this.x && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
      }
   }

   private class CombinedButton {
      int x;
      int y;
      int width;
      int height;
      final String leftName;
      final String rightName;
      private float leftHoverAnim = 0.0F;
      private float rightHoverAnim = 0.0F;
      private float leftScale = 1.0F;
      private float rightScale = 1.0F;

      CombinedButton(int x, int y, int width, int height, String leftName, String rightName) {
         this.x = x;
         this.y = y;
         this.width = width;
         this.height = height;
         this.leftName = leftName;
         this.rightName = rightName;
      }

      void render(class_332 context, int mouseX, int mouseY, float delta) {
         int buttonGap = 2;
         int halfWidth = this.width / 2;
         int shrink = 4;
         boolean leftHovered = this.isOptionHovered((double)mouseX, (double)mouseY);
         boolean rightHovered = this.isQuitHovered((double)mouseX, (double)mouseY);
         float animSpeed = 0.04F;
         if (leftHovered) {
            this.leftHoverAnim = Math.min(1.0F, this.leftHoverAnim + animSpeed);
            this.leftScale = Math.min(1.02F, this.leftScale + animSpeed * 0.5F);
         } else {
            this.leftHoverAnim = Math.max(0.0F, this.leftHoverAnim - animSpeed);
            this.leftScale = Math.max(1.0F, this.leftScale - animSpeed * 0.5F);
         }

         if (rightHovered) {
            this.rightHoverAnim = Math.min(1.0F, this.rightHoverAnim + animSpeed);
            this.rightScale = Math.min(1.02F, this.rightScale + animSpeed * 0.5F);
         } else {
            this.rightHoverAnim = Math.max(0.0F, this.rightHoverAnim - animSpeed);
            this.rightScale = Math.max(1.0F, this.rightScale - animSpeed * 0.5F);
         }

         int baseColor = (new Color(35, 35, 35)).getRGB();
         int hoverColor = (new Color(55, 55, 55)).getRGB();
         int outlineColor = (new Color(60, 60, 60, 180)).getRGB();
         int buttonWidth = halfWidth - shrink;
         int leftX = this.x + buttonGap;
         int leftBg = ColorUtil.blendColorsInt(baseColor, hoverColor, this.leftHoverAnim);
         context.method_51448().method_22903();
         context.method_51448().method_46416((float)leftX + (float)buttonWidth / 2.0F, (float)this.y + (float)this.height / 2.0F, 0.0F);
         context.method_51448().method_22905(this.leftScale, this.leftScale, 1.0F);
         context.method_51448().method_46416(-((float)leftX + (float)buttonWidth / 2.0F), -((float)this.y + (float)this.height / 2.0F), 0.0F);
         RenderUtil.drawRoundedRect(context.method_51448(), (float)leftX, (float)this.y, (float)buttonWidth, (float)this.height, 4.0F, leftBg);
         RenderUtil.drawRoundedBorder(context.method_51448(), (float)leftX, (float)this.y, (float)buttonWidth, (float)this.height, 4.0F, 1.0F, outlineColor);
         FontUtils.sf_medium[20].centeredDraw(context.method_51448(), this.leftName, (float)leftX + (float)buttonWidth / 2.0F, (float)this.y + (float)(this.height - 10) / 2.2F, Color.WHITE.getRGB());
         context.method_51448().method_22909();
         int rightX = this.x + halfWidth + buttonGap;
         int rightBg = ColorUtil.blendColorsInt(baseColor, hoverColor, this.rightHoverAnim);
         context.method_51448().method_22903();
         context.method_51448().method_46416((float)rightX + (float)buttonWidth / 2.0F, (float)this.y + (float)this.height / 2.0F, 0.0F);
         context.method_51448().method_22905(this.rightScale, this.rightScale, 1.0F);
         context.method_51448().method_46416(-((float)rightX + (float)buttonWidth / 2.0F), -((float)this.y + (float)this.height / 2.0F), 0.0F);
         RenderUtil.drawRoundedRect(context.method_51448(), (float)rightX, (float)this.y, (float)buttonWidth, (float)this.height, 4.0F, rightBg);
         RenderUtil.drawRoundedBorder(context.method_51448(), (float)rightX, (float)this.y, (float)buttonWidth, (float)this.height, 4.0F, 1.0F, outlineColor);
         FontUtils.sf_medium[20].centeredDraw(context.method_51448(), this.rightName, (float)rightX + (float)buttonWidth / 2.0F, (float)this.y + (float)(this.height - 10) / 2.2F, Color.WHITE.getRGB());
         context.method_51448().method_22909();
      }

      boolean isOptionHovered(double mouseX, double mouseY) {
         return mouseX >= (double)this.x && mouseX < (double)(this.x + this.width / 2 - 1) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
      }

      boolean isQuitHovered(double mouseX, double mouseY) {
         return mouseX > (double)(this.x + this.width / 2 + 1) && mouseX <= (double)(this.x + this.width) && mouseY >= (double)this.y && mouseY <= (double)(this.y + this.height);
      }
   }
}
