package ru.levin.screens.unhook;

import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_437;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.misc.UnHook;

public class UnHookScreen extends class_437 implements IMinecraft {
   private final UnHook unHookFunction;

   public UnHookScreen() {
      super(class_2561.method_43470("UnHook"));
      this.unHookFunction = Manager.FUNCTION_MANAGER.unHook;
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      super.method_25394(context, mouseX, mouseY, delta);
      this.handleTimers();
   }

   private void handleTimers() {
      ClientManager.legitMode = true;
      this.unHookFunction.onUnhook();
      mc.method_1507((class_437)null);
   }
}
