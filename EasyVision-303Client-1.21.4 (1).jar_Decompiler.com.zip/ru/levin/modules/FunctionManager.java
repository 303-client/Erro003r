package ru.levin.modules;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import ru.levin.modules.combat.AntiBot;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.combat.AttackExtend;
import ru.levin.modules.combat.AutoExplosion;
import ru.levin.modules.combat.AutoPotion;
import ru.levin.modules.combat.AutoSwap;
import ru.levin.modules.combat.AutoTotem;
import ru.levin.modules.combat.Criticals;
import ru.levin.modules.combat.CrystalAura;
import ru.levin.modules.combat.HitBox;
import ru.levin.modules.combat.NoFriendDamage;
import ru.levin.modules.combat.SelfTrap;
import ru.levin.modules.combat.Striker;
import ru.levin.modules.combat.SuperBow;
import ru.levin.modules.combat.TargetStrafe;
import ru.levin.modules.combat.Velocity;
import ru.levin.modules.misc.AntyKostka;
import ru.levin.modules.misc.AutoBreak;
import ru.levin.modules.misc.AutoDrain;
import ru.levin.modules.misc.AutoDuel;
import ru.levin.modules.misc.AutoDuelBot;
import ru.levin.modules.misc.AutoLever;
import ru.levin.modules.misc.ClientSounds;
import ru.levin.modules.misc.DeathCoords;
import ru.levin.modules.misc.DiscordRCP;
import ru.levin.modules.misc.EasyVision;
import ru.levin.modules.misc.ElytraHelper;
import ru.levin.modules.misc.ErrorKiller;
import ru.levin.modules.misc.FTHelper;
import ru.levin.modules.misc.FastDrain;
import ru.levin.modules.misc.FastErrorKiller;
import ru.levin.modules.misc.FastNameProtect;
import ru.levin.modules.misc.Globals;
import ru.levin.modules.misc.HWHelper;
import ru.levin.modules.misc.IRC;
import ru.levin.modules.misc.NameProtect;
import ru.levin.modules.misc.NoCommands;
import ru.levin.modules.misc.Optimizer;
import ru.levin.modules.misc.RWHelper;
import ru.levin.modules.misc.ServerRPSpoff;
import ru.levin.modules.misc.TPLoot;
import ru.levin.modules.misc.TpacceptSounds;
import ru.levin.modules.misc.UnHook;
import ru.levin.modules.misc.WiciaMsgSpammer;
import ru.levin.modules.misc.WiciaNameProtect;
import ru.levin.modules.misc.Xray;
import ru.levin.modules.movement.AirStuck;
import ru.levin.modules.movement.AutoSprint;
import ru.levin.modules.movement.Blink;
import ru.levin.modules.movement.ElytraMotion;
import ru.levin.modules.movement.ElytraRecast;
import ru.levin.modules.movement.ElytraTarget;
import ru.levin.modules.movement.Flight;
import ru.levin.modules.movement.FreeLook;
import ru.levin.modules.movement.NoSlow;
import ru.levin.modules.movement.NoWeb;
import ru.levin.modules.movement.Phase;
import ru.levin.modules.movement.Speed;
import ru.levin.modules.movement.Spider;
import ru.levin.modules.movement.Strafe;
import ru.levin.modules.movement.SuperFirework;
import ru.levin.modules.movement.Timer;
import ru.levin.modules.player.ArmorEquipper;
import ru.levin.modules.player.AutoAccept;
import ru.levin.modules.player.AutoDrip;
import ru.levin.modules.player.AutoLeave;
import ru.levin.modules.player.AutoMessage;
import ru.levin.modules.player.AutoNielota;
import ru.levin.modules.player.AutoPlotek;
import ru.levin.modules.player.AutoRespawn;
import ru.levin.modules.player.AutoTool;
import ru.levin.modules.player.ChestStealer;
import ru.levin.modules.player.ClickAction;
import ru.levin.modules.player.CustomCoolDown;
import ru.levin.modules.player.EnderChestExploit;
import ru.levin.modules.player.FastAutoPlotek;
import ru.levin.modules.player.FastBetterPainting;
import ru.levin.modules.player.FastDripstone;
import ru.levin.modules.player.FastLever;
import ru.levin.modules.player.FastPlace;
import ru.levin.modules.player.FreeCamera;
import ru.levin.modules.player.GuiWalk;
import ru.levin.modules.player.HighJump;
import ru.levin.modules.player.InvseeExploit;
import ru.levin.modules.player.ItemFixSwap;
import ru.levin.modules.player.ItemScroller;
import ru.levin.modules.player.MiddleClickFriend;
import ru.levin.modules.player.MiddleClickPearl;
import ru.levin.modules.player.NoDelay;
import ru.levin.modules.player.NoGuiSign;
import ru.levin.modules.player.NoInteract;
import ru.levin.modules.player.NoPush;
import ru.levin.modules.player.NoRayTrace;
import ru.levin.modules.player.PerfectTime;
import ru.levin.modules.player.Refiller;
import ru.levin.modules.player.RegionExploit;
import ru.levin.modules.player.WiciaAntyKostka;
import ru.levin.modules.player.WiciaDripstone;
import ru.levin.modules.player.WiciaFastPlace;
import ru.levin.modules.player.WiciaMiddleClickFriend;
import ru.levin.modules.player.WiciaNielota;
import ru.levin.modules.render.Arrows;
import ru.levin.modules.render.AspectRatio;
import ru.levin.modules.render.BetterPainting;
import ru.levin.modules.render.BlockESP;
import ru.levin.modules.render.BlockHighLight;
import ru.levin.modules.render.Breadcrumbs;
import ru.levin.modules.render.ClickGUI;
import ru.levin.modules.render.CrossHair;
import ru.levin.modules.render.CrownHat;
import ru.levin.modules.render.ESP;
import ru.levin.modules.render.ElytraDetector;
import ru.levin.modules.render.EntityVisibility;
import ru.levin.modules.render.ExtraTab;
import ru.levin.modules.render.FullBright;
import ru.levin.modules.render.HUD;
import ru.levin.modules.render.ItemPhysic;
import ru.levin.modules.render.JumpCircles;
import ru.levin.modules.render.LittleSnickers;
import ru.levin.modules.render.LogoutSpots;
import ru.levin.modules.render.NameTags;
import ru.levin.modules.render.NeonHat;
import ru.levin.modules.render.NoRender;
import ru.levin.modules.render.Particles;
import ru.levin.modules.render.Prediction;
import ru.levin.modules.render.ScoreBoardStealer;
import ru.levin.modules.render.ScoreboardEditor;
import ru.levin.modules.render.SwingAnimations;
import ru.levin.modules.render.TargetESP;
import ru.levin.modules.render.Trails;
import ru.levin.modules.render.TrapESP;
import ru.levin.modules.render.ViewModel;
import ru.levin.modules.render.WiciaEntityVisibility;
import ru.levin.modules.render.WiciaNameTags;
import ru.levin.modules.render.WiciaPainting;
import ru.levin.modules.render.WiciaTracers;
import ru.levin.modules.render.World;

public class FunctionManager {
   public static final List<Function> functions = new CopyOnWriteArrayList();
   public final ClickGUI clickGUI;
   public final Optimizer optimizer;
   public final ClientSounds clientSounds;
   public final TpacceptSounds tpacceptSounds;
   public final ElytraTarget elytraTarget;
   public final SuperFirework superFirework;
   public final AttackAura attackAura;
   public final CrystalAura crystalAura;
   public final Striker striker;
   public final NoFriendDamage noFriendDamage;
   public final HitBox xbox;
   public final NoCommands noCommands;
   public final SwingAnimations swingAnimations;
   public final ViewModel viewModel;
   public final NoPush noPush;
   public final NoGuiSign noGuiSign;
   public final FastPlace fastPlace;
   public final AutoDrip autoDrip;
   public final FastDripstone fastDripstone;
   public final WiciaDripstone wiciaDripstone;
   public final WiciaNielota wiciaNielota;
   public final WiciaPainting wiciaPainting;
   public final WiciaTracers wiciaTracers;
   public final WiciaFastPlace wiciaFastPlace;
   public final WiciaEntityVisibility wiciaEntityVisibility;
   public final WiciaAntyKostka wiciaAntyKostka;
   public final WiciaNameTags wiciaNameTags;
   public final WiciaNameProtect wiciaNameProtect;
   public final WiciaMiddleClickFriend wiciaMiddleClickFriend;
   public final WiciaMsgSpammer wiciaMsgSpammer;
   public final Refiller refiller;
   public final FastAutoPlotek fastAutoPlotek;
   public final FastBetterPainting fastBetterPainting;
   public final FastLever fastLever;
   public final FastErrorKiller fastErrorKiller;
   public final FastDrain fastDrain;
   public final FastNameProtect fastNameProtect;
   public final ArmorEquipper armorEquipper;
   public final AutoPlotek autoPlotek;
   public final AutoDrain autoDrain;
   public final AutoBreak autoBreak;
   public final Xray xray;
   public final EasyVision easyVision = new EasyVision();
   public final AutoLever autoLever;
   public final ErrorKiller errorKiller;
   public final BetterPainting betterPainting;
   public final AntyKostka antyKostka;
   public final EntityVisibility entityVisibility;
   public final TrapESP trapESP;
   public final AutoNielota autoNielota;
   public final FreeCamera freeCamera;
   public final HUD hud;
   public final ScoreboardEditor scoreboardEditor;
   public final ScoreBoardStealer scoreBoardStealer;
   public final NeonHat neonHat;
   public final NoRender noRender;
   public final NameProtect nameProtect;
   public final NoInteract noInteract;
   public final ItemScroller itemScroller;
   public final NoSlow noSlow;
   public final LittleSnickers littleSnickers;
   public final UnHook unHook;
   public final FullBright fullBright;
   public final ItemPhysic itemPhysic;
   public final AutoPotion autoPotion;
   public final GuiWalk guiWalk;
   public final ExtraTab extraTab;
   public final FreeLook freeLook;
   public final AntiBot antiBot;
   public final AutoExplosion autoExplosion;
   public final Arrows arrows;
   public final CustomCoolDown customCoolDown;
   public final Blink blink;
   public final NameTags nameTags;
   public final LogoutSpots logoutSpots;
   public final ElytraDetector elytraDetector;
   public final BlockESP blockESP;
   public final ChestStealer chestStealer;
   public final AspectRatio aspectRatio;
   public final World customWorld;
   public final NoRayTrace noRayTrace;
   public final IRC irc;
   public final ClickAction clickAction;
   public final Phase phase;
   public final TargetStrafe targetStrafe;
   public final Globals globals;
   public final AutoSprint autoSprint;
   public final Speed speed;
   public final CrossHair crossHair;
   public final SelfTrap selfTrap;
   public final AutoTotem autoTotem;
   public final BlockHighLight blockHighLight;
   public final CrownHat crownHat;

   public FunctionManager() {
      functions.add(this.easyVision);
      functions.addAll(Arrays.asList(new Criticals(), this.targetStrafe = new TargetStrafe(), this.noFriendDamage = new NoFriendDamage(), this.autoExplosion = new AutoExplosion(), new AttackExtend(), this.attackAura = new AttackAura(), this.crystalAura = new CrystalAura(), this.striker = new Striker(), this.selfTrap = new SelfTrap(), this.autoPotion = new AutoPotion(), this.autoTotem = new AutoTotem(), new AutoSwap(), new SuperBow(), this.xbox = new HitBox(), this.antiBot = new AntiBot(), new Velocity(), this.unHook = new UnHook(), this.optimizer = new Optimizer(), this.clientSounds = new ClientSounds(), this.tpacceptSounds = new TpacceptSounds(), new DeathCoords(), new ServerRPSpoff(), this.xray = new Xray(), new ElytraHelper(), new FTHelper(), new HWHelper(), new RWHelper(), new AutoDuel(), new AutoDuelBot(), new DiscordRCP(), this.globals = new Globals(), this.irc = new IRC(), this.nameProtect = new NameProtect(), this.autoDrain = new AutoDrain(), this.autoBreak = new AutoBreak(), this.autoLever = new AutoLever(), this.errorKiller = new ErrorKiller(), this.betterPainting = new BetterPainting(), this.antyKostka = new AntyKostka(), this.entityVisibility = new EntityVisibility(), this.trapESP = new TrapESP(), this.autoNielota = new AutoNielota(), this.noCommands = new NoCommands(), this.blink = new Blink(), this.phase = new Phase(), this.autoSprint = new AutoSprint(), new HighJump(), new Flight(), this.elytraTarget = new ElytraTarget(), new ElytraRecast(), new ElytraMotion(), this.superFirework = new SuperFirework(), this.freeLook = new FreeLook(), this.speed = new Speed(), new Strafe(), new Spider(), new AirStuck(), this.noSlow = new NoSlow(), new Timer(), new NoWeb(), this.guiWalk = new GuiWalk(), new NoDelay(), new AutoLeave(), new AutoMessage(), this.clickAction = new ClickAction(), this.itemScroller = new ItemScroller(), new ItemFixSwap(), new PerfectTime(), this.noRayTrace = new NoRayTrace(), this.noPush = new NoPush(), this.noGuiSign = new NoGuiSign(), this.fastPlace = new FastPlace(), new AutoRespawn(), new AutoTool(), this.autoDrip = new AutoDrip(), this.fastDripstone = new FastDripstone(), this.wiciaDripstone = new WiciaDripstone(), this.wiciaNielota = new WiciaNielota(), this.wiciaPainting = new WiciaPainting(), this.wiciaTracers = new WiciaTracers(), this.wiciaFastPlace = new WiciaFastPlace(), this.wiciaEntityVisibility = new WiciaEntityVisibility(), this.wiciaAntyKostka = new WiciaAntyKostka(), this.wiciaNameTags = new WiciaNameTags(), this.wiciaNameProtect = new WiciaNameProtect(), this.wiciaMiddleClickFriend = new WiciaMiddleClickFriend(), this.wiciaMsgSpammer = new WiciaMsgSpammer(), this.refiller = new Refiller(), this.fastAutoPlotek = new FastAutoPlotek(), this.fastBetterPainting = new FastBetterPainting(), this.fastLever = new FastLever(), this.fastErrorKiller = new FastErrorKiller(), this.fastDrain = new FastDrain(), this.fastNameProtect = new FastNameProtect(), this.armorEquipper = new ArmorEquipper(), this.autoPlotek = new AutoPlotek(), this.freeCamera = new FreeCamera(), this.customCoolDown = new CustomCoolDown(), new MiddleClickFriend(), new MiddleClickPearl(), this.noInteract = new NoInteract(), this.chestStealer = new ChestStealer(), new EnderChestExploit(), new InvseeExploit(), new RegionExploit(), this.clickGUI = new ClickGUI(), this.hud = new HUD(), this.scoreboardEditor = new ScoreboardEditor(), this.scoreBoardStealer = new ScoreBoardStealer(), this.neonHat = new NeonHat(), this.swingAnimations = new SwingAnimations(), this.viewModel = new ViewModel(), this.aspectRatio = new AspectRatio(), this.crossHair = new CrossHair(), this.fullBright = new FullBright(), this.customWorld = new World(), this.noRender = new NoRender(), this.blockESP = new BlockESP(), this.itemPhysic = new ItemPhysic(), this.extraTab = new ExtraTab(), this.arrows = new Arrows(), new ESP(), this.nameTags = new NameTags(), this.logoutSpots = new LogoutSpots(), this.elytraDetector = new ElytraDetector(), new Prediction(), this.blockHighLight = new BlockHighLight(), new AutoAccept(), new JumpCircles(), new Breadcrumbs(), new Trails(), new Particles(), new TargetESP(), new TPLoot(), this.littleSnickers = new LittleSnickers(), this.crownHat = new CrownHat()));
   }

   public List<Function> getFunctions() {
      return functions;
   }

   public List<Function> getFunctions(Type var1) {
      ArrayList var2 = new ArrayList();

      for(Function var4 : this.getFunctions()) {
         if (var4.getCategory() == var1) {
            var2.add(var4);
         }
      }

      return var2;
   }

   public static Function get(String var0) {
      for(Function var2 : functions) {
         if (var2 != null && var2.name.equalsIgnoreCase(var0)) {
            return var2;
         }
      }

      return null;
   }
}
