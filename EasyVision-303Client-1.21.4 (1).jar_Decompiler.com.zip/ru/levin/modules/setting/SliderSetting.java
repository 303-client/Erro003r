package ru.levin.modules.setting;

import java.util.function.Supplier;
import net.minecraft.class_3532;

public class SliderSetting extends Setting {
   public boolean dragging;
   public float circleScale = 1.0F;
   private String name;
   private double value;
   private double min;
   private double max;
   private double increment;
   private Supplier<Boolean> visible;
   public double circlePos = (double)-1.0F;

   public SliderSetting(String name, double value, double min, double max, double increment) {
      this.name = name;
      this.value = value;
      this.min = min;
      this.max = max;
      this.increment = increment;
      this.setVisible(() -> true);
   }

   public SliderSetting(String name, double value, double min, double max, double increment, Supplier<Boolean> visible) {
      this.name = name;
      this.value = value;
      this.min = min;
      this.max = max;
      this.increment = increment;
      this.setVisible(visible);
   }

   public boolean isVisible() {
      return (Boolean)this.visible.get();
   }

   public void setVisible(Supplier<Boolean> visible) {
      this.visible = visible;
   }

   public String getName() {
      return this.name;
   }

   public Number get() {
      return class_3532.method_15350(this.value, this.getMin(), this.getMax());
   }

   public void set(double value) {
      this.value = class_3532.method_15350(value, this.getMin(), this.getMax());
   }

   public double getMin() {
      return this.min;
   }

   public double getMax() {
      return this.max;
   }

   public double getIncrement() {
      return this.increment;
   }
}
