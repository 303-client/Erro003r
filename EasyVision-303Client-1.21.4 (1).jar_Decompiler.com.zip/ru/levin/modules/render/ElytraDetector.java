package ru.levin.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_238;
import ru.levin.ExosWare;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.dragManager.Dragging;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "ElytraDetector",
   desc = "Wykrywa graczy na elytra / w locie",
   type = Type.Render
)
public class ElytraDetector extends Function {
   private final SliderSetting range = new SliderSetting("Zasięg", (double)50.0F, (double)10.0F, (double)120.0F, (double)1.0F);
   private final SliderSetting scale = new SliderSetting("Rozmiar", (double)1.0F, (double)0.5F, (double)2.5F, (double)0.1F);
   public final Dragging hud = ExosWare.getInstance().createDrag(this, "ElytraDetectorHUD", 120.0F, 120.0F);

   public ElytraDetector() {
      this.addSettings(new Setting[]{this.range, this.scale});
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender3D) {
         this.render3D();
      } else {
         if (event instanceof EventRender2D) {
            EventRender2D render2D = (EventRender2D)event;
            this.renderHud(render2D);
         }

      }
   }

   private void render3D() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         double maxDistance = this.range.get().doubleValue();

         for(class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1657) {
               class_1657 player = (class_1657)entity;
               if (player != mc.field_1724) {
                  boolean hasElytra = player.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
                  if ((hasElytra || player.method_6128()) && !((double)mc.field_1724.method_5739(player) > maxDistance)) {
                     class_238 box = entity.method_5829().method_1014(0.05);
                     RenderUtil.render3D.drawHoleOutline(box, (new Color(90, 220, 255, 180)).getRGB(), 2.0F);
                  }
               }
            }
         }

      }
   }

   private void renderHud(EventRender2D render2D) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         List<class_1657> detected = new ArrayList();
         double maxDistance = this.range.get().doubleValue();

         for(class_1297 entity : mc.field_1687.method_18112()) {
            if (entity instanceof class_1657) {
               class_1657 player = (class_1657)entity;
               if (player != mc.field_1724) {
                  boolean hasElytra = player.method_6118(class_1304.field_6174).method_31574(class_1802.field_8833);
                  if ((hasElytra || player.method_6128()) && !((double)mc.field_1724.method_5739(player) > maxDistance)) {
                     detected.add(player);
                  }
               }
            }
         }

         if (!detected.isEmpty()) {
            float scaleValue = this.scale.get().floatValue();
            float x = this.hud.getX();
            float y = this.hud.getY();
            float padding = 6.0F * scaleValue;
            float rowHeight = 12.0F * scaleValue;
            float titleHeight = 14.0F * scaleValue;
            float maxWidth = 0.0F;

            for(class_1657 player : detected) {
               String var10000 = player.method_7334().getName();
               String label = var10000 + " " + (player.method_6128() ? "LECI" : "ELYTRA");
               float width = FontUtils.durman[13].getWidth(label) * scaleValue;
               if (width > maxWidth) {
                  maxWidth = width;
               }
            }

            float width = maxWidth + padding * 2.0F;
            float height = titleHeight + 6.0F + (float)detected.size() * rowHeight + padding * 2.0F;
            this.hud.setWidth(width);
            this.hud.setHeight(height);
            RenderUtil.drawRoundedRect(render2D.getMatrixStack(), x, y, width, height, 4.0F, (new Color(12, 12, 18, 180)).getRGB());
            FontUtils.durman[14].drawLeftAligned(render2D.getMatrixStack(), "ElytraDetector", x + padding, y + padding + 2.0F, (new Color(120, 220, 255)).getRGB());
            float currentY = y + titleHeight + 8.0F;

            for(class_1657 player : detected) {
               String status = player.method_6128() ? "Leci" : "Elytra";
               String var27 = player.method_7334().getName();
               String text = var27 + " | " + status;
               FontUtils.durman[13].drawLeftAligned(render2D.getMatrixStack(), text, x + padding, currentY, -1);
               currentY += rowHeight;
            }

         }
      }
   }
}
