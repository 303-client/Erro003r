package ru.levin.modules.render;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "LogoutSpots",
   desc = "Pokazuje miejsca wylogowania graczy",
   type = Type.Render
)
public class LogoutSpots extends Function {
   private final BooleanSetting showName = new BooleanSetting("Pokaż nick", true);
   private final BooleanSetting showTime = new BooleanSetting("Pokaż czas", true);
   private final Map<UUID, Snapshot> lastSeen = new HashMap();
   private final Map<UUID, Spot> spots = new HashMap();

   public LogoutSpots() {
      this.addSettings(new Setting[]{this.showName, this.showTime});
   }

   protected void onEnable() {
      this.lastSeen.clear();
      this.spots.clear();
   }

   protected void onDisable() {
      this.lastSeen.clear();
      this.spots.clear();
   }

   public void onEvent(Event event) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         if (event instanceof EventUpdate) {
            this.updatePlayers();
         } else if (event instanceof EventRender3D) {
            EventRender3D render3D = (EventRender3D)event;
            this.renderSpots(render3D);
         }

      }
   }

   private void updatePlayers() {
      Set<UUID> visible = new HashSet();

      for(class_1657 player : mc.field_1687.method_18456()) {
         if (player != mc.field_1724) {
            UUID uuid = player.method_5667();
            visible.add(uuid);
            this.lastSeen.put(uuid, new Snapshot(player.method_19538(), player.method_5477().getString()));
            this.spots.remove(uuid);
         }
      }

      for(Map.Entry<UUID, Snapshot> entry : this.lastSeen.entrySet()) {
         if (!visible.contains(entry.getKey()) && !this.spots.containsKey(entry.getKey())) {
            Snapshot snapshot = (Snapshot)entry.getValue();
            this.spots.put((UUID)entry.getKey(), new Spot((UUID)entry.getKey(), snapshot.position(), snapshot.name(), System.currentTimeMillis()));
         }
      }

   }

   private void renderSpots(EventRender3D event) {
      for(Spot spot : this.spots.values()) {
         class_243 position = spot.position();
         class_238 box = new class_238(position.field_1352 - 0.32, position.field_1351, position.field_1350 - 0.32, position.field_1352 + 0.32, position.field_1351 + 1.8, position.field_1350 + 0.32);
         RenderUtil.render3D.drawHoleOutline(box, -1325443755, 2.0F);
      }

   }

   public boolean isShowName() {
      return this.showName.get();
   }

   public boolean isShowTime() {
      return this.showTime.get();
   }

   public static record Spot(UUID uuid, class_243 position, String name, long logoutTime) {
   }

   private static record Snapshot(class_243 position, String name) {
   }
}
