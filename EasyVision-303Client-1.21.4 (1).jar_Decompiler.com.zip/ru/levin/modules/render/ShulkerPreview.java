package ru.levin.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2520;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_7225;
import net.minecraft.class_918;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "ShulkerPreview",
   desc = "Podgląd zawartości shulkerów",
   type = Type.Render
)
public class ShulkerPreview extends Function {
   private final class_310 mc = class_310.method_1551();

   public void onEvent(Event event) {
   }

   private boolean isShulkerBox(class_1799 stack) {
      return stack.method_31574(class_1802.field_8545) || stack.method_31574(class_1802.field_8722) || stack.method_31574(class_1802.field_8380) || stack.method_31574(class_1802.field_8050) || stack.method_31574(class_1802.field_8829) || stack.method_31574(class_1802.field_8271) || stack.method_31574(class_1802.field_8548) || stack.method_31574(class_1802.field_8520) || stack.method_31574(class_1802.field_8627) || stack.method_31574(class_1802.field_8451) || stack.method_31574(class_1802.field_8213) || stack.method_31574(class_1802.field_8816) || stack.method_31574(class_1802.field_8350) || stack.method_31574(class_1802.field_8584) || stack.method_31574(class_1802.field_8461) || stack.method_31574(class_1802.field_8676) || stack.method_31574(class_1802.field_8268);
   }

   private class_2371<class_1799> getItems(class_1799 stack) {
      class_2371<class_1799> list = class_2371.method_10213(27, class_1799.field_8037);
      class_7225.class_7874 registries = class_310.method_1551().method_1562().method_29091();
      class_2520 nbtElement = stack.method_57375(registries);
      if (nbtElement instanceof class_2487 compound) {
         if (!compound.method_10573("BlockEntityTag", 10)) {
            return list;
         } else {
            class_2487 blockEntityTag = compound.method_10562("BlockEntityTag");
            if (!blockEntityTag.method_10573("Items", 9)) {
               return list;
            } else {
               class_2499 nbtList = blockEntityTag.method_10554("Items", 10);

               for(int i = 0; i < nbtList.size(); ++i) {
                  class_2487 nbt = nbtList.method_10602(i);
                  int slot = nbt.method_10571("Slot") & 255;
                  if (slot < list.size()) {
                     list.set(slot, class_1799.method_57359(registries, nbt));
                  }
               }

               return list;
            }
         }
      } else {
         return list;
      }
   }

   private void drawPreview(class_332 context, class_2371<class_1799> items, int x, int y) {
      class_918 itemRenderer = this.mc.method_1480();
      RenderSystem.enableBlend();

      for(int i = 0; i < items.size(); ++i) {
         class_1799 s = (class_1799)items.get(i);
         if (!s.method_7960()) {
            int row = i / 9;
            int col = i % 9;
            int px = x + col * 18;
            int py = y + row * 18;
            context.method_51427(s, px, py);
         }
      }

      RenderSystem.disableBlend();
   }
}
