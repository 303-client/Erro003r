package ru.levin.modules.render;

import java.awt.Color;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "BlockESP",
   desc = "Pokazuje skrzynie, piece, spawnery i inne obiekty",
   type = Type.Render
)
public class BlockESP extends Function {
   private final SliderSetting radius = new SliderSetting("Zasięg", (double)20.0F, (double)1.0F, (double)30.0F, (double)1.0F);
   private final BooleanSetting chest = new BooleanSetting("Skrzynie", true);
   private final BooleanSetting furnace = new BooleanSetting("Piece", true);
   private final BooleanSetting spawner = new BooleanSetting("Spawnery", true);
   private final BooleanSetting brewingStand = new BooleanSetting("Stojaki alchemiczne", true);
   private final BooleanSetting enderChest = new BooleanSetting("Skrzynie Endu", true);
   private final BooleanSetting detectorRail = new BooleanSetting("Detektor torów", true);
   private final Map<String, Color> customBlocks = new HashMap();

   public BlockESP() {
      this.addSettings(new Setting[]{this.radius, this.chest, this.furnace, this.spawner, this.brewingStand, this.enderChest, this.detectorRail});
   }

   public void addCustomBlock(String blockId, Color color) {
      class_2248 block = (class_2248)class_7923.field_41175.method_63535(class_2960.method_60654(blockId));
      if (block != class_2246.field_10124) {
         this.customBlocks.put(blockId, color);
      }

   }

   public void removeCustomBlock(String blockId) {
      this.customBlocks.remove(blockId);
   }

   public Map<String, Color> getCustomBlocks() {
      return this.customBlocks;
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender3D) {
         int r = this.radius.get().intValue();
         class_2338 playerPos = mc.field_1724.method_24515();

         for(int x = playerPos.method_10263() - r; x <= playerPos.method_10263() + r; ++x) {
            for(int y = playerPos.method_10264() - r; y <= playerPos.method_10264() + r; ++y) {
               for(int z = playerPos.method_10260() - r; z <= playerPos.method_10260() + r; ++z) {
                  class_2338 pos = new class_2338(x, y, z);
                  class_2680 state = mc.field_1687.method_8320(pos);
                  class_238 box = (new class_238(pos)).method_1011(0.01);
                  if (!this.chest.get() || state.method_26204() != class_2246.field_10034 && state.method_26204() != class_2246.field_10380) {
                     if (!this.furnace.get() || state.method_26204() != class_2246.field_10181 && state.method_26204() != class_2246.field_16333 && state.method_26204() != class_2246.field_16334) {
                        if (this.spawner.get() && state.method_26204() == class_2246.field_10260) {
                           RenderUtil.render3D.drawHoleOutline(box, (new Color(255, 0, 255, 150)).getRGB(), 2.0F);
                        } else if (this.brewingStand.get() && state.method_26204() == class_2246.field_10333) {
                           RenderUtil.render3D.drawHoleOutline(box, (new Color(0, 191, 255, 150)).getRGB(), 2.0F);
                        } else if (this.enderChest.get() && state.method_26204() == class_2246.field_10443) {
                           RenderUtil.render3D.drawHoleOutline(box, (new Color(75, 0, 130, 150)).getRGB(), 2.0F);
                        } else if (this.detectorRail.get() && state.method_26204() == class_2246.field_10025) {
                           RenderUtil.render3D.drawHoleOutline(box, (new Color(255, 165, 0, 150)).getRGB(), 2.0F);
                        } else {
                           String id = class_7923.field_41175.method_10221(state.method_26204()).toString();
                           Color c = (Color)this.customBlocks.get(id);
                           if (c != null) {
                              RenderUtil.render3D.drawHoleOutline(box, c.getRGB(), 2.0F);
                           }
                        }
                     } else {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(128, 128, 128, 150)).getRGB(), 2.0F);
                     }
                  } else {
                     RenderUtil.render3D.drawHoleOutline(box, (new Color(139, 69, 19, 150)).getRGB(), 2.0F);
                  }
               }
            }
         }

      }
   }
}
