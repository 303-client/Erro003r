package ru.levin.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1421;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_4587;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector4f;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "WiciaTracers",
   desc = "Strzałki do graczy poza ekranem (wersja Wicia)",
   type = Type.Render
)
public class WiciaTracers extends Function {
   public final BooleanSetting showPlayers = new BooleanSetting("Gracze", true);
   public final BooleanSetting showMobs = new BooleanSetting("Mobki", true);
   public final BooleanSetting showAnimals = new BooleanSetting("Zwierzęta", true);
   public final BooleanSetting showArmorStands = new BooleanSetting("Armor Standy", true);
   public final BooleanSetting showBoats = new BooleanSetting("Łodzie", true);
   public final BooleanSetting showInvisible = new BooleanSetting("Niewidzialne", true);
   public final BooleanSetting distanceBasedColor = new BooleanSetting("Kolor wg dystansu", true);
   public final SliderSetting maxDistance = new SliderSetting("Max dystans", (double)256.0F, (double)50.0F, (double)500.0F, (double)10.0F);
   public final SliderSetting arrowSize = new SliderSetting("Rozmiar strzałki", (double)5.0F, (double)2.0F, (double)20.0F, (double)1.0F);
   public final BooleanSetting pulsing = new BooleanSetting("Pulsowanie", false);
   public final SliderSetting pulsingSpeed = new SliderSetting("Szybkość pulsowania", (double)1.0F, (double)0.1F, (double)5.0F, (double)0.1F);

   public void onEvent(Event event) {
      if (event instanceof EventRender2D renderEvent) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (!this.state) {
            return;
         }

         this.renderTracers(renderEvent.getMatrixStack(), mc.method_61966().method_60637(true));
      }

   }

   private void renderTracers(class_4587 matrices, float tickDelta) {
      List<EntityTarget> targets = this.getTargets(tickDelta);
      if (!targets.isEmpty()) {
         int windowWidth = mc.method_22683().method_4486();
         int windowHeight = mc.method_22683().method_4502();
         float scale = (float)mc.method_22683().method_4495();
         Vector2f screenCenter = new Vector2f((float)windowWidth / 2.0F, (float)windowHeight / 2.0F);
         RenderSystem.enableBlend();
         RenderSystem.defaultBlendFunc();

         for(EntityTarget target : targets) {
            class_243 screenPos = this.projectToScreen(target.getPosition(), tickDelta);
            if (screenPos == null) {
               screenPos = this.projectOffScreen(target.getPosition(), tickDelta);
               if (screenPos != null) {
                  float distance = (float)screenPos.field_1350 / scale;
                  float angle = (float)Math.toDegrees(Math.atan2(screenPos.field_1351, screenPos.field_1352)) - 90.0F;
                  float radians = (float)Math.toRadians((double)angle);
                  int size = this.arrowSize.get().intValue();
                  Vector2f arrowPos = new Vector2f(screenCenter.x + (float)size * (float)Math.cos((double)radians), screenCenter.y + (float)size * (float)Math.sin((double)radians));
                  Vector2f[] triangle = new Vector2f[]{new Vector2f(arrowPos.x - (float)size, arrowPos.y - (float)size), new Vector2f(arrowPos.x + (float)size * 0.73205F, arrowPos.y), new Vector2f(arrowPos.x - (float)size, arrowPos.y + (float)size)};
                  this.rotateTriangle(triangle, angle);
                  int color = target.getColor();
                  float red = (float)(color >> 16 & 255) / 255.0F;
                  float green = (float)(color >> 8 & 255) / 255.0F;
                  float blue = (float)(color & 255) / 255.0F;
                  int alpha = color >> 24 & 255;
                  float alphaValue = alpha == 0 ? 0.5F : (float)alpha / 255.0F;
                  if (this.pulsing.get()) {
                     alphaValue *= this.getPulsingAlpha();
                  }

                  this.renderTriangle(matrices, triangle[2], triangle[1], triangle[0], red, green, blue, alphaValue);
               }
            }
         }

         RenderSystem.disableBlend();
      }
   }

   private void rotateTriangle(Vector2f[] triangle, float angle) {
      Vector2f center = new Vector2f(0.0F, 0.0F);
      center.add(triangle[0]).add(triangle[1]).add(triangle[2]).div(3.0F);
      float radians = (float)Math.toRadians((double)angle);
      float cos = (float)Math.cos((double)radians);
      float sin = (float)Math.sin((double)radians);

      for(int i = 0; i < 3; ++i) {
         Vector2f point = (new Vector2f(triangle[i])).sub(center);
         Vector2f rotated = new Vector2f(point.x * cos - point.y * sin, point.x * sin + point.y * cos);
         rotated.add(center);
         triangle[i] = rotated;
      }

   }

   private class_243 projectToScreen(class_243 worldPos, float tickDelta) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 cameraPos = mc.field_1773.method_19418().method_19326();
         Matrix4f projectionMatrix = new Matrix4f(RenderSystem.getProjectionMatrix());
         Matrix4f modelViewMatrix = new Matrix4f();
         Vector4f worldPos4f = new Vector4f((float)(worldPos.field_1352 - cameraPos.field_1352), (float)(worldPos.field_1351 - cameraPos.field_1351), (float)(worldPos.field_1350 - cameraPos.field_1350), 1.0F);
         modelViewMatrix.transform(worldPos4f);
         projectionMatrix.transform(worldPos4f);
         if (worldPos4f.w <= 0.0F) {
            return null;
         } else {
            float screenX = worldPos4f.x / worldPos4f.w;
            float screenY = worldPos4f.y / worldPos4f.w;
            int windowWidth = mc.method_22683().method_4486();
            int windowHeight = mc.method_22683().method_4502();
            return new class_243((double)((screenX + 1.0F) / 2.0F * (float)windowWidth), (double)((1.0F - (screenY + 1.0F) / 2.0F) * (float)windowHeight), (double)worldPos4f.w);
         }
      } else {
         return null;
      }
   }

   private class_243 projectOffScreen(class_243 worldPos, float tickDelta) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 cameraPos = mc.field_1773.method_19418().method_19326();
         Matrix4f projectionMatrix = new Matrix4f(RenderSystem.getProjectionMatrix());
         Matrix4f modelViewMatrix = new Matrix4f();
         Vector4f worldPos4f = new Vector4f((float)(worldPos.field_1352 - cameraPos.field_1352), (float)(worldPos.field_1351 - cameraPos.field_1351), (float)(worldPos.field_1350 - cameraPos.field_1350), 1.0F);
         modelViewMatrix.transform(worldPos4f);
         projectionMatrix.transform(worldPos4f);
         if (worldPos4f.w <= 0.0F) {
            worldPos4f.x = -worldPos4f.x;
            worldPos4f.y = -worldPos4f.y;
         }

         float w = Math.abs(worldPos4f.w) < 1.0E-6F ? 1.0E-6F : worldPos4f.w;
         float screenX = worldPos4f.x / w;
         float screenY = worldPos4f.y / w;
         int windowWidth = mc.method_22683().method_4486();
         int windowHeight = mc.method_22683().method_4502();
         return new class_243((double)((screenX + 1.0F) / 2.0F * (float)windowWidth), (double)((1.0F - (screenY + 1.0F) / 2.0F) * (float)windowHeight), (double)worldPos4f.w);
      } else {
         return null;
      }
   }

   private float getPulsingAlpha() {
      long time = System.currentTimeMillis();
      double speed = this.pulsingSpeed.get().doubleValue() / (double)4.0F;
      double offset = Math.abs((double)time * speed % (double)1000.0F - (double)500.0F) / (double)500.0F;
      return (float)offset;
   }

   private void renderTriangle(class_4587 matrices, Vector2f p1, Vector2f p2, Vector2f p3, float red, float green, float blue, float alpha) {
      class_289 tessellator = class_289.method_1348();
      class_287 bufferBuilder = tessellator.method_60827(class_5596.field_27379, class_290.field_1576);
      Matrix4f matrix = matrices.method_23760().method_23761();
      bufferBuilder.method_22918(matrix, p1.x, p1.y, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, p2.x, p2.y, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, p3.x, p3.y, 0.0F).method_22915(red, green, blue, alpha);
      class_286.method_43433(bufferBuilder.method_60800());
   }

   private List<EntityTarget> getTargets(float tickDelta) {
      List<EntityTarget> targets = new ArrayList();
      if (mc.field_1724 != null && mc.field_1687 != null) {
         for(class_1297 entity : mc.field_1687.method_18112()) {
            if (this.shouldRenderEntity(entity)) {
               class_243 position = entity.method_30950(tickDelta);
               double distance = mc.field_1724.method_5858(entity);
               double maxDist = this.maxDistance.get().doubleValue();
               if (!(distance > maxDist * maxDist)) {
                  int color = this.getEntityColor(entity, distance);
                  targets.add(new EntityTarget(entity, position, color));
               }
            }
         }

         return targets;
      } else {
         return targets;
      }
   }

   private boolean shouldRenderEntity(class_1297 entity) {
      if (entity == mc.field_1724) {
         return false;
      } else if (!entity.method_5805()) {
         return false;
      } else if (entity instanceof class_1657) {
         return this.showPlayers.get();
      } else if (entity instanceof class_1308) {
         return entity instanceof class_1421 ? this.showAnimals.get() : this.showMobs.get();
      } else if (entity instanceof class_1296) {
         return this.showAnimals.get();
      } else if (entity instanceof class_1531) {
         return this.showArmorStands.get();
      } else {
         return entity instanceof class_1690 ? this.showBoats.get() : false;
      }
   }

   private int getEntityColor(class_1297 entity, double distance) {
      if (this.distanceBasedColor.get()) {
         double maxDist = this.maxDistance.get().doubleValue();
         float ratio = (float)((double)1.0F - Math.min(distance, maxDist) / maxDist);
         int green = 65280;
         int yellow = 16776960;
         int red = 16711680;
         int color;
         if (ratio <= 0.333F) {
            color = this.interpolateColor(green, yellow, ratio / 0.333F);
         } else if (ratio <= 0.666F) {
            color = this.interpolateColor(yellow, red, (ratio - 0.333F) / 0.333F);
         } else {
            color = this.interpolateColor(red, 16711935, (ratio - 0.666F) / 0.334F);
         }

         return -16777216 | color;
      } else if (entity instanceof class_1657) {
         String name = entity.method_5477().getString();
         return Manager.FRIEND_MANAGER.isFriend(name) ? -16711936 : -65536;
      } else if (entity instanceof class_1308) {
         return -65281;
      } else {
         return entity instanceof class_1296 ? -256 : -1;
      }
   }

   private int interpolateColor(int color1, int color2, float ratio) {
      ratio = Math.max(0.0F, Math.min(1.0F, ratio));
      int r1 = color1 >> 16 & 255;
      int g1 = color1 >> 8 & 255;
      int b1 = color1 & 255;
      int r2 = color2 >> 16 & 255;
      int g2 = color2 >> 8 & 255;
      int b2 = color2 & 255;
      int r = Math.round((float)r1 + (float)(r2 - r1) * ratio);
      int g = Math.round((float)g1 + (float)(g2 - g1) * ratio);
      int b = Math.round((float)b1 + (float)(b2 - b1) * ratio);
      return r << 16 | g << 8 | b;
   }

   private static class EntityTarget {
      private final class_1297 entity;
      private final class_243 position;
      private final int color;

      public EntityTarget(class_1297 entity, class_243 position, int color) {
         this.entity = entity;
         this.position = position;
         this.color = color;
      }

      public class_1297 getEntity() {
         return this.entity;
      }

      public class_243 getPosition() {
         return this.position;
      }

      public int getColor() {
         return this.color;
      }
   }
}
