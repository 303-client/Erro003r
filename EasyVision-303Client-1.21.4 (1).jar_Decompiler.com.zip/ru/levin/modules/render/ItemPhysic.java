package ru.levin.modules.render;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "ItemPhysic",
   desc = "Efektowny wygląd przedmiotów na ziemi",
   type = Type.Render
)
public class ItemPhysic extends Function {
   public final ModeSetting mode = new ModeSetting("Fizyka", "Zwykła", new String[]{"Zwykła", "2D"});

   public ItemPhysic() {
      this.addSettings(new Setting[]{this.mode});
   }

   public void onEvent(Event event) {
   }
}
