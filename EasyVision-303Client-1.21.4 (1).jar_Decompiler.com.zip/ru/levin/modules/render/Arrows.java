package ru.levin.modules.render;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.class_1041;
import net.minecraft.class_1657;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_746;
import net.minecraft.class_7833;
import org.joml.Vector2f;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "Arrows",
   desc = "Strzałki wskazujące graczy na ekranie",
   type = Type.Render
)
public class Arrows extends Function {
   private final SliderSetting radius = new SliderSetting("Zasięg", (double)70.0F, (double)50.0F, (double)160.0F, (double)1.0F);
   private final BooleanSetting dynamic = new BooleanSetting("Dynamiczne", true);
   private float animatedRadius;
   private final Map<UUID, Float> smoothedAngles;

   public Arrows() {
      this.animatedRadius = this.radius.get().floatValue();
      this.smoothedAngles = new HashMap();
      this.addSettings(new Setting[]{this.radius, this.dynamic});
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender2D render2D) {
         class_746 player = mc.field_1724;
         if (player != null) {
            float targetRadius = this.radius.get().floatValue();
            if (this.dynamic.get() && player.method_5624()) {
               targetRadius += 20.0F;
            }

            this.animatedRadius += (targetRadius - this.animatedRadius) * 0.1F;

            for(class_1657 other : Manager.SYNC_MANAGER.getPlayers()) {
               if (!other.equals(player) && !Manager.FUNCTION_MANAGER.antiBot.check(other)) {
                  this.drawArrow(render2D.getMatrixStack(), other, other.method_23317(), other.method_23321(), ColorUtil.getColorStyle(360.0F));
               }
            }

         }
      }
   }

   private void drawArrow(class_4587 stack, class_1657 target, double x, double z, int baseColor) {
      class_746 player = mc.field_1724;
      class_1041 window = mc.method_22683();
      int width = window.method_4486();
      int height = window.method_4502();
      float centerX = (float)width / 2.0F;
      float centerY = (float)height / 2.0F;
      float desiredAngle = class_3532.method_15393(this.getRotationTo(new Vector2f((float)x, (float)z)) - player.method_36454());
      float angle = this.smoothAngle(target.method_5667(), desiredAngle);
      stack.method_22903();
      stack.method_46416(centerX, centerY, 0.0F);
      stack.method_22907(class_7833.field_40718.rotationDegrees(angle));
      stack.method_46416(-centerX, -centerY, 0.0F);
      int color = Manager.FRIEND_MANAGER.isFriend(target.method_5477().getString()) ? ColorUtil.rgba(20, 255, 20, 255) : (Manager.FUNCTION_MANAGER.attackAura.target == target ? ColorUtil.rgba(255, 50, 50, 255) : baseColor);
      RenderUtil.drawTexture(stack, "images/triangle.png", centerX - 7.0F, centerY - this.animatedRadius, 20.0F, 20.0F, 1.0F, color);
      stack.method_22909();
   }

   private float smoothAngle(UUID id, float targetAngle) {
      float prev = (Float)this.smoothedAngles.getOrDefault(id, targetAngle);
      float delta = class_3532.method_15393(targetAngle - prev);
      float factor = 0.08F;
      float result = prev + delta * factor;
      this.smoothedAngles.put(id, result);
      return result;
   }

   private float getRotationTo(Vector2f vec) {
      class_746 player = mc.field_1724;
      if (player == null) {
         return 0.0F;
      } else {
         double dx = (double)vec.x - player.method_23317();
         double dz = (double)vec.y - player.method_23321();
         return (float)(-(Math.atan2(dx, dz) * (180D / Math.PI)));
      }
   }
}
