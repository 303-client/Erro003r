package ru.levin.modules.render;

import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1421;
import net.minecraft.class_1531;
import net.minecraft.class_1533;
import net.minecraft.class_1541;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1688;
import net.minecraft.class_1690;
import net.minecraft.class_1694;
import net.minecraft.class_1696;
import net.minecraft.class_1699;
import net.minecraft.class_1700;
import net.minecraft.class_1701;
import net.minecraft.class_2586;
import net.minecraft.class_2593;
import net.minecraft.class_2595;
import net.minecraft.class_2601;
import net.minecraft.class_2608;
import net.minecraft.class_2614;
import net.minecraft.class_3866;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;

@FunctionAnnotation(
   name = "WiciaEntityVisibility",
   desc = "Całkowite ukrywanie entities - znikają ze świata, nie mają kolizji, nie blokują perły",
   type = Type.Render
)
public class WiciaEntityVisibility extends Function {
   public final BooleanSetting hideItems = new BooleanSetting("Ukryj itemy", true);
   public final BooleanSetting hideArmorStands = new BooleanSetting("Ukryj armor standy", true);
   public final BooleanSetting hideMobs = new BooleanSetting("Ukryj mobki", true);
   public final BooleanSetting hideAnimals = new BooleanSetting("Ukryj zwierzęta", true);
   public final BooleanSetting hideBoats = new BooleanSetting("Ukryj łódki", true);
   public final BooleanSetting hideMinecarts = new BooleanSetting("Ukryj wagoniki", true);
   public final BooleanSetting hideChestMinecarts = new BooleanSetting("Ukryj wagoniki ze skrzynią", true);
   public final BooleanSetting hideFurnaceMinecarts = new BooleanSetting("Ukryj wagoniki z piecem", true);
   public final BooleanSetting hideHopperMinecarts = new BooleanSetting("Ukryj wagoniki z hopperem", true);
   public final BooleanSetting hideTntMinecarts = new BooleanSetting("Ukryj wagoniki z TNT", true);
   public final BooleanSetting hideSpawnerMinecarts = new BooleanSetting("Ukryj wagoniki ze spawnerem", true);
   public final BooleanSetting hidePlayers = new BooleanSetting("Ukryj graczy", false);
   public final BooleanSetting hideChests = new BooleanSetting("Ukryj skrzynie", true);
   public final BooleanSetting hideFurnaces = new BooleanSetting("Ukryj piecec", true);
   public final BooleanSetting hideHoppers = new BooleanSetting("Ukryj ludka akacjowa", true);
   public final BooleanSetting hideDispensers = new BooleanSetting("Ukryj dispensery", true);
   public final BooleanSetting hideDroppers = new BooleanSetting("Ukryj droppery", true);
   public final BooleanSetting hideCommandBlocks = new BooleanSetting("Ukryj command block", true);
   public final BooleanSetting hideTNT = new BooleanSetting("Ukryj TNT", true);
   public final BooleanSetting hideItemFrames = new BooleanSetting("Ukryj item frame", true);

   public void onEvent(Event event) {
   }

   public boolean shouldHideEntity(class_1297 entity) {
      if (this.state && entity != null) {
         if (entity == mc.field_1724) {
            return false;
         } else if (this.hideItems.get() && entity instanceof class_1542) {
            return true;
         } else if (this.hideArmorStands.get() && entity instanceof class_1531) {
            return true;
         } else if (this.hideMobs.get() && entity instanceof class_1308) {
            return entity instanceof class_1421 ? this.hideAnimals.get() : true;
         } else if (this.hideAnimals.get() && entity instanceof class_1296) {
            return true;
         } else if (this.hideBoats.get() && entity instanceof class_1690) {
            return true;
         } else if (this.hideChestMinecarts.get() && entity instanceof class_1694) {
            return true;
         } else if (this.hideFurnaceMinecarts.get() && entity instanceof class_1696) {
            return true;
         } else if (this.hideHopperMinecarts.get() && entity instanceof class_1700) {
            return true;
         } else if (this.hideTntMinecarts.get() && entity instanceof class_1701) {
            return true;
         } else if (this.hideSpawnerMinecarts.get() && entity instanceof class_1699) {
            return true;
         } else if (this.hideMinecarts.get() && entity instanceof class_1688) {
            return true;
         } else if (this.hidePlayers.get() && entity instanceof class_1657) {
            return true;
         } else if (this.hideTNT.get() && entity instanceof class_1541) {
            return true;
         } else {
            return this.hideItemFrames.get() && entity instanceof class_1533;
         }
      } else {
         return false;
      }
   }

   public boolean shouldHideBlockEntity(class_2586 blockEntity) {
      if (this.state && blockEntity != null) {
         if (this.hideChests.get() && blockEntity instanceof class_2595) {
            return true;
         } else if (this.hideFurnaces.get() && blockEntity instanceof class_3866) {
            return true;
         } else if (this.hideHoppers.get() && blockEntity instanceof class_2614) {
            return true;
         } else if (this.hideDispensers.get() && blockEntity instanceof class_2601) {
            return true;
         } else if (this.hideDroppers.get() && blockEntity instanceof class_2608) {
            return true;
         } else {
            return this.hideCommandBlocks.get() && blockEntity instanceof class_2593;
         }
      } else {
         return false;
      }
   }

   public boolean shouldRemoveCollision(class_1297 entity) {
      return this.shouldHideEntity(entity);
   }

   public boolean shouldBlockProjectile(class_1297 entity) {
      return !this.shouldHideEntity(entity);
   }
}
