package ru.levin.modules.render;

import net.minecraft.class_1268;
import net.minecraft.class_1306;
import net.minecraft.class_1309;
import net.minecraft.class_1764;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_742;
import net.minecraft.class_7833;
import net.minecraft.class_811;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventHeldItemRenderer;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "SwingAnimations",
   desc = "Efektowne animacje przedmiotu w ręce",
   type = Type.Render
)
public class SwingAnimations extends Function {
   private final ModeSetting mode = new ModeSetting("Typ", "Smooth", new String[]{"Smooth", "Block", "ToBack", "SelfBack", "360", "Down", "Glide", "DropDown", "DeadCode"});
   public final BooleanSetting slowAnimation = new BooleanSetting("Płynność", false);
   public final SliderSetting slowAnimationSpeed = new SliderSetting("Siła wygładzania", (double)12.0F, (double)1.0F, (double)50.0F, (double)1.0F, () -> this.slowAnimation.get());
   private final SliderSetting corner = new SliderSetting("Kąt", (double)12.0F, (double)1.0F, (double)360.0F, (double)1.0F);
   private final SliderSetting slant = new SliderSetting("Pochylenie", (double)12.0F, (double)1.0F, (double)360.0F, (double)1.0F);

   public SwingAnimations() {
      this.addSettings(new Setting[]{this.mode, this.slowAnimation, this.slowAnimationSpeed, this.corner, this.slant});
   }

   private void renderSwordAnimation(class_4587 matrices, float swingProgress, float equipProgress, class_1306 arm) {
      int i = arm == class_1306.field_6183 ? 1 : -1;
      switch (this.mode.get()) {
         case "Smooth":
            matrices.method_46416(0.56F * (float)i, -0.52F, -0.72F);
            this.applySwingOffset(matrices, arm, swingProgress);
            break;
         case "Block":
            if (swingProgress > 0.0F) {
               float g = class_3532.method_15374(class_3532.method_15355(swingProgress) * (float)Math.PI);
               matrices.method_46416(0.56F * (float)i, equipProgress * -0.2F - 0.5F, -0.7F);
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(45 * i)));
               matrices.method_22907(class_7833.field_40714.rotationDegrees(g * -85.0F));
               matrices.method_46416(-0.1F * (float)i, 0.28F, 0.2F);
               matrices.method_22907(class_7833.field_40714.rotationDegrees(-85.0F));
            } else {
               float n = -0.4F * class_3532.method_15374(class_3532.method_15355(swingProgress) * (float)Math.PI);
               float m = 0.2F * class_3532.method_15374(class_3532.method_15355(swingProgress) * ((float)Math.PI * 2F));
               float f1 = -0.2F * class_3532.method_15374(swingProgress * (float)Math.PI);
               matrices.method_46416(n * (float)i, m, f1);
               this.applyEquipOffset(matrices, arm, equipProgress);
               this.applySwingOffset(matrices, arm, swingProgress);
            }
            break;
         case "ToBack":
            float g = class_3532.method_15374(class_3532.method_15355(swingProgress) * (float)Math.PI);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(50.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees((-30.0F * (1.0F - g) - 30.0F) * (float)i));
            matrices.method_22907(class_7833.field_40718.rotationDegrees(110.0F * (float)i));
            break;
         case "SelfBack":
            float anim = (float)Math.sin((double)swingProgress * (Math.PI / 2D) * (double)2.0F);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(90 * i)));
            matrices.method_22907(class_7833.field_40718.rotationDegrees((float)(-70 * i)));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-100.0F - 60.0F * anim));
            break;
         case "360":
            matrices.method_46416(0.56F * (float)i, -0.52F, -0.72F);
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-swingProgress * 360.0F));
            break;
         case "Down":
            float yPosition;
            if (swingProgress < 0.8F) {
               yPosition = -0.52F - swingProgress * 1.25F;
            } else {
               float returnProgress = (swingProgress - 0.8F) * 5.0F;
               yPosition = -0.52F - (1.0F - returnProgress);
            }

            matrices.method_46416(0.56F * (float)i, yPosition, -0.72F);
            break;
         case "Glide":
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees((float)(80 * i)));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
            matrices.method_22904((double)0.0F, (double)0.0F, -0.8 * (double)swingProgress);
            break;
         case "DropDown":
            float anim = (float)Math.sin((double)swingProgress * (Math.PI / 2D) * (double)2.0F);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(80.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(this.corner.get().floatValue()));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-this.slant.get().floatValue() * anim));
            break;
         case "DeadCode":
            float anim = (float)Math.sin((double)swingProgress * (Math.PI / 2D) * (double)2.0F);
            this.applyEquipOffset(matrices, arm, 0.0F);
            matrices.method_22907(class_7833.field_40716.rotationDegrees(45.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(anim * -40.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(30.0F));
            matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
            matrices.method_22907(class_7833.field_40716.rotationDegrees(60.0F));
      }

   }

   public void renderFirstPersonItem(class_742 player, float tickDelta, float pitch, class_1268 hand, float swingProgress, class_1799 item, float equipProgress, class_4587 matrices, class_4597 vertexConsumers, int light) {
      if (!player.method_31550()) {
         boolean bl = hand == class_1268.field_5808;
         class_1306 arm = bl ? player.method_6068() : player.method_6068().method_5928();
         matrices.method_22903();
         if (item.method_31574(class_1802.field_8399)) {
            boolean bl2 = class_1764.method_7781(item);
            boolean bl3 = arm == class_1306.field_6183;
            int i = bl3 ? 1 : -1;
            if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
               this.applyEquipOffset(matrices, arm, equipProgress);
               matrices.method_46416((float)i * -0.4785682F, -0.094387F, 0.05731531F);
               matrices.method_22907(class_7833.field_40714.rotationDegrees(-11.935F));
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * 65.3F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * -9.785F));
               float f = (float)item.method_7935(mc.field_1724) - ((float)mc.field_1724.method_6014() - tickDelta + 1.0F);
               float g = f / (float)class_1764.method_7775(item, mc.field_1724);
               if (g > 1.0F) {
                  g = 1.0F;
               }

               if (g > 0.1F) {
                  float h = class_3532.method_15374((f - 0.1F) * 1.3F);
                  float j = g - 0.1F;
                  float k = h * j;
                  matrices.method_46416(k * 0.0F, k * 0.004F, k * 0.0F);
               }

               matrices.method_46416(g * 0.0F, g * 0.0F, g * 0.04F);
               matrices.method_22905(1.0F, 1.0F, 1.0F + g * 0.2F);
               matrices.method_22907(class_7833.field_40715.rotationDegrees((float)i * 45.0F));
            } else {
               float fx = -0.4F * class_3532.method_15374(class_3532.method_15355(swingProgress) * (float)Math.PI);
               float gx = 0.2F * class_3532.method_15374(class_3532.method_15355(swingProgress) * ((float)Math.PI * 2F));
               float h = -0.2F * class_3532.method_15374(swingProgress * (float)Math.PI);
               matrices.method_46416((float)i * fx, gx, h);
               this.applyEquipOffset(matrices, arm, equipProgress);
               this.applySwingOffset(matrices, arm, swingProgress);
               if (bl2 && swingProgress < 0.001F && bl) {
                  matrices.method_46416((float)i * -0.641864F, 0.0F, 0.0F);
                  matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * 10.0F));
               }
            }

            EventHeldItemRenderer event = new EventHeldItemRenderer(hand, item, equipProgress, matrices);
            Event.call(event);
            this.renderItem(player, item, bl3 ? class_811.field_4322 : class_811.field_4321, !bl3, matrices, vertexConsumers, light);
         } else {
            boolean bl2 = arm == class_1306.field_6183;
            ViewModel viewModel = Manager.FUNCTION_MANAGER.viewModel;
            if (viewModel.state) {
               if (bl2) {
                  matrices.method_46416(viewModel.right_x.get().floatValue(), viewModel.right_y.get().floatValue(), viewModel.right_z.get().floatValue());
               } else {
                  matrices.method_46416(-viewModel.left_x.get().floatValue(), viewModel.left_y.get().floatValue(), viewModel.left_z.get().floatValue());
               }
            }

            if (player.method_6115() && player.method_6014() > 0 && player.method_6058() == hand) {
               int l = bl2 ? 1 : -1;
               switch (item.method_7976()) {
                  case field_8952:
                  case field_8949:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     break;
                  case field_8950:
                  case field_8946:
                     this.applyEatOrDrinkTransformation(matrices, tickDelta, arm, item);
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     break;
                  case field_8953:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     matrices.method_46416((float)l * -0.2785682F, 0.18344387F, 0.15731531F);
                     matrices.method_22907(class_7833.field_40714.rotationDegrees(-13.935F));
                     matrices.method_22907(class_7833.field_40716.rotationDegrees((float)l * 35.3F));
                     matrices.method_22907(class_7833.field_40718.rotationDegrees((float)l * -9.785F));
                     float mx = (float)item.method_7935(mc.field_1724) - ((float)mc.field_1724.method_6014() - tickDelta + 1.0F);
                     float fxx = mx / 20.0F;
                     fxx = (fxx * fxx + fxx * 2.0F) / 3.0F;
                     if (fxx > 1.0F) {
                        fxx = 1.0F;
                     }

                     if (fxx > 0.1F) {
                        float gx = class_3532.method_15374((mx - 0.1F) * 1.3F);
                        float h = fxx - 0.1F;
                        float j = gx * h;
                        matrices.method_46416(j * 0.0F, j * 0.004F, j * 0.0F);
                     }

                     matrices.method_46416(fxx * 0.0F, fxx * 0.0F, fxx * 0.04F);
                     matrices.method_22905(1.0F, 1.0F, 1.0F + fxx * 0.2F);
                     matrices.method_22907(class_7833.field_40715.rotationDegrees((float)l * 45.0F));
                     break;
                  case field_8951:
                     this.applyEquipOffset(matrices, arm, equipProgress);
                     matrices.method_46416((float)l * -0.5F, 0.7F, 0.1F);
                     matrices.method_22907(class_7833.field_40714.rotationDegrees(-55.0F));
                     matrices.method_22907(class_7833.field_40716.rotationDegrees((float)l * 35.3F));
                     matrices.method_22907(class_7833.field_40718.rotationDegrees((float)l * -9.785F));
                     float m = (float)item.method_7935(mc.field_1724) - ((float)mc.field_1724.method_6014() - tickDelta + 1.0F);
                     float fx = m / 10.0F;
                     if (fx > 1.0F) {
                        fx = 1.0F;
                     }

                     if (fx > 0.1F) {
                        float gx = class_3532.method_15374((m - 0.1F) * 1.3F);
                        float h = fx - 0.1F;
                        float j = gx * h;
                        matrices.method_46416(j * 0.0F, j * 0.004F, j * 0.0F);
                     }

                     matrices.method_46416(0.0F, 0.0F, fx * 0.2F);
                     matrices.method_22905(1.0F, 1.0F, 1.0F + fx * 0.2F);
                     matrices.method_22907(class_7833.field_40715.rotationDegrees((float)l * 45.0F));
                     break;
                  case field_42717:
                     this.applyBrushTransformation(matrices, tickDelta, arm, item, equipProgress);
               }
            } else if (player.method_6123()) {
               this.applyEquipOffset(matrices, arm, equipProgress);
               int l = bl2 ? 1 : -1;
               matrices.method_46416((float)l * -0.4F, 0.8F, 0.3F);
               matrices.method_22907(class_7833.field_40716.rotationDegrees((float)l * 65.0F));
               matrices.method_22907(class_7833.field_40718.rotationDegrees((float)l * -85.0F));
            } else if (arm == mc.field_1724.method_6068() && this.state) {
               this.renderSwordAnimation(matrices, swingProgress, equipProgress, arm);
            } else {
               float n = -0.4F * class_3532.method_15374(class_3532.method_15355(swingProgress) * (float)Math.PI);
               float mxx = 0.2F * class_3532.method_15374(class_3532.method_15355(swingProgress) * ((float)Math.PI * 2F));
               float fxxx = -0.2F * class_3532.method_15374(swingProgress * (float)Math.PI);
               int o = bl2 ? 1 : -1;
               matrices.method_46416((float)o * n, mxx, fxxx);
               this.applyEquipOffset(matrices, arm, equipProgress);
               this.applySwingOffset(matrices, arm, swingProgress);
            }

            EventHeldItemRenderer event = new EventHeldItemRenderer(hand, item, equipProgress, matrices);
            Event.call(event);
            this.renderItem(player, item, bl2 ? class_811.field_4322 : class_811.field_4321, !bl2, matrices, vertexConsumers, light);
         }

         matrices.method_22909();
      }

   }

   private void applyBrushTransformation(class_4587 matrices, float tickDelta, class_1306 arm, class_1799 stack, float equipProgress) {
      this.applyEquipOffset(matrices, arm, equipProgress);
      float f = (float)(mc.field_1724.method_6014() % 10);
      float g = f - tickDelta + 1.0F;
      float h = 1.0F - g / 10.0F;
      float n = -15.0F + 75.0F * class_3532.method_15362(h * 2.0F * (float)Math.PI);
      if (arm != class_1306.field_6183) {
         matrices.method_22904(0.1, 0.83, 0.35);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-90.0F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(n));
         matrices.method_22904(-0.3, 0.22, 0.35);
      } else {
         matrices.method_22904((double)-0.25F, 0.22, 0.35);
         matrices.method_22907(class_7833.field_40714.rotationDegrees(-80.0F));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(90.0F));
         matrices.method_22907(class_7833.field_40718.rotationDegrees(0.0F));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(n));
      }

   }

   private void applyEatOrDrinkTransformation(class_4587 matrices, float tickDelta, class_1306 arm, class_1799 stack) {
      float f = (float)mc.field_1724.method_6014() - tickDelta + 1.0F;
      float g = f / (float)stack.method_7935(mc.field_1724);
      if (g < 0.8F) {
         float h = class_3532.method_15379(class_3532.method_15362(f / 4.0F * (float)Math.PI) * 0.1F);
         matrices.method_46416(0.0F, h, 0.0F);
      }

      float h = 1.0F - (float)Math.pow((double)g, (double)27.0F);
      int i = arm == class_1306.field_6183 ? 1 : -1;
      matrices.method_46416(h * 0.6F * (float)i, h * -0.5F, h * 0.0F);
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * h * 90.0F));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(h * 10.0F));
      matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * h * 30.0F));
   }

   private void applyEquipOffset(class_4587 matrices, class_1306 arm, float equipProgress) {
      int i = arm == class_1306.field_6183 ? 1 : -1;
      matrices.method_46416((float)i * 0.56F, -0.52F + equipProgress * -0.6F, -0.72F);
   }

   private void applySwingOffset(class_4587 matrices, class_1306 arm, float swingProgress) {
      int i = arm == class_1306.field_6183 ? 1 : -1;
      float f = class_3532.method_15374(swingProgress * swingProgress * (float)Math.PI);
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * (45.0F + f * -20.0F)));
      float g = class_3532.method_15374(class_3532.method_15355(swingProgress) * (float)Math.PI);
      matrices.method_22907(class_7833.field_40718.rotationDegrees((float)i * g * -20.0F));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(g * -80.0F));
      matrices.method_22907(class_7833.field_40716.rotationDegrees((float)i * -45.0F));
   }

   public void renderItem(class_1309 entity, class_1799 stack, class_811 renderMode, boolean leftHanded, class_4587 matrices, class_4597 vertexConsumers, int light) {
      if (!stack.method_7960()) {
         mc.method_1480().method_23177(entity, stack, renderMode, leftHanded, matrices, vertexConsumers, entity.method_37908(), light, class_4608.field_21444, entity.method_5628() + renderMode.ordinal());
      }

   }

   public void onEvent(Event event) {
   }
}
