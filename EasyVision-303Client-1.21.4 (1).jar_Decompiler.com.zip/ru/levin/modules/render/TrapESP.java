package ru.levin.modules.render;

import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2382;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "TrapESP",
   desc = "Wykrywa skupiska obiektów używanych w trapach",
   type = Type.Render
)
public class TrapESP extends Function {
   private final SliderSetting range = new SliderSetting("Zasięg", (double)100.0F, (double)16.0F, (double)160.0F, (double)1.0F);
   private final SliderSetting clusterRadius = new SliderSetting("Promień grupy", (double)16.0F, (double)4.0F, (double)32.0F, (double)1.0F);
   private final SliderSetting minimumObjects = new SliderSetting("Minimum obiektów", (double)6.0F, (double)1.0F, (double)32.0F, (double)1.0F);
   private final BooleanSetting fastRender = new BooleanSetting("Szybki render", true);
   private final MultiSetting objects = new MultiSetting("Obiekty", List.of("Skrzynie", "Pistony", "Redstone", "Obsydian", "Cobweb", "TNT", "Inne"), new String[]{"Skrzynie", "Pistony", "Redstone", "Obsydian", "Cobweb", "TNT", "Inne"});
   private final TextSetting customObjects = new TextSetting("Dodaj bloki", "");
   private final TextSetting excludedObjects = new TextSetting("Usuń bloki", "");
   private final List<Cluster> clusters = new ArrayList();
   private String cachedCustomValue = "";
   private String cachedExcludedValue = "";
   private Set<class_2248> customBlocks = Set.of();
   private Set<class_2248> excludedBlocks = Set.of();
   private long nextScanAt;
   private class_2338 lastScanOrigin;
   private int lastScanRadius = -1;

   public TrapESP() {
      this.addSettings(new Setting[]{this.range, this.clusterRadius, this.minimumObjects, this.fastRender, this.objects, this.customObjects, this.excludedObjects});
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender3D && mc.field_1724 != null && mc.field_1687 != null) {
         class_2338 origin = mc.field_1724.method_24515();
         long now = System.currentTimeMillis();
         int currentRadius = this.range.get().intValue();
         if (now >= this.nextScanAt || this.lastScanOrigin == null || !this.lastScanOrigin.equals(origin) || this.lastScanRadius != currentRadius) {
            this.scan();
            this.nextScanAt = now + 350L;
            this.lastScanOrigin = origin.method_10062();
            this.lastScanRadius = currentRadius;
         }

         for(Cluster cluster : this.clusters) {
            if (this.fastRender.get()) {
               RenderUtil.render3D.drawHoleOutline(cluster.bounds, -1258336176, 2.0F);
            } else {
               for(class_2338 pos : cluster.positions) {
                  Color color = this.colorFor(mc.field_1687.method_8320(pos).method_26204());
                  RenderUtil.render3D.drawHoleOutline((new class_238(pos)).method_1011(0.01), color.getRGB(), 2.0F);
               }
            }
         }

      }
   }

   private void scan() {
      this.clusters.clear();
      this.updateCustomBlockCache();
      int radius = this.range.get().intValue();
      class_2338 origin = mc.field_1724.method_24515();
      List<class_2338> candidates = new ArrayList();

      for(int x = -radius; x <= radius; ++x) {
         for(int y = -radius; y <= radius; ++y) {
            for(int z = -radius; z <= radius; ++z) {
               class_2338 pos = origin.method_10069(x, y, z);
               if (!(origin.method_10262(pos) > (double)radius * (double)radius)) {
                  class_2680 state = mc.field_1687.method_8320(pos);
                  if (this.isTrapObject(state.method_26204())) {
                     candidates.add(pos.method_10062());
                  }
               }
            }
         }
      }

      int clusterDistance = this.clusterRadius.get().intValue();
      boolean[] used = new boolean[candidates.size()];

      for(int index = 0; index < candidates.size(); ++index) {
         if (!used[index]) {
            List<class_2338> group = new ArrayList();
            List<Integer> pending = new ArrayList();
            pending.add(index);
            used[index] = true;

            for(int cursor = 0; cursor < pending.size(); ++cursor) {
               class_2338 current = (class_2338)candidates.get((Integer)pending.get(cursor));
               group.add(current);

               for(int next = 0; next < candidates.size(); ++next) {
                  if (!used[next] && current.method_10262((class_2382)candidates.get(next)) <= (double)clusterDistance * (double)clusterDistance) {
                     used[next] = true;
                     pending.add(next);
                  }
               }
            }

            if (group.size() >= this.minimumObjects.get().intValue()) {
               this.clusters.add(new Cluster(group, this.boundsOf(group)));
            }
         }
      }

   }

   private class_238 boundsOf(List<class_2338> positions) {
      int minX = Integer.MAX_VALUE;
      int minY = Integer.MAX_VALUE;
      int minZ = Integer.MAX_VALUE;
      int maxX = Integer.MIN_VALUE;
      int maxY = Integer.MIN_VALUE;
      int maxZ = Integer.MIN_VALUE;

      for(class_2338 pos : positions) {
         minX = Math.min(minX, pos.method_10263());
         minY = Math.min(minY, pos.method_10264());
         minZ = Math.min(minZ, pos.method_10260());
         maxX = Math.max(maxX, pos.method_10263());
         maxY = Math.max(maxY, pos.method_10264());
         maxZ = Math.max(maxZ, pos.method_10260());
      }

      return (new class_238((double)minX, (double)minY, (double)minZ, (double)maxX + (double)1.0F, (double)maxY + (double)1.0F, (double)maxZ + (double)1.0F)).method_1011(0.01);
   }

   private boolean isTrapObject(class_2248 block) {
      this.updateCustomBlockCache();
      if (this.excludedBlocks.contains(block)) {
         return false;
      } else if (this.customBlocks.contains(block)) {
         return true;
      } else if (!this.objects.get("Skrzynie") || block != class_2246.field_10034 && block != class_2246.field_10380 && block != class_2246.field_10443) {
         if (!this.objects.get("Pistony") || block != class_2246.field_10560 && block != class_2246.field_10615 && block != class_2246.field_10379) {
            if (!this.objects.get("Redstone") || block != class_2246.field_10002 && block != class_2246.field_10523 && block != class_2246.field_10091 && block != class_2246.field_10450 && block != class_2246.field_10377) {
               if (!this.objects.get("Obsydian") || block != class_2246.field_10540 && block != class_2246.field_22423) {
                  if (this.objects.get("Cobweb") && block == class_2246.field_10343) {
                     return true;
                  } else if (this.objects.get("TNT") && block == class_2246.field_10375) {
                     return true;
                  } else {
                     return this.objects.get("Inne") && (block == class_2246.field_10200 || block == class_2246.field_10228 || block == class_2246.field_10312 || block == class_2246.field_10348 || block == class_2246.field_10363);
                  }
               } else {
                  return true;
               }
            } else {
               return true;
            }
         } else {
            return true;
         }
      } else {
         return true;
      }
   }

   private void updateCustomBlockCache() {
      String customValue = this.customObjects.getValue();
      String excludedValue = this.excludedObjects.getValue();
      if (!customValue.equals(this.cachedCustomValue) || !excludedValue.equals(this.cachedExcludedValue)) {
         this.cachedCustomValue = customValue;
         this.cachedExcludedValue = excludedValue;
         this.customBlocks = this.resolveBlocks(customValue);
         this.excludedBlocks = this.resolveBlocks(excludedValue);
      }
   }

   private Set<class_2248> resolveBlocks(String value) {
      Set<class_2248> blocks = new HashSet();

      for(String rawId : value.split(",")) {
         String id = rawId.trim().toLowerCase();
         if (!id.isEmpty()) {
            if (!id.contains(":")) {
               id = "minecraft:" + id;
            }

            try {
               class_2248 block = (class_2248)class_7923.field_41175.method_63535(class_2960.method_60654(id));
               if (block != class_2246.field_10124) {
                  blocks.add(block);
               }
            } catch (IllegalArgumentException var9) {
            }
         }
      }

      return blocks;
   }

   private Color colorFor(class_2248 block) {
      if (block == class_2246.field_10343) {
         return new Color(190, 190, 190, 180);
      } else if (block != class_2246.field_10540 && block != class_2246.field_22423) {
         if (block == class_2246.field_10375) {
            return new Color(220, 40, 40, 190);
         } else {
            return block != class_2246.field_10034 && block != class_2246.field_10380 && block != class_2246.field_10443 ? new Color(255, 80, 80, 180) : new Color(240, 170, 40, 190);
         }
      } else {
         return new Color(150, 60, 220, 190);
      }
   }

   private static record Cluster(List<class_2338> positions, class_238 bounds) {
   }
}
