package ru.levin.modules.render;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "FullBright",
   desc = "Rozjaśnia otoczenie",
   type = Type.Render
)
public class FullBright extends Function {
   private final class_1293 nightVisionEffect;

   public FullBright() {
      this.nightVisionEffect = new class_1293(class_1294.field_5925, -1, 255, false, false, true);
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         mc.field_1724.method_37222(this.nightVisionEffect, mc.field_1724);
      }

   }

   public void onDisable() {
      mc.field_1724.method_6016(this.nightVisionEffect.method_5579());
      super.onDisable();
   }
}
