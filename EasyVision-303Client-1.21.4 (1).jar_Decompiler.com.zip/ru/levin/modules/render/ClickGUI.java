package ru.levin.modules.render;

import java.awt.Color;
import java.util.Arrays;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ClickGUI",
   desc = "Sterowanie / personalizacja GUI",
   type = Type.Render,
   key = 344
)
public class ClickGUI extends Function {
   public final ModeSetting colorGUI = new ModeSetting("Motyw", "Jasnoczarny", new String[]{"Jasnoczarny", "Ciemny"});
   public final SliderSetting alpha = new SliderSetting("Przezroczystość", (double)200.0F, (double)120.0F, (double)255.0F, (double)1.0F);
   public final BooleanSetting blur = new BooleanSetting("Rozmycie", true);
   public final MultiSetting blurSetting = new MultiSetting(() -> this.blur.get(), "Elementy", Arrays.asList("Szukaj", "Panele"), new String[]{"Szukaj", "Motywy", "Panele", "Opis", "Tworzenie motywu"});
   public final BooleanSetting strike = new BooleanSetting("Obramowanie modułów", true);
   public final BooleanSetting filling = new BooleanSetting("Wypełnienie modułów", true);
   public final SliderSetting rounding = new SliderSetting("Zaokrąglenie", (double)4.0F, (double)0.0F, (double)6.0F, (double)1.0F, () -> this.strike.get() || this.filling.get());
   public final SliderSetting alphaModules = new SliderSetting("Przezroczystość modułów", (double)20.0F, (double)10.0F, (double)40.0F, (double)1.0F, () -> this.strike.get() || this.filling.get());

   public ClickGUI() {
      this.addSettings(new Setting[]{this.colorGUI, this.alpha, this.blur, this.blurSetting, this.strike, this.filling, this.rounding, this.alphaModules});
   }

   public Color getGuiColor() {
      String var1 = this.colorGUI.get();
      byte var2 = -1;
      switch (var1.hashCode()) {
         case 1278731855:
            if (var1.equals("Ciemny")) {
               var2 = 0;
            }
            break;
         case 1538306962:
            if (var1.equals("Jasnoczarny")) {
               var2 = 1;
            }
      }

      switch (var2) {
         case 0:
            return new Color(0, 0, 0, this.alpha.get().intValue());
         case 1:
         default:
            return new Color(17, 15, 28, this.alpha.get().intValue());
      }
   }

   public void onEvent(Event event) {
   }

   public void onEnable() {
      this.setState(false);
      super.onEnable();
   }
}
