package ru.levin.modules.render;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ViewModel",
   desc = "Zmiana położenia rąk",
   type = Type.Render
)
public class ViewModel extends Function {
   public final SliderSetting right_x = new SliderSetting("RightX", (double)0.6F, (double)-2.0F, (double)2.0F, (double)0.1F);
   public final SliderSetting right_y = new SliderSetting("RightY", (double)-0.6F, (double)-2.0F, (double)2.0F, (double)0.1F);
   public final SliderSetting right_z = new SliderSetting("RightZ", (double)-0.8F, (double)-2.0F, (double)2.0F, (double)0.1F);
   public final SliderSetting left_x = new SliderSetting("LeftX", (double)0.0F, (double)-2.0F, (double)2.0F, (double)0.1F);
   public final SliderSetting left_y = new SliderSetting("LeftY", (double)0.0F, (double)-2.0F, (double)2.0F, (double)0.1F);
   public final SliderSetting left_z = new SliderSetting("LeftZ", (double)0.0F, (double)-2.0F, (double)2.0F, (double)0.1F);

   public ViewModel() {
      this.addSettings(new Setting[]{this.right_x, this.right_y, this.right_z, this.left_x, this.left_y, this.left_z});
   }

   public void onEvent(Event event) {
   }
}
