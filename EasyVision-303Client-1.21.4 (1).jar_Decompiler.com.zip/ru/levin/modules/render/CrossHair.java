package ru.levin.modules.render;

import java.awt.Color;
import net.minecraft.class_332;
import net.minecraft.class_3966;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "CrossHair",
   type = Type.Render
)
public class CrossHair extends Function {
   private final SliderSetting attackSetting = new SliderSetting("Rozmiar podczas ataku", (double)6.0F, (double)0.0F, (double)20.0F, (double)1.0F);
   private final SliderSetting indentSetting = new SliderSetting("Odstęp", (double)2.0F, (double)0.0F, (double)5.0F, (double)1.0F);
   private final SliderSetting size1Setting = new SliderSetting("Wysokość linii", (double)6.0F, (double)2.0F, (double)10.0F, (double)1.0F);
   private final SliderSetting size2Setting = new SliderSetting("Grubość linii", (double)2.0F, (double)2.0F, (double)4.0F, (double)1.0F);
   private float red = 0.0F;

   public CrossHair() {
      this.addSettings(new Setting[]{this.attackSetting, this.indentSetting, this.size1Setting, this.size2Setting});
   }

   public void onEvent(Event event) {
   }

   public void render(class_332 drawContext) {
      this.red = MathUtil.interpolateSmooth((double)2.0F, this.red, mc.field_1765 instanceof class_3966 ? 5.0F : 1.0F);
      int firstColor = ColorUtil.multRed(Color.WHITE.getRGB(), this.red);
      int secondColor = Color.BLACK.getRGB();
      float x = (float)mc.method_22683().method_4486() / 2.0F;
      float y = (float)mc.method_22683().method_4502() / 2.0F;
      float cooldown = (float)this.attackSetting.get().intValue() - (float)this.attackSetting.get().intValue() * mc.field_1724.method_7261(mc.method_61966().method_60637(true));
      float size = this.size1Setting.get().floatValue();
      float size2 = this.size2Setting.get().floatValue();
      float offset = size2 / 2.0F;
      float indent = (float)this.indentSetting.get().intValue() + cooldown;
      this.renderMain(drawContext, x, y, size, size2, 1.0F, indent, offset, secondColor);
      this.renderMain(drawContext, x, y, size, size2, 0.0F, indent, offset, firstColor);
   }

   private void renderMain(class_332 drawContext, float x, float y, float size, float size2, float padding, float indent, float offset, int color) {
      RenderUtil.drawRoundedRect(drawContext.method_51448(), x - offset - padding / 2.0F, y - size - indent - padding / 2.0F, size2 + padding, size + padding, 0.0F, color);
      RenderUtil.drawRoundedRect(drawContext.method_51448(), x - offset - padding / 2.0F, y + indent - padding / 2.0F, size2 + padding, size + padding, 0.0F, color);
      RenderUtil.drawRoundedRect(drawContext.method_51448(), x - size - indent - padding / 2.0F, y - offset - padding / 2.0F, size + padding, size2 + padding, 0.0F, color);
      RenderUtil.drawRoundedRect(drawContext.method_51448(), x + indent - padding / 2.0F, y - offset - padding / 2.0F, size + padding, size2 + padding, 0.0F, color);
   }
}
