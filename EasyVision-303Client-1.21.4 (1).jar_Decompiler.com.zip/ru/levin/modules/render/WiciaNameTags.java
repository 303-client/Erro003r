package ru.levin.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_124;
import net.minecraft.class_1296;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1421;
import net.minecraft.class_1531;
import net.minecraft.class_1657;
import net.minecraft.class_1690;
import net.minecraft.class_1695;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;
import org.joml.Vector4f;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "WiciaNameTags",
   desc = "Rozszerzone name tags (wersja Wicia)",
   type = Type.Render
)
public class WiciaNameTags extends Function {
   public final BooleanSetting showPlayers = new BooleanSetting("Gracze", true);
   public final BooleanSetting showMobs = new BooleanSetting("Mobki", true);
   public final BooleanSetting showAnimals = new BooleanSetting("Zwierzęta", true);
   public final BooleanSetting showArmorStands = new BooleanSetting("Armor Standy", true);
   public final BooleanSetting showVehicles = new BooleanSetting("Pojazdy", true);
   public final BooleanSetting showInvisible = new BooleanSetting("Niewidzialne", true);
   public final BooleanSetting distanceBased = new BooleanSetting("Kolor wg dystansu", true);
   public final BooleanSetting friendHighlight = new BooleanSetting("Podświetl znajomych", true);
   public final SliderSetting maxDistance = new SliderSetting("Max dystans", (double)256.0F, (double)50.0F, (double)500.0F, (double)10.0F);
   public final SliderSetting heightOffset = new SliderSetting("Przesunięcie wysokości", (double)0.0F, (double)-2.0F, (double)3.0F, (double)0.1F);
   public final SliderSetting fontSize = new SliderSetting("Rozmiar czcionki", (double)1.0F, (double)0.5F, (double)2.0F, (double)0.1F);

   public void onEvent(Event event) {
      if (event instanceof EventRender2D renderEvent) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if (!this.state) {
            return;
         }

         this.renderNameTags(renderEvent.getMatrixStack(), mc.method_61966().method_60637(true));
      }

   }

   private void renderNameTags(class_4587 matrices, float tickDelta) {
      List<EntityTarget> targets = this.getTargets(tickDelta);
      if (!targets.isEmpty()) {
         int windowWidth = mc.method_22683().method_4486();
         int windowHeight = mc.method_22683().method_4502();
         float scale = (float)mc.method_22683().method_4495();

         for(EntityTarget target : targets) {
            class_243 screenPos = this.projectToScreen(target.getPosition(), tickDelta);
            if (screenPos != null && !(screenPos.field_1350 < (double)0.0F) && !(screenPos.field_1352 < (double)0.0F) && !(screenPos.field_1352 > (double)windowWidth) && !(screenPos.field_1351 < (double)0.0F) && !(screenPos.field_1351 > (double)windowHeight)) {
               float yOffset = this.heightOffset.get().floatValue();
               float finalY = (float)screenPos.field_1351 + yOffset * scale;
               int color = target.getColor();
               String name = target.getName();
               class_327 textRenderer = mc.field_1772;
               float textWidth = (float)textRenderer.method_27525(class_2561.method_43470(name)) * this.fontSize.get().floatValue();
               Objects.requireNonNull(textRenderer);
               float textHeight = 9.0F * this.fontSize.get().floatValue();
               float x = (float)screenPos.field_1352 - textWidth / 2.0F;
               float y = finalY - textHeight;
               RenderSystem.enableBlend();
               RenderSystem.defaultBlendFunc();
               int bgColor = (new Color(30, 30, 30, 180)).getRGB();
               if (this.friendHighlight.get() && target.isFriend()) {
                  bgColor = (new Color(0, 100, 0, 180)).getRGB();
               }

               this.drawRoundedRect(matrices, x - 2.0F, y - 1.0F, textWidth + 4.0F, textHeight + 2.0F, 2.0F, bgColor);
               float red = (float)(color >> 16 & 255) / 255.0F;
               float green = (float)(color >> 8 & 255) / 255.0F;
               float blue = (float)(color & 255) / 255.0F;
               matrices.method_22903();
               matrices.method_46416(x, y, 0.0F);
               matrices.method_22905(this.fontSize.get().floatValue(), this.fontSize.get().floatValue(), 1.0F);
               textRenderer.method_27522(class_2561.method_43470(name), 0.0F, 0.0F, color, false, matrices.method_23760().method_23761(), mc.method_22940().method_23000(), class_6415.field_33993, 0, 15728880);
               matrices.method_22909();
               RenderSystem.disableBlend();
            }
         }

      }
   }

   private class_243 projectToScreen(class_243 worldPos, float tickDelta) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_243 cameraPos = mc.field_1773.method_19418().method_19326();
         Matrix4f projectionMatrix = new Matrix4f(RenderSystem.getProjectionMatrix());
         Matrix4f modelViewMatrix = new Matrix4f(mc.field_1773.method_22973(1.0F));
         Vector4f worldPos4f = new Vector4f((float)(worldPos.field_1352 - cameraPos.field_1352), (float)(worldPos.field_1351 - cameraPos.field_1351), (float)(worldPos.field_1350 - cameraPos.field_1350), 1.0F);
         modelViewMatrix.transform(worldPos4f);
         projectionMatrix.transform(worldPos4f);
         if (worldPos4f.w <= 0.0F) {
            return null;
         } else {
            float screenX = worldPos4f.x / worldPos4f.w;
            float screenY = worldPos4f.y / worldPos4f.w;
            int windowWidth = mc.method_22683().method_4486();
            int windowHeight = mc.method_22683().method_4502();
            return new class_243((double)((screenX + 1.0F) / 2.0F * (float)windowWidth), (double)((1.0F - (screenY + 1.0F) / 2.0F) * (float)windowHeight), (double)worldPos4f.w);
         }
      } else {
         return null;
      }
   }

   private List<EntityTarget> getTargets(float tickDelta) {
      List<EntityTarget> targets = new ArrayList();
      if (mc.field_1724 != null && mc.field_1687 != null) {
         for(class_1297 entity : mc.field_1687.method_18112()) {
            if (this.shouldRenderEntity(entity)) {
               class_243 position = entity.method_30950(tickDelta);
               double distance = mc.field_1724.method_5858(entity);
               double maxDist = this.maxDistance.get().doubleValue();
               if (!(distance > maxDist * maxDist)) {
                  int color = this.getEntityColor(entity, distance);
                  String name = this.getEntityName(entity);
                  boolean isFriend = entity instanceof class_1657 && Manager.FRIEND_MANAGER.isFriend(entity.method_5477().getString());
                  targets.add(new EntityTarget(entity, position, color, name, isFriend));
               }
            }
         }

         return targets;
      } else {
         return targets;
      }
   }

   private boolean shouldRenderEntity(class_1297 entity) {
      if (entity == mc.field_1724) {
         return false;
      } else if (!entity.method_5805()) {
         return false;
      } else if (!this.showInvisible.get() && entity.method_5767()) {
         return false;
      } else if (entity instanceof class_1657) {
         return this.showPlayers.get();
      } else if (entity instanceof class_1308) {
         return entity instanceof class_1421 ? this.showAnimals.get() : this.showMobs.get();
      } else if (entity instanceof class_1296) {
         return this.showAnimals.get();
      } else if (entity instanceof class_1531) {
         return this.showArmorStands.get();
      } else {
         return !(entity instanceof class_1690) && !(entity instanceof class_1695) ? false : this.showVehicles.get();
      }
   }

   private int getEntityColor(class_1297 entity, double distance) {
      if (this.distanceBased.get()) {
         double maxDist = this.maxDistance.get().doubleValue();
         float ratio = (float)((double)1.0F - Math.min(distance, maxDist) / maxDist);
         int green = 65280;
         int yellow = 16776960;
         int red = 16711680;
         int color;
         if (ratio <= 0.333F) {
            color = this.interpolateColor(green, yellow, ratio / 0.333F);
         } else if (ratio <= 0.666F) {
            color = this.interpolateColor(yellow, red, (ratio - 0.333F) / 0.333F);
         } else {
            color = this.interpolateColor(red, 16711935, (ratio - 0.666F) / 0.334F);
         }

         return -16777216 | color;
      } else if (entity instanceof class_1657) {
         return -65536;
      } else if (entity instanceof class_1308) {
         return -65281;
      } else {
         return entity instanceof class_1296 ? -256 : -1;
      }
   }

   private String getEntityName(class_1297 entity) {
      if (entity instanceof class_1657 player) {
         String name = player.method_5477().getString();
         if (this.friendHighlight.get() && Manager.FRIEND_MANAGER.isFriend(name)) {
            String var10000 = String.valueOf(class_124.field_1060);
            return var10000 + "[F] " + String.valueOf(class_124.field_1070) + name;
         } else {
            return name;
         }
      } else {
         return entity.method_5477().getString();
      }
   }

   private int interpolateColor(int color1, int color2, float ratio) {
      ratio = Math.max(0.0F, Math.min(1.0F, ratio));
      int r1 = color1 >> 16 & 255;
      int g1 = color1 >> 8 & 255;
      int b1 = color1 & 255;
      int r2 = color2 >> 16 & 255;
      int g2 = color2 >> 8 & 255;
      int b2 = color2 & 255;
      int r = Math.round((float)r1 + (float)(r2 - r1) * ratio);
      int g = Math.round((float)g1 + (float)(g2 - g1) * ratio);
      int b = Math.round((float)b1 + (float)(b2 - b1) * ratio);
      return r << 16 | g << 8 | b;
   }

   private void drawRoundedRect(class_4587 matrices, float x, float y, float width, float height, float radius, int color) {
      float red = (float)(color >> 16 & 255) / 255.0F;
      float green = (float)(color >> 8 & 255) / 255.0F;
      float blue = (float)(color & 255) / 255.0F;
      float alpha = (float)(color >> 24 & 255) / 255.0F;
      class_289 tessellator = class_289.method_1348();
      class_287 bufferBuilder = tessellator.method_60827(class_5596.field_27382, class_290.field_1576);
      Matrix4f matrix = matrices.method_23760().method_23761();
      bufferBuilder.method_22918(matrix, x, y, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x + width, y, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x + width, y + height, 0.0F).method_22915(red, green, blue, alpha);
      bufferBuilder.method_22918(matrix, x, y + height, 0.0F).method_22915(red, green, blue, alpha);
      class_286.method_43433(bufferBuilder.method_60800());
   }

   private static class EntityTarget {
      private final class_1297 entity;
      private final class_243 position;
      private final int color;
      private final String name;
      private final boolean isFriend;

      public EntityTarget(class_1297 entity, class_243 position, int color, String name, boolean isFriend) {
         this.entity = entity;
         this.position = position;
         this.color = color;
         this.name = name;
         this.isFriend = isFriend;
      }

      public class_1297 getEntity() {
         return this.entity;
      }

      public class_243 getPosition() {
         return this.position;
      }

      public int getColor() {
         return this.color;
      }

      public String getName() {
         return this.name;
      }

      public boolean isFriend() {
         return this.isFriend;
      }
   }
}
