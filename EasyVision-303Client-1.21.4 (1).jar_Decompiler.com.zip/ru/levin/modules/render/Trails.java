package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_5498;
import net.minecraft.class_293.class_5596;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.IEntity;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "Trails",
   type = Type.Render,
   desc = "Linia śladu za graczem"
)
public class Trails extends Function {
   private final MultiSetting targets = new MultiSetting("Wyświetlaj dla", Arrays.asList("Znajomych", "Mnie"), new String[]{"Graczy", "Znajomych", "Mnie"});
   private final long trailLifetimeMs = 250L;
   private final double minDistance = 0.01;

   public Trails() {
      this.addSettings(new Setting[]{this.targets});
   }

   public void onEvent(Event event) {
      long now = System.currentTimeMillis();
      if (event instanceof EventUpdate) {
         for(class_1657 entity : Manager.SYNC_MANAGER.getPlayers()) {
            if (this.shouldRenderTrails(entity)) {
               List<Trail> trails = ((IEntity)entity).exosWareFabric1_21_4$getTrails();
               trails.removeIf((t) -> t.isExpired(now));
            }
         }

      } else {
         if (event instanceof EventRender3D) {
            EventRender3D renderEvent = (EventRender3D)event;
            float tickDelta = renderEvent.getDeltatick().method_60637(true);
            class_243 cameraPos = mc.field_1773.method_19418().method_19326();

            for(class_1657 entity : Manager.SYNC_MANAGER.getPlayers()) {
               if (this.shouldRenderTrails(entity)) {
                  class_243 interp = this.interpolateEntityPosition(entity, tickDelta);
                  List<Trail> trails = ((IEntity)entity).exosWareFabric1_21_4$getTrails();
                  if (trails.isEmpty()) {
                     trails.add(new Trail(interp, this.getTrailColor(entity), now));
                  } else {
                     Trail last = (Trail)trails.get(trails.size() - 1);
                     if (last.pos.method_1022(interp) >= 0.01) {
                        trails.add(new Trail(interp, this.getTrailColor(entity), now));
                     }
                  }

                  this.render(renderEvent, entity, cameraPos, now);
               }
            }
         }

      }
   }

   private int getTrailColor(class_1657 entity) {
      return Manager.FRIEND_MANAGER.isFriend(entity.method_5477().getString()) ? (new Color(0, 255, 0)).getRGB() : ColorUtil.getColorStyle(360.0F);
   }

   private boolean shouldRenderTrails(class_1657 entity) {
      if (entity == mc.field_1724) {
         return mc.field_1690.method_31044() == class_5498.field_26664 ? false : this.targets.get("Mnie");
      } else {
         return this.targets.get("Znajomych") && Manager.FRIEND_MANAGER.isFriend(entity.method_5477().getString()) ? true : this.targets.get("Graczy");
      }
   }

   private class_243 interpolateEntityPosition(class_1657 entity, float tickDelta) {
      double ix = entity.field_6014 + (entity.method_23317() - entity.field_6014) * (double)tickDelta;
      double iy = entity.field_6036 + (entity.method_23318() - entity.field_6036) * (double)tickDelta;
      double iz = entity.field_5969 + (entity.method_23321() - entity.field_5969) * (double)tickDelta;
      return new class_243(ix, iy, iz);
   }

   private void render(EventRender3D event, class_1657 entity, class_243 cameraPos, long now) {
      List<Trail> trails = ((IEntity)entity).exosWareFabric1_21_4$getTrails();
      if (!trails.isEmpty()) {
         float playerHeight = entity.method_17682();
         event.getMatrixStack().method_22903();
         RenderSystem.disableCull();
         RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         RenderSystem.enableDepthTest();
         RenderSystem.depthFunc(515);
         RenderSystem.setShader(class_10142.field_53876);
         class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27380, class_290.field_1576);

         for(Trail p : trails) {
            if (!p.isExpired(now)) {
               float ageFrac = (float)(now - p.time) / 250.0F;
               float alpha = 1.0F - Math.min(1.0F, ageFrac);
               alpha = Math.max(0.01F, alpha);
               int color = RenderUtil.injectAlpha(p.color, (int)(alpha * 255.0F));
               class_243 posRel = p.pos.method_1020(cameraPos);
               buffer.method_22918(event.getMatrixStack().method_23760().method_23761(), (float)posRel.field_1352, (float)(posRel.field_1351 + (double)playerHeight), (float)posRel.field_1350).method_39415(color);
               buffer.method_22918(event.getMatrixStack().method_23760().method_23761(), (float)posRel.field_1352, (float)posRel.field_1351, (float)posRel.field_1350).method_39415(color);
            }
         }

         RenderUtil.render3D.endBuilding(buffer);
         RenderUtil.disableRender();
         RenderSystem.disableDepthTest();
         event.getMatrixStack().method_22909();
      }
   }

   public class Trail {
      public final class_243 pos;
      public final int color;
      public final long time;

      public Trail(class_243 pos, int color, long time) {
         this.pos = pos;
         this.color = color;
         this.time = time;
      }

      public boolean isExpired(long now) {
         return now - this.time > 250L;
      }
   }
}
