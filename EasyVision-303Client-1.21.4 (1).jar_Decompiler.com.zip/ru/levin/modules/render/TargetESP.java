package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_3532;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.animations.impl.EaseInOutQuad;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.math.RayTraceUtil;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.providers.ResourceProvider;

@FunctionAnnotation(
   name = "TargetESP",
   desc = "Efektowny wskaźnik przeciwnika",
   type = Type.Render
)
public class TargetESP extends Function {
   private final ModeSetting mode = new ModeSetting("Moduł", "Duchy", new String[]{"Znacznik", "Znacznik 2", "Duchy", "Okrąg"});
   private final float[] SCALE_CACHE = new float[101];
   private final EaseInOutQuad animation = new EaseInOutQuad(800, (double)1.0F);
   private class_1297 lastTarget = null;
   private double scale = (double)0.0F;

   public TargetESP() {
      this.addSettings(new Setting[]{this.mode});

      for(int i = 0; i <= 100; ++i) {
         this.SCALE_CACHE[i] = Math.max(0.28F * ((float)i / 100.0F), 0.2F);
      }

   }

   public void onEvent(Event event) {
      if (event instanceof EventRender3D renderEvent) {
         class_1297 currentTarget = Manager.FUNCTION_MANAGER.attackAura.target;
         if (currentTarget == null || this.lastTarget != null && this.lastTarget.equals(currentTarget)) {
            if (currentTarget == null) {
               this.animation.setDirection(class_2352.field_11060);
            }
         } else {
            this.animation.setDirection(class_2352.field_11056);
         }

         this.lastTarget = currentTarget;
         if (currentTarget != null) {
            if (!this.mode.is("Znacznik") && !this.mode.is("Znacznik 2")) {
               if (this.mode.is("Duchy")) {
                  this.renderGhosts(14, 8, 1.8F, 3.0F, currentTarget);
               } else if (this.mode.is("Okrąg")) {
                  this.cicle(currentTarget, renderEvent.getMatrixStack(), renderEvent.getDeltatick().method_60637(true));
               }
            } else {
               this.render(currentTarget);
            }
         }

      }
   }

   public void onDisable() {
      super.onDisable();
   }

   public void renderGhosts(int espLength, int factor, float shaking, float amplitude, class_1297 target) {
      if (target != null) {
         class_4184 camera = mc.field_1773.method_19418();
         if (camera != null) {
            float hitProgress = RayTraceUtil.getHitProgress(target);
            float delta = mc.method_61966().method_60637(true);
            class_243 camPos = camera.method_19326();
            double tX = MathUtil.interpolate(target.field_6014, target.method_23317(), (double)delta) - camPos.field_1352;
            double tY = MathUtil.interpolate(target.field_6036, target.method_23318(), (double)delta) - camPos.field_1351;
            double tZ = MathUtil.interpolate(target.field_5969, target.method_23321(), (double)delta) - camPos.field_1350;
            float age = MathUtil.interpolateFloat((float)(target.field_6012 - 1), (float)target.field_6012, delta);
            boolean canSee = mc.field_1724.method_6057(target);
            RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
            RenderSystem.setShaderTexture(0, ResourceProvider.firefly);
            RenderSystem.setShader(class_10142.field_53880);
            if (canSee) {
               RenderSystem.enableDepthTest();
               RenderSystem.depthMask(false);
            } else {
               RenderSystem.disableDepthTest();
            }

            class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);
            float pitch = camera.method_19329();
            float yaw = camera.method_19330();
            float ghostAlpha = (float)this.animation.getOutput();

            for(int j = 0; j < 3; ++j) {
               for(int i = 0; i <= espLength; ++i) {
                  float offset = (float)i / (float)espLength;
                  double radians = Math.toRadians((double)((((float)i / 1.5F + age) * (float)factor + (float)(j * 120)) % (float)(factor * 360)));
                  double sinQuad = Math.sin(Math.toRadians((double)(age * 2.5F + (float)(i * (j + 1)))) * (double)amplitude) / (double)shaking;
                  class_4587 matrices = new class_4587();
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(yaw + 180.0F));
                  matrices.method_22904(tX + Math.cos(radians) * (double)target.method_17681(), tY + (double)1.0F + sinQuad, tZ + Math.sin(radians) * (double)target.method_17681());
                  matrices.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
                  matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
                  Matrix4f matrix = matrices.method_23760().method_23761();
                  int baseColor;
                  if (hitProgress > 0.0F) {
                     baseColor = Color.RED.getRGB();
                  } else {
                     baseColor = ColorUtil.getColorStyle((float)((int)(180.0F * offset)));
                  }

                  int color = RenderUtil.applyOpacity(baseColor, offset * ghostAlpha);
                  float scale = this.SCALE_CACHE[Math.min((int)(offset * 100.0F), 100)];
                  buffer.method_22918(matrix, -scale, scale, 0.0F).method_22913(0.0F, 1.0F).method_39415(color);
                  buffer.method_22918(matrix, scale, scale, 0.0F).method_22913(1.0F, 1.0F).method_39415(color);
                  buffer.method_22918(matrix, scale, -scale, 0.0F).method_22913(1.0F, 0.0F).method_39415(color);
                  buffer.method_22918(matrix, -scale, -scale, 0.0F).method_22913(0.0F, 0.0F).method_39415(color);
               }
            }

            RenderUtil.render3D.endBuilding(buffer);
            if (canSee) {
               RenderSystem.depthMask(true);
               RenderSystem.disableDepthTest();
            } else {
               RenderSystem.enableDepthTest();
            }

            RenderSystem.disableBlend();
         }
      }
   }

   private void cicle(class_1297 target, class_4587 matrices, float tickDelta) {
      class_243 camPos = mc.field_1773.method_19418().method_19326();
      double x = class_3532.method_16436((double)tickDelta, target.field_6038, target.method_23317()) - camPos.field_1352;
      double z = class_3532.method_16436((double)tickDelta, target.field_5989, target.method_23321()) - camPos.field_1350;
      double y = class_3532.method_16436((double)tickDelta, target.field_5971, target.method_23318()) - camPos.field_1351 + Math.min(Math.sin((double)System.currentTimeMillis() / (double)400.0F) + 0.95, (double)target.method_17682());
      disableDepth();
      RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
      RenderSystem.setShader(class_10142.field_53876);
      Matrix4f matrix = matrices.method_23760().method_23761();
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27380, class_290.field_1576);
      int baseColor = ColorUtil.getColorStyle(360.0F);
      float r = (float)(baseColor >> 16 & 255) / 255.0F;
      float g = (float)(baseColor >> 8 & 255) / 255.0F;
      float b = (float)(baseColor & 255) / 255.0F;
      float alpha = (float)this.animation.getOutput();
      float radius = target.method_17681() * 0.8F;

      for(float i = 0.0F; (double)i <= 6.440264939859076; i = (float)((double)i + 0.15707963267948966)) {
         double vecX = x + (double)radius * Math.cos((double)i);
         double vecZ = z + (double)radius * Math.sin((double)i);
         buffer.method_22918(matrix, (float)vecX, (float)(y - Math.cos((double)System.currentTimeMillis() / (double)400.0F) / (double)2.0F), (float)vecZ).method_22915(r, g, b, 0.01F * alpha);
         buffer.method_22918(matrix, (float)vecX, (float)y, (float)vecZ).method_22915(r, g, b, 1.0F * alpha);
      }

      RenderUtil.render3D.endBuilding(buffer);
      endRender();
   }

   private static void disableDepth() {
      RenderSystem.disableDepthTest();
      RenderSystem.disableCull();
   }

   private static void endRender() {
      RenderUtil.disableRender();
      RenderSystem.enableDepthTest();
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
      RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
   }

   private void render(class_1297 target) {
      class_4184 camera = mc.field_1773.method_19418();
      if (camera != null) {
         this.scale = this.animation.getOutput();
         if (this.scale != (double)0.0F) {
            float delta = mc.method_61966().method_60637(true);
            float hitProgress = RayTraceUtil.getHitProgress(target);
            class_243 camPos = camera.method_19326();
            double tX = MathUtil.interpolate(target.field_6014, target.method_23317(), (double)delta) - camPos.field_1352;
            double tY = MathUtil.interpolate(target.field_6036, target.method_23318(), (double)delta) - camPos.field_1351;
            double tZ = MathUtil.interpolate(target.field_5969, target.method_23321(), (double)delta) - camPos.field_1350;
            class_4587 matrices = this.setupMatrices(camera, target, delta, tX, tY, tZ);
            Matrix4f matrix = matrices.method_23760().method_23761();
            disableDepth();
            RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
            if (this.mode.is("Znacznik")) {
               RenderSystem.setShaderTexture(0, ResourceProvider.marker);
            }

            if (this.mode.is("Znacznik 2")) {
               RenderSystem.setShaderTexture(0, ResourceProvider.marker2);
            }

            RenderSystem.setShader(class_10142.field_53880);
            float alpha = (float)this.animation.getOutput();
            int[] baseColors = hitProgress > 0.0F ? new int[]{Color.RED.getRGB(), ColorUtil.getColorStyle(0.0F), Color.RED.getRGB(), ColorUtil.getColorStyle(270.0F)} : new int[]{ColorUtil.getColorStyle(90.0F), ColorUtil.getColorStyle(0.0F), ColorUtil.getColorStyle(180.0F), ColorUtil.getColorStyle(270.0F)};
            this.drawQuad(matrix, this.applyAlphaToColors(baseColors, alpha));
            endRender();
         }
      }
   }

   private class_4587 setupMatrices(class_4184 camera, class_1297 target, float delta, double tX, double tY, double tZ) {
      class_4587 matrices = new class_4587();
      float pitch = camera.method_19329();
      float yaw = camera.method_19330();
      matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
      matrices.method_22907(class_7833.field_40716.rotationDegrees(yaw + 180.0F));
      matrices.method_22904(tX, tY + (double)(target.method_18381(target.method_18376()) / 2.0F), tZ);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(-yaw));
      matrices.method_22907(class_7833.field_40714.rotationDegrees(pitch));
      float interpolatedAngle = MathUtil.interpolateFloat(1.0F, 1.0F, delta);
      matrices.method_22907(class_7833.field_40718.rotationDegrees(interpolatedAngle));
      float radians = (float)Math.toRadians((double)((float)(System.currentTimeMillis() % 3600L) / 5.0F));
      matrices.method_34425((new Matrix4f()).rotate(radians, 0.0F, 0.0F, 1.0F));
      matrices.method_22904((double)-0.75F, (double)-0.75F, -0.01);
      return matrices;
   }

   private int[] applyAlphaToColors(int[] colors, float alpha) {
      int[] out = new int[colors.length];

      for(int i = 0; i < colors.length; ++i) {
         Color color = new Color(colors[i]);
         out[i] = (new Color(color.getRed(), color.getGreen(), color.getBlue(), (int)((float)color.getAlpha() * alpha))).getRGB();
      }

      return out;
   }

   private void drawQuad(Matrix4f matrix, int[] colors) {
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);
      buffer.method_22918(matrix, 0.0F, 1.5F, 0.0F).method_22913(0.0F, 1.0F).method_39415(colors[0]);
      buffer.method_22918(matrix, 1.5F, 1.5F, 0.0F).method_22913(1.0F, 1.0F).method_39415(colors[1]);
      buffer.method_22918(matrix, 1.5F, 0.0F, 0.0F).method_22913(1.0F, 0.0F).method_39415(colors[2]);
      buffer.method_22918(matrix, 0.0F, 0.0F, 0.0F).method_22913(0.0F, 0.0F).method_39415(colors[3]);
      RenderUtil.render3D.endBuilding(buffer);
   }
}
