package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_7833;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.animations.Animation;
import ru.levin.util.animations.impl.EaseBackIn;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.player.TimerUtil;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "JumpCircles",
   type = Type.Render,
   desc = "Efektowne okręgi podczas skoku"
)
public class JumpCircles extends Function {
   private final ModeSetting circleType = new ModeSetting("Typ okręgu", "Type-2", new String[]{"Type-1", "Type-2", "Type-3"});
   private final SliderSetting rotateSpeed = new SliderSetting("Prędkość", (double)0.1F, (double)0.1F, (double)5.0F, (double)0.1F);
   private final SliderSetting circleScale = new SliderSetting("Rozmiar", (double)0.7F, (double)0.6F, (double)5.0F, (double)0.1F);
   private final MultiSetting targets = new MultiSetting("Wyświetlaj dla", Arrays.asList("Znajomych", "Mnie"), new String[]{"Graczy", "Znajomych", "Mnie"});
   private final class_2960 CIRCLE_TEXTURE = class_2960.method_60655("exosware", "images/circles/circle.png");
   private final class_2960 CIRCLE2_TEXTURE = class_2960.method_60655("exosware", "images/circles/circle2.png");
   private final class_2960 CIRCLE3_TEXTURE = class_2960.method_60655("exosware", "images/circles/circle3.png");
   private final List<Circle> circles = new ArrayList();
   private final Map<class_1657, Boolean> wasOnGround = new HashMap();
   private class_2960 texture = null;

   public JumpCircles() {
      this.addSettings(new Setting[]{this.circleType, this.targets, this.rotateSpeed, this.circleScale});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         this.circles.removeIf((c) -> c.timer.getTime() > 8000L);

         for(class_1657 player : Manager.SYNC_MANAGER.getPlayers()) {
            if (player != null && !player.method_31481()) {
               boolean isFriend = Manager.FRIEND_MANAGER != null && player.method_5477() != null && Manager.FRIEND_MANAGER.isFriend(player.method_5477().getString());
               boolean isMe = player == mc.field_1724;
               boolean showPlayers = this.targets.get("Graczy");
               boolean showFriends = this.targets.get("Znajomych");
               boolean showMe = this.targets.get("Mnie");
               boolean shouldTrack = isMe && showMe || !isMe && isFriend && showFriends || !isMe && !isFriend && showPlayers;
               if (!shouldTrack) {
                  this.wasOnGround.remove(player);
               } else {
                  boolean previouslyOnGround = (Boolean)this.wasOnGround.getOrDefault(player, true);
                  boolean currentlyOnGround = player.method_24828();
                  if (previouslyOnGround && !currentlyOnGround) {
                     Circle circle = new Circle(new class_243(player.method_23317(), Math.floor(player.method_23318()) + (double)0.001F, player.method_23321()), new TimerUtil(), new EaseBackIn(400, (double)1.0F, 1.3F));
                     circle.animation.setDirection(class_2352.field_11056);
                     this.circles.add(circle);
                  }

                  this.wasOnGround.put(player, currentlyOnGround);
               }
            }
         }
      }

      if (event instanceof EventRender3D render3D) {
         this.renderCircles(render3D);
      }

   }

   private void renderCircles(EventRender3D eventRender3D) {
      Collections.reverse(this.circles);
      eventRender3D.getMatrixStack().method_22903();
      RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      switch (this.circleType.get()) {
         case "Type-1" -> this.texture = this.CIRCLE_TEXTURE;
         case "Type-2" -> this.texture = this.CIRCLE2_TEXTURE;
         case "Type-3" -> this.texture = this.CIRCLE3_TEXTURE;
      }

      RenderSystem.setShaderTexture(0, this.texture);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(Circle c : this.circles) {
         float elapsed = (float)c.timer.getTime();
         float alphaFade = MathUtil.clamp(1.0F - elapsed / 8000.0F, 0.0F, 1.0F);
         float animScale = (float)c.animation.getOutput();
         eventRender3D.getMatrixStack().method_22903();
         eventRender3D.getMatrixStack().method_22904(c.pos().field_1352 - mc.method_1561().field_4686.method_19326().method_10216(), c.pos().field_1351 - mc.method_1561().field_4686.method_19326().method_10214(), c.pos().field_1350 - mc.method_1561().field_4686.method_19326().method_10215());
         eventRender3D.getMatrixStack().method_22907(class_7833.field_40714.rotationDegrees(90.0F));
         eventRender3D.getMatrixStack().method_22907(class_7833.field_40718.rotationDegrees(elapsed / 50.0F * this.rotateSpeed.get().floatValue()));
         RenderAddon.sizeAnimation(eventRender3D.getMatrixStack(), (double)0.0F, (double)0.0F, (double)(animScale * this.circleScale.get().floatValue()));
         float size = 1.0F;
         Matrix4f matrix = eventRender3D.getMatrixStack().method_23760().method_23761();
         buffer.method_22918(matrix, -size, size, 0.0F).method_22913(0.0F, 1.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(270.0F), alphaFade));
         buffer.method_22918(matrix, size, size, 0.0F).method_22913(1.0F, 1.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(0.0F), alphaFade));
         buffer.method_22918(matrix, size, -size, 0.0F).method_22913(1.0F, 0.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(180.0F), alphaFade));
         buffer.method_22918(matrix, -size, -size, 0.0F).method_22913(0.0F, 0.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(90.0F), alphaFade));
         eventRender3D.getMatrixStack().method_22909();
      }

      RenderUtil.render3D.endBuilding(buffer);
      RenderSystem.depthMask(true);
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
      RenderSystem.disableDepthTest();
      RenderSystem.disableBlend();
      eventRender3D.getMatrixStack().method_22909();
      Collections.reverse(this.circles);
   }

   static record Circle(class_243 pos, TimerUtil timer, Animation animation) {
   }
}
