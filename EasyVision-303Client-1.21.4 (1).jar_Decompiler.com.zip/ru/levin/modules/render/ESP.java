package ru.levin.modules.render;

import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.Arrays;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_5498;
import net.minecraft.class_742;
import net.minecraft.class_9779;
import net.minecraft.class_293.class_5596;
import org.jetbrains.annotations.NotNull;
import org.joml.Matrix4f;
import org.joml.Vector4d;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "ESP",
   desc = "Efektowne ramki wokół graczy",
   type = Type.Render
)
public class ESP extends Function {
   private final MultiSetting targets = new MultiSetting("Wyświetlaj", Arrays.asList("Graczy", "Znajomych", "Mnie"), new String[]{"Graczy", "Znajomych", "Mnie", "Przedmioty"});

   public ESP() {
      this.addSettings(new Setting[]{this.targets});
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender2D e) {
         if (!mc.field_1690.field_1842) {
            Matrix4f matrix = e.getDrawContext().method_51448().method_23760().method_23761();
            RenderUtil.enableRender();
            RenderSystem.setShader(class_10142.field_53876);
            class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1576);
            List<class_742> players = Manager.SYNC_MANAGER.getPlayers();
            List<class_1297> entities = this.targets.get("Przedmioty") ? Manager.SYNC_MANAGER.getEntities() : List.of();

            for(class_1657 player : players) {
               if (this.shouldRender(player)) {
                  this.drawBox(e.getDeltatick(), buffer, player, matrix);
               }
            }

            for(class_1297 entity : entities) {
               if (entity instanceof class_1542) {
                  this.drawBox(e.getDeltatick(), buffer, entity, matrix);
               }
            }

            RenderUtil.render3D.endBuilding(buffer);
            RenderUtil.disableRender();
         }
      }
   }

   private boolean shouldRender(class_1657 entity) {
      if (entity == mc.field_1724) {
         return mc.field_1690.method_31044() == class_5498.field_26664 ? false : this.targets.get("Mnie");
      } else {
         return this.targets.get("Znajomych") && Manager.FRIEND_MANAGER.isFriend(entity.method_5477().getString()) ? true : this.targets.get("Graczy");
      }
   }

   public void drawBox(class_9779 tick, class_287 buffer, @NotNull class_1297 ent, Matrix4f matrix) {
      class_243[] corners = this.getVectors(tick, ent);
      Vector4d pos = null;

      for(class_243 corner : corners) {
         class_243 screen = RenderUtil.render3D.worldSpaceToScreenSpace(corner);
         if (!(screen.field_1350 <= (double)0.0F) && !(screen.field_1350 >= (double)1.0F)) {
            if (pos == null) {
               pos = new Vector4d(screen.field_1352, screen.field_1351, screen.field_1352, screen.field_1351);
            } else {
               if (screen.field_1352 < pos.x) {
                  pos.x = screen.field_1352;
               }

               if (screen.field_1351 < pos.y) {
                  pos.y = screen.field_1351;
               }

               if (screen.field_1352 > pos.z) {
                  pos.z = screen.field_1352;
               }

               if (screen.field_1351 > pos.w) {
                  pos.w = screen.field_1351;
               }
            }
         }
      }

      if (pos != null) {
         double screenW = (double)mc.method_22683().method_4486();
         double screenH = (double)mc.method_22683().method_4502();
         if (!(pos.z < (double)0.0F) && !(pos.x > screenW) && !(pos.w < (double)0.0F) && !(pos.y > screenH)) {
            float x1 = (float)pos.x;
            float y1 = (float)pos.y;
            float x2 = (float)pos.z;
            float y2 = (float)pos.w;
            int black = Color.BLACK.getRGB();
            this.drawRect(buffer, matrix, x1 - 1.0F, y1, x1 + 0.5F, y2 + 0.5F, black);
            this.drawRect(buffer, matrix, x1 - 1.0F, y1 - 0.5F, x2 + 0.5F, y1 + 1.0F, black);
            this.drawRect(buffer, matrix, x2 - 1.0F, y1, x2 + 0.5F, y2 + 0.5F, black);
            this.drawRect(buffer, matrix, x1 - 1.0F, y2 - 1.0F, x2 + 0.5F, y2 + 0.5F, black);
            int cTop = ColorUtil.getColorStyle(270.0F);
            int cRight = ColorUtil.getColorStyle(90.0F);
            int cBottom = ColorUtil.getColorStyle(180.0F);
            int cLeft = ColorUtil.getColorStyle(0.0F);
            this.drawRect(buffer, matrix, x1 - 0.5F, y1, x1 + 0.5F, y2, cTop, cLeft, cLeft, cTop);
            this.drawRect(buffer, matrix, x1, y2 - 0.5F, x2, y2, cLeft, cBottom, cBottom, cLeft);
            this.drawRect(buffer, matrix, x1 - 0.5F, y1, x2, y1 + 0.5F, cBottom, cRight, cRight, cBottom);
            this.drawRect(buffer, matrix, x2 - 0.5F, y1, x2, y2, cRight, cTop, cTop, cRight);
         }
      }
   }

   private void drawRect(class_287 buffer, Matrix4f matrix, float x1, float y1, float x2, float y2, int c1) {
      buffer.method_22918(matrix, x1, y2, 0.0F).method_39415(c1);
      buffer.method_22918(matrix, x2, y2, 0.0F).method_39415(c1);
      buffer.method_22918(matrix, x2, y1, 0.0F).method_39415(c1);
      buffer.method_22918(matrix, x1, y1, 0.0F).method_39415(c1);
   }

   private void drawRect(class_287 buffer, Matrix4f matrix, float x1, float y1, float x2, float y2, int c1, int c2, int c3, int c4) {
      buffer.method_22918(matrix, x1, y2, 0.0F).method_39415(c1);
      buffer.method_22918(matrix, x2, y2, 0.0F).method_39415(c2);
      buffer.method_22918(matrix, x2, y1, 0.0F).method_39415(c3);
      buffer.method_22918(matrix, x1, y1, 0.0F).method_39415(c4);
   }

   private @NotNull class_243[] getVectors(class_9779 tick, @NotNull class_1297 ent) {
      double x = ent.field_6014 + (ent.method_23317() - ent.field_6014) * (double)tick.method_60637(true);
      double y = ent.field_6036 + (ent.method_23318() - ent.field_6036) * (double)tick.method_60637(true);
      double z = ent.field_5969 + (ent.method_23321() - ent.field_5969) * (double)tick.method_60637(true);
      class_238 bb = ent.method_5829();
      double dx = bb.field_1323 - ent.method_23317() + x;
      double dy = bb.field_1322 - ent.method_23318() + y;
      double dz = bb.field_1321 - ent.method_23321() + z;
      double dx2 = bb.field_1320 - ent.method_23317() + x;
      double dy2 = bb.field_1325 - ent.method_23318() + y;
      double dz2 = bb.field_1324 - ent.method_23321() + z;
      return new class_243[]{new class_243(dx - 0.05, dy, dz - 0.05), new class_243(dx - 0.05, dy2 + 0.15, dz - 0.05), new class_243(dx2 + 0.05, dy, dz - 0.05), new class_243(dx2 + 0.05, dy2 + 0.15, dz - 0.05), new class_243(dx - 0.05, dy, dz2 + 0.05), new class_243(dx - 0.05, dy2 + 0.15, dz2 + 0.05), new class_243(dx2 + 0.05, dy, dz2 + 0.05), new class_243(dx2 + 0.05, dy2 + 0.15, dz2 + 0.05)};
   }
}
