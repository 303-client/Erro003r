package ru.levin.modules.render;

import java.util.Objects;
import net.minecraft.class_2761;
import net.minecraft.class_6854;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.world.EventFog;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;

@FunctionAnnotation(
   name = "World",
   desc = "Pozwala zmieniać porę dnia, pogodę i mgłę",
   type = Type.Render
)
public class World extends Function {
   private final BooleanSetting timeBox = new BooleanSetting("Zmieniaj porę dnia", true);
   private final ModeSetting timeMode;
   private final SliderSetting customTime;
   private final BooleanSetting weatherBox;
   private final ModeSetting weatherMode;
   public final BooleanSetting fog;
   public final SliderSetting fogEnd;

   public World() {
      BooleanSetting var10003 = this.timeBox;
      Objects.requireNonNull(var10003);
      this.timeMode = new ModeSetting(var10003::get, "Pora dnia", "Dzień", new String[]{"Dzień", "Noc", "Poranek", "Wschód słońca", "Własne"});
      this.customTime = new SliderSetting("Własna pora dnia", (double)6000.0F, (double)0.0F, (double)24000.0F, (double)100.0F, () -> this.timeBox.get() && this.timeMode.is("Własne"));
      this.weatherBox = new BooleanSetting("Zmieniaj pogodę", true);
      var10003 = this.weatherBox;
      Objects.requireNonNull(var10003);
      this.weatherMode = new ModeSetting(var10003::get, "Pogoda", "Bezchmurnie", new String[]{"Bezchmurnie", "Deszcz", "Burza"});
      this.fog = new BooleanSetting("Mgła", false);
      BooleanSetting var10008 = this.fog;
      Objects.requireNonNull(var10008);
      this.fogEnd = new SliderSetting("Zasięg mgły", (double)200.0F, (double)0.0F, (double)500.0F, (double)1.0F, var10008::get);
      this.addSettings(new Setting[]{this.timeBox, this.timeMode, this.customTime, this.weatherBox, this.weatherMode, this.fog, this.fogEnd});
   }

   public void onEvent(Event event) {
      if (mc.field_1687 != null) {
         if (event instanceof EventPacket) {
            EventPacket packet = (EventPacket)event;
            if (this.timeBox.get() && packet.getPacket() instanceof class_2761) {
               packet.setCancel(true);
            }
         }

         if (event instanceof EventUpdate) {
            if (this.timeBox.get()) {
               mc.field_1687.method_29089(this.resolveTime(), this.resolveTime(), false);
            }

            if (this.weatherBox.get()) {
               String fogEvent = this.weatherMode.get();
               byte var3 = -1;
               switch (fogEvent.hashCode()) {
                  case 32987411:
                     if (fogEvent.equals("Bezchmurnie")) {
                        var3 = 0;
                     }
                     break;
                  case 996723178:
                     if (fogEvent.equals("Burza")) {
                        var3 = 2;
                     }
                     break;
                  case 997579364:
                     if (fogEvent.equals("Deszcz")) {
                        var3 = 1;
                     }
               }

               switch (var3) {
                  case 0:
                     mc.field_1687.method_8519(0.0F);
                     mc.field_1687.method_8496(0.0F);
                     break;
                  case 1:
                     mc.field_1687.method_8519(1.0F);
                     mc.field_1687.method_8496(0.0F);
                     break;
                  case 2:
                     mc.field_1687.method_8519(1.0F);
                     mc.field_1687.method_8496(1.0F);
               }
            }
         }

         if (event instanceof EventFog) {
            EventFog fogEvent = (EventFog)event;
            if (this.fog.get()) {
               int themeColor = ColorUtil.gradient(15, 360, Manager.STYLE_MANAGER.getFirstColor(), Manager.STYLE_MANAGER.getSecondColor());
               fogEvent.r = (float)(themeColor >> 16 & 255) / 255.0F;
               fogEvent.g = (float)(themeColor >> 8 & 255) / 255.0F;
               fogEvent.b = (float)(themeColor & 255) / 255.0F;
               fogEvent.alpha = 1.0F;
               fogEvent.start = 0.0F;
               fogEvent.end = this.fogEnd.get().floatValue();
               fogEvent.shape = class_6854.field_36350;
               fogEvent.modified = true;
            }
         }

      }
   }

   private long resolveTime() {
      String var1 = this.timeMode.get();
      byte var2 = -1;
      switch (var1.hashCode()) {
         case -1463518049:
            if (var1.equals("Własne")) {
               var2 = 4;
            }
            break;
         case 32171536:
            if (var1.equals("Dzień")) {
               var2 = 0;
            }
            break;
         case 32448614:
            if (var1.equals("Noc")) {
               var2 = 1;
            }
            break;
         case 32630973:
            if (var1.equals("Poranek")) {
               var2 = 2;
            }
            break;
         case 803275590:
            if (var1.equals("Wschód słońca")) {
               var2 = 3;
            }
      }

      long var10000;
      switch (var2) {
         case 0 -> var10000 = 1000L;
         case 1 -> var10000 = 13000L;
         case 2 -> var10000 = 0L;
         case 3 -> var10000 = 23000L;
         case 4 -> var10000 = (long)this.customTime.get().floatValue();
         default -> var10000 = 6000L;
      }

      return var10000;
   }
}
