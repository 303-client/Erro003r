package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_7833;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_327.class_6415;
import org.joml.Matrix4f;
import ru.levin.events.Event;
import ru.levin.manager.IMinecraft;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "CrownHat",
   desc = "Neonowa korona z napisem 303 nad głową",
   type = Type.Render
)
public final class CrownHat extends Function {
   private static final int RING_SEGMENTS = 10;
   private static final float RADIUS = 0.3F;
   private static final float BAND_HEIGHT = 0.12F;
   private static final float PEAK_HEIGHT = 0.38F;
   private final ModeSetting colorMode = new ModeSetting("Kolor", "Blue-Purple", new String[]{"Blue-Purple", "Red-Green", "Rainbow"});
   private final SliderSetting color1 = new SliderSetting("Kolor 1", (double)55807.0F, (double)0.0F, (double)1.6777215E7F, (double)1.0F);
   private final SliderSetting color2 = new SliderSetting("Kolor 2", (double)1.2865023E7F, (double)0.0F, (double)1.6777215E7F, (double)1.0F);

   public CrownHat() {
      this.addSettings(new Setting[]{this.colorMode, this.color1, this.color2});
   }

   public void onEvent(Event event) {
   }

   public boolean isEnabled() {
      return this.state;
   }

   public void renderHatAttached(class_4587 matrices, class_4597 vertexConsumers, class_1657 player, float tickDelta) {
      if (this.state && player != null) {
         class_310 client = class_310.method_1551();
         if (client != null) {
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ONE, class_4534.ZERO);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            matrices.method_22903();
            matrices.method_46416(0.0F, player.method_17682() + 0.15F, 0.0F);
            this.renderCrown(matrices);
            this.renderLabel(matrices, vertexConsumers, client, 0.0F, -0.3F, 180.0F);
            this.renderLabel(matrices, vertexConsumers, client, 0.0F, 0.3F, 0.0F);
            matrices.method_22909();
            RenderSystem.depthMask(true);
            RenderSystem.enableCull();
            RenderSystem.defaultBlendFunc();
            RenderSystem.disableBlend();
         }
      }
   }

   private void renderCrown(class_4587 matrices) {
      RenderSystem.setShader(class_10142.field_53876);
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27379, class_290.field_1576);
      Matrix4f matrix = matrices.method_23760().method_23761();

      for(int i = 0; i < 10; ++i) {
         float angle1 = (float)((Math.PI * 2D) * (double)i / (double)10.0F);
         float angle2 = (float)((Math.PI * 2D) * (double)(i + 1) / (double)10.0F);
         float midAngle = (angle1 + angle2) * 0.5F;
         float x1 = (float)Math.cos((double)angle1) * 0.3F;
         float z1 = (float)Math.sin((double)angle1) * 0.3F;
         float x2 = (float)Math.cos((double)angle2) * 0.3F;
         float z2 = (float)Math.sin((double)angle2) * 0.3F;
         float peakRadius = 0.276F;
         float peakX = (float)Math.cos((double)midAngle) * peakRadius;
         float peakZ = (float)Math.sin((double)midAngle) * peakRadius;
         float peakY = i % 2 == 0 ? 0.38F : 0.18F;
         int color1 = withAlpha(this.paletteColor((float)i / 10.0F), 0.8F);
         int color2 = withAlpha(this.paletteColor((float)(i + 1) / 10.0F), 0.55F);
         buffer.method_22918(matrix, x1, 0.12F, z1).method_39415(color1);
         buffer.method_22918(matrix, x2, 0.12F, z2).method_39415(color2);
         buffer.method_22918(matrix, peakX, peakY, peakZ).method_39415(withAlpha(color1, 0.95F));
         buffer.method_22918(matrix, x1, 0.0F, z1).method_39415(withAlpha(color1, 0.72F));
         buffer.method_22918(matrix, x1, 0.12F, z1).method_39415(color1);
         buffer.method_22918(matrix, x2, 0.12F, z2).method_39415(color2);
         buffer.method_22918(matrix, x1, 0.0F, z1).method_39415(withAlpha(color1, 0.72F));
         buffer.method_22918(matrix, x2, 0.12F, z2).method_39415(color2);
         buffer.method_22918(matrix, x2, 0.0F, z2).method_39415(withAlpha(color2, 0.72F));
      }

      RenderUtil.render3D.endBuilding(buffer);
   }

   private void renderLabel(class_4587 matrices, class_4597 vertexConsumers, class_310 client, float x, float z, float yaw) {
      matrices.method_22903();
      matrices.method_46416(x, 0.29F, z);
      matrices.method_22907(class_7833.field_40716.rotationDegrees(yaw));
      matrices.method_22905(0.014F, -0.014F, 0.014F);
      class_2561 label = class_2561.method_43470("303");
      float width = (float)client.field_1772.method_27525(label);
      int color = withAlpha(this.paletteColor(0.5F), 0.98F);
      client.field_1772.method_27522(label, -width / 2.0F, -4.0F, color, false, matrices.method_23760().method_23761(), vertexConsumers, class_6415.field_33993, 0, 15728880);
      matrices.method_22909();
   }

   private int paletteColor(float position) {
      position = Math.max(0.0F, Math.min(1.0F, position));
      String mode = this.colorMode.get();
      if ("Rainbow".equals(mode)) {
         return Color.HSBtoRGB((position + (float)(System.currentTimeMillis() % 5000L) / 5000.0F) % 1.0F, 0.75F, 1.0F);
      } else {
         return "Red-Green".equals(mode) ? blend((int)this.color1.get().doubleValue(), (int)this.color2.get().doubleValue(), position) : blend((int)this.color1.get().doubleValue(), (int)this.color2.get().doubleValue(), position);
      }
   }

   private static int blend(int first, int second, float amount) {
      int r = (int)((float)(first >> 16 & 255) * (1.0F - amount) + (float)(second >> 16 & 255) * amount);
      int g = (int)((float)(first >> 8 & 255) * (1.0F - amount) + (float)(second >> 8 & 255) * amount);
      int b = (int)((float)(first & 255) * (1.0F - amount) + (float)(second & 255) * amount);
      return r << 16 | g << 8 | b;
   }

   private static int withAlpha(int color, float alpha) {
      int a = Math.max(0, Math.min(255, (int)(alpha * 255.0F)));
      return a << 24 | color & 16777215;
   }
}
