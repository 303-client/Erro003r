package ru.levin.modules.render;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1810;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;

@FunctionAnnotation(
   name = "WiciaPainting",
   desc = "Pozwala stawiać obrazy (painting) przez cobweb (wersja Wicia)",
   type = Type.Render
)
public class WiciaPainting extends Function {
   public final BooleanSetting throughCobweb = new BooleanSetting("Przez cobweb", true);
   public final BooleanSetting throughGlass = new BooleanSetting("Przez szkło", true);
   public final BooleanSetting throughPainting = new BooleanSetting("Przez obrazy", true);
   public final BooleanSetting breakCobweb = new BooleanSetting("Niszcz cobweb", false);

   public void onEvent(Event event) {
   }

   public boolean shouldHandlePaintingEntity() {
      if (mc.field_1724 == null) {
         return false;
      } else {
         return this.state && !mc.field_1724.method_7325();
      }
   }

   public boolean isPassThroughBlock(class_2680 state) {
      if (state == null) {
         return false;
      } else if (this.throughCobweb.get() && state.method_27852(class_2246.field_10343)) {
         return true;
      } else {
         if (this.throughGlass.get()) {
            class_2248 block = state.method_26204();
            String blockName = block.toString().toLowerCase();
            if (blockName.contains("glass")) {
               return true;
            }
         }

         return false;
      }
   }

   public boolean isCobweb(class_2680 state) {
      return state != null && state.method_27852(class_2246.field_10343);
   }

   public boolean shouldBreakBlock(class_2338 pos) {
      if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         if (!mc.field_1687.method_8320(pos).method_27852(class_2246.field_10343)) {
            return false;
         } else {
            class_1792 mainHandItem = mc.field_1724.method_6047().method_7909();
            class_1792 offHandItem = mc.field_1724.method_6079().method_7909();
            if (!(mainHandItem instanceof class_1743) && !(offHandItem instanceof class_1743)) {
               return !(mainHandItem instanceof class_1810) && !(offHandItem instanceof class_1810) ? this.breakCobweb.get() : false;
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   public class_3965 raycastFromCamera(float tickDelta, class_243 startPos) {
      if (mc.field_1687 != null && mc.field_1719 != null) {
         class_1297 camera = mc.field_1719;
         class_243 endPos = startPos != null ? startPos : camera.method_5836(tickDelta);
         class_243 lookVec = camera.method_5828(tickDelta);
         double reachDistance = (double)4.5F;
         if (mc.field_1724 != null) {
            reachDistance = mc.field_1724.method_55754();
         }

         class_243 rayEnd = endPos.method_1019(lookVec.method_1021(reachDistance));
         class_3959 context = new class_3959(endPos, rayEnd, class_3960.field_17559, class_242.field_1348, camera);
         class_3965 result = mc.field_1687.method_17742(context);
         return result != null && result.method_17783() != class_240.field_1333 ? result : null;
      } else {
         return null;
      }
   }

   public class_3965 skipPassThrough(float tickDelta, class_3965 originalHit) {
      if (mc.field_1687 != null && originalHit != null) {
         class_2680 blockState = mc.field_1687.method_8320(originalHit.method_17777());
         if (!this.isPassThroughBlock(blockState)) {
            return originalHit;
         } else {
            class_243 startPos = this.advancePastHit(originalHit, tickDelta);

            for(int i = 0; i < 8; ++i) {
               if (startPos == null) {
                  return null;
               }

               class_3965 hit = this.raycastFromCamera(tickDelta, startPos);
               if (hit == null) {
                  return null;
               }

               class_2680 hitState = mc.field_1687.method_8320(hit.method_17777());
               if (!this.isPassThroughBlock(hitState)) {
                  return hit;
               }

               startPos = this.advancePastHit(hit, tickDelta);
            }

            return null;
         }
      } else {
         return originalHit;
      }
   }

   public class_3965 skipCobweb(float tickDelta, class_3965 originalHit) {
      if (mc.field_1687 != null && originalHit != null) {
         class_2680 blockState = mc.field_1687.method_8320(originalHit.method_17777());
         if (!this.isCobweb(blockState)) {
            return originalHit;
         } else {
            class_243 startPos = this.advancePastHit(originalHit, tickDelta);

            for(int i = 0; i < 8; ++i) {
               if (startPos == null) {
                  return null;
               }

               class_3965 hit = this.raycastFromCamera(tickDelta, startPos);
               if (hit == null) {
                  return null;
               }

               class_2680 hitState = mc.field_1687.method_8320(hit.method_17777());
               if (!this.isCobweb(hitState)) {
                  return hit;
               }

               startPos = this.advancePastHit(hit, tickDelta);
            }

            return null;
         }
      } else {
         return originalHit;
      }
   }

   public class_243 advancePastHit(class_3965 hit, float tickDelta) {
      if (hit != null && mc.field_1719 != null) {
         class_243 rotationVec = mc.field_1719.method_5828(tickDelta);
         if (rotationVec == null) {
            return null;
         } else {
            class_243 hitPos = hit.method_17784();
            class_2338 blockPos = hit.method_17777();
            class_243 direction = rotationVec.method_1029().method_1021(0.2);

            for(int i = 0; i < 10; ++i) {
               hitPos = hitPos.method_1019(direction);
               if (!(new class_2338((int)hitPos.field_1352, (int)hitPos.field_1351, (int)hitPos.field_1350)).equals(blockPos)) {
                  break;
               }
            }

            return hitPos;
         }
      } else {
         return null;
      }
   }

   public class_243 getDirectionFromHit(class_3965 hit) {
      if (hit == null) {
         return null;
      } else {
         class_2350 side = hit.method_17780();
         class_243 blockCenter = class_243.method_24953(hit.method_17777());
         return blockCenter.method_1019(class_243.method_24954(side.method_62675()).method_1021(0.51));
      }
   }

   public class_239 raycastPaintingEntity(class_243 start, class_243 end, double reachDistance) {
      if (mc.field_1724 == null) {
         return null;
      } else if (start != null && end != null) {
         start.method_1019(end);
         class_238 box = (new class_238(start, start)).method_18804(end).method_1014((double)1.0F);
         return null;
      } else {
         return null;
      }
   }

   private boolean isPaintingEntity(class_1297 entity) {
      return entity.method_5864() == class_1299.field_6120;
   }

   public class_2350 horizontalFaceTowardCamera(class_243 blockCenter, class_243 cameraPos) {
      if (blockCenter != null && cameraPos != null) {
         class_243 diff = cameraPos.method_1020(blockCenter);
         double absX = Math.abs(diff.field_1352);
         double absZ = Math.abs(diff.field_1350);
         if (absX < absZ) {
            return diff.field_1350 >= (double)0.0F ? class_2350.field_11035 : class_2350.field_11043;
         } else {
            return diff.field_1352 >= (double)0.0F ? class_2350.field_11034 : class_2350.field_11039;
         }
      } else {
         return class_2350.field_11043;
      }
   }
}
