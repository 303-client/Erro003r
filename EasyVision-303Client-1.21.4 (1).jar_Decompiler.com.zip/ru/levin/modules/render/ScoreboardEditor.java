package ru.levin.modules.render;

import net.minecraft.class_2561;
import ru.levin.events.Event;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "ScoreboardEditor",
   desc = "Zmienia wyglad i tekst sidebaru scoreboardu",
   type = Type.Render
)
public class ScoreboardEditor extends Function {
   public final BooleanSetting useNameProtect = new BooleanSetting("Używaj NameProtect", true);
   public final TextSetting title = new TextSetting("Tytuł", "");
   public final TextSetting lines = new TextSetting("Linie", "");

   public ScoreboardEditor() {
      this.addSettings(new Setting[]{this.useNameProtect, this.title, this.lines});
   }

   public class_2561 editTitle(class_2561 original) {
      String replacement = this.title.getValue();
      return (class_2561)(replacement != null && !replacement.isBlank() ? class_2561.method_43470(this.replaceFormatting(replacement)) : original);
   }

   public class_2561 editLine(class_2561 original, int lineFromBottom) {
      String value = original.getString();
      String replacement = this.findReplacement(value);
      if (replacement != null) {
         return class_2561.method_43470(this.replaceFormatting(replacement));
      } else {
         if (this.useNameProtect.get() && ScoreboardEditor.ManagerAccess.nameProtectEnabled()) {
            String protectedValue = ScoreboardEditor.ManagerAccess.protect(value);
            if (!protectedValue.equals(value)) {
               return class_2561.method_43470(protectedValue);
            }
         }

         return original;
      }
   }

   private String findReplacement(String value) {
      String config = this.lines.getValue();
      if (config != null && !config.isBlank()) {
         for(String pair : config.split(";")) {
            int separator = pair.indexOf(61);
            if (separator > 0) {
               String from = pair.substring(0, separator).trim();
               if (from.equals(value)) {
                  return pair.substring(separator + 1).trim();
               }
            }
         }

         return null;
      } else {
         return null;
      }
   }

   private String replaceFormatting(String value) {
      return value.replace('&', '§');
   }

   public void onEvent(Event event) {
   }

   private static final class ManagerAccess {
      private static boolean nameProtectEnabled() {
         return Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.nameProtect.state;
      }

      private static String protect(String value) {
         return !nameProtectEnabled() ? value : Manager.FUNCTION_MANAGER.nameProtect.getProtectedName(value);
      }
   }
}
