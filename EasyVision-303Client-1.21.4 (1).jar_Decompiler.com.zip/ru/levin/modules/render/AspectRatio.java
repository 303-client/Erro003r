package ru.levin.modules.render;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "AspectRatio",
   desc = "Pozwala zmienić proporcje ekranu",
   type = Type.Render
)
public class AspectRatio extends Function {
   public final ModeSetting mods = new ModeSetting("Tryb", "16:9", new String[]{"4:3", "16:9", "1:1", "16:10", "Własny"});
   public final SliderSetting slider = new SliderSetting("Proporcje", (double)1.8F, (double)0.1F, (double)5.0F, (double)0.1F, () -> this.mods.is("Własny"));

   public AspectRatio() {
      this.addSettings(new Setting[]{this.mods, this.slider});
   }

   public void onEvent(Event event) {
   }
}
