package ru.levin.modules.render;

import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1511;
import net.minecraft.class_1531;
import net.minecraft.class_1533;
import net.minecraft.class_1534;
import net.minecraft.class_1542;
import net.minecraft.class_1688;
import net.minecraft.class_1690;
import net.minecraft.class_1694;
import net.minecraft.class_1696;
import net.minecraft.class_1699;
import net.minecraft.class_1700;
import net.minecraft.class_1701;
import net.minecraft.class_2573;
import net.minecraft.class_2586;
import net.minecraft.class_2595;
import net.minecraft.class_2611;
import net.minecraft.class_2614;
import net.minecraft.class_2627;
import net.minecraft.class_3719;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "EntityVisibility",
   desc = "Ukrywa encje i obiekty używane w trapach",
   type = Type.Render
)
public class EntityVisibility extends Function {
   public final BooleanSetting armorStands = new BooleanSetting("Armor standy", true);
   public final BooleanSetting boats = new BooleanSetting("Łódki", true);
   public final BooleanSetting chestMinecarts = new BooleanSetting("Wagoniki ze skrzynią", true);
   public final BooleanSetting furnaceMinecarts = new BooleanSetting("Wagoniki z piecem", true);
   public final BooleanSetting hopperMinecarts = new BooleanSetting("Wagoniki z hopperem", true);
   public final BooleanSetting tntMinecarts = new BooleanSetting("Wagoniki z TNT", true);
   public final BooleanSetting spawnerMinecarts = new BooleanSetting("Wagoniki ze spawnerem", true);
   public final BooleanSetting otherMinecarts = new BooleanSetting("Pozostałe wagoniki", true);
   public final BooleanSetting itemFrames = new BooleanSetting("Item frame", true);
   public final BooleanSetting paintings = new BooleanSetting("Obrazy", true);
   public final BooleanSetting mobs = new BooleanSetting("Moby", true);
   public final BooleanSetting items = new BooleanSetting("Itemy", true);
   public final BooleanSetting crystals = new BooleanSetting("Kryształy", true);
   public final BooleanSetting containers = new BooleanSetting("Skrzynie i kontenery", true);
   public final BooleanSetting banners = new BooleanSetting("Banery", true);

   public EntityVisibility() {
      this.addSettings(new Setting[]{this.armorStands, this.boats, this.chestMinecarts, this.furnaceMinecarts, this.hopperMinecarts, this.tntMinecarts, this.spawnerMinecarts, this.otherMinecarts, this.itemFrames, this.paintings, this.mobs, this.items, this.crystals, this.containers, this.banners});
   }

   public boolean shouldHideEntity(class_1297 entity) {
      if (this.state && entity != null) {
         if (entity instanceof class_1531) {
            return this.armorStands.get();
         } else if (entity instanceof class_1690) {
            return this.boats.get();
         } else if (entity instanceof class_1694) {
            return this.chestMinecarts.get();
         } else if (entity instanceof class_1696) {
            return this.furnaceMinecarts.get();
         } else if (entity instanceof class_1700) {
            return this.hopperMinecarts.get();
         } else if (entity instanceof class_1701) {
            return this.tntMinecarts.get();
         } else if (entity instanceof class_1699) {
            return this.spawnerMinecarts.get();
         } else if (entity instanceof class_1688) {
            return this.otherMinecarts.get();
         } else if (entity instanceof class_1533) {
            return this.itemFrames.get();
         } else if (entity instanceof class_1534) {
            return this.paintings.get();
         } else if (entity instanceof class_1308) {
            return this.mobs.get();
         } else if (entity instanceof class_1542) {
            return this.items.get();
         } else {
            return entity instanceof class_1511 ? this.crystals.get() : false;
         }
      } else {
         return false;
      }
   }

   public boolean shouldHideBlockEntity(class_2586 blockEntity) {
      if (this.state && blockEntity != null) {
         if (blockEntity instanceof class_2573) {
            return this.banners.get();
         } else {
            return this.containers.get() && (blockEntity instanceof class_2595 || blockEntity instanceof class_2611 || blockEntity instanceof class_3719 || blockEntity instanceof class_2614 || blockEntity instanceof class_2627);
         }
      } else {
         return false;
      }
   }

   public void onEvent(Event event) {
   }
}
