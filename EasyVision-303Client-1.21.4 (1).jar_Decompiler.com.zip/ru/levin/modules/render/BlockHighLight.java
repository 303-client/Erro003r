package ru.levin.modules.render;

import net.minecraft.class_2338;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import net.minecraft.class_239.class_240;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.render.Render3DUtil;

@FunctionAnnotation(
   name = "BlockHighLight",
   desc = "Podświetla blok, na który wskazujesz",
   type = Type.Render
)
public class BlockHighLight extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventRender3D e) {
         class_239 var4 = mc.field_1765;
         if (var4 instanceof class_3965 result) {
            if (result.method_17783() == class_240.field_1332) {
               class_2338 pos = result.method_17777();
               if (pos != null) {
                  Render3DUtil.drawShapeAlternative(pos, mc.field_1687.method_8320(pos).method_26218(mc.field_1687, pos), ColorUtil.getColorStyle(360.0F), 2.0F, true, true);
               }
            }
         }
      }
   }
}
