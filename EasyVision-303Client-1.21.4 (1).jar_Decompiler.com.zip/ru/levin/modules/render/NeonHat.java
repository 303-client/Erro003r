package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import net.minecraft.class_10142;
import net.minecraft.class_1304;
import net.minecraft.class_1657;
import net.minecraft.class_1738;
import net.minecraft.class_1799;
import net.minecraft.class_243;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_310;
import net.minecraft.class_315;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5498;
import net.minecraft.class_746;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import org.lwjgl.opengl.GL11;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ChinaHat",
   desc = "Półprzezroczysty stożek z cyjanowo-fioletową siatką",
   type = Type.Render
)
public final class NeonHat extends Function {
   private static final int RIM_SEGMENTS = 64;
   private static final int RADIAL_LINES = 24;
   private static final float HAT_RADIUS = 0.79F;
   private static final float HAT_HEIGHT = 0.34F;
   private final ModeSetting colorMode = new ModeSetting("Kolor", "Blue-Purple", new String[]{"Blue-Purple", "Red-Green", "Rainbow"});
   private final SliderSetting color1 = new SliderSetting("Kolor 1", (double)55807.0F, (double)0.0F, (double)1.6777215E7F, (double)1.0F);
   private final SliderSetting color2 = new SliderSetting("Kolor 2", (double)1.2397567E7F, (double)0.0F, (double)1.6777215E7F, (double)1.0F);

   public NeonHat() {
      this.addSettings(new Setting[]{this.colorMode, this.color1, this.color2});
   }

   public void onEvent(Event var1) {
   }

   public boolean isEnabled() {
      return this.state;
   }

   public int getColor1() {
      return this.color1.get().intValue();
   }

   public int getColor2() {
      return this.color2.get().intValue();
   }

   public String getColorMode() {
      return this.colorMode.get();
   }

   public void renderHatAttached(class_4587 var1, class_4597 var2, class_1657 var3, float var4) {
      if (this.state && var3 != null) {
         class_310 var5 = class_310.method_1551();
         class_315 var6 = var5.field_1690;
         class_5498 var7 = var6.method_31044();
         if (!var7.method_31034()) {
            RenderSystem.enableBlend();
            RenderSystem.blendFuncSeparate(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA, class_4535.ONE, class_4534.ZERO);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.disableCull();
            var1.method_22903();

            try {
               var1.method_46416(0.0F, var3.method_17682() + this.getYOffset(var3), 0.0F);
               this.renderCap(var1);
            } finally {
               var1.method_22909();
               RenderSystem.depthMask(true);
               RenderSystem.enableCull();
               RenderSystem.defaultBlendFunc();
               RenderSystem.depthFunc(513);
            }

         }
      }
   }

   public void renderHat(class_4587 var1) {
      class_310 var2 = class_310.method_1551();
      class_746 var3 = var2.field_1724;
      if (this.state && var3 != null) {
         class_315 var4 = var2.field_1690;
         if (!var4.method_31044().method_31034()) {
            class_243 var5 = ((class_1657)var3).method_30950(1.0F);
            var1.method_22903();
            var1.method_22904(var5.field_1352, var5.field_1351 + (double)((class_1657)var3).method_17682() + (double)this.getYOffset(var3), var5.field_1350);
            this.renderCap(var1);
            var1.method_22909();
         }
      }
   }

   private float getYOffset(class_1657 var1) {
      class_1799 var2 = var1.method_6118(class_1304.field_6169);
      return var2.method_7909() instanceof class_1738 ? 0.06F : 0.012F;
   }

   private void renderCap(class_4587 var1) {
      this.renderSurface(var1);
      this.renderGrid(var1);
   }

   private void renderSurface(class_4587 var1) {
      RenderSystem.setShader(class_10142.field_53876);
      class_287 var2 = class_289.method_1348().method_60827(class_5596.field_27381, class_290.field_1576);
      Matrix4f var3 = var1.method_23760().method_23761();
      var2.method_22918(var3, 0.0F, 0.34F, 0.0F).method_39415(withAlpha(this.paletteColor(0.5F), 0.42F));

      for(int var4 = 0; var4 <= 64; ++var4) {
         float var5 = (float)((Math.PI * 2D) * (double)var4 / (double)64.0F);
         float var6 = (float)Math.cos((double)var5) * 0.79F;
         float var7 = (float)Math.sin((double)var5) * 0.79F;
         float var8 = (var6 / 0.79F + 1.0F) * 0.5F;
         int var9 = this.paletteColor(var8);
         float var10 = var4 % 4 == 0 ? 0.3F : 0.22F;
         var2.method_22918(var3, var6, 0.0F, var7).method_39415(withAlpha(var9, var10));
      }

      class_286.method_43433(var2.method_60800());
   }

   private void renderGrid(class_4587 var1) {
      RenderSystem.setShader(class_10142.field_53864);
      RenderSystem.lineWidth(1.65F);
      GL11.glEnable(2848);
      GL11.glHint(3154, 4354);
      class_287 var2 = class_289.method_1348().method_60827(class_5596.field_27377, class_290.field_29337);
      class_4587.class_4665 var3 = var1.method_23760();

      for(int var4 = 0; var4 < 24; ++var4) {
         float var5 = (float)((Math.PI * 2D) * (double)var4 / (double)24.0F);
         float var6 = (float)Math.cos((double)var5) * 0.79F;
         float var7 = (float)Math.sin((double)var5) * 0.79F;
         int var8 = withAlpha(this.paletteColor((var6 / 0.79F + 1.0F) * 0.5F), 0.64F);
         this.lineVertex(var2, var3, 0.0F, 0.34F, 0.0F, var8);
         this.lineVertex(var2, var3, var6, 0.004F, var7, var8);
      }

      for(int var17 = 1; var17 <= 2; ++var17) {
         float var19 = (float)var17 / 3.0F;
         float var21 = 0.79F * var19;
         float var23 = 0.34F * (1.0F - var19);

         for(int var25 = 0; var25 < 64; ++var25) {
            float var9 = (float)((Math.PI * 2D) * (double)var25 / (double)64.0F);
            float var10 = (float)((Math.PI * 2D) * (double)(var25 + 1) / (double)64.0F);
            float var11 = (float)Math.cos((double)var9) * var21;
            float var12 = (float)Math.sin((double)var9) * var21;
            float var13 = (float)Math.cos((double)var10) * var21;
            float var14 = (float)Math.sin((double)var10) * var21;
            int var15 = withAlpha(this.paletteColor((var11 / 0.79F + 1.0F) * 0.5F), 0.34F);
            int var16 = withAlpha(this.paletteColor((var13 / 0.79F + 1.0F) * 0.5F), 0.34F);
            this.lineVertex(var2, var3, var11, var23, var12, var15);
            this.lineVertex(var2, var3, var13, var23, var14, var16);
         }
      }

      for(int var18 = 0; var18 < 64; ++var18) {
         float var20 = (float)((Math.PI * 2D) * (double)var18 / (double)64.0F);
         float var22 = (float)((Math.PI * 2D) * (double)(var18 + 1) / (double)64.0F);
         float var24 = (float)Math.cos((double)var20) * 0.79F;
         float var26 = (float)Math.sin((double)var20) * 0.79F;
         float var27 = (float)Math.cos((double)var22) * 0.79F;
         float var28 = (float)Math.sin((double)var22) * 0.79F;
         int var29 = withAlpha(this.paletteColor((var24 / 0.79F + 1.0F) * 0.5F), 0.94F);
         int var30 = withAlpha(this.paletteColor((var27 / 0.79F + 1.0F) * 0.5F), 0.94F);
         this.lineVertex(var2, var3, var24, 0.006F, var26, var29);
         this.lineVertex(var2, var3, var27, 0.006F, var28, var30);
      }

      class_286.method_43433(var2.method_60800());
      GL11.glDisable(2848);
      RenderSystem.lineWidth(1.0F);
   }

   private void lineVertex(class_287 var1, class_4587.class_4665 var2, float var3, float var4, float var5, int var6) {
      var1.method_56824(var2, var3, var4, var5).method_39415(var6).method_60831(var2, 0.0F, 1.0F, 0.0F);
   }

   private int paletteColor(float var1) {
      float var2 = Math.max(0.0F, Math.min(1.0F, var1));
      String var3 = this.colorMode.get();
      if ("Rainbow".equals(var3)) {
         float var9 = (var2 + (float)(System.currentTimeMillis() % 12000L) / 12000.0F) % 1.0F;
         return Color.HSBtoRGB(var9, 0.82F, 1.0F) & 16777215;
      } else {
         int var4 = this.getColor1();
         int var5 = this.getColor2();
         if ("Red-Green".equals(var3)) {
            var4 = 16729976;
            var5 = 5570459;
         }

         int var6 = (int)((float)(var4 >> 16 & 255) * (1.0F - var2) + (float)(var5 >> 16 & 255) * var2);
         int var7 = (int)((float)(var4 >> 8 & 255) * (1.0F - var2) + (float)(var5 >> 8 & 255) * var2);
         int var8 = (int)((float)(var4 & 255) * (1.0F - var2) + (float)(var5 & 255) * var2);
         return var6 << 16 | var7 << 8 | var8;
      }
   }

   private static int withAlpha(int var0, float var1) {
      int var2 = Math.max(0, Math.min(255, (int)(var1 * 255.0F)));
      return var2 << 24 | var0 & 16777215;
   }
}
