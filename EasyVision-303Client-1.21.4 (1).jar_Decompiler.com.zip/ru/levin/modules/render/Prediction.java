package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_1682;
import net.minecraft.class_1684;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_3486;
import net.minecraft.class_3959;
import net.minecraft.class_4587;
import net.minecraft.class_4588;
import net.minecraft.class_239.class_240;
import net.minecraft.class_293.class_5596;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.joml.Matrix4f;
import org.joml.Vector3d;
import org.joml.Vector3f;
import org.lwjgl.opengl.GL11;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.shader.ShaderManager;
import ru.levin.util.vector.VectorUtil;

@FunctionAnnotation(
   name = "PearlTracker",
   type = Type.Render,
   desc = "Śledzi trajektorię ender pereł i pokazuje miejsce lądowania"
)
public class Prediction extends Function {
   private final BooleanSetting box = new BooleanSetting("Punkt lądowania", false);
   private final BooleanSetting rect = new BooleanSetting("Ramka przy czasie", false);
   private final BooleanSetting trajectory = new BooleanSetting("Trajektoria", true);
   private final BooleanSetting landingTime = new BooleanSetting("Czas lądowania", true);
   private final BooleanSetting dots = new BooleanSetting("Kropki trajektorii", true);
   private final SliderSetting steps = new SliderSetting("Kroki symulacji", (double)150.0F, (double)25.0F, (double)300.0F, (double)1.0F);
   private static final class_1799 ENDER_PEARL_STACK;
   private static final Color BOX_COLOR;
   private static final int MAX_STEPS = 150;
   private static final float FADE_LEN = 6.0F;
   private final List<PearlPoint> pearlPoints = new ArrayList();

   public Prediction() {
      this.addSettings(new Setting[]{this.box, this.rect, this.trajectory, this.landingTime, this.dots, this.steps});
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender2D render2D) {
         for(PearlPoint pearlPoint : this.pearlPoints) {
            Vector3d projection = VectorUtil.toScreen(pearlPoint.position.field_1352, pearlPoint.position.field_1351 - (double)0.3F, pearlPoint.position.field_1350);
            if (projection != null && !(projection.z < (double)0.0F)) {
               double time = (double)pearlPoint.ticks * 0.05;
               String text = String.format("%.1f s", time);
               float fontHeight = FontUtils.durman[15].getHeight();
               float textWidth = FontUtils.durman[15].getWidth(text);
               float paddingX = 3.0F;
               float bgWidth = textWidth + paddingX * 2.0F;
               float bgHeight = fontHeight + 1.0F;
               float centerX = (float)projection.x;
               float centerY = (float)projection.y;
               float bgX = centerX - bgWidth / 2.0F;
               if (this.landingTime.get()) {
                  RenderUtil.drawRoundedRect(render2D.getMatrixStack(), bgX, centerY, bgWidth, bgHeight, 2.0F, -1308227822);
                  float textX = centerX - textWidth / 2.0F;
                  float textY = centerY + (bgHeight - fontHeight) / 2.0F;
                  FontUtils.durman[15].drawLeftAligned(render2D.getDrawContext().method_51448(), text, textX, textY, -1);
               }

               float pearlSize = 11.0F;
               float pearlX = centerX - pearlSize / 2.0F;
               float pearlY = centerY - pearlSize - 2.0F;
               if (this.rect.get() && this.landingTime.get()) {
                  RenderUtil.drawRoundedRect(render2D.getMatrixStack(), pearlX - 0.5F, pearlY - 0.2F, 12.0F, 12.0F, 2.0F, -1308227822);
               }

               RenderAddon.renderItem(render2D.getDrawContext(), ENDER_PEARL_STACK, pearlX, pearlY, pearlSize / 16.0F, false);
            }
         }
      }

      if (event instanceof EventRender3D e3d) {
         this.renderTrajectories(e3d);
      }

   }

   private void renderTrajectories(EventRender3D event) {
      if (this.trajectory.get()) {
         class_4587 stack = event.getMatrixStack();
         class_243 cameraPos = mc.method_1561().field_4686.method_19326();
         stack.method_22903();
         stack.method_22904(-cameraPos.field_1352, -cameraPos.field_1351, -cameraPos.field_1350);
         GL11.glEnable(2881);
         RenderSystem.disableDepthTest();
         RenderSystem.disableCull();
         RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
         RenderSystem.setShader(class_10142.field_53864);
         RenderSystem.lineWidth(3.0F);
         class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27377, class_290.field_29337);
         this.pearlPoints.clear();

         for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
            if (entity instanceof class_1684) {
               class_1684 enderPearlEntity = (class_1684)entity;
               this.simulatePearl(stack, buffer, enderPearlEntity);
            }
         }

         RenderUtil.render3D.endBuilding(buffer);
         if (this.box.get()) {
            RenderSystem.setShader(class_10142.field_53876);

            for(PearlPoint pearlPoint : this.pearlPoints) {
               class_243 pos = pearlPoint.position;
               class_238 outlineBox = new class_238(pos.field_1352 - 0.15, pos.field_1351 - 0.15, pos.field_1350 - 0.15, pos.field_1352 + 0.15, pos.field_1351 + 0.15, pos.field_1350 + 0.15);
               RenderUtil.render3D.drawHoleOutline(outlineBox, BOX_COLOR.getRGB(), 1.0F);
            }
         }

         RenderUtil.disableRender();
         RenderSystem.enableDepthTest();
         RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
         RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
         GL11.glDisable(2881);
         stack.method_22909();
      }
   }

   private void simulatePearl(class_4587 stack, class_287 buffer, class_1684 pearl) {
      class_243 motion = pearl.method_18798();
      class_243 pos = pearl.method_19538();
      int ticks = 0;
      float dist = 0.0F;
      int baseRGB = ColorUtil.getColorStyle(360.0F) & 16777215;
      int maxSteps = Math.min(300, this.steps.get().intValue());

      for(int i = 0; i < maxSteps; ++i) {
         class_243 prevPos = pos;
         pos = pos.method_1019(motion);
         motion = this.getNextMotion(pearl, prevPos, motion);
         class_239 hitResult = mc.field_1687.method_17742(new class_3959(prevPos, pos, class_3960.field_17558, class_242.field_1348, pearl));
         if (hitResult.method_17783() == class_240.field_1332) {
            pos = hitResult.method_17784();
         }

         float segLen = (float)prevPos.method_1022(pos);
         float a1 = MathUtil.smoothstep(0.0F, 6.0F, dist);
         float a2 = MathUtil.smoothstep(0.0F, 6.0F, dist + segLen);
         int c1 = ColorUtil.withAlpha(baseRGB, a1);
         int c2 = ColorUtil.withAlpha(baseRGB, a2);
         if (this.dots.get() || i == 0 || i == maxSteps - 1) {
            this.vertexLineGradient(stack, buffer, (float)prevPos.field_1352, (float)prevPos.field_1351, (float)prevPos.field_1350, (float)pos.field_1352, (float)pos.field_1351, (float)pos.field_1350, c1, c2);
         }

         dist += segLen;
         if (hitResult.method_17783() == class_240.field_1332 || pos.field_1351 < (double)-128.0F) {
            this.pearlPoints.add(new PearlPoint(pos, ticks));
            break;
         }

         ++ticks;
      }

   }

   private void vertexLineGradient(class_4587 matrices, class_4588 buffer, float x1, float y1, float z1, float x2, float y2, float z2, int color1, int color2) {
      Matrix4f model = matrices.method_23760().method_23761();
      float[] col1 = ColorUtil.rgba(color1);
      float[] col2 = ColorUtil.rgba(color2);
      Vector3f normalVec = ShaderManager.getNormal(x1, y1, z1, x2, y2, z2);
      buffer.method_22918(model, x1, y1, z1).method_22915(col1[0], col1[1], col1[2], col1[3]).method_60831(matrices.method_23760(), normalVec.x(), normalVec.y(), normalVec.z());
      buffer.method_22918(model, x2, y2, z2).method_22915(col2[0], col2[1], col2[2], col2[3]).method_60831(matrices.method_23760(), normalVec.x(), normalVec.y(), normalVec.z());
   }

   private class_243 getNextMotion(class_1682 throwable, class_243 prevPos, class_243 motion) {
      boolean isInWater = mc.field_1687.method_8320(class_2338.method_49638(prevPos)).method_26227().method_15767(class_3486.field_15517);
      motion = motion.method_1021(isInWater ? 0.8 : 0.99);
      if (!throwable.method_5740()) {
         motion = motion.method_1031((double)0.0F, (double)-0.03F, (double)0.0F);
      }

      return motion;
   }

   static {
      ENDER_PEARL_STACK = new class_1799(class_1802.field_8634);
      BOX_COLOR = new Color(255, 255, 255, 255);
   }

   static record PearlPoint(class_243 position, int ticks) {
   }
}
