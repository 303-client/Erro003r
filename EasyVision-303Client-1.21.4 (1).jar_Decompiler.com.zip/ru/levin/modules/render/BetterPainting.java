package ru.levin.modules.render;

import net.minecraft.class_2246;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "BetterPainting",
   desc = "Pozwala celować i używać przedmiotów przez cobweb",
   type = Type.Render
)
public class BetterPainting extends Function {
   public final BooleanSetting throughCobweb = new BooleanSetting("Przez cobweb", true);
   public final BooleanSetting protectCobweb = new BooleanSetting("Nie niszcz cobwebu", true);
   public final ModeSetting mode = new ModeSetting("Tryb", "Exosware", new String[]{"Exosware", "Fast"});

   public BetterPainting() {
      this.addSettings(new Setting[]{this.mode, this.throughCobweb, this.protectCobweb});
   }

   public boolean isPassThrough(class_2680 state) {
      return state != null && this.throughCobweb.get() && state.method_27852(class_2246.field_10343);
   }

   public class_3965 skipCobweb(class_3965 hit) {
      if (mc.field_1687 != null && hit != null && hit.method_17777() != null && this.isPassThrough(mc.field_1687.method_8320(hit.method_17777()))) {
         class_243 direction = mc.method_1560() == null ? class_243.field_1353 : mc.method_1560().method_5828(1.0F);
         if (direction.method_1027() == (double)0.0F) {
            return hit;
         } else {
            class_3965 result = hit;

            for(int index = 0; index < (this.mode.is("Fast") ? 8 : 1); ++index) {
               if (result == null || result.method_17777() == null || !this.isPassThrough(mc.field_1687.method_8320(result.method_17777()))) {
                  return result;
               }

               class_243 start = class_243.method_24953(result.method_17777()).method_1019(direction.method_1021(0.71));
               class_243 end = start.method_1019(direction.method_1021((double)16.0F));
               result = mc.field_1687.method_17742(new class_3959(start, end, class_3960.field_17559, class_242.field_1348, mc.method_1560()));
            }

            return result;
         }
      } else {
         return hit;
      }
   }

   public class_3965 findFastTarget() {
      if (this.state && this.mode.is("Fast") && mc.field_1687 != null && mc.method_1560() != null) {
         class_3965 hit = mc.field_1687.method_17742(new class_3959(mc.method_1560().method_5836(1.0F), mc.method_1560().method_5836(1.0F).method_1019(mc.method_1560().method_5828(1.0F).method_1021((double)8.0F)), class_3960.field_17559, class_242.field_1348, mc.method_1560()));
         if (hit != null && hit.method_17777() != null) {
            class_3965 target = this.skipCobweb(hit);
            return target != null && target.method_17777() != null && !this.isPassThrough(mc.field_1687.method_8320(target.method_17777())) ? target : null;
         } else {
            return null;
         }
      } else {
         return null;
      }
   }

   public boolean shouldProtect(class_2680 state) {
      return this.protectCobweb.get() && this.isPassThrough(state);
   }

   public void onEvent(Event event) {
   }
}
