package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_10142;
import net.minecraft.class_1657;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_7833;
import net.minecraft.class_2350.class_2352;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.util.animations.Animation;
import ru.levin.util.animations.impl.EaseBackIn;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.player.TimerUtil;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "Breadcrumbs",
   type = Type.Render,
   desc = "Efektowne okręgi podczas ruchu"
)
public class Breadcrumbs extends Function {
   private final class_2960 IMAGE = class_2960.method_60655("exosware", "images/circles/circles5.png");
   private final List<Circle> circles = new ArrayList();
   private final Map<class_1657, TimerUtil> spawnTimers = new HashMap();

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         this.circles.removeIf((c) -> c.timer.getTime() > 8000L);
         class_243 velocity = mc.field_1724.method_18798();
         boolean isMoving = velocity.field_1352 * velocity.field_1352 + velocity.field_1350 * velocity.field_1350 > 0.001;
         TimerUtil spawnTimer = (TimerUtil)this.spawnTimers.computeIfAbsent(mc.field_1724, (p) -> new TimerUtil());
         if (isMoving && mc.field_1724.method_24828() && spawnTimer.hasTimeElapsed(150L)) {
            spawnTimer.reset();
            class_243 spawnPos = new class_243(mc.field_1724.method_23317(), Math.floor(mc.field_1724.method_23318()) + (double)0.001F, mc.field_1724.method_23321());
            Circle circle = new Circle(spawnPos, new TimerUtil(), new EaseBackIn(400, (double)1.0F, 1.3F));
            circle.animation.setDirection(class_2352.field_11056);
            circle.yaw = getYawFromVelocity(velocity);
            this.circles.add(circle);
         }
      }

      if (event instanceof EventRender3D render3D) {
         this.render(render3D);
      }

   }

   private static float getYawFromVelocity(class_243 velocity) {
      if (velocity.method_1027() < 1.0E-4) {
         return 0.0F;
      } else {
         double dx = velocity.field_1352;
         double dz = velocity.field_1350;
         return (float)(-(Math.atan2(dx, dz) * (180D / Math.PI)));
      }
   }

   private void render(EventRender3D eventRender3D) {
      Collections.reverse(this.circles);
      eventRender3D.getMatrixStack().method_22903();
      RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
      RenderSystem.enableDepthTest();
      RenderSystem.depthMask(false);
      RenderSystem.setShaderTexture(0, this.IMAGE);
      RenderSystem.setShader(class_10142.field_53880);
      class_287 buffer = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);

      for(Circle c : this.circles) {
         float elapsed = (float)c.timer.getTime();
         float alphaFade = MathUtil.clamp(1.0F - elapsed / 1200.0F, 0.0F, 1.0F);
         float animScale = (float)c.animation.getOutput();
         eventRender3D.getMatrixStack().method_22903();
         eventRender3D.getMatrixStack().method_22904(c.pos.field_1352 - mc.method_1561().field_4686.method_19326().method_10216(), c.pos.field_1351 - mc.method_1561().field_4686.method_19326().method_10214(), c.pos.field_1350 - mc.method_1561().field_4686.method_19326().method_10215());
         eventRender3D.getMatrixStack().method_22907(class_7833.field_40714.rotationDegrees(90.0F));
         eventRender3D.getMatrixStack().method_22907(class_7833.field_40718.rotationDegrees(c.yaw - 180.0F));
         RenderAddon.sizeAnimation(eventRender3D.getMatrixStack(), (double)0.0F, (double)0.0F, (double)(animScale * 0.45F));
         float size = 1.0F;
         Matrix4f matrix = eventRender3D.getMatrixStack().method_23760().method_23761();
         buffer.method_22918(matrix, -size, size, 0.0F).method_22913(0.0F, 1.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(270.0F), alphaFade));
         buffer.method_22918(matrix, size - 0.3F, size, 0.0F).method_22913(1.0F, 1.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(0.0F), alphaFade));
         buffer.method_22918(matrix, size - 0.3F, -size, 0.0F).method_22913(1.0F, 0.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(180.0F), alphaFade));
         buffer.method_22918(matrix, -size, -size, 0.0F).method_22913(0.0F, 0.0F).method_39415(RenderUtil.applyOpacity(ColorUtil.getColorStyle(90.0F), alphaFade));
         eventRender3D.getMatrixStack().method_22909();
      }

      RenderUtil.render3D.endBuilding(buffer);
      RenderSystem.depthMask(true);
      RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
      RenderSystem.disableDepthTest();
      RenderSystem.disableBlend();
      eventRender3D.getMatrixStack().method_22909();
      Collections.reverse(this.circles);
   }

   static class Circle {
      private final class_243 pos;
      private final TimerUtil timer;
      private final Animation animation;
      private float yaw;

      public Circle(class_243 pos, TimerUtil timer, Animation animation) {
         this.pos = pos;
         this.timer = timer;
         this.animation = animation;
      }

      public class_243 pos() {
         return this.pos;
      }

      public TimerUtil timer() {
         return this.timer;
      }

      public Animation animation() {
         return this.animation;
      }

      public float yaw() {
         return this.yaw;
      }
   }
}
