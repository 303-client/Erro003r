package ru.levin.modules.render;

import it.unimi.dsi.fastutil.objects.Object2IntMap;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.class_1074;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1739;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1809;
import net.minecraft.class_1887;
import net.minecraft.class_2480;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_6880;
import net.minecraft.class_746;
import net.minecraft.class_9288;
import net.minecraft.class_9290;
import net.minecraft.class_9334;
import net.minecraft.class_327.class_6415;
import org.joml.Vector3d;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.Manager;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.providers.ResourceProvider;
import ru.levin.util.vector.EntityPosition;
import ru.levin.util.vector.VectorUtil;

@FunctionAnnotation(
   name = "NameTags",
   desc = "Etykiety nad graczami",
   type = Type.Render
)
public class NameTags extends Function {
   public final MultiSetting tags = new MultiSetting("Encje", Arrays.asList("Gracze"), new String[]{"Gracze", "Przedmioty na ziemi"});
   private final BooleanSetting armorRender = new BooleanSetting("Pokazuj przedmioty", true, () -> this.tags.get("Gracze"));
   private final BooleanSetting effectRender = new BooleanSetting("Pokazuj efekty", true, () -> this.tags.get("Gracze"));
   private final BooleanSetting enchantRender = new BooleanSetting("Pokazuj zaklęcia", true, () -> this.tags.get("Gracze"));
   private final BooleanSetting loreRender = new BooleanSetting("Pokazuj opis przedmiotu", true, () -> this.tags.get("Gracze"));
   private final BooleanSetting sphereRender = new BooleanSetting("Pokazuj kule/talizmany", true, () -> this.tags.get("Gracze"));
   private final BooleanSetting shulkerCheck = new BooleanSetting("Pokazuj zawartość shulkerów", true, () -> this.tags.get("Przedmioty na ziemi"));
   private static final int BG_COLOR = (new Color(30, 30, 30, 150)).getRGB();
   private static final Set<String> IMPORTANT_ENCHANTS = Set.of("Protection", "Ochrona", "Unbreaking", "Wytrzymałość", "Looting", "Grabież", "Fortune", "Szczęście", "Efficiency", "Wydajność", "Power", "Siła", "Feather Falling", "Upadek pióra", "Thorns", "Ciernie", "Silk Touch", "Jedwabny dotyk", "Respiration", "Oddychanie pod wodą", "Mending", "Naprawa", "Knockback", "Odrzut", "Curse of Vanishing", "Klątwa znikania");

   public NameTags() {
      this.addSettings(new Setting[]{this.tags, this.armorRender, this.effectRender, this.enchantRender, this.loreRender, this.sphereRender, this.shulkerCheck});
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender2D e) {
         if (this.tags.get("Gracze")) {
            this.renderPlayers(e);
         }

         if (this.tags.get("Przedmioty na ziemi")) {
            this.renderItems(e);
         }
      }

   }

   private void renderPlayers(EventRender2D e) {
      int screenW = mc.method_22683().method_4486();
      int screenH = mc.method_22683().method_4502();
      float tickDelta = e.getDeltatick().method_60637(true);
      class_4587 matrixStack = e.getMatrixStack();

      for(class_1657 player : Manager.SYNC_MANAGER.getPlayers()) {
         if (player != null && (!(player instanceof class_746) || !mc.field_1690.method_31044().method_31034())) {
            Vector3d vec = VectorUtil.toScreen(EntityPosition.get(player, 2.0F, tickDelta));
            if (!(vec.z < (double)0.0F) && !(vec.x < (double)0.0F) && !(vec.x > (double)screenW) && !(vec.y < (double)0.0F) && !(vec.y > (double)screenH)) {
               boolean isClientUser = Manager.FUNCTION_MANAGER.globals.isClientUserCache.containsKey(player.method_5667());
               String friendPrefix = Manager.FRIEND_MANAGER.isFriend(player.method_5477().getString()) ? String.valueOf(class_124.field_1080) + "[" + String.valueOf(class_124.field_1060) + "F" + String.valueOf(class_124.field_1080) + "] " : "";
               float health = player.method_6032() + player.method_6067();
               String var10000 = String.valueOf(class_124.field_1080);
               String hpText = var10000 + " [" + (health < 300.0F ? class_124.field_1061.toString() + (int)health : String.valueOf(class_124.field_1061) + "Unknown") + String.valueOf(class_124.field_1080) + "]" + String.valueOf(class_124.field_1070);
               String name = Manager.FUNCTION_MANAGER.nameProtect.getProtectedName(player.method_7334().getName());
               class_2561 prefix = (class_2561)(player.method_5781() != null ? player.method_5781().method_1144() : class_2561.method_43470(""));
               class_2561 itemText = null;
               if (this.sphereRender.get()) {
                  class_1799 offHand = player.method_6079();
                  if (!offHand.method_7960() && (offHand.method_7909() == class_1802.field_8288 || offHand.method_7909() instanceof class_1809)) {
                     class_2561 customName = offHand.method_65130();
                     if (customName != null) {
                        itemText = customName;
                     }
                  }
               }

               float iconWidth = isClientUser ? 12.0F : 0.0F;
               float friendWidth = (float)mc.field_1772.method_27525(class_2561.method_43470(friendPrefix)) * 0.7F;
               float prefixWidth = (float)mc.field_1772.method_27525(prefix) * 0.7F;
               float nameHpWidth = FontUtils.durman[13].getWidth(name + hpText);
               float itemWidth = itemText != null ? (float)mc.field_1772.method_27525(itemText) * 0.7F + 3.0F : 0.0F;
               float totalWidth = iconWidth + friendWidth + prefixWidth + nameHpWidth + itemWidth;
               float x = (float)vec.x - (totalWidth + 8.0F) / 2.0F;
               float y = (float)vec.y - 14.0F - 1.0F;
               RenderUtil.drawRoundedRect(matrixStack, x, y, totalWidth + 8.0F, 12.0F, 1.5F, BG_COLOR);
               class_4587 matrices = e.getDrawContext().method_51448();
               matrices.method_22903();
               matrices.method_46416(x + 4.0F, y + 3.2F, 0.0F);
               matrices.method_22905(0.7F, 0.7F, 1.0F);
               int dx = 0;
               if (isClientUser) {
                  RenderUtil.drawTexture(matrices, "images/hud/tags.png", (float)dx, -2.0F, 12.0F, 12.0F, 0.0F, Color.white.getRGB());
                  dx = (int)((float)dx + iconWidth / 0.7F + 2.0F);
               }

               if (!friendPrefix.isEmpty()) {
                  mc.field_1772.method_27522(class_2561.method_43470(friendPrefix), (float)dx, 0.0F, -1, false, matrices.method_23760().method_23761(), mc.method_22940().method_23000(), class_6415.field_33993, 0, 15728880);
                  dx = (int)((float)dx + friendWidth / 0.7F);
               }

               mc.field_1772.method_27522(prefix, (float)dx, 0.0F, -1, false, matrices.method_23760().method_23761(), mc.method_22940().method_23000(), class_6415.field_33993, 0, 15728880);
               int var28 = (int)((float)dx + prefixWidth / 0.7F);
               matrices.method_22909();
               FontUtils.durman[13].drawLeftAligned(matrixStack, name + hpText, x + 4.0F + iconWidth + friendWidth + prefixWidth, y + 1.8F, -1);
               if (itemText != null) {
                  matrices.method_22903();
                  matrices.method_46416(x + 4.0F + iconWidth + friendWidth + prefixWidth + nameHpWidth + 3.0F, y + 3.5F, 0.0F);
                  matrices.method_22905(0.7F, 0.7F, 1.0F);
                  mc.field_1772.method_27522(itemText, 0.0F, 0.0F, -1, false, matrices.method_23760().method_23761(), mc.method_22940().method_23000(), class_6415.field_33993, 0, 15728880);
                  matrices.method_22909();
               }

               if (this.effectRender.get()) {
                  this.renderEffect(e, player);
               }

               if (this.armorRender.get()) {
                  this.renderPlayerItems(e, x + 5.0F, y, player);
               }

               if (this.loreRender.get()) {
                  this.renderHeldItemLore(e, player, (float)vec.x, y);
               }
            }
         }
      }

   }

   private void renderHeldItemLore(EventRender2D event, class_1657 player, float centerX, float nameTagY) {
      class_1799 heldItem = player.method_6047();
      class_9290 lore = (class_9290)heldItem.method_57824(class_9334.field_49632);
      if (lore != null && !lore.comp_2400().isEmpty()) {
         List<class_2561> lines = lore.comp_2400();
         int visibleLines = Math.min(lines.size(), 6);
         float lineY = nameTagY - 28.0F - (float)(visibleLines - 1) * 8.0F;

         for(int index = 0; index < visibleLines; ++index) {
            class_2561 line = (class_2561)lines.get(index);
            if (!line.getString().isBlank()) {
               FontUtils.durman[12].centeredDraw(event.getDrawContext().method_51448(), line.getString(), centerX, lineY + (float)index * 8.0F, line.method_10866().method_10973() != null ? line.method_10866().method_10973().method_27716() : Color.WHITE.getRGB());
            }
         }

      }
   }

   private void renderEffect(EventRender2D e, class_1657 player) {
      Vector3d footPos = VectorUtil.toScreen(EntityPosition.get(player, 0.0F, e.getDeltatick().method_60637(true)));
      if (!(footPos.z < (double)0.0F)) {
         int offsetY = 5;

         for(class_1293 effect : player.method_6026()) {
            String name = class_1074.method_4662(((class_1291)effect.method_5579().comp_349()).method_5560().getString(), new Object[0]);
            int lvl = effect.method_5578() + 1;
            int sec = effect.method_5584() / 20;
            String text = String.valueOf(class_124.field_1068) + name + (lvl > 1 ? " " + lvl : "") + String.valueOf(class_124.field_1068) + " | " + sec / 60 + ":" + String.format("%02d", sec % 60);
            FontUtils.durman[14].centeredDraw(e.getDrawContext().method_51448(), text, (float)footPos.x, (float)footPos.y + (float)offsetY, Color.white.getRGB());
            offsetY += 9;
         }

      }
   }

   private void renderPlayerItems(EventRender2D e, float x, float y, class_1657 player) {
      List<class_1799> stacks = new ArrayList(6);
      stacks.add(player.method_6047());
      Iterable var10000 = player.method_5661();
      Objects.requireNonNull(stacks);
      var10000.forEach(stacks::add);
      stacks.add(player.method_6079());
      stacks.removeIf((i) -> i.method_7960() || i.method_7909() instanceof class_1739);
      float offset = 0.0F;

      for(class_1799 stack : stacks) {
         RenderAddon.renderItem(e.getDrawContext(), stack, x + offset - 3.0F, y - 18.0F, 0.8F, true);
         if (this.enchantRender.get() && !stack.method_58657().method_57543()) {
            List<Object2IntMap.Entry<class_6880<class_1887>>> enchantments = new ArrayList(stack.method_58657().method_57539());
            enchantments.removeIf((entryx) -> {
               class_2561 name = class_1887.method_8179((class_6880)entryx.getKey(), entryx.getIntValue());
               String full = name.getString();
               Stream var10000 = IMPORTANT_ENCHANTS.stream();
               Objects.requireNonNull(full);
               return var10000.noneMatch(full::contains);
            });
            if (!enchantments.isEmpty()) {
               int totalHeight = enchantments.size() * 8;
               int startY = (int)(y - 18.0F - (float)totalHeight);
               class_4587 matrices = e.getMatrixStack();

               for(Object2IntMap.Entry<class_6880<class_1887>> entry : enchantments) {
                  class_6880<class_1887> regEntry = (class_6880)entry.getKey();
                  int level = entry.getIntValue();
                  class_2561 enchantText = class_1887.method_8179(regEntry, level);
                  String display = this.getShortName(enchantText, level);
                  matrices.method_22903();
                  matrices.method_46416(x + offset, (float)startY, 0.0F);
                  matrices.method_22905(0.7F, 0.7F, 1.0F);
                  FontUtils.durman[14].drawLeftAligned(e.getDrawContext().method_51448(), display, 0.0F, 0.0F, Color.white.getRGB());
                  matrices.method_22909();
                  startY += 8;
               }
            }
         }

         offset += 15.0F;
      }

   }

   private String getShortName(class_2561 description, int level) {
      String full = description.getString();
      String[] words = full.split(" ");
      String shortName;
      if (words.length == 1) {
         shortName = words[0].substring(0, Math.min(2, words[0].length())).toUpperCase();
      } else {
         shortName = "";

         for(String w : words) {
            if (!w.isEmpty()) {
               shortName = shortName + w.charAt(0);
            }
         }

         shortName = shortName.toUpperCase();
      }

      return shortName + " " + level;
   }

   private void renderItems(EventRender2D e) {
      float tickDelta = e.getDeltatick().method_60637(true);
      int screenW = mc.method_22683().method_4486();
      int screenH = mc.method_22683().method_4502();

      for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
         if (entity instanceof class_1542 itemEntity) {
            class_1799 stack = itemEntity.method_6983();
            class_1792 item = stack.method_7909();
            if (item instanceof class_1747 bi) {
               if (bi.method_7711() instanceof class_2480) {
                  Vector3d vec = VectorUtil.toScreen(EntityPosition.get(entity, 0.6F, tickDelta));
                  if (vec.z < (double)0.0F || vec.x < (double)0.0F || vec.x > (double)screenW || vec.y < (double)0.0F || vec.y > (double)screenH) {
                     continue;
                  }

                  int offsetX = (int)vec.x;
                  int offsetY = (int)vec.y;
                  this.renderShulkerToolTip(e.getDrawContext(), offsetX, offsetY, stack);
               }
            }

            Vector3d vec = VectorUtil.toScreen(EntityPosition.get(entity, 0.6F, tickDelta));
            if (!(vec.z < (double)0.0F) && !(vec.x < (double)0.0F) && !(vec.x > (double)screenW) && !(vec.y < (double)0.0F) && !(vec.y > (double)screenH)) {
               String name = itemEntity.method_5477().getString();
               int count = stack.method_7947();
               if (count > 1) {
                  name = name + " [x" + String.valueOf(class_124.field_1061) + count + String.valueOf(class_124.field_1068) + "]";
               }

               float width = FontUtils.sf_bold[15].getWidth(name);
               float height = FontUtils.sf_bold[15].getHeight();
               float x = (float)vec.x - width / 2.0F - 3.0F;
               float y = (float)vec.y;
               RenderUtil.drawRoundedRect(e.getMatrixStack(), x, y, width + 6.0F, height + 2.0F, 1.5F, BG_COLOR);
               FontUtils.sf_bold[15].centeredDraw(e.getDrawContext().method_51448(), name, (float)vec.x, y + 0.3F, Color.WHITE.getRGB());
            }
         }
      }

   }

   public boolean renderShulkerToolTip(class_332 context, int offsetX, int offsetY, class_1799 stack) {
      class_9288 compoundTag = (class_9288)stack.method_57824(class_9334.field_49622);
      if (compoundTag != null && !compoundTag.method_58114().method_7960()) {
         this.draw(context, compoundTag.method_57489().toList(), offsetX, offsetY);
         return true;
      } else {
         return false;
      }
   }

   private void draw(class_332 context, List<class_1799> itemStacks, int offsetX, int offsetY) {
      int columns = 9;
      int rows = 3;
      float itemSize = 16.0F;
      float spacing = 0.1F;
      int paddingX = 8;
      int paddingY = 7;
      offsetX += 8;
      offsetY -= 75;
      int bgWidth = 160;
      int bgHeight = 62;
      RenderUtil.drawTexture(context.method_51448(), ResourceProvider.container, (float)(offsetX - 8), (float)(offsetY - 7), (float)bgWidth, (float)bgHeight, 0.0F, -1);

      for(int index = 0; index < itemStacks.size(); ++index) {
         int row = index / 9;
         int col = index % 9;
         float x = (float)offsetX + (float)col * 16.1F;
         float y = (float)offsetY + (float)row * 16.1F;
         RenderAddon.renderItem(context, (class_1799)itemStacks.get(index), x, y, 0.85F, true);
      }

   }
}
