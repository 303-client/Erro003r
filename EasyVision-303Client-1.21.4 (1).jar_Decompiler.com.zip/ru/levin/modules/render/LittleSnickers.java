package ru.levin.modules.render;

import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1313;
import net.minecraft.class_1321;
import net.minecraft.class_1493;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_1297.class_5529;
import ru.levin.events.Event;
import ru.levin.events.impl.player.EventAttack;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.render.littlePet.GhostWolfEntity;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "LittlePet",
   desc = "Pies podąża za tobą (AI wkrótce)",
   type = Type.Render
)
public class LittleSnickers extends Function {
   private class_1309 fakeEntity = null;
   private boolean active = false;
   private class_1937 lastWorld = null;
   private final BooleanSetting bumbum = new BooleanSetting("Podążaj za celem", false);
   private int ticksAway = 0;
   private int stuckTicks = 0;
   private class_1309 currentTarget = null;
   private final ClientTickEvents.EndTick tickListener = (client) -> {
      if (this.active && mc.field_1724 != null && mc.field_1687 != null) {
         if (this.fakeEntity == null) {
            this.fakeEntity = this.createEntity();
            if (this.fakeEntity != null) {
               mc.field_1687.method_53875(this.fakeEntity);
               this.lastWorld = mc.field_1687;
            }

         } else {
            if (mc.field_1687 != this.lastWorld) {
               if (this.fakeEntity != null) {
                  mc.field_1687.method_2945(this.fakeEntity.method_5628(), class_5529.field_26999);
               }

               this.fakeEntity = this.createEntity();
               if (this.fakeEntity == null) {
                  return;
               }

               mc.field_1687.method_53875(this.fakeEntity);
               this.lastWorld = mc.field_1687;
            }

            class_243 playerPos = mc.field_1724.method_19538();
            class_243 entityPos = this.fakeEntity.method_19538();
            double distToPlayer = playerPos.method_1022(entityPos);
            if (!(distToPlayer > (double)10.0F) && this.stuckTicks <= 40) {
               this.ticksAway = 0;
            } else {
               ++this.ticksAway;
               if (this.ticksAway >= 60 || this.stuckTicks > 40) {
                  double targetX = playerPos.field_1352;
                  double targetY = playerPos.field_1351;
                  double targetZ = playerPos.field_1350;
                  if (mc.field_1724.method_6128() || !mc.field_1724.method_24828()) {
                     class_2338.class_2339 posBelow = new class_2338.class_2339((int)Math.floor(playerPos.field_1352), (int)Math.floor(playerPos.field_1351), (int)Math.floor(playerPos.field_1350));

                     for(int yOffset = 0; yOffset < 64; ++yOffset) {
                        if (this.isSolid(posBelow)) {
                           targetY = (double)posBelow.method_10264() + (double)1.0F;
                           break;
                        }

                        posBelow.method_10100(0, -1, 0);
                     }
                  }

                  this.fakeEntity.method_5808(targetX, targetY, targetZ, this.fakeEntity.method_36454(), this.fakeEntity.method_36455());
                  this.fakeEntity.method_18799(class_243.field_1353);
                  this.ticksAway = 0;
                  this.stuckTicks = 0;
               }
            }

            if (this.currentTarget != null && (this.currentTarget.method_31481() || this.currentTarget.method_29504())) {
               this.currentTarget = null;
            }

            class_243 moveTo = playerPos;
            class_1297 lookTarget = mc.field_1724;
            if (this.bumbum.get() && this.currentTarget != null) {
               double distToTarget = this.currentTarget.method_19538().method_1022(entityPos);
               if (distToTarget <= (double)12.0F) {
                  moveTo = this.currentTarget.method_19538();
                  lookTarget = this.currentTarget;
               } else {
                  this.currentTarget = null;
                  moveTo = playerPos;
                  lookTarget = mc.field_1724;
               }
            }

            this.moveEntityTowardsTarget(moveTo);
            this.fakeEntity.method_6007();
            this.updateEntityRotation(lookTarget);
         }
      }
   };

   public LittleSnickers() {
      this.addSettings(new Setting[]{this.bumbum});
   }

   private class_1309 createEntity() {
      GhostWolfEntity entity = new GhostWolfEntity(class_1299.field_6055, mc.field_1687);
      if (entity == null) {
         return null;
      } else {
         entity.method_5808(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), mc.field_1724.method_36454(), mc.field_1724.method_36455());
         entity.method_5648(false);
         entity.method_5880(false);
         entity.method_6033(20.0F);
         if (entity instanceof class_1321) {
            ((class_1321)entity).method_6173(true, false);
            ((class_1321)entity).method_6174(mc.field_1724.method_5667());
         }

         return entity;
      }
   }

   private boolean isSolid(class_2338 pos) {
      class_2680 blockState = mc.field_1687.method_8320(pos);
      return !blockState.method_26215() && !blockState.method_26220(mc.field_1687, pos).method_1110();
   }

   private void moveEntityTowardsTarget(class_243 targetPos) {
      class_243 entityPos = this.fakeEntity.method_19538();
      double dx = targetPos.field_1352 - entityPos.field_1352;
      double dz = targetPos.field_1350 - entityPos.field_1350;
      double distanceXZ = Math.sqrt(dx * dx + dz * dz);
      double dy = targetPos.field_1351 - entityPos.field_1351;
      boolean isMoving = false;
      boolean isJumping = false;
      class_2338 entityBlockPos = new class_2338((int)Math.floor(entityPos.field_1352), (int)Math.floor(entityPos.field_1351 - 0.1), (int)Math.floor(entityPos.field_1350));
      boolean onGround = this.isSolid(entityBlockPos);
      if (!(Math.abs(dy) >= (double)12.0F) && !(distanceXZ > (double)20.0F)) {
         if (distanceXZ > 1.2) {
            double speed = 0.21;
            double normX = dx / distanceXZ;
            double normZ = dz / distanceXZ;
            class_2338 frontPos = new class_2338((int)Math.floor(entityPos.field_1352 + normX * 0.6), (int)Math.floor(entityPos.field_1351), (int)Math.floor(entityPos.field_1350 + normZ * 0.6));
            class_2338 aboveFrontPos = frontPos.method_10084();
            class_2338 blockBelowFront = frontPos.method_10074();
            class_2338 blockBelow = entityBlockPos.method_10074();
            boolean frontSolid = this.isSolid(frontPos);
            boolean aboveClear = !this.isSolid(aboveFrontPos);
            boolean belowSolid = this.isSolid(blockBelow);
            boolean belowFrontSolid = this.isSolid(blockBelowFront);
            if (frontSolid && aboveClear && onGround) {
               int blockHeight = frontPos.method_10264() - entityBlockPos.method_10264();
               if (blockHeight > 1) {
                  ++this.stuckTicks;
                  return;
               }

               class_243 vel = this.fakeEntity.method_18798();
               this.fakeEntity.method_18800(vel.field_1352, (double)0.5F, vel.field_1350);
               isJumping = true;
               onGround = false;
            }

            if (!frontSolid && !belowFrontSolid) {
               boolean foundGround = false;

               for(int drop = 1; drop <= 3; ++drop) {
                  class_2338 check = frontPos.method_10087(drop);
                  if (this.isSolid(check)) {
                     class_243 vel = this.fakeEntity.method_18798();
                     this.fakeEntity.method_18800(vel.field_1352, -0.1, vel.field_1350);
                     foundGround = true;
                     break;
                  }
               }

               if (!foundGround) {
                  ++this.stuckTicks;
                  return;
               }
            }

            if (isJumping || !belowSolid && !onGround) {
               if (!isJumping) {
                  ++this.stuckTicks;
               }
            } else {
               this.fakeEntity.method_5784(class_1313.field_6308, new class_243(normX * speed, (double)0.0F, normZ * speed));
               isMoving = true;
               this.stuckTicks = 0;
            }

            if (isMoving) {
               float yaw = (float)Math.toDegrees(Math.atan2(-dx, dz));
               this.fakeEntity.method_36456(yaw);
               this.fakeEntity.method_5636(yaw);
               class_1309 var39 = this.fakeEntity;
               if (var39 instanceof class_1308) {
                  class_1308 mob = (class_1308)var39;
                  mob.method_5847(yaw);
               }
            }
         }

         if (!onGround) {
            class_243 velocity = this.fakeEntity.method_18798();
            this.fakeEntity.method_18800(velocity.field_1352 * 0.91, Math.max(velocity.field_1351 - 0.08, (double)-0.5F), velocity.field_1350 * 0.91);
            this.fakeEntity.method_5784(class_1313.field_6308, this.fakeEntity.method_18798());
         }

         if (!isMoving && onGround) {
            this.fakeEntity.method_18799(class_243.field_1353);
         }

         class_1309 var16 = this.fakeEntity;
         if (var16 instanceof class_1493) {
            class_1493 wolf = (class_1493)var16;
            wolf.method_5728(isMoving && !isJumping);
            wolf.method_24346(!isMoving && onGround);
         }

      } else {
         this.fakeEntity.method_5808(targetPos.field_1352, targetPos.field_1351, targetPos.field_1350, this.fakeEntity.method_36454(), this.fakeEntity.method_36455());
         this.fakeEntity.method_18799(class_243.field_1353);
         this.stuckTicks = 0;
      }
   }

   private void updateEntityRotation(class_1297 target) {
      if (target != null) {
         class_243 entityEyes = this.fakeEntity.method_19538().method_1031((double)0.0F, (double)this.fakeEntity.method_5751(), (double)0.0F);
         class_243 targetEyes = target.method_19538().method_1031((double)0.0F, (double)target.method_5751(), (double)0.0F);
         class_243 diff = targetEyes.method_1020(entityEyes);
         double flatDist = Math.sqrt(diff.field_1352 * diff.field_1352 + diff.field_1350 * diff.field_1350);
         float yaw = (float)Math.toDegrees(Math.atan2(-diff.field_1352, diff.field_1350));
         float pitch = (float)Math.toDegrees(-Math.atan2(diff.field_1351, flatDist));
         this.fakeEntity.method_36456(yaw);
         this.fakeEntity.method_36457(pitch);
         this.fakeEntity.method_5636(yaw);
         class_1309 var10 = this.fakeEntity;
         if (var10 instanceof class_1308) {
            class_1308 mob = (class_1308)var10;
            mob.method_5847(yaw);
         }

      }
   }

   public void onEvent(Event event) {
      if (event instanceof EventAttack attack) {
         if (this.bumbum.get()) {
            class_1297 attacked = attack.getTarget();
            if (attacked instanceof class_1309) {
               class_1309 living = (class_1309)attacked;
               if (living != mc.field_1724) {
                  this.currentTarget = living;
               }
            }
         }
      }

   }

   public void onEnable() {
      ClientTickEvents.END_CLIENT_TICK.register(this.tickListener);
      this.active = true;
      this.lastWorld = mc.field_1687;
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.fakeEntity = this.createEntity();
         if (this.fakeEntity != null) {
            mc.field_1687.method_53875(this.fakeEntity);
         }
      }

   }

   public void onDisable() {
      if (this.active) {
         if (mc.field_1687 != null && this.fakeEntity != null) {
            mc.field_1687.method_2945(this.fakeEntity.method_5628(), class_5529.field_26999);
            this.fakeEntity = null;
         }

         this.active = false;
         this.ticksAway = 0;
         this.stuckTicks = 0;
         this.currentTarget = null;
      }
   }
}
