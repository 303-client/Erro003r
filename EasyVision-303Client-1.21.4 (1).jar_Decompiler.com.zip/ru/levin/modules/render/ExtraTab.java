package ru.levin.modules.render;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "ExtraTab",
   desc = "Zwiększa liczbę graczy na liście TAB",
   type = Type.Render
)
public class ExtraTab extends Function {
   public void onEvent(Event event) {
   }
}
