package ru.levin.modules.render;

import com.mojang.blaze3d.platform.GlStateManager.class_4534;
import com.mojang.blaze3d.platform.GlStateManager.class_4535;
import com.mojang.blaze3d.systems.RenderSystem;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import net.minecraft.class_10142;
import net.minecraft.class_1297;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_287;
import net.minecraft.class_290;
import net.minecraft.class_2960;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import net.minecraft.class_293.class_5596;
import org.joml.Matrix4f;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.player.EventAttack;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.IMinecraft;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.providers.ResourceProvider;

@FunctionAnnotation(
   name = "Particles",
   desc = "Efektowne cząsteczki w powietrzu",
   type = Type.Render
)
public class Particles extends Function {
   private final MultiSetting types = new MultiSetting("Typy", Arrays.asList("Obrażenia", "Świat"), new String[]{"Obrażenia", "Świat"});
   private final ModeSetting mode = new ModeSetting("Tekstura", "Gwiazda", new String[]{"Korona", "Dolar", "Świetlik", "Serce", "Błyskawica", "Linia", "Punkt", "Romb", "Płatek śniegu", "Iskra", "Gwiazda"});
   private final SliderSetting countDamage = new SliderSetting("Liczba przy obrażeniach", (double)20.0F, (double)5.0F, (double)50.0F, (double)1.0F, () -> this.types.get("Obrażenia"));
   private final SliderSetting countWorld = new SliderSetting("Liczba w świecie", (double)12.0F, (double)2.0F, (double)15.0F, (double)1.0F, () -> this.types.get("Świat"));
   private final SliderSetting sizeDamage = new SliderSetting("Rozmiar przy obrażeniach", (double)0.3F, (double)0.1F, (double)0.6F, (double)0.1F, () -> this.types.get("Obrażenia"));
   private final SliderSetting sizeWorld = new SliderSetting("Rozmiar w świecie", (double)1.1F, (double)0.1F, (double)1.2F, (double)0.1F, () -> this.types.get("Świat"));
   private final SliderSetting sila = new SliderSetting("Siła rozrzutu", (double)0.2F, (double)0.1F, (double)0.5F, (double)0.1F);
   private final SliderSetting time = new SliderSetting("Czas życia", (double)4000.0F, (double)500.0F, (double)8000.0F, (double)100.0F);
   private final SliderSetting speedMultiplier = new SliderSetting("Prędkość", (double)1.2F, (double)0.1F, (double)3.0F, (double)0.1F);
   private final BooleanSetting randomRotation = new BooleanSetting("Losowy obrót", true);
   private final ArrayList<World> worldParticles = new ArrayList();
   private final ArrayList<Damage> damageParticles = new ArrayList();
   private static final Map<String, class_2960> TEXTURES = new HashMap();

   public Particles() {
      this.addSettings(new Setting[]{this.types, this.mode, this.countDamage, this.countWorld, this.sizeDamage, this.sizeWorld, this.sila, this.time, this.speedMultiplier, this.randomRotation});
   }

   public void onEvent(Event event) {
      if (this.types.get("Świat")) {
         if (event instanceof EventUpdate) {
            this.worldParticles.removeIf(World::tick);
            float con = this.countWorld.get().floatValue() * 100.0F;

            for(int j = this.worldParticles.size(); (float)j < con; ++j) {
               boolean drop = false;
               this.worldParticles.add(new World((float)(mc.field_1724.method_23317() + (double)MathUtil.random(-48.0F, 48.0F)), (float)(mc.field_1724.method_23318() + (double)MathUtil.random(2.0F, 48.0F)), (float)(mc.field_1724.method_23321() + (double)MathUtil.random(-48.0F, 48.0F)), drop ? 0.0F : MathUtil.random(-0.4F, 0.4F), drop ? MathUtil.random(-0.2F, -0.05F) : MathUtil.random(-0.1F, 0.1F), drop ? 0.0F : MathUtil.random(-0.4F, 0.4F)));
            }
         }

         if (event instanceof EventRender3D) {
            EventRender3D e = (EventRender3D)event;
            e.getMatrixStack().method_22903();
            RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(class_10142.field_53880);
            class_287 bufferBuilder = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);
            this.worldParticles.forEach((p) -> p.render(bufferBuilder));
            RenderUtil.render3D.endBuilding(bufferBuilder);
            RenderSystem.depthMask(true);
            RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.disableDepthTest();
            RenderSystem.disableBlend();
            e.getMatrixStack().method_22909();
         }
      }

      if (this.types.get("Obrażenia")) {
         if (event instanceof EventUpdate) {
            this.damageParticles.removeIf(Damage::tick);
         } else if (event instanceof EventAttack) {
            EventAttack eventAttack = (EventAttack)event;
            class_1297 target = eventAttack.getTarget();
            if (target == null) {
               return;
            }

            double x = target.method_23317();
            double y = target.method_23318() + (double)0.5F;
            double z = target.method_23321();
            float con = this.countDamage.get().floatValue();

            for(int i = 0; (float)i < con; ++i) {
               float motionX = MathUtil.random(-this.sila.get().floatValue(), this.sila.get().floatValue()) * this.speedMultiplier.get().floatValue();
               float motionZ = MathUtil.random(-this.sila.get().floatValue(), this.sila.get().floatValue()) * this.speedMultiplier.get().floatValue();
               float motionY = MathUtil.random(-0.05F, -0.1F);
               motionY *= this.speedMultiplier.get().floatValue();
               float rotation = this.randomRotation.get() ? MathUtil.random(0.0F, 360.0F) : 0.0F;
               int color = ColorUtil.getColorStyle((float)((int)(Math.random() * (double)360.0F)));
               this.damageParticles.add(new Damage((float)x, (float)y, (float)z, motionX, motionY, motionZ, this.time.get().longValue(), color, rotation));
            }
         } else if (event instanceof EventRender3D) {
            EventRender3D e = (EventRender3D)event;
            class_4587 matrixStack = e.getMatrixStack();
            matrixStack.method_22903();
            RenderUtil.enableRender(class_4535.SRC_ALPHA, class_4534.ONE);
            RenderSystem.enableDepthTest();
            RenderSystem.depthMask(false);
            RenderSystem.setShader(class_10142.field_53880);
            class_287 bufferBuilder = IMinecraft.tessellator().method_60827(class_5596.field_27382, class_290.field_1575);
            class_2960 tex = (class_2960)TEXTURES.getOrDefault(this.mode.get(), (class_2960)TEXTURES.get("Gwiazda"));
            RenderSystem.setShaderTexture(0, tex);
            this.damageParticles.forEach((p) -> p.render(bufferBuilder));
            RenderUtil.render3D.endBuilding(bufferBuilder);
            RenderSystem.depthMask(true);
            RenderSystem.blendFunc(class_4535.SRC_ALPHA, class_4534.ONE_MINUS_SRC_ALPHA);
            RenderSystem.disableDepthTest();
            RenderSystem.disableBlend();
            matrixStack.method_22909();
         }
      }

   }

   static {
      TEXTURES.put("Korona", ResourceProvider.crown);
      TEXTURES.put("Dolar", ResourceProvider.dollar);
      TEXTURES.put("Świetlik", ResourceProvider.firefly);
      TEXTURES.put("Serce", ResourceProvider.heart);
      TEXTURES.put("Błyskawica", ResourceProvider.lightning);
      TEXTURES.put("Linia", ResourceProvider.line);
      TEXTURES.put("Punkt", ResourceProvider.point);
      TEXTURES.put("Romb", ResourceProvider.rhombus);
      TEXTURES.put("Płatek śniegu", ResourceProvider.snowflake);
      TEXTURES.put("Iskra", ResourceProvider.spark);
      TEXTURES.put("Gwiazda", ResourceProvider.star);
   }

   public class Damage {
      private float prevposX;
      private float prevposY;
      private float prevposZ;
      private float posX;
      private float posY;
      private float posZ;
      private float motionX;
      private float motionY;
      private float motionZ;
      private final long createdTime;
      private final long maxAge;
      private int currentColor;
      private final float rotation;

      public Damage(float posX, float posY, float posZ, float motionX, float motionY, float motionZ, long maxAge, int color, float rotation) {
         this.posX = this.prevposX = posX;
         this.posY = this.prevposY = posY;
         this.posZ = this.prevposZ = posZ;
         this.motionX = motionX;
         this.motionY = motionY;
         this.motionZ = motionZ;
         this.createdTime = System.currentTimeMillis();
         this.maxAge = maxAge;
         this.currentColor = color;
         this.rotation = rotation;
      }

      public boolean tick() {
         long now = System.currentTimeMillis();
         if (now - this.createdTime > this.maxAge) {
            return true;
         } else {
            this.prevposX = this.posX;
            this.prevposY = this.posY;
            this.prevposZ = this.posZ;

            for(int i = 0; i < 4; ++i) {
               this.tryMove(this.motionX / 4.0F, this.motionY / 4.0F, this.motionZ / 4.0F);
            }

            this.motionX *= 0.97F;
            this.motionY *= 0.97F;
            this.motionZ *= 0.97F;
            return false;
         }
      }

      private boolean isSolid(float x, float y, float z) {
         class_2338 pos = new class_2338((int)Math.floor((double)x), (int)Math.floor((double)y), (int)Math.floor((double)z));
         return IMinecraft.mc.field_1687 != null && IMinecraft.mc.field_1687.method_8320(pos).method_26234(IMinecraft.mc.field_1687, pos);
      }

      private void tryMove(float dx, float dy, float dz) {
         float newX = this.posX + dx;
         float newY = this.posY + dy;
         float newZ = this.posZ + dz;
         if (!this.isSolid(newX, this.posY, this.posZ)) {
            this.posX = newX;
         } else {
            this.motionX *= -0.4F;
         }

         if (!this.isSolid(this.posX, newY, this.posZ)) {
            this.posY = newY;
         } else {
            this.motionY *= -0.4F;
         }

         if (!this.isSolid(this.posX, this.posY, newZ)) {
            this.posZ = newZ;
         } else {
            this.motionZ *= -0.4F;
         }

      }

      public void render(class_287 bufferBuilder) {
         class_4184 camera = IMinecraft.mc.field_1773.method_19418();
         class_243 pos = RenderUtil.interpolatePos(this.prevposX, this.prevposY, this.prevposZ, this.posX, this.posY, this.posZ);
         class_4587 matrices = new class_4587();
         matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
         matrices.method_22904(pos.field_1352, pos.field_1351, pos.field_1350);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
         matrices.method_22907(class_7833.field_40718.rotation(this.rotation));
         float alpha = Math.max(0.0F, 1.0F - (float)(System.currentTimeMillis() - this.createdTime) / (float)this.maxAge);
         int colorWithAlpha = RenderUtil.injectAlpha(this.currentColor, (int)(255.0F * alpha));
         Matrix4f matrix = matrices.method_23760().method_23761();
         float s = Particles.this.sizeDamage.get().floatValue();
         bufferBuilder.method_22918(matrix, 0.0F, -s, 0.0F).method_22913(0.0F, 1.0F).method_39415(colorWithAlpha);
         bufferBuilder.method_22918(matrix, -s, -s, 0.0F).method_22913(1.0F, 1.0F).method_39415(colorWithAlpha);
         bufferBuilder.method_22918(matrix, -s, 0.0F, 0.0F).method_22913(1.0F, 0.0F).method_39415(colorWithAlpha);
         bufferBuilder.method_22918(matrix, 0.0F, 0.0F, 0.0F).method_22913(0.0F, 0.0F).method_39415(colorWithAlpha);
      }
   }

   public class World {
      protected float prevposX;
      protected float prevposY;
      protected float prevposZ;
      protected float posX;
      protected float posY;
      protected float posZ;
      protected float motionX;
      protected float motionY;
      protected float motionZ;
      protected int age;
      protected int maxAge;

      public World(float posX, float posY, float posZ, float motionX, float motionY, float motionZ) {
         this.posX = posX;
         this.posY = posY;
         this.posZ = posZ;
         this.prevposX = posX;
         this.prevposY = posY;
         this.prevposZ = posZ;
         this.motionX = motionX;
         this.motionY = motionY;
         this.motionZ = motionZ;
         this.age = (int)MathUtil.random(100.0F, 300.0F);
         this.maxAge = this.age;
      }

      public boolean tick() {
         if (IMinecraft.mc.field_1724.method_5649((double)this.posX, (double)this.posY, (double)this.posZ) > (double)4096.0F) {
            this.age -= 8;
         } else {
            --this.age;
         }

         if (this.age < 0) {
            return true;
         } else {
            this.prevposX = this.posX;
            this.prevposY = this.posY;
            this.prevposZ = this.posZ;
            this.posX += this.motionX;
            this.posY += this.motionY;
            this.posZ += this.motionZ;
            this.motionX *= 0.9F;
            this.motionY *= 0.9F;
            this.motionZ *= 0.9F;
            this.motionY -= 0.001F;
            return false;
         }
      }

      public void render(class_287 bufferBuilder) {
         class_2960 tex = (class_2960)Particles.TEXTURES.getOrDefault(Particles.this.mode.get(), (class_2960)Particles.TEXTURES.get("Gwiazda"));
         RenderSystem.setShaderTexture(0, tex);
         class_4184 camera = IMinecraft.mc.field_1773.method_19418();
         int color1 = ColorUtil.getColorStyle((float)(this.age * 2));
         class_243 pos = RenderUtil.interpolatePos(this.prevposX, this.prevposY, this.prevposZ, this.posX, this.posY, this.posZ);
         class_4587 matrices = new class_4587();
         matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
         matrices.method_22907(class_7833.field_40716.rotationDegrees(camera.method_19330() + 180.0F));
         matrices.method_22904(pos.field_1352, pos.field_1351, pos.field_1350);
         matrices.method_22907(class_7833.field_40716.rotationDegrees(-camera.method_19330()));
         matrices.method_22907(class_7833.field_40714.rotationDegrees(camera.method_19329()));
         Matrix4f matrix1 = matrices.method_23760().method_23761();
         float size = Particles.this.sizeWorld.get().floatValue();
         bufferBuilder.method_22918(matrix1, 0.0F, -size, 0.0F).method_22913(0.0F, 1.0F).method_39415(RenderUtil.injectAlpha(color1, (int)(255.0F * ((float)this.age / (float)this.maxAge))));
         bufferBuilder.method_22918(matrix1, -size, -size, 0.0F).method_22913(1.0F, 1.0F).method_39415(RenderUtil.injectAlpha(color1, (int)(255.0F * ((float)this.age / (float)this.maxAge))));
         bufferBuilder.method_22918(matrix1, -size, 0.0F, 0.0F).method_22913(1.0F, 0.0F).method_39415(RenderUtil.injectAlpha(color1, (int)(255.0F * ((float)this.age / (float)this.maxAge))));
         bufferBuilder.method_22918(matrix1, 0.0F, 0.0F, 0.0F).method_22913(0.0F, 0.0F).method_39415(RenderUtil.injectAlpha(color1, (int)(255.0F * ((float)this.age / (float)this.maxAge))));
      }
   }
}
