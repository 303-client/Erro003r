package ru.levin.modules.render;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_8646;
import net.minecraft.class_9011;
import net.minecraft.class_9022;
import net.minecraft.class_9025;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.ScoreboardColorUtil;

@FunctionAnnotation(
   name = "ScoreBoardStealer",
   desc = "Zczytuje i edytuje lokalny scoreboard",
   type = Type.Render
)
public class ScoreBoardStealer extends Function {
   private final BooleanSetting enabled = new BooleanSetting("Włączony", true);
   private final List<String> originalLines = new ArrayList();
   private final List<String> editedLines = new ArrayList();
   private final List<String> originalColors = new ArrayList();
   private final List<String> editedColors = new ArrayList();
   private final List<class_2561> originalTextLines = new ArrayList();
   private final Map<String, String> lineValues = new HashMap();
   private Object sourceWorld;
   private boolean hasReadScoreboard;
   private boolean pendingEditorOpen;

   public ScoreBoardStealer() {
      this.addSettings(new Setting[]{this.enabled});
   }

   protected void onEnable() {
      this.readScoreboard();
      class_310 client = class_310.method_1551();
      this.pendingEditorOpen = client.field_1724 != null;
      if (this.hasReadScoreboard) {
         this.openGUI();
      }

   }

   protected void onDisable() {
      this.pendingEditorOpen = false;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.enabled.get()) {
         this.readScoreboard();
         class_310 client = class_310.method_1551();
         if (this.pendingEditorOpen && this.hasReadScoreboard && client.field_1724 != null && !(client.field_1755 instanceof ScoreBoardStealerGUI)) {
            this.openGUI();
         }
      }

   }

   private boolean readScoreboard() {
      List<class_2561> visibleLines = this.readCurrentSidebarLines();
      if (visibleLines == null) {
         return false;
      } else {
         this.captureLines(visibleLines);
         return this.hasReadScoreboard;
      }
   }

   private List<class_2561> readCurrentSidebarLines() {
      return this.readCurrentSidebarLines((List)null);
   }

   private List<class_2561> readCurrentSidebarLines(List<class_2561> mixinLines) {
      class_310 client = class_310.method_1551();
      if (client.field_1687 != null && client.field_1724 != null) {
         if (this.sourceWorld != client.field_1687) {
            this.clearSnapshot();
            this.sourceWorld = client.field_1687;
         }

         class_269 scoreboard = client.field_1687.method_8428();
         class_266 objective = scoreboard.method_1189(class_8646.field_45157);
         if (objective == null) {
            return null;
         } else {
            List<class_2561> visibleLines = new ArrayList();
            class_2561 objectiveTitle = objective.method_1114();
            class_9022 numberFormat = objective.method_55380(class_9025.field_47567);
            List<class_9011> entries = new ArrayList(scoreboard.method_1184(objective));
            entries.removeIf(class_9011::method_55385);
            entries.sort(Comparator.comparingInt(class_9011::comp_2128).reversed().thenComparing(class_9011::comp_2127, String.CASE_INSENSITIVE_ORDER));
            if (entries.size() > 15) {
               entries = new ArrayList(entries.subList(0, 15));
            }

            boolean useMixinLines = mixinLines != null && mixinLines.size() == entries.size() + 1 && hasReadableText(mixinLines);
            if (useMixinLines) {
               objectiveTitle = (class_2561)mixinLines.get(0);
            }

            if (safeTextString(objectiveTitle) == null) {
               objectiveTitle = class_2561.method_43470("");
            }

            visibleLines.add(objectiveTitle);

            for(int i = 0; i < entries.size(); ++i) {
               class_9011 entry = (class_9011)entries.get(i);
               class_268 team = scoreboard.method_1164(entry.comp_2127());
               class_2561 sourceDisplay = (class_2561)(useMixinLines ? (class_2561)mixinLines.get(i + 1) : class_268.method_1142(team, entry.method_55387()));
               String visibleName = safeTextString(sourceDisplay);
               if (visibleName == null) {
                  sourceDisplay = class_268.method_1142(team, entry.method_55387());
                  visibleName = safeTextString(sourceDisplay);
               }

               if (visibleName == null) {
                  sourceDisplay = class_2561.method_43470(entry.comp_2127());
                  visibleName = entry.comp_2127();
               }

               String sourceColor = ScoreboardColorUtil.toHex(sourceDisplay);
               class_2561 display = ScoreboardColorUtil.applyColor(sourceDisplay, sourceColor);
               visibleName = ScoreboardColorUtil.stripLegacyFormattingCodes(visibleName).stripTrailing();

               class_2561 score;
               String rawScore;
               try {
                  score = entry.method_55386(numberFormat);
                  rawScore = safeTextString(score);
               } catch (RuntimeException var20) {
                  score = null;
                  rawScore = null;
               }

               if (rawScore == null) {
                  rawScore = Integer.toString(entry.comp_2128());
                  score = class_2561.method_43470(rawScore);
               }

               String visibleScore = ScoreboardColorUtil.stripLegacyFormattingCodes(rawScore).trim();
               if (!visibleScore.isBlank() && !alreadyIncludesScore(visibleName, visibleScore)) {
                  display = display.method_27661().method_10852(class_2561.method_43470(" ")).method_10852(score);
               }

               visibleLines.add(display);
            }

            return visibleLines;
         }
      } else {
         return null;
      }
   }

   private static boolean alreadyIncludesScore(String line, String score) {
      int scoreStart = line.length() - score.length();
      if (scoreStart >= 0 && line.regionMatches(scoreStart, score, 0, score.length())) {
         return scoreStart == 0 || !Character.isLetterOrDigit(line.charAt(scoreStart - 1));
      } else {
         return false;
      }
   }

   private static boolean hasReadableText(List<class_2561> lines) {
      for(class_2561 line : lines) {
         if (safeTextString(line) == null) {
            return false;
         }
      }

      return true;
   }

   private static String safeTextString(class_2561 text) {
      if (text == null) {
         return null;
      } else {
         try {
            return text.getString();
         } catch (RuntimeException var2) {
            return null;
         }
      }
   }

   private void captureLines(List<class_2561> lines) {
      if (lines != null && !lines.isEmpty()) {
         Object currentWorld = class_310.method_1551().field_1687;
         if (this.sourceWorld != currentWorld) {
            this.clearSnapshot();
            this.sourceWorld = currentWorld;
         }

         List<String> previousOriginals = new ArrayList(this.originalLines);
         List<String> previousEdits = new ArrayList(this.editedLines);
         List<String> previousColors = new ArrayList(this.originalColors);
         List<String> previousEditedColors = new ArrayList(this.editedColors);
         this.originalLines.clear();
         this.originalColors.clear();
         this.originalTextLines.clear();
         this.editedLines.clear();
         this.editedColors.clear();
         this.lineValues.clear();

         for(int i = 0; i < lines.size(); ++i) {
            class_2561 line = (class_2561)(lines.get(i) == null ? class_2561.method_43473() : (class_2561)lines.get(i));
            String original = ScoreboardColorUtil.stripLegacyFormattingCodes(line.getString());
            String originalColor = ScoreboardColorUtil.toHex(line);
            boolean hasPreviousLine = i < previousOriginals.size() && i < previousEdits.size() && i < previousColors.size() && i < previousEditedColors.size();
            boolean hasCustomEdit = hasPreviousLine && (!((String)previousEdits.get(i)).equals(previousOriginals.get(i)) || !ScoreboardColorUtil.normalizeHex((String)previousEditedColors.get(i), (String)previousColors.get(i)).equals(previousColors.get(i)));
            this.originalTextLines.add(line);
            this.originalLines.add(original);
            this.originalColors.add(originalColor);
            this.editedLines.add(hasCustomEdit ? (String)previousEdits.get(i) : original);
            this.editedColors.add(hasCustomEdit ? ScoreboardColorUtil.normalizeHex((String)previousEditedColors.get(i), originalColor) : originalColor);
            this.lineValues.put(i == 0 ? "title" : "line_" + (i - 1), original);
         }

         this.hasReadScoreboard = true;
      }
   }

   private void clearSnapshot() {
      this.originalLines.clear();
      this.editedLines.clear();
      this.originalColors.clear();
      this.editedColors.clear();
      this.originalTextLines.clear();
      this.lineValues.clear();
      this.hasReadScoreboard = false;
   }

   public class_2561 editLine(class_2561 original, int lineFromBottom) {
      if (!this.hasReadScoreboard) {
         return original;
      } else {
         int index = this.editedLines.size() - lineFromBottom;
         if (this.enabled.get()) {
            return this.renderEditedLine(index, original);
         } else {
            return index >= 0 && index < this.originalTextLines.size() ? (class_2561)this.originalTextLines.get(index) : original;
         }
      }
   }

   public class_2561 editTitle(class_2561 original) {
      return this.enabled.get() && this.hasReadScoreboard ? this.renderEditedLine(0, original) : original;
   }

   private class_2561 renderEditedLine(int index, class_2561 fallback) {
      if (index >= 0 && index < this.editedLines.size()) {
         String text = (String)this.editedLines.get(index);
         String color = (String)this.editedColors.get(index);
         if (index < this.originalLines.size() && text.equals(this.originalLines.get(index)) && color.equals(this.originalColors.get(index))) {
            return index < this.originalTextLines.size() ? (class_2561)this.originalTextLines.get(index) : fallback;
         } else {
            return ScoreboardColorUtil.coloredText(text, color);
         }
      } else {
         return fallback;
      }
   }

   public List<String> getOriginalLines() {
      return new ArrayList(this.originalLines);
   }

   public List<String> getEditedLines() {
      return new ArrayList(this.editedLines);
   }

   public List<String> getOriginalColors() {
      return new ArrayList(this.originalColors);
   }

   public List<String> getEditedColors() {
      return new ArrayList(this.editedColors);
   }

   public List<class_2561> getOriginalTextLines() {
      return new ArrayList(this.originalTextLines);
   }

   public boolean hasReadScoreboard() {
      return this.hasReadScoreboard;
   }

   public void forceReadScoreboard() {
      this.readScoreboard();
   }

   public void updateScoreboardLines(List<String> lines) {
      if (lines != null && !lines.isEmpty()) {
         List<class_2561> textLines = new ArrayList(lines.size());

         for(String line : lines) {
            textLines.add(class_2561.method_43470(line == null ? "" : line));
         }

         this.captureLines(textLines);
      }
   }

   public void updateScoreboardTextLines(List<class_2561> textLines) {
      if (!(class_310.method_1551().field_1755 instanceof ScoreBoardStealerGUI)) {
         List<class_2561> currentLines = this.readCurrentSidebarLines(textLines);
         this.captureLines(currentLines == null ? textLines : currentLines);
      }
   }

   public Map<String, String> getLineValues() {
      return new HashMap(this.lineValues);
   }

   public void openGUI() {
      class_310 client = class_310.method_1551();
      if (client.field_1724 != null) {
         if (!this.hasReadScoreboard) {
            this.readScoreboard();
         }

         if (this.hasReadScoreboard) {
            this.pendingEditorOpen = false;
            client.method_1507(new ScoreBoardStealerGUI(this, client.field_1755));
         }
      }

   }

   public void applyLineChanges(List<String> newLines) {
      if (newLines != null && newLines.size() == this.originalLines.size()) {
         this.editedLines.clear();
         this.editedLines.addAll(newLines);
      }
   }

   public void applyLineColors(List<String> newColors) {
      if (newColors != null && newColors.size() == this.originalColors.size()) {
         this.editedColors.clear();

         for(int i = 0; i < newColors.size(); ++i) {
            this.editedColors.add(ScoreboardColorUtil.normalizeHex((String)newColors.get(i), (String)this.originalColors.get(i)));
         }

      }
   }

   public void restoreOriginals() {
      this.editedLines.clear();
      this.editedLines.addAll(this.originalLines);
      this.editedColors.clear();
      this.editedColors.addAll(this.originalColors);
   }
}
