package ru.levin.modules.render;

import com.google.common.collect.Lists;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.regex.Pattern;
import net.minecraft.class_1058;
import net.minecraft.class_1074;
import net.minecraft.class_1291;
import net.minecraft.class_1292;
import net.minecraft.class_1293;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1739;
import net.minecraft.class_1792;
import net.minecraft.class_1796;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1921;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_269;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_3532;
import net.minecraft.class_3966;
import net.minecraft.class_4074;
import net.minecraft.class_408;
import net.minecraft.class_4587;
import net.minecraft.class_640;
import net.minecraft.class_6880;
import net.minecraft.class_2350.class_2352;
import org.jetbrains.annotations.Nullable;
import org.joml.Vector4f;
import org.joml.Vector4i;
import ru.levin.ExosWare;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.dragManager.Dragging;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.manager.fontManager.RenderFonts;
import ru.levin.manager.themeManager.StyleManager;
import ru.levin.mixin.iface.ItemCooldownEntryAccessor;
import ru.levin.mixin.iface.ItemCooldownManagerAccessor;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.animations.Animation;
import ru.levin.util.animations.impl.EaseBackIn;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;
import ru.levin.util.player.ServerUtil;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.Scissor;

@FunctionAnnotation(
   name = "HUD",
   desc = "Interfejs klienta",
   type = Type.Render
)
public class HUD extends Function {
   public final MultiSetting setting = new MultiSetting("Elementy", Arrays.asList("WaterMark", "TargetHUD", "KeyBinds", "StaffList", "PotionHUD", "ItemCoolDownHUD", "Coordinates / TPS", "ArmorHUD", "Notifications"), new String[]{"WaterMark", "TargetHUD", "KeyBinds", "StaffList", "PotionHUD", "ItemCoolDownHUD", "Coordinates / TPS", "ArmorHUD", "Notifications"});
   private final ModeSetting hudColor = new ModeSetting("Kolor HUD-u", "Zwykły", new String[]{"Zwykły", "Zależne od motywu"});
   private final ModeSetting gradientType = new ModeSetting(() -> this.hudColor.is("Zależne od motywu"), "Typ gradientu", "Od lewej do prawej", new String[]{"Od lewej do prawej", "Od prawej do lewej"});
   private final SliderSetting customAlpha = new SliderSetting("Przezroczystość", (double)120.0F, (double)120.0F, (double)255.0F, (double)5.0F);
   private final BooleanSetting visibleCrosshair = new BooleanSetting("Pokazuj TargetHUD po namierzeniu gracza", false, "Pokazuje HUD celu po namierzeniu gracza", () -> this.setting.get("TargetHUD"));
   private final BooleanSetting blur = new BooleanSetting("Rozmycie", false, "Dodaje rozmycie do wszystkich elementów HUD-u");
   private final SliderSetting roundingSilaSanya = new SliderSetting("Zaokrąglenie głowy", (double)2.0F, (double)0.0F, (double)12.0F, (double)1.0F);
   private static final Pattern NAME_PATTERN = Pattern.compile("^\\w{3,16}$");
   private static final Pattern PREFIX_MATCHES = Pattern.compile(".*(mod|мод|adm|адм|help|хелп|curat|курат|own|овн|dev|supp|сапп|yt|ют|сотруд).*", 2);
   private static final class_1792[] TRACKED_ITEMS;
   private static final Map<class_1792, String> ITEM_NAMES;
   public final Dragging watermarkDrag = ExosWare.getInstance().createDrag(this, "WaterMark", 10.0F, 10.0F);
   public final Dragging targethudDrag = ExosWare.getInstance().createDrag(this, "TargetHUD", 10.0F, 45.0F);
   public final Dragging keybindsDrag = ExosWare.getInstance().createDrag(this, "KeyBindsHUD", 10.0F, 95.0F);
   public final Dragging stafflistDrag = ExosWare.getInstance().createDrag(this, "StaffListHUD", 10.0F, 128.0F);
   public final Dragging itemcooldownDrag = ExosWare.getInstance().createDrag(this, "CoolDownHUD", 10.0F, 165.0F);
   public final Dragging potionhudDrag = ExosWare.getInstance().createDrag(this, "PotionHUD", 10.0F, 198.0F);
   public final Dragging coordinateshudDrag = ExosWare.getInstance().createDrag(this, "CoordinatesHUD", 10.0F, 198.0F);
   public final Dragging armorDrag = ExosWare.getInstance().createDrag(this, "ArmorHUD", 478.0F, 468.0F);
   Animation tHudAnimation = new EaseBackIn(300, (double)1.0F, 1.5F);
   private final Vector4f corner = new Vector4f(3.0F, 0.0F, 0.0F, 3.0F);
   class_1309 target = null;
   float health = 0.0F;
   float health2 = 0.0F;
   int activeModules = 0;
   private float heightDynamic = 0.0F;
   private double scale = (double)0.0F;
   private final List<StaffPlayer> staffPlayers = new ArrayList(32);
   private final Set<String> addedPlayers = new HashSet(64);
   private String serverAddressCache = "";
   private boolean isLocalServerCache = false;
   private float potionListHeightDynamic = 0.0F;
   private float cooldownListHeightDynamic = 0.0F;
   private int activeStaff = 0;
   private float hDynam = 0.0F;
   private float widthDynamic = 0.0F;
   private float nameWidth = 0.0F;
   private float lastHealth = 0.0F;
   private float lastAbsorption = 0.0F;
   private float keybindsHeightDynamic = 0.0F;

   public HUD() {
      this.addSettings(new Setting[]{this.setting, this.hudColor, this.gradientType, this.customAlpha, this.visibleCrosshair, this.blur, this.roundingSilaSanya});
   }

   public void onEvent(Event event) {
      if (mc != null && mc.field_1724 != null && mc.field_1687 != null) {
         if (event instanceof EventUpdate && this.setting.get("StaffList")) {
            this.updateStaffPlayers(mc);
         }

         if (event instanceof EventRender2D) {
            EventRender2D eventRender2D = (EventRender2D)event;
            boolean sWaterMark = this.setting.get("WaterMark");
            boolean sTargetHUD = this.setting.get("TargetHUD");
            boolean sStaffList = this.setting.get("StaffList");
            boolean sKeyBinds = this.setting.get("KeyBinds");
            boolean sItemCooldown = this.setting.get("ItemCoolDownHUD");
            boolean sPotion = this.setting.get("PotionHUD");
            boolean sCoordinates = this.setting.get("Coordinates / TPS");
            boolean sArmorHUD = this.setting.get("ArmorHUD");
            boolean sMediaPlayer = this.setting.get("MediaPlayer");
            if (sWaterMark) {
               this.waterMark(eventRender2D);
            }

            if (sTargetHUD) {
               this.targethud(eventRender2D);
            }

            if (sStaffList) {
               this.staffList(eventRender2D);
            }

            if (sKeyBinds) {
               this.keybindHud(eventRender2D);
            }

            if (sItemCooldown) {
               this.cooldown(eventRender2D);
            }

            if (sPotion) {
               this.potion(eventRender2D);
            }

            if (sCoordinates) {
               this.współrzędne(eventRender2D);
            }

            if (sArmorHUD) {
               this.armor(eventRender2D);
            }
         }

      }
   }

   private void armor(EventRender2D eventRender2D) {
      float x = this.armorDrag.getX();
      float y = this.armorDrag.getY();
      int armorCount = 0;

      for(int i = 0; i < 4; ++i) {
         if (!((class_1799)mc.field_1724.method_31548().field_7548.get(i)).method_7960()) {
            ++armorCount;
         }
      }

      int width = armorCount > 0 ? 20 * armorCount : 35;
      this.armorDrag.setWidth((float)width);
      this.armorDrag.setHeight(18.0F);
      float startX = x + (float)width - 20.0F;

      for(int i = 0; i < 4; ++i) {
         class_1799 itemStack = (class_1799)mc.field_1724.method_31548().field_7548.get(i);
         if (!itemStack.method_7960()) {
            eventRender2D.getDrawContext().method_51448().method_22903();
            eventRender2D.getDrawContext().method_51448().method_46416(startX, y + 0.2F, 0.0F);
            eventRender2D.getDrawContext().method_51448().method_22905(1.0F, 1.0F, 1.0F);
            eventRender2D.getDrawContext().method_51428(itemStack, 0, 0, 0);
            eventRender2D.getDrawContext().method_51431(mc.field_1772, itemStack, 0, 0);
            eventRender2D.getDrawContext().method_51448().method_22909();
            startX -= 20.0F;
         }
      }

   }

   private void updateStaffPlayers(class_310 mc) {
      this.staffPlayers.clear();
      this.addedPlayers.clear();
      Map<String, class_640> nameToEntry = new HashMap(mc.field_1724.field_3944.method_2880().size() + 4);

      for(class_640 e : mc.field_1724.field_3944.method_2880()) {
         if (e.method_2966() != null && e.method_2966().getName() != null) {
            nameToEntry.put(e.method_2966().getName().toLowerCase(Locale.ROOT), e);
         }
      }

      String ourName = mc.field_1724.method_5477().getString();
      class_269 scoreboard = mc.field_1687.method_8428();

      for(class_268 team : scoreboard.method_1159()) {
         class_2561 prefixComponent = team.method_1144();
         String prefix = prefixComponent.getString();
         String cleanPrefixLower = this.repairString(prefix).toLowerCase(Locale.ROOT);

         for(String member : team.method_1204()) {
            if (member != null && !member.equals(ourName) && !this.addedPlayers.contains(member) && NAME_PATTERN.matcher(member).matches()) {
               class_640 entry = (class_640)nameToEntry.get(member.toLowerCase(Locale.ROOT));
               boolean isVanished = entry == null;
               if (!isVanished) {
                  if (PREFIX_MATCHES.matcher(cleanPrefixLower).matches() || Manager.STAFF_MANAGER.isStaff(member)) {
                     UUID uuid = entry.method_2966().getId();
                     this.staffPlayers.add(new StaffPlayer(member, prefixComponent, uuid));
                     this.addedPlayers.add(member);
                  }
               } else if (!prefix.isEmpty()) {
                  this.staffPlayers.add(new StaffPlayer(member, prefixComponent, (UUID)null));
                  this.addedPlayers.add(member);
               }
            }
         }
      }

      if (!this.staffPlayers.isEmpty()) {
         this.staffPlayers.sort(Comparator.comparing(StaffPlayer::getName));
      }

   }

   private void potion(EventRender2D eventRender2D) {
      float posX = this.potionhudDrag.getX();
      float posY = this.potionhudDrag.getY();
      float time = (float)(System.currentTimeMillis() % 2000L) / 2000.0F;
      float pulse = (float)(Math.sin((double)time * Math.PI * (double)2.0F) * (double)0.1F + (double)0.9F);
      int headerHeight = 18;
      int padding = 5;
      int lineHeight = 10;
      List<class_1293> activeEffects = new ArrayList(mc.field_1724.method_6026());
      float maxWidth = 100.0F;
      List<Runnable> list = Lists.newArrayListWithCapacity(activeEffects.size());
      float maxDurationWidth = 0.0F;

      for(class_1293 eff : activeEffects) {
         String name = class_1074.method_4662(((class_1291)eff.method_5579().comp_349()).method_5567(), new Object[0]);
         int level = eff.method_5578() + 1;
         String levelStr = level > 1 ? " " + level : "";
         String displayName = name + levelStr;
         float nameWidth = FontUtils.durman[13].getWidth(displayName);
         String duration = this.formatDuration(eff);
         float durationWidth = FontUtils.durman[13].getWidth(duration);
         maxDurationWidth = Math.max(maxDurationWidth, durationWidth);
         float totalWidth = (float)(padding * 2 + 25) + nameWidth + (float)padding + durationWidth;
         if (totalWidth > maxWidth) {
            maxWidth = totalWidth;
         }
      }

      float listHeightTarget = (float)(activeEffects.size() * lineHeight);
      this.potionListHeightDynamic = MathUtil.fast(this.potionListHeightDynamic, listHeightTarget, 15.0F);
      float totalHeight = (float)headerHeight + this.potionListHeightDynamic;
      int alpha = this.customAlpha.get().intValue();
      if (alpha <= 240 && this.blur.get()) {
         RenderUtil.drawBlur(eventRender2D.getDrawContext().method_51448(), posX, posY + (float)headerHeight - 1.0F, maxWidth, this.potionListHeightDynamic + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), 12.0F, Color.white.getRGB());
      }

      StyleManager theme = Manager.STYLE_MANAGER;
      Color upColor = new Color(theme.getFirstColor());
      Color downColor = new Color(theme.getSecondColor());
      if (this.hudColor.is("Zwykły")) {
         RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX, posY, maxWidth, (float)(headerHeight + 1), new Vector4f(3.0F, 0.0F, 0.0F, 3.0F), ColorUtil.hud_color);
      } else {
         int left = ColorUtil.gradient(10, 90, upColor.getRGB(), downColor.getRGB());
         int right = ColorUtil.gradient(10, 0, upColor.getRGB(), downColor.getRGB());
         int top = ColorUtil.gradient(10, 180, upColor.getRGB(), downColor.getRGB());
         int bottom = ColorUtil.gradient(10, 270, upColor.getRGB(), downColor.getRGB());
         boolean leftToRight = this.gradientType.is("Od lewej do prawej");
         int c1 = leftToRight ? ColorUtil.hud_color : left;
         int c2 = leftToRight ? ColorUtil.hud_color : right;
         int c3 = leftToRight ? right : ColorUtil.hud_color;
         int c4 = leftToRight ? left : ColorUtil.hud_color;
         RenderUtil.rectRGB(eventRender2D.getDrawContext().method_51448(), posX, posY, maxWidth, (float)(headerHeight + 1), this.corner, c1, c2, c3, c4);
      }

      RenderUtil.drawTexture(eventRender2D.getDrawContext().method_51448(), "images/hud/potion.png", posX + maxWidth - 16.0F, posY + 4.5F, 11.0F, 11.0F, 0.0F, Color.white.getRGB());
      FontUtils.durman[15].drawLeftAligned(eventRender2D.getDrawContext().method_51448(), "Effects", posX + 10.0F, posY + 5.0F, -1);
      RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX, posY + (float)headerHeight - 1.0F, maxWidth, this.potionListHeightDynamic + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), (new Color(22, 22, 22, alpha)).getRGB());
      Scissor.push();
      Scissor.setFromComponentCoordinates((double)posX, (double)posY, (double)maxWidth, (double)((float)headerHeight + this.potionListHeightDynamic + (float)padding / 2.0F + 5.0F));
      float yOffset = posY + (float)headerHeight + (float)padding - 1.0F;
      class_4074 spriteManager = mc.method_18505();

      for(class_1293 eff : activeEffects) {
         class_1291 effect = (class_1291)eff.method_5579().comp_349();
         class_6880<class_1291> holder = eff.method_5579();
         String name = class_1074.method_4662(effect.method_5567(), new Object[0]);
         int level = eff.method_5578() + 1;
         String levelStr = level > 1 ? " " + level : "";
         String displayName = name + levelStr;
         String duration = this.formatDuration(eff);
         int ticksLeft = eff.method_5584();
         int colorAlpha;
         if (ticksLeft <= 60 && ticksLeft > 0) {
            colorAlpha = (int)(Math.sin((double)System.currentTimeMillis() / (double)200.0F) * (double)80.0F + (double)128.0F);
         } else {
            colorAlpha = 255;
         }

         int color = ColorUtil.rgba(255, 255, 255, colorAlpha);
         class_1058 texture = spriteManager.method_18663(holder);
         list.add((Runnable)() -> eventRender2D.getDrawContext().method_52710(class_1921::method_62277, texture, (int)(posX + (float)padding - 1.5F), (int)yOffset - 1, 9, 9, -1));
         RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX + (float)padding + 9.0F, yOffset - 1.0F, 1.2F, 9.0F, 0.0F, (new Color(255, 255, 255, 120)).getRGB());
         FontUtils.durman[13].drawLeftAligned(eventRender2D.getDrawContext().method_51448(), displayName, posX + (float)padding + 14.0F, yOffset - 1.0F, color);
         RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX + maxWidth - maxDurationWidth - (float)padding - 7.0F, yOffset - 1.0F, 8.0F + maxDurationWidth, 10.0F, 1.0F, ColorUtil.hud_color);
         FontUtils.durman[13].drawLeftAligned(eventRender2D.getDrawContext().method_51448(), duration, posX + maxWidth - maxDurationWidth - (float)padding - 3.0F, yOffset - 0.3F, color);
         yOffset += (float)lineHeight;
      }

      Scissor.unset();
      Scissor.pop();
      list.forEach(Runnable::run);
      this.potionhudDrag.setWidth(maxWidth);
      this.potionhudDrag.setHeight(totalHeight + 5.0F);
   }

   private String formatDuration(class_1293 eff) {
      if (!eff.method_48559() && eff.method_5584() <= 18000) {
         String raw = class_1292.method_5577(eff, 1.0F, 20.0F).getString();
         return raw.replace("{", "").replace("}", "");
      } else {
         return "**:**";
      }
   }

   private void cooldown(EventRender2D eventRender2D) {
      float posX = this.itemcooldownDrag.getX();
      float posY = this.itemcooldownDrag.getY();
      int headerHeight = 18;
      int padding = 5;
      int lineHeight = 10;
      List<class_1792> activeItems = new ArrayList();
      float maxWidth = 100.0F;
      class_1796 manager = mc.field_1724.method_7357();
      ItemCooldownManagerAccessor accessor = (ItemCooldownManagerAccessor)manager;

      for(class_1792 item : TRACKED_ITEMS) {
         class_1799 stack = new class_1799(item);
         if (manager.method_7904(stack)) {
            activeItems.add(item);
            String itemName = (String)ITEM_NAMES.getOrDefault(item, stack.method_7964().getString());
            class_2960 id = manager.method_62836(stack);
            Object rawEntry = accessor.getEntries().get(id);
            float remainingSeconds = 0.0F;
            if (rawEntry instanceof ItemCooldownEntryAccessor) {
               ItemCooldownEntryAccessor entry = (ItemCooldownEntryAccessor)rawEntry;
               int end = entry.getEndTick();
               int current = accessor.getTick();
               float remainingTicks = (float)end - ((float)current + mc.method_61966().method_60637(true));
               remainingSeconds = Math.max(0.0F, remainingTicks / 20.0F);
            }

            String timeLeft = this.formatCooldownTime(remainingSeconds);
            float nameWidth = FontUtils.durman[13].getWidth(itemName);
            float timeWidth = FontUtils.durman[13].getWidth(timeLeft);
            float totalWidth = (float)(padding * 2 + 25) + nameWidth + (float)padding + timeWidth;
            if (totalWidth > maxWidth) {
               maxWidth = totalWidth;
            }
         }
      }

      float listHeightTarget = (float)(activeItems.size() * lineHeight);
      this.cooldownListHeightDynamic = MathUtil.fast(this.cooldownListHeightDynamic, listHeightTarget, 15.0F);
      float totalHeight = (float)headerHeight + this.cooldownListHeightDynamic;
      int alpha = this.customAlpha.get().intValue();
      if (alpha <= 240 && this.blur.get()) {
         RenderUtil.drawBlur(eventRender2D.getDrawContext().method_51448(), posX, posY + (float)headerHeight - 1.0F, maxWidth, this.cooldownListHeightDynamic + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), 12.0F, Color.white.getRGB());
      }

      StyleManager theme = Manager.STYLE_MANAGER;
      Color upColor = new Color(theme.getFirstColor());
      Color downColor = new Color(theme.getSecondColor());
      if (this.hudColor.is("Zwykły")) {
         RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX, posY, maxWidth, (float)(headerHeight + 1), new Vector4f(3.0F, 0.0F, 0.0F, 3.0F), ColorUtil.hud_color);
      } else {
         int left = ColorUtil.gradient(10, 90, upColor.getRGB(), downColor.getRGB());
         int right = ColorUtil.gradient(10, 0, upColor.getRGB(), downColor.getRGB());
         int top = ColorUtil.gradient(10, 180, upColor.getRGB(), downColor.getRGB());
         int bottom = ColorUtil.gradient(10, 270, upColor.getRGB(), downColor.getRGB());
         boolean leftToRight = this.gradientType.is("Od lewej do prawej");
         int c1 = leftToRight ? ColorUtil.hud_color : left;
         int c2 = leftToRight ? ColorUtil.hud_color : right;
         int c3 = leftToRight ? right : ColorUtil.hud_color;
         int c4 = leftToRight ? left : ColorUtil.hud_color;
         RenderUtil.rectRGB(eventRender2D.getDrawContext().method_51448(), posX, posY, maxWidth, (float)(headerHeight + 1), this.corner, c1, c2, c3, c4);
      }

      RenderUtil.drawTexture(eventRender2D.getDrawContext().method_51448(), "images/hud/cooldown.png", posX + maxWidth - 17.0F, posY + 4.5F, 11.0F, 11.0F, 0.0F, Color.white.getRGB());
      FontUtils.durman[15].drawLeftAligned(eventRender2D.getDrawContext().method_51448(), "Cooldowns", posX + 10.0F, posY + 5.0F, -1);
      RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX, posY + (float)headerHeight - 1.0F, maxWidth, this.cooldownListHeightDynamic + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), (new Color(22, 22, 22, alpha)).getRGB());
      Scissor.push();
      Scissor.setFromComponentCoordinates((double)posX, (double)posY, (double)maxWidth, (double)((float)headerHeight + this.cooldownListHeightDynamic + (float)padding / 2.0F + 5.0F));
      float yOffset = posY + (float)headerHeight + (float)padding - 1.0F;

      for(class_1792 item : activeItems) {
         class_1799 stack = item.method_7854();
         String itemName = (String)ITEM_NAMES.getOrDefault(item, stack.method_7964().getString());
         class_2960 id = manager.method_62836(stack);
         Object rawEntry = accessor.getEntries().get(id);
         float remainingSeconds = 0.0F;
         if (rawEntry instanceof ItemCooldownEntryAccessor entry) {
            int end = entry.getEndTick();
            int current = accessor.getTick();
            float remainingTicks = (float)end - ((float)current + mc.method_61966().method_60637(true));
            remainingSeconds = Math.max(0.0F, remainingTicks / 20.0F);
         }

         String timeLeft = this.formatCooldownTime(remainingSeconds);
         RenderAddon.renderItem(eventRender2D.getDrawContext(), stack, posX + (float)padding - 1.5F, yOffset - 1.0F, 0.6F, false);
         RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX + (float)padding + 10.0F, yOffset - 0.5F, 1.2F, 9.0F, 0.0F, (new Color(255, 255, 255, 120)).getRGB());
         FontUtils.durman[13].drawLeftAligned(eventRender2D.getDrawContext().method_51448(), itemName, posX + (float)padding + 14.0F, yOffset - 0.3F, -1);
         float timeWidth = FontUtils.durman[13].getWidth(timeLeft);
         RenderUtil.drawRoundedRect(eventRender2D.getDrawContext().method_51448(), posX + maxWidth - timeWidth - (float)padding - 5.0F, yOffset - 1.0F, 6.0F + timeWidth, 10.0F, 1.0F, ColorUtil.hud_color);
         FontUtils.durman[13].drawLeftAligned(eventRender2D.getDrawContext().method_51448(), timeLeft, posX + maxWidth - timeWidth - (float)padding - 2.0F, yOffset - 0.3F, -1);
         yOffset += (float)lineHeight;
      }

      Scissor.unset();
      Scissor.pop();
      this.itemcooldownDrag.setWidth(maxWidth);
      this.itemcooldownDrag.setHeight(totalHeight + 5.0F);
   }

   private void staffList(EventRender2D render2D) {
      float posX = this.stafflistDrag.getX();
      float posY = this.stafflistDrag.getY();
      RenderFonts fontBig = FontUtils.durman[15];
      RenderFonts fontSmall = FontUtils.durman[13];
      int headerHeight = 18;
      int padding = 4;
      int offset = 10;
      float width = Math.max(this.nameWidth + 60.0F, 100.0F);
      int index = 0;
      this.nameWidth = 0.0F;
      this.hDynam = MathUtil.fast(this.hDynam, (float)(this.activeStaff * offset), 15.0F);
      this.widthDynamic = MathUtil.fast(this.widthDynamic, width, 8.0F);
      int alpha = this.customAlpha.get().intValue();
      if (alpha <= 240 && this.blur.get()) {
         RenderUtil.drawBlur(render2D.getDrawContext().method_51448(), posX, posY + (float)headerHeight - 1.0F, this.widthDynamic, this.hDynam + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), 12.0F, Color.white.getRGB());
      }

      StyleManager theme = Manager.STYLE_MANAGER;
      Color upColor = new Color(theme.getFirstColor());
      Color downColor = new Color(theme.getSecondColor());
      if (this.hudColor.is("Zwykły")) {
         RenderUtil.drawRoundedRect(render2D.getDrawContext().method_51448(), posX, posY, this.widthDynamic, (float)(headerHeight + 1), this.corner, ColorUtil.hud_color);
      } else {
         int left = ColorUtil.gradient(10, 90, upColor.getRGB(), downColor.getRGB());
         int right = ColorUtil.gradient(10, 0, upColor.getRGB(), downColor.getRGB());
         int top = ColorUtil.gradient(10, 180, upColor.getRGB(), downColor.getRGB());
         int bottom = ColorUtil.gradient(10, 270, upColor.getRGB(), downColor.getRGB());
         boolean leftToRight = this.gradientType.is("Od lewej do prawej");
         int c1 = leftToRight ? ColorUtil.hud_color : left;
         int c2 = leftToRight ? ColorUtil.hud_color : right;
         int c3 = leftToRight ? right : ColorUtil.hud_color;
         int c4 = leftToRight ? left : ColorUtil.hud_color;
         RenderUtil.rectRGB(render2D.getDrawContext().method_51448(), posX, posY, this.widthDynamic, (float)(headerHeight + 1), this.corner, c1, c2, c3, c4);
      }

      RenderUtil.drawTexture(render2D.getDrawContext().method_51448(), "images/hud/staff.png", posX + this.widthDynamic - (float)headerHeight, posY + 4.0F, 12.0F, 12.0F, 0.0F, Color.white.getRGB());
      fontBig.drawLeftAligned(render2D.getDrawContext().method_51448(), "StaffList", posX + 10.0F, posY + 5.0F, -1);
      RenderUtil.drawRoundedRect(render2D.getDrawContext().method_51448(), posX, posY + (float)headerHeight - 1.0F, this.widthDynamic, this.hDynam + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), (new Color(22, 22, 22, alpha)).getRGB());
      if (!this.staffPlayers.isEmpty()) {
         Scissor.push();
         Scissor.setFromComponentCoordinates((double)posX, (double)posY, (double)this.widthDynamic, (double)((float)headerHeight + this.hDynam + (float)padding / 2.0F + 5.0F));
         Map<String, class_640> playerInfoMap = new HashMap();

         for(class_640 info : mc.method_1562().method_2880()) {
            playerInfoMap.put(info.method_2966().getName(), info);
         }

         for(StaffPlayer staff : this.staffPlayers) {
            String staffname = staff.getName();
            String status = staff.getStatus().getString();
            float statusWidth = fontSmall.getWidth(status);
            float currentWidth = fontSmall.getWidth(staffname);
            if (currentWidth > this.nameWidth) {
               this.nameWidth = currentWidth;
            }

            float baseY = posY + (float)headerHeight + (float)padding + (float)(index * offset);
            class_640 playerInfo = (class_640)playerInfoMap.get(staffname);
            if (playerInfo != null) {
               if (staff.getStatus() != HUD.StaffPlayer.Status.VANISHED && staff.getStatus() != HUD.StaffPlayer.Status.SPEC) {
                  RenderAddon.drawStaffHead(render2D.getDrawContext().method_51448(), playerInfo.method_52810().comp_1626(), posX + (float)padding, baseY - 1.0F, 9.0F, 3.0F);
               }
            } else {
               RenderUtil.drawTexture(render2D.getDrawContext().method_51448(), "images/hud/staffvanish.png", posX + (float)padding, baseY - 1.0F, 9.0F, 9.0F, 3.0F, Color.white.getRGB());
            }

            RenderUtil.drawRoundedRect(render2D.getDrawContext().method_51448(), posX + (float)padding + 11.0F, baseY - 0.8F, 1.2F, 9.0F, 0.0F, (new Color(255, 255, 255, 120)).getRGB());
            fontSmall.drawLeftAligned(render2D.getDrawContext().method_51448(), staffname, posX + (float)padding + 16.0F, baseY - 0.5F, Color.WHITE.getRGB());
            fontSmall.drawLeftAligned(render2D.getDrawContext().method_51448(), status, posX + this.widthDynamic - statusWidth - 4.0F, baseY - 1.0F, this.getStatusColor(staff.getStatus()));
            ++index;
         }

         Scissor.unset();
         Scissor.pop();
      }

      this.activeStaff = index;
      this.stafflistDrag.setWidth(this.widthDynamic);
      this.stafflistDrag.setHeight(this.hDynam + (float)headerHeight + (float)padding + 1.0F);
   }

   private void targethud(EventRender2D render2D) {
      float x = this.targethudDrag.getX();
      float y = this.targethudDrag.getY();
      this.target = this.getTarget(this.target);
      this.scale = this.tHudAnimation.getOutput();
      if (this.scale != (double)0.0F && this.target != null) {
         float rawHealth = class_3532.method_15363(ServerUtil.getHealth(this.target), 0.0F, 1.0F);
         float rawAbsorption = class_3532.method_15363(this.target.method_6067(), 0.0F, 7.1F);
         this.lastHealth = MathUtil.fast(this.lastHealth, rawHealth, 8.0F);
         this.lastAbsorption = MathUtil.fast(this.lastAbsorption, rawAbsorption, 8.0F);
         String healthDisplay = String.format(Locale.ENGLISH, "%.0f", this.lastHealth * 20.0F);
         render2D.getMatrixStack().method_22903();
         RenderAddon.sizeAnimation(render2D.getMatrixStack(), (double)(x + 60.0F), (double)(y + 17.5F), this.scale);
         RenderUtil.drawRoundedRect(render2D.getDrawContext().method_51448(), x, y, 120.0F, 35.0F, 3.0F, ColorUtil.hud_color);
         String displayName = Manager.FUNCTION_MANAGER.nameProtect.getProtectedName(this.target.method_5477().getString());
         if (displayName.length() > 12) {
            displayName = displayName.substring(0, 12) + "...";
         }

         FontUtils.durman[15].drawLeftAligned(render2D.getDrawContext().method_51448(), displayName, x + 35.0F, y + 5.0F, -1);
         RenderAddon.drawHead(render2D.getDrawContext().method_51448(), this.target, x + 4.0F, y + 3.5F, 28.0F, this.roundingSilaSanya.get().floatValue());
         RenderUtil.drawRoundedRect(render2D.getDrawContext().method_51448(), x + 34.2F, y + 26.0F, 82.0F, 5.0F, 0.0F, (new Color(44, 41, 42, 255)).getRGB());
         StyleManager theme = Manager.STYLE_MANAGER;
         Color upColor = new Color(theme.getFirstColor());
         Color downColor = new Color(theme.getSecondColor());
         Vector4i vec = new Vector4i(ColorUtil.gradient(5, 90, upColor.getRGB(), downColor.getRGB()), ColorUtil.gradient(5, 0, upColor.getRGB(), downColor.getRGB()), ColorUtil.gradient(5, 180, upColor.getRGB(), downColor.getRGB()), ColorUtil.gradient(5, 270, upColor.getRGB(), downColor.getRGB()));
         RenderUtil.rectRGB(render2D.getDrawContext().method_51448(), x + 34.2F, y + 26.0F, 82.0F * this.lastHealth, 5.0F, 0.0F, vec.w, vec.x, vec.y, vec.z);
         RenderUtil.drawRoundedRect(render2D.getDrawContext().method_51448(), x + 34.2F, y + 26.0F, 4.0F * this.lastAbsorption, 5.0F, 0.0F, Color.YELLOW.getRGB());
         FontUtils.sf_bold[13].centeredDraw(render2D.getDrawContext().method_51448(), healthDisplay + " HP", x + 105.0F, y + 16.0F, -1);
         List<class_1799> stacks = new ArrayList();
         stacks.add(this.target.method_6047());
         stacks.add(this.target.method_6079());
         stacks.removeIf((i) -> i.method_7909() instanceof class_1739 || i.method_7960());
         float renderOffset = 0.0F;

         for(class_1799 stack : stacks) {
            render2D.getDrawContext().method_51448().method_22903();
            render2D.getDrawContext().method_51448().method_46416(x + renderOffset + 35.0F, y + 16.0F, 0.0F);
            render2D.getDrawContext().method_51448().method_22905(0.5F, 0.5F, 1.0F);
            render2D.getDrawContext().method_51429(stack, 0, 0, 7, 0);
            render2D.getDrawContext().method_51431(mc.field_1772, stack, 0, 0);
            render2D.getDrawContext().method_51448().method_22909();
            renderOffset += 15.0F;
         }

         render2D.getMatrixStack().method_22909();
         this.targethudDrag.setWidth(120.0F);
         this.targethudDrag.setHeight(35.0F);
      }
   }

   private void waterMark(EventRender2D render2D) {
      float x = this.watermarkDrag.getX();
      float y = this.watermarkDrag.getY();
      String textLogo = "303 Client";
      String var10000 = Manager.USER_PROFILE.getName();
      String textInfo = var10000 + " | " + ClientManager.getFps() + " FPS | " + ClientManager.getPing() + " MS | " + ClientManager.getBps(mc.field_1724) + " BPS";
      class_4587 matrices = render2D.getDrawContext().method_51448();
      RenderFonts fontBig = FontUtils.durman[16];
      RenderFonts fontSmall = FontUtils.durman[15];
      float logoWidth = fontBig.getWidth(textLogo);
      float infoWidth = fontSmall.getWidth(textInfo);
      int alpha = this.customAlpha.get().intValue();
      int infoBoxColor = (new Color(22, 22, 22, alpha)).getRGB();
      if (alpha <= 240 && this.blur.get()) {
         RenderUtil.drawBlur(matrices, x + 81.0F, y, 10.0F + infoWidth, 18.0F, new Vector4f(0.0F, 0.0F, 3.0F, 3.0F), 12.0F, Color.white.getRGB());
      }

      RenderUtil.drawRoundedRect(matrices, x, y, 17.0F + logoWidth, 18.0F, new Vector4f(5.0F, 5.0F, 0.0F, 0.0F), ColorUtil.hud_color);
      RenderUtil.drawRoundedRect(matrices, x + 81.0F, y, 10.0F + infoWidth, 18.0F, new Vector4f(0.0F, 0.0F, 3.0F, 3.0F), infoBoxColor);
      fontBig.renderGradientText(matrices, textLogo, x + 8.0F, y + 4.0F, ColorUtil.getColorStyle(180.0F), ColorUtil.getColorStyle(30.0F));
      fontSmall.drawLeftAligned(matrices, textInfo, x + 85.5F, y + 4.5F, -1);
      this.watermarkDrag.setHeight(18.0F);
      this.watermarkDrag.setWidth(26.0F + logoWidth + infoWidth);
   }

   private void współrzędne(EventRender2D render2D) {
      int screenWidth = mc.method_22683().method_4486();
      RenderFonts font = FontUtils.sf_bold[17];
      float x = this.coordinateshudDrag.getX();
      float y = this.coordinateshudDrag.getY();
      String coords = String.format("X: %d, Y: %d, Z: %d", (int)mc.field_1724.method_23317(), (int)mc.field_1724.method_23318(), (int)mc.field_1724.method_23321());
      float var10000 = ClientManager.getTPS();
      String tps = "TPS: " + var10000;
      int textWidth = (int)font.getWidth(coords);
      boolean isLeftSide = x < (float)(screenWidth / 2);
      if (isLeftSide) {
         font.drawLeftAligned(render2D.getDrawContext().method_51448(), coords, x, y + 12.0F, Color.white.getRGB());
         font.drawLeftAligned(render2D.getDrawContext().method_51448(), tps, x, y, Color.white.getRGB());
         this.coordinateshudDrag.setWidth((float)textWidth);
      } else {
         font.drawRightAligned(render2D.getDrawContext().method_51448(), coords, x + (float)textWidth, y + 12.0F, Color.white.getRGB());
         font.drawRightAligned(render2D.getDrawContext().method_51448(), tps, x + (float)textWidth, y, Color.white.getRGB());
         this.coordinateshudDrag.setWidth((float)textWidth);
      }

      this.coordinateshudDrag.setHeight(24.0F);
   }

   private void keybindHud(EventRender2D render2D) {
      float posX = this.keybindsDrag.getX();
      float posY = this.keybindsDrag.getY();
      int headerHeight = 18;
      int padding = 5;
      int lineHeight = 12;
      int index = 0;
      class_4587 matrices = render2D.getDrawContext().method_51448();
      RenderFonts font = FontUtils.durman[13];
      int alpha = this.customAlpha.get().intValue();
      float maxWidth = 100.0F;

      for(Function f : Manager.FUNCTION_MANAGER.getFunctions()) {
         if (f.bind != 0 && f.state) {
            String bindKey = this.getShortKey(ClientManager.getKey(f.bind));
            float nameWidth = font.getWidth(f.name);
            float bindWidth = font.getWidth(bindKey);
            float totalWidth = (float)(padding * 2) + nameWidth + 14.0F + bindWidth;
            if (totalWidth > maxWidth) {
               maxWidth = totalWidth;
            }
         }

         for(Setting setting : f.getSettings()) {
            if (setting instanceof BindBooleanSetting bindSetting) {
               if (bindSetting.isVisible() && bindSetting.getBindKey() != 0 && bindSetting.get()) {
                  String bindKey = this.getShortKey(ClientManager.getKey(bindSetting.getBindKey()));
                  float nameWidth = font.getWidth(bindSetting.getName());
                  float bindWidth = font.getWidth(bindKey);
                  float totalWidth = (float)(padding * 2) + nameWidth + 14.0F + bindWidth;
                  if (totalWidth > maxWidth) {
                     maxWidth = totalWidth;
                  }
               }
            }
         }
      }

      float listHeightTarget = (float)(this.activeModules * lineHeight);
      this.keybindsHeightDynamic = MathUtil.fast(this.keybindsHeightDynamic, listHeightTarget, 15.0F);
      float totalHeight = (float)headerHeight + this.keybindsHeightDynamic;
      float animatedWidth = MathUtil.fast(this.keybindsDrag.getWidth(), maxWidth, 15.0F);
      if (alpha <= 240 && this.blur.get()) {
         RenderUtil.drawBlur(matrices, posX, posY + (float)headerHeight - 1.0F, animatedWidth, this.keybindsHeightDynamic + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), 12.0F, Color.white.getRGB());
      }

      StyleManager theme = Manager.STYLE_MANAGER;
      Color upColor = new Color(theme.getFirstColor());
      Color downColor = new Color(theme.getSecondColor());
      if (this.hudColor.is("Zwykły")) {
         RenderUtil.drawRoundedRect(matrices, posX, posY, animatedWidth, (float)(headerHeight + 1), new Vector4f(3.0F, 0.0F, 0.0F, 3.0F), ColorUtil.hud_color);
      } else {
         int left = ColorUtil.gradient(10, 90, upColor.getRGB(), downColor.getRGB());
         int right = ColorUtil.gradient(10, 0, upColor.getRGB(), downColor.getRGB());
         int top = ColorUtil.gradient(10, 180, upColor.getRGB(), downColor.getRGB());
         int bottom = ColorUtil.gradient(10, 270, upColor.getRGB(), downColor.getRGB());
         boolean leftToRight = this.gradientType.is("Od lewej do prawej");
         int c1 = leftToRight ? ColorUtil.hud_color : left;
         int c2 = leftToRight ? ColorUtil.hud_color : right;
         int c3 = leftToRight ? right : ColorUtil.hud_color;
         int c4 = leftToRight ? left : ColorUtil.hud_color;
         RenderUtil.rectRGB(matrices, posX, posY, animatedWidth, (float)(headerHeight + 1), this.corner, c1, c2, c3, c4);
      }

      RenderUtil.drawTexture(matrices, "images/hud/keybinds.png", posX + animatedWidth - 17.0F, posY + 4.5F, 11.0F, 11.0F, 0.0F, Color.white.getRGB());
      FontUtils.durman[15].drawLeftAligned(matrices, "KeyBinds", posX + 10.0F, posY + 5.0F, -1);
      RenderUtil.drawRoundedRect(matrices, posX, posY + (float)headerHeight - 1.0F, animatedWidth, this.keybindsHeightDynamic + 6.0F, new Vector4f(0.0F, 3.0F, 3.0F, 0.0F), (new Color(22, 22, 22, alpha)).getRGB());
      Scissor.push();
      Scissor.setFromComponentCoordinates((double)posX, (double)posY, (double)animatedWidth, (double)((float)headerHeight + this.keybindsHeightDynamic + (float)padding / 2.0F + 5.0F));
      float yOffset = posY + (float)headerHeight + (float)padding - 1.0F;

      for(Function f : Manager.FUNCTION_MANAGER.getFunctions()) {
         if (f.bind != 0 && f.state) {
            String bindKey = this.getShortKey(ClientManager.getKey(f.bind));
            float bindWidth = font.getWidth(bindKey);
            font.drawLeftAligned(matrices, f.name, posX + (float)padding + 2.0F, yOffset, -1);
            RenderUtil.drawRoundedRect(matrices, posX + animatedWidth - bindWidth - (float)padding - 6.0F, yOffset - 1.0F, bindWidth + 8.0F, 10.0F, 2.0F, ColorUtil.hud_color);
            font.drawLeftAligned(matrices, bindKey, posX + animatedWidth - bindWidth - (float)padding - 2.0F, yOffset - 0.3F, -1);
            yOffset += (float)lineHeight;
            ++index;
         }

         for(Setting setting : f.getSettings()) {
            if (setting instanceof BindBooleanSetting bindSetting) {
               if (bindSetting.isVisible() && bindSetting.getBindKey() != 0 && bindSetting.get()) {
                  String bindKey = this.getShortKey(ClientManager.getKey(bindSetting.getBindKey()));
                  float bindWidth = font.getWidth(bindKey);
                  font.drawLeftAligned(matrices, bindSetting.getName(), posX + (float)padding + 2.0F, yOffset, -1);
                  RenderUtil.drawRoundedRect(matrices, posX + animatedWidth - bindWidth - (float)padding - 6.0F, yOffset - 1.0F, bindWidth + 8.0F, 10.0F, 2.0F, ColorUtil.hud_color);
                  font.drawLeftAligned(matrices, bindKey, posX + animatedWidth - bindWidth - (float)padding - 2.0F, yOffset - 0.3F, -1);
                  yOffset += (float)lineHeight;
                  ++index;
               }
            }
         }
      }

      Scissor.unset();
      Scissor.pop();
      this.activeModules = index;
      this.keybindsDrag.setWidth(animatedWidth);
      this.keybindsDrag.setHeight(totalHeight + 5.0F);
   }

   private String getShortKey(String key) {
      if (key == null) {
         return "";
      } else {
         String bindText = key.toUpperCase();
         return bindText.length() > 6 ? bindText.substring(0, 6) + "…" : bindText;
      }
   }

   public class_1309 getTarget(class_1309 nullTarget) {
      class_1309 target = nullTarget;
      if (Manager.FUNCTION_MANAGER.attackAura.target instanceof class_1309) {
         target = Manager.FUNCTION_MANAGER.attackAura.target;
         this.tHudAnimation.setDirection(class_2352.field_11056);
      } else if (this.visibleCrosshair.get() && mc.field_1765 instanceof class_3966) {
         class_1297 aimed = ((class_3966)mc.field_1765).method_17782();
         if (aimed instanceof class_1309) {
            target = (class_1309)aimed;
            this.tHudAnimation.setDirection(class_2352.field_11056);
         } else {
            this.tHudAnimation.setDirection(class_2352.field_11060);
         }
      } else if (mc.field_1755 instanceof class_408) {
         target = mc.field_1724;
         this.tHudAnimation.setDirection(class_2352.field_11056);
      } else {
         this.tHudAnimation.setDirection(class_2352.field_11060);
      }

      return target;
   }

   private String repairString(String input) {
      StringBuilder sb = new StringBuilder(input.length());

      for(char c : input.toCharArray()) {
         if (c >= '！' && c <= '～') {
            sb.append((char)(c - 'ﻠ'));
         } else {
            sb.append(c);
         }
      }

      return sb.toString();
   }

   public void onDisable() {
      this.staffPlayers.clear();
      this.addedPlayers.clear();
   }

   private String processName(String original) {
      return original.length() <= 12 && !original.matches(".*\\d.*") ? original : original.substring(0, Math.min(9, original.length())) + "...";
   }

   private int getStatusColor(StaffPlayer.Status status) {
      switch (status.ordinal()) {
         case 1 -> {
            return Color.ORANGE.getRGB();
         }
         case 2 -> {
            return Color.YELLOW.getRGB();
         }
         case 3 -> {
            return Color.RED.getRGB();
         }
         default -> {
            return Color.GREEN.getRGB();
         }
      }
   }

   private String formatCooldownTime(float seconds) {
      int totalSeconds = (int)Math.floor((double)seconds);
      int minutes = totalSeconds / 60;
      int secs = totalSeconds % 60;
      if (minutes > 0) {
         return secs > 0 ? String.format("%d min %02d s", minutes, secs) : String.format("%d min", minutes);
      } else {
         return String.format("%d s", secs);
      }
   }

   static {
      TRACKED_ITEMS = new class_1792[]{class_1802.field_8634, class_1802.field_8233, class_1802.field_8639, class_1802.field_8255, class_1802.field_8463, class_1802.field_8367, class_1802.field_8288, class_1802.field_8543, class_1802.field_8551, class_1802.field_8449, class_1802.field_22021, class_1802.field_8287, class_1802.field_8614};
      Map<class_1792, String> tmp = new HashMap(16);
      tmp.put(class_1802.field_8634, "Perła Endu");
      tmp.put(class_1802.field_8233, "Owoc chorus");
      tmp.put(class_1802.field_8639, "Fajerwerk");
      tmp.put(class_1802.field_8255, "Tarcza");
      tmp.put(class_1802.field_8463, "Złote jabłko");
      tmp.put(class_1802.field_8367, "Zaklęte złote jabłko");
      tmp.put(class_1802.field_8288, "Totem");
      tmp.put(class_1802.field_8543, "Śnieżka");
      tmp.put(class_1802.field_8551, "Ładunek");
      tmp.put(class_1802.field_8449, "Dezorientacja");
      tmp.put(class_1802.field_22021, "Pułapka");
      tmp.put(class_1802.field_8287, "Butelka doświadczenia");
      tmp.put(class_1802.field_8614, "Aura");
      ITEM_NAMES = Collections.unmodifiableMap(tmp);
   }

   public class StaffPlayer {
      private final String name;
      private final class_2561 prefix;
      private Status status;
      private final long joinTime;
      private class_1934 gameMode;
      private boolean isOnPlayerList;
      private final UUID uuid;

      public StaffPlayer(String name, @Nullable class_2561 prefix, UUID uuid) {
         this.name = name;
         this.prefix = prefix;
         this.uuid = uuid;
         this.joinTime = System.currentTimeMillis();
         this.updateStatus();
      }

      public void updateStatus() {
         if (IMinecraft.mc != null && IMinecraft.mc.field_1687 != null && IMinecraft.mc.method_1562() != null) {
            class_640 entry = null;
            if (this.uuid != null) {
               for(class_640 e : IMinecraft.mc.method_1562().method_2880()) {
                  if (this.uuid.equals(e.method_2966().getId())) {
                     entry = e;
                     break;
                  }
               }
            } else {
               for(class_640 e : IMinecraft.mc.method_1562().method_2880()) {
                  if (e.method_2966() != null && e.method_2966().getName() != null && e.method_2966().getName().equalsIgnoreCase(this.name)) {
                     entry = e;
                     break;
                  }
               }
            }

            this.isOnPlayerList = entry != null;
            this.gameMode = entry != null ? entry.method_2958() : null;
            boolean entityLoaded = false;
            if (entry != null) {
               class_1657 loaded = IMinecraft.mc.field_1687.method_18470(entry.method_2966().getId());
               entityLoaded = loaded != null;
            }

            if (!this.isOnPlayerList) {
               this.status = HUD.StaffPlayer.Status.VANISHED;
            } else if (this.gameMode == class_1934.field_9219) {
               this.status = HUD.StaffPlayer.Status.SPEC;
            } else if (entityLoaded) {
               this.status = HUD.StaffPlayer.Status.NEAR;
            } else {
               this.status = HUD.StaffPlayer.Status.NONE;
            }

         } else {
            this.status = HUD.StaffPlayer.Status.VANISHED;
            this.isOnPlayerList = false;
            this.gameMode = null;
         }
      }

      public String getName() {
         return this.name;
      }

      public class_2561 getPrefix() {
         return this.prefix;
      }

      public Status getStatus() {
         return this.status;
      }

      public long getJoinTime() {
         return this.joinTime;
      }

      public class_1934 getGameMode() {
         return this.gameMode;
      }

      public boolean isOnPlayerList() {
         return this.isOnPlayerList;
      }

      public UUID getUuid() {
         return this.uuid;
      }

      public static enum Status {
         NONE("§2[ON]"),
         NEAR("§6[N]"),
         SPEC("§e[GM3]"),
         VANISHED("§c[V]");

         final String string;

         private Status(String string) {
            this.string = string;
         }

         public String getString() {
            return this.string;
         }

         // $FF: synthetic method
         private static Status[] $values() {
            return new Status[]{NONE, NEAR, SPEC, VANISHED};
         }
      }
   }
}
