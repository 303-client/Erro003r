package ru.levin.modules.render;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import ru.levin.util.ScoreboardColorUtil;

public class ScoreBoardStealerGUI extends class_437 {
   private static final int MAX_PAGE_SIZE = 8;
   private final ScoreBoardStealer stealer;
   private final class_437 parentScreen;
   private final int page;
   private final List<String> pendingLines;
   private final List<String> pendingColors;
   private final List<class_342> lineFields;
   private final List<class_342> colorFields;
   private int pageSize;
   private int firstLineIndex;

   public ScoreBoardStealerGUI(ScoreBoardStealer stealer, class_437 parentScreen) {
      this(stealer, parentScreen, 0, stealer.getEditedLines(), stealer.getEditedColors());
   }

   private ScoreBoardStealerGUI(ScoreBoardStealer stealer, class_437 parentScreen, int page, List<String> pendingLines, List<String> pendingColors) {
      super(class_2561.method_43470("ScoreBoard Stealer"));
      this.lineFields = new ArrayList();
      this.colorFields = new ArrayList();
      this.stealer = stealer;
      this.parentScreen = parentScreen;
      this.page = Math.max(0, page);
      this.pendingLines = new ArrayList(pendingLines);
      this.pendingColors = new ArrayList(pendingColors);
   }

   protected void method_25426() {
      super.method_25426();
      this.pageSize = Math.max(1, Math.min(8, (this.field_22790 - 180) / 35));
      int pageCount = Math.max(1, (this.pendingLines.size() + this.pageSize - 1) / this.pageSize);
      int safePage = Math.min(this.page, pageCount - 1);
      this.firstLineIndex = safePage * this.pageSize;
      int colorX = 14;
      int colorWidth = 76;
      int textX = colorX + colorWidth + 8;
      int textWidth = Math.max(80, this.field_22789 - textX - 14);
      int rowY = 60;
      int rowHeight = 35;

      for(int offset = 0; offset < this.pageSize; ++offset) {
         int index = this.firstLineIndex + offset;
         if (index >= this.pendingLines.size()) {
            break;
         }

         class_342 colorField = new class_342(this.field_22793, colorX, rowY + offset * rowHeight + 13, colorWidth, 20, class_2561.method_43470("#RRGGBB"));
         colorField.method_1880(7);
         colorField.method_1852((String)this.pendingColors.get(index));
         this.colorFields.add((class_342)this.method_37063(colorField));
         class_342 lineField = new class_342(this.field_22793, textX, rowY + offset * rowHeight + 13, textWidth, 20, class_2561.method_43470("Tekst scoreboardu"));
         lineField.method_1880(160);
         lineField.method_1852((String)this.pendingLines.get(index));
         this.lineFields.add((class_342)this.method_37063(lineField));
      }

      int navY = this.field_22790 - 74;
      int navWidth = 82;
      ((class_4185)this.method_37063(class_4185.method_46430(class_2561.method_43470("Poprzednia"), (button) -> this.openPage(safePage - 1)).method_46434(14, navY, navWidth, 20).method_46431())).field_22763 = safePage > 0;
      ((class_4185)this.method_37063(class_4185.method_46430(class_2561.method_43470("Następna"), (button) -> this.openPage(safePage + 1)).method_46434(this.field_22789 - navWidth - 14, navY, navWidth, 20).method_46431())).field_22763 = safePage + 1 < pageCount;
      int restoreWidth = Math.min(138, (this.field_22789 - 44) / 3);
      int saveWidth = Math.min(88, (this.field_22789 - 44) / 3);
      int gap = 6;
      int buttonsWidth = restoreWidth + saveWidth + saveWidth + gap * 2;
      int buttonX = (this.field_22789 - buttonsWidth) / 2;
      int buttonY = this.field_22790 - 43;
      this.method_37063(class_4185.method_46430(class_2561.method_43470("Przywróć"), (button) -> this.restoreOriginals()).method_46434(buttonX, buttonY, restoreWidth, 20).method_46431());
      this.method_37063(class_4185.method_46430(class_2561.method_43470("Zapisz"), (button) -> this.saveAndClose()).method_46434(buttonX + restoreWidth + gap, buttonY, saveWidth, 20).method_46431());
      this.method_37063(class_4185.method_46430(class_2561.method_43470("Zamknij"), (button) -> this.saveAndClose()).method_46434(buttonX + restoreWidth + gap + saveWidth + gap, buttonY, saveWidth, 20).method_46431());
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
      this.method_25420(context, mouseX, mouseY, delta);
      super.method_25394(context, mouseX, mouseY, delta);
      context.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 12, 16777215);
      context.method_27534(this.field_22793, class_2561.method_43470("Zmiany są lokalne. Przywróć = odczytany oryginał z serwera."), this.field_22789 / 2, 29, 11450564);
      context.method_25303(this.field_22793, "HEX", 14, 48, 10135476);
      context.method_25303(this.field_22793, "Własny tekst", 98, 48, 10135476);
      List<class_2561> originals = this.stealer.getOriginalTextLines();
      int rowY = 60;
      int rowHeight = 35;

      for(int offset = 0; offset < this.lineFields.size(); ++offset) {
         int index = this.firstLineIndex + offset;
         if (index < originals.size()) {
            context.method_27535(this.field_22793, (class_2561)originals.get(index), 14, rowY + offset * rowHeight, 16777215);
         }
      }

      int pageCount = Math.max(1, (this.pendingLines.size() + this.pageSize - 1) / this.pageSize);
      int var10002 = this.page + 1;
      context.method_27534(this.field_22793, class_2561.method_43470("Strona " + var10002 + " / " + pageCount), this.field_22789 / 2, this.field_22790 - 69, 16777215);
      context.method_27534(this.field_22793, class_2561.method_43470("Wpisz kolor jako #RRGGBB"), this.field_22789 / 2, this.field_22790 - 92, 10135476);
   }

   public boolean method_25421() {
      return false;
   }

   public void method_25419() {
      this.saveChanges();
      this.field_22787.method_1507(this.parentScreen);
   }

   private void openPage(int newPage) {
      this.collectVisibleFields();
      int pageCount = Math.max(1, (this.pendingLines.size() + this.pageSize - 1) / this.pageSize);
      int boundedPage = Math.max(0, Math.min(newPage, pageCount - 1));
      this.field_22787.method_1507(new ScoreBoardStealerGUI(this.stealer, this.parentScreen, boundedPage, this.pendingLines, this.pendingColors));
   }

   private void restoreOriginals() {
      this.stealer.restoreOriginals();
      this.pendingLines.clear();
      this.pendingLines.addAll(this.stealer.getOriginalLines());
      this.pendingColors.clear();
      this.pendingColors.addAll(this.stealer.getOriginalColors());
      this.collectWidgetsFromPending();
   }

   private void collectWidgetsFromPending() {
      for(int offset = 0; offset < this.lineFields.size(); ++offset) {
         int index = this.firstLineIndex + offset;
         if (index < this.pendingLines.size()) {
            ((class_342)this.lineFields.get(offset)).method_1852((String)this.pendingLines.get(index));
            ((class_342)this.colorFields.get(offset)).method_1852((String)this.pendingColors.get(index));
         }
      }

   }

   private void collectVisibleFields() {
      for(int offset = 0; offset < this.lineFields.size(); ++offset) {
         int index = this.firstLineIndex + offset;
         if (index < this.pendingLines.size()) {
            this.pendingLines.set(index, ((class_342)this.lineFields.get(offset)).method_1882());
            this.pendingColors.set(index, ((class_342)this.colorFields.get(offset)).method_1882());
         }
      }

   }

   private void saveChanges() {
      this.collectVisibleFields();
      this.stealer.applyLineChanges(this.pendingLines);
      List<String> safeColors = new ArrayList(this.pendingColors.size());
      List<String> originals = this.stealer.getOriginalColors();

      for(int i = 0; i < this.pendingColors.size(); ++i) {
         String fallback = i < originals.size() ? (String)originals.get(i) : "#FFFFFF";
         safeColors.add(ScoreboardColorUtil.normalizeHex((String)this.pendingColors.get(i), fallback));
      }

      this.stealer.applyLineColors(safeColors);
   }

   private void saveAndClose() {
      this.saveChanges();
      this.field_22787.method_1507(this.parentScreen);
   }
}
