package ru.levin.modules.render;

import java.util.Arrays;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "NoRender",
   type = Type.Render,
   desc = "Ukrywa wybrane elementy ekranu"
)
public class NoRender extends Function {
   public MultiSetting mods = new MultiSetting("Ukryj", Arrays.asList("Drgania kamery", "Ogień na ekranie", "Woda na ekranie", "Duszenie", "Negatywne efekty"), new String[]{"Drgania kamery", "Ogień na ekranie", "Woda na ekranie", "Duszenie", "Tablica wyników", "Negatywne efekty"});

   public NoRender() {
      this.addSettings(new Setting[]{this.mods});
   }

   public void onEvent(Event event) {
   }
}
