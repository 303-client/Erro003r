package ru.levin.modules.combat;

import net.minecraft.class_1713;
import net.minecraft.class_1743;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1829;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventKey;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.InventoryUtil;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "AutoSwap",
   type = Type.Combat,
   desc = "Pozwala zmieniać przedmioty przypisanym klawiszem"
)
public class AutoSwap extends Function {
   private final BindSetting itemSwapKey = new BindSetting("Klawisz zmiany przedmiotu", 0);
   private final ModeSetting firstItem = new ModeSetting("Pierwszy przedmiot", "Tarcza", new String[]{"Tarcza", "Jabłko", "Totem", "Kula", "Fajerwerk"});
   private final ModeSetting secondItem = new ModeSetting("Drugi przedmiot", "Tarcza", new String[]{"Tarcza", "Jabłko", "Totem", "Kula", "Fajerwerk"});
   private final BooleanSetting swapSwordWithAxe = new BooleanSetting("Zamieniaj topór i miecz", false);
   private final BooleanSetting funTimeAndHolyWorldBypass = new BooleanSetting("Obejście FT/HW", false);
   private final TimerUtil timer = new TimerUtil();
   private boolean bypassActive = false;
   private boolean awaitingSwap = false;
   private int pendingSlot = -1;

   public AutoSwap() {
      this.addSettings(new Setting[]{this.itemSwapKey, this.firstItem, this.secondItem, this.swapSwordWithAxe, this.funTimeAndHolyWorldBypass});
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey eventKey) {
         if (eventKey.key == this.itemSwapKey.getKey()) {
            class_1792 itemA = this.getItem(this.firstItem.getIndex());
            class_1792 itemB = this.getItem(this.secondItem.getIndex());
            if (itemA == null || itemB == null) {
               return;
            }

            int inventorySlot = this.findItemInInventory(mc.field_1724.method_6079().method_7909() == itemA ? itemB : itemA);
            if (inventorySlot == -1) {
               return;
            }

            if (this.funTimeAndHolyWorldBypass.get()) {
               this.timer.reset();
               this.bypassActive = true;
               this.awaitingSwap = true;
               this.pendingSlot = inventorySlot;
            } else {
               mc.field_1761.method_2906(0, inventorySlot < 9 ? inventorySlot + 36 : inventorySlot, 40, class_1713.field_7791, mc.field_1724);
               if (this.swapSwordWithAxe.get()) {
                  this.handleWeaponSwap();
               }
            }
         }
      }

      if (this.bypassActive) {
         mc.field_1690.field_1894.method_23481(false);
         mc.field_1690.field_1881.method_23481(false);
         mc.field_1690.field_1913.method_23481(false);
         mc.field_1690.field_1849.method_23481(false);
         mc.field_1690.field_1867.method_23481(false);
         if (this.awaitingSwap && this.timer.hasTimeElapsed(90L)) {
            this.awaitingSwap = false;
            if (this.pendingSlot != -1) {
               mc.field_1761.method_2906(0, this.pendingSlot < 9 ? this.pendingSlot + 36 : this.pendingSlot, 40, class_1713.field_7791, mc.field_1724);
               if (this.swapSwordWithAxe.get()) {
                  this.handleWeaponSwap();
               }

               this.pendingSlot = -1;
            }
         }

         if (this.timer.hasTimeElapsed(150L)) {
            this.bypassActive = false;
            this.awaitingSwap = false;
            this.pendingSlot = -1;
            this.updateKeyBinding(mc.field_1690.field_1894);
            this.updateKeyBinding(mc.field_1690.field_1881);
            this.updateKeyBinding(mc.field_1690.field_1913);
            this.updateKeyBinding(mc.field_1690.field_1849);
            this.updateKeyBinding(mc.field_1690.field_1867);
         }
      }

   }

   private int findItemInInventory(class_1792 item) {
      for(int i = 0; i < mc.field_1724.method_31548().method_5439(); ++i) {
         class_1799 itemStack = mc.field_1724.method_31548().method_5438(i);
         if (!itemStack.method_7960() && itemStack.method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   private class_1792 getItem(int index) {
      if (index == 0) {
         return class_1802.field_8255;
      } else if (index == 1) {
         return class_1802.field_8463;
      } else if (index == 2) {
         return class_1802.field_8288;
      } else if (index == 3) {
         return class_1802.field_8575;
      } else {
         return index == 4 ? class_1802.field_8639 : null;
      }
   }

   private void handleWeaponSwap() {
      int swordSlot = InventoryUtil.getItem(class_1829.class, true);
      if (swordSlot == -1) {
         swordSlot = InventoryUtil.getItem(class_1829.class, false);
      }

      int axeSlot = InventoryUtil.getItem(class_1743.class, true);
      if (axeSlot == -1) {
         axeSlot = InventoryUtil.getItem(class_1743.class, false);
      }

      if (swordSlot != -1 && axeSlot != -1) {
         InventoryUtil.swapSlots(swordSlot, axeSlot);
      }

   }

   private void updateKeyBinding(class_304 keyMapping) {
      keyMapping.method_23481(class_3675.method_15987(mc.method_22683().method_4490(), keyMapping.method_1429().method_1444()));
   }
}
