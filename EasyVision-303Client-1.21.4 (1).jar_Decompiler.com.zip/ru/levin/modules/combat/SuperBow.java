package ru.levin.modules.combat;

import net.minecraft.class_2596;
import net.minecraft.class_2828;
import net.minecraft.class_2846;
import net.minecraft.class_2848;
import net.minecraft.class_2846.class_2847;
import net.minecraft.class_2848.class_2849;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "SuperBow",
   type = Type.Combat,
   desc = "Zwiększa obrażenia zadawane z łuku"
)
public class SuperBow extends Function {
   private final SliderSetting power = new SliderSetting("Siła", (double)30.0F, (double)1.0F, (double)200.0F, (double)1.0F);

   public SuperBow() {
      this.addSettings(new Setting[]{this.power});
   }

   public void onEvent(Event event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (event instanceof EventPacket) {
            EventPacket e = (EventPacket)event;
            class_2596 var4 = e.getPacket();
            if (var4 instanceof class_2846) {
               class_2846 p = (class_2846)var4;
               if (p.method_12363() == class_2847.field_12974) {
                  mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12981));

                  for(int i = 0; i < this.power.get().intValue(); ++i) {
                     mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() - 1.0E-9, mc.field_1724.method_23321(), true, true));
                     mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + 1.0E-9, mc.field_1724.method_23321(), true, false));
                  }
               }
            }
         }

      }
   }
}
