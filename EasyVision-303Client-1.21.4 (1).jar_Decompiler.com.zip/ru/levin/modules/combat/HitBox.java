package ru.levin.modules.combat;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "HitBox",
   type = Type.Combat,
   desc = "Pozwala zwiększyć hitbox graczy"
)
public class HitBox extends Function {
   public SliderSetting size = new SliderSetting("Rozmiar", (double)0.4F, (double)0.1F, (double)5.5F, (double)0.1F);

   public HitBox() {
      this.addSettings(new Setting[]{this.size});
   }

   public void onEvent(Event event) {
   }
}
