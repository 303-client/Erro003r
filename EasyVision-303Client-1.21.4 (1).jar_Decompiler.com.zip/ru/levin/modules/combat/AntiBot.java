package ru.levin.modules.combat;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1297.class_5529;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "AntiBot",
   desc = "Usuwa boty wykrywane przez antycheat",
   type = Type.Combat
)
public class AntiBot extends Function {
   private final BooleanSetting removeWorld = new BooleanSetting("Usuń ze świata", false);
   private final List<class_1297> bots = new ArrayList();

   public AntiBot() {
      this.addSettings(new Setting[]{this.removeWorld});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         this.detectBots();
      }

   }

   private void detectBots() {
      for(class_1657 entity : Manager.SYNC_MANAGER.getPlayers()) {
         if (entity != mc.field_1724) {
            if (this.isBotCandidate(entity)) {
               if (!this.bots.contains(entity)) {
                  this.bots.add(entity);
                  if (this.removeWorld.get()) {
                     mc.field_1687.method_2945(entity.method_5628(), class_5529.field_26998);
                  }
               }
            } else {
               this.bots.remove(entity);
            }
         }
      }

   }

   private boolean isBotCandidate(class_1657 entity) {
      class_1799 boots = (class_1799)entity.method_31548().field_7548.get(0);
      class_1799 leggings = (class_1799)entity.method_31548().field_7548.get(1);
      class_1799 chestplate = (class_1799)entity.method_31548().field_7548.get(2);
      class_1799 helmet = (class_1799)entity.method_31548().field_7548.get(3);
      boolean fullArmor = !boots.method_7960() && !leggings.method_7960() && !chestplate.method_7960() && !helmet.method_7960();
      boolean enchantable = boots.method_7923() && leggings.method_7923() && chestplate.method_7923() && helmet.method_7923();
      boolean validArmorTypes = boots.method_7909() == class_1802.field_8370 || leggings.method_7909() == class_1802.field_8570 || chestplate.method_7909() == class_1802.field_8577 || helmet.method_7909() == class_1802.field_8267 || boots.method_7909() == class_1802.field_8660 || leggings.method_7909() == class_1802.field_8396 || chestplate.method_7909() == class_1802.field_8523 || helmet.method_7909() == class_1802.field_8743;
      boolean offhandEmpty = entity.method_6079().method_7960();
      boolean mainHandNotEmpty = !entity.method_6047().method_7960();
      boolean armorNotDamaged = !boots.method_7986() && !leggings.method_7986() && !chestplate.method_7986() && !helmet.method_7986();
      boolean foodFull = entity.method_7344().method_7586() == 20;
      return fullArmor && enchantable && validArmorTypes && offhandEmpty && mainHandNotEmpty && armorNotDamaged && foodFull;
   }

   public boolean check(class_1309 entity) {
      return entity instanceof class_1657 && this.bots.contains(entity);
   }

   protected void onEnable() {
      super.onEnable();
      this.bots.clear();
   }

   protected void onDisable() {
      super.onDisable();
      this.bots.clear();
   }
}
