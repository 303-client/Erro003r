package ru.levin.modules.combat;

import ru.levin.events.Event;
import ru.levin.events.impl.input.EventKeyBoard;
import ru.levin.events.impl.player.EventAttack;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.move.MoveUtil;

@FunctionAnnotation(
   name = "WTap",
   type = Type.Combat,
   keywords = {"ExtendedAttack", "ExtendedKnockBack"},
   desc = "Pozwala mocniej odrzucać przeciwnika"
)
public class AttackExtend extends Function {
   private final BooleanSetting onlyOnGround = new BooleanSetting("Tylko na ziemi", true);
   private int sprintResetTicks;

   public AttackExtend() {
      this.addSettings(new Setting[]{this.onlyOnGround});
   }

   public void onEvent(Event event) {
      if (event instanceof EventKeyBoard e) {
         if (this.sprintResetTicks > 0 && MoveUtil.isMoving()) {
            e.setMovementForward(0.0F);
            --this.sprintResetTicks;
         }
      }

      if (event instanceof EventAttack && (!this.onlyOnGround.get() || mc.field_1724.method_24828()) && !mc.field_1724.method_52535() && mc.field_1724.method_5624()) {
         this.sprintResetTicks = 1;
      }

   }
}
