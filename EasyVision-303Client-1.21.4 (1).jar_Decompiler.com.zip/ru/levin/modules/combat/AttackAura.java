package ru.levin.modules.combat;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1308;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1531;
import net.minecraft.class_1569;
import net.minecraft.class_1646;
import net.minecraft.class_1657;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2815;
import net.minecraft.class_2848;
import net.minecraft.class_2868;
import net.minecraft.class_3532;
import net.minecraft.class_746;
import net.minecraft.class_2848.class_2849;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.input.EventKeyBoard;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.events.impl.player.EventSprint;
import ru.levin.manager.Manager;
import ru.levin.mixin.iface.ClientPlayerEntityAccessor;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.movement.ElytraTarget;
import ru.levin.modules.render.littlePet.GhostWolfEntity;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.math.RayTraceUtil;
import ru.levin.util.move.MoveUtil;
import ru.levin.util.player.AuraUtil;
import ru.levin.util.player.InventoryUtil;

@FunctionAnnotation(
   name = "AttackAura",
   keywords = {"Atakować", "Atakować", "KillAura"},
   desc = "Atakuje wszystkich wokół",
   type = Type.Combat
)
public class AttackAura extends Function {
   private final ModeSetting mode = new ModeSetting("Moduł", "ReallyWorld", new String[]{"ReallyWorld", "HollyWorld", "FunTime", "SpookyTime", "Snap", "KoopinAc", "LonyGrief", "1.8.8"});
   private final MultiSetting targets = new MultiSetting("Cele", Arrays.asList("Gracze", "Bez pancerza", "Moby", "Potwory"), new String[]{"Gracze", "Bez pancerza", "Znajomi", "Moby", "Potwory", "Wieśniacy"});
   private final ModeSetting sort = new ModeSetting("Sortuj", "Według zdrowia", new String[]{"Według zdrowia", "Według odległości", "Według pancerza"});
   private final MultiSetting setting = new MultiSetting("Ustawienia", Arrays.asList("Tylko trafienia krytyczne", "Rozbijać tarczę", "Zbijanie tarczy"), new String[]{"Tylko trafienia krytyczne", "Rozbijać tarczę", "Zbijanie tarczy"});
   private final SliderSetting distance = new SliderSetting("Zasięg ataku", (double)3.0F, (double)1.8F, (double)6.0F, (double)0.1F);
   private final SliderSetting rotateDistance = new SliderSetting("Zasięg wykrywania", (double)5.0F, (double)0.0F, (double)10.0F, (double)0.1F);
   private final SliderSetting elytraDistance = new SliderSetting("Zasięg podczas lotu na elytrze", (double)40.0F, (double)0.0F, (double)80.0F, (double)1.0F);
   private final SliderSetting snapSpeed = new SliderSetting("Szybkość obrotu", (double)150.0F, (double)50.0F, (double)300.0F, (double)50.0F, () -> this.mode.is("Snap"));
   private final BindBooleanSetting onlySpaceCritical = new BindBooleanSetting("Tylko po naciśnięciu spacji", false, () -> this.setting.get("Tylko trafienia krytyczne"));
   private final BooleanSetting noAttackIfEat = new BooleanSetting("Nie atakuj podczas jedzenia", false);
   private final BooleanSetting raycast = new BooleanSetting("Sprawdzaj celownik", false);
   public final BooleanSetting correction = new BooleanSetting("Korekta", true);
   public final ModeSetting correctionType = new ModeSetting(() -> this.correction.get(), "Typ korekty", "Free", new String[]{"Free", "Focus"});
   private final ModeSetting sprintreset = new ModeSetting("Tryb sprintu", "Rage", new String[]{"Rage", "Legit", "None"});
   public class_1309 target = null;
   private long cpsLimit = 0L;
   private long lastHitMs = 0L;
   private int preSprintTicks = 0;
   private float randomYawOffset = 0.0F;
   private float randomPitchOffset = 0.0F;
   private int randomUpdateTicks = 0;
   private float bodyYaw;
   private float bodyPitch;
   private float prevBodyYaw;
   private float prevBodyPitch;
   private float headYaw;
   private float headPitch;
   private float prevHeadYaw;
   private float prevHeadPitch;
   private final int updateInterval = 2;
   private final float maxYawShake = 0.3F;
   private final float maxPitchShake = 0.25F;
   private final Random random = new Random();
   private long shakeStartTime = 0L;
   private boolean swingSideRight = false;
   private float jitterYaw = 0.0F;
   private float jitterYawTarget = 0.0F;
   private float jitterYawSpeed = 0.0F;
   private float microJitter = 0.0F;
   private float swayPhase = 0.0F;
   private float swaySpeed = 0.04F;
   private float swayAmplitude = 2.5F;
   private long lastSwitch = 0L;
   private long lastBreathChange = 0L;

   public AttackAura() {
      this.addSettings(new Setting[]{this.mode, this.targets, this.sort, this.setting, this.distance, this.rotateDistance, this.elytraDistance, this.snapSpeed, this.correction, this.correctionType, this.sprintreset, this.onlySpaceCritical, this.noAttackIfEat, this.raycast});
   }

   public void onEvent(Event event) {
      class_746 player = mc.field_1724;
      if (player != null && !player.method_29504()) {
         if (event instanceof EventKeyBoard) {
            EventKeyBoard e = (EventKeyBoard)event;
            if (this.correction.get() && this.correctionType.is("Free")) {
               MoveUtil.fixMovement(e, Manager.FUNCTION_MANAGER.autoPotion.isActivePotion ? Manager.ROTATION.getPitch() : Manager.ROTATION.getYaw());
            }
         }

         if (event instanceof EventSprint) {
            EventSprint sprint = (EventSprint)event;
            if (this.sprintreset.is("Legit") && this.canAttack() && this.target != null && player.method_5624()) {
               sprint.setSprinting(false);
            }
         }

         if (event instanceof EventUpdate) {
            if (this.target == null || !this.isValidTarget(this.target)) {
               this.target = this.findTarget();
            }

            if (this.target == null) {
               Manager.ROTATION.set(player.method_36454(), player.method_36455());
               this.cpsLimit = System.currentTimeMillis();
               return;
            }

            this.handleAttackAndRotation(this.target);
         }

         if (event instanceof EventMotion) {
            EventMotion motion = (EventMotion)event;
            motion.setYaw(Manager.ROTATION.getYaw());
            motion.setPitch(Manager.ROTATION.getPitch());
         }

      } else {
         this.target = null;
         this.preSprintTicks = 0;
      }
   }

   protected void onEnable() {
      super.onEnable();
   }

   protected void onDisable() {
      if (this.target != null && this.isValidTarget(this.target)) {
         String modeName = this.mode.get();
         if (!modeName.equals("FunTime") && !modeName.equals("HollyWorld") && !modeName.equals("ReallyWorld")) {
            Manager.ROTATION.set(mc.field_1724.method_36454(), mc.field_1724.method_36455());
         } else {
            Manager.ROTATION.smoothReturn(350L);
         }
      }

      this.target = null;
      this.cpsLimit = System.currentTimeMillis();
      super.onDisable();
   }

   private boolean isValidTarget(class_1309 entity) {
      if (entity != null && !entity.method_29504() && entity.method_5805() && entity != mc.field_1724) {
         double dist = AuraUtil.getDistance(entity);
         double attackRange = this.distance.get().doubleValue();
         double detectRange = mc.field_1724.method_6128() ? this.elytraDistance.get().doubleValue() : this.rotateDistance.get().doubleValue();
         if (!(dist > attackRange) || !(detectRange <= (double)0.0F) && !(dist > detectRange)) {
            if (Manager.FUNCTION_MANAGER.antiBot.check(entity)) {
               return false;
            } else {
               if (entity instanceof class_1657) {
                  if (!this.targets.get("Gracze")) {
                     return false;
                  }

                  if (!this.targets.get("Znajomi") && Manager.FRIEND_MANAGER.isFriend(entity.method_5477().getString())) {
                     return false;
                  }
               } else {
                  if (entity instanceof class_1646 && !this.targets.get("Wieśniacy")) {
                     return false;
                  }

                  if (!(entity instanceof class_1308) && !(entity instanceof class_1429)) {
                     if (entity instanceof class_1569 && !this.targets.get("Potwory")) {
                        return false;
                     }
                  } else if (!this.targets.get("Moby")) {
                     return false;
                  }
               }

               if (entity instanceof class_1531) {
                  return false;
               } else {
                  return !Manager.FUNCTION_MANAGER.littleSnickers.state || !(entity instanceof GhostWolfEntity);
               }
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private class_1309 findTarget() {
      List<class_1309> list = new ArrayList();

      for(class_1297 e : Manager.SYNC_MANAGER.getEntities()) {
         if (e instanceof class_1309 le) {
            if (this.isValidTarget(le)) {
               list.add(le);
            }
         }
      }

      if (list.isEmpty()) {
         return null;
      } else {
         String var5 = this.sort.get();
         byte var6 = -1;
         switch (var5.hashCode()) {
            case -697210061:
               if (var5.equals("Według odległości")) {
                  var6 = 1;
               }
               break;
            case -179181466:
               if (var5.equals("Według pancerza")) {
                  var6 = 2;
               }
               break;
            case 460219158:
               if (var5.equals("Według zdrowia")) {
                  var6 = 0;
               }
         }

         switch (var6) {
            case 0:
               list.sort(Comparator.comparing(class_1309::method_6032));
               break;
            case 1:
               class_746 var10001 = mc.field_1724;
               Objects.requireNonNull(var10001);
               list.sort(Comparator.comparingDouble(var10001::method_5739));
               break;
            case 2:
               list.sort(Comparator.comparingDouble(AuraUtil::getArmor));
         }

         return (class_1309)list.get(0);
      }
   }

   private void handleAttackAndRotation(class_1309 t) {
      float currYaw = Manager.ROTATION.getYaw();
      float currPitch = Manager.ROTATION.getPitch();
      boolean canAttackNow = this.shouldAttack(t);
      boolean passRay = !this.raycast.get() || RayTraceUtil.getMouseOver(t, currYaw, currPitch, (double)this.distance.get().floatValue()) == t;
      boolean noPotion = !Manager.FUNCTION_MANAGER.autoPotion.isActivePotion;
      if (this.handleElytraRotation(t)) {
         if (canAttackNow && passRay && noPotion) {
            this.attackTarget(mc.field_1724);
         }

      } else if (!this.mode.is("KoopinAc") && !this.mode.is("1.8.8")) {
         if (this.mode.is("SpookyTime")) {
            if (mc.field_1724 != null) {
               if (this.target == null) {
                  this.randomYawOffset = 0.0F;
                  this.randomPitchOffset = 0.0F;
                  float centerYaw = mc.field_1724.method_36454();
                  float centerPitch = mc.field_1724.method_36455();
                  this.prevBodyYaw = this.bodyYaw;
                  this.prevBodyPitch = this.bodyPitch;
                  float yawDiff = class_3532.method_15393(centerYaw - this.bodyYaw);
                  float pitchDiff = centerPitch - this.bodyPitch;
                  float yawStep = class_3532.method_15363(yawDiff, -45.0F, 45.0F);
                  float pitchStep = class_3532.method_15363(pitchDiff, -45.0F, 45.0F);
                  this.bodyYaw += yawStep;
                  this.bodyPitch = class_3532.method_15363(this.bodyPitch + pitchStep, -90.0F, 90.0F);
                  this.prevHeadYaw = this.headYaw;
                  this.prevHeadPitch = this.headPitch;
                  yawDiff = class_3532.method_15393(centerYaw - this.headYaw);
                  pitchDiff = centerPitch - this.headPitch;
                  yawStep = class_3532.method_15363(yawDiff, -50.0F, 50.0F);
                  pitchStep = class_3532.method_15363(pitchDiff, -50.0F, 50.0F);
                  this.headYaw += yawStep;
                  this.headPitch = class_3532.method_15363(this.headPitch + pitchStep, -90.0F, 90.0F);
               } else {
                  ++this.randomUpdateTicks;
                  if (this.randomUpdateTicks >= 2) {
                     this.randomUpdateTicks = 0;
                     this.randomYawOffset = (this.random.nextFloat() * 2.0F - 1.0F) * 0.3F;
                     this.randomPitchOffset = (this.random.nextFloat() * 2.0F - 1.0F) * 0.25F;
                  }

                  double x = this.target.method_5829().method_1005().field_1352;
                  double y = this.target.method_23318();
                  double z = this.target.method_5829().method_1005().field_1350;
                  int randPoint = this.random.nextInt(4);
                  switch (randPoint) {
                     case 0 -> y += (double)this.target.method_17682() * 0.9;
                     case 1 -> y += (double)this.target.method_17682() * (double)0.75F;
                     case 2 -> y += (double)this.target.method_17682() * (double)0.5F;
                     case 3 -> y += (double)this.target.method_17682() * (double)0.25F;
                  }

                  x += this.random.nextDouble() * 0.4 - 0.2;
                  z += this.random.nextDouble() * 0.4 - 0.2;
                  class_243 targetPos = new class_243(x, y, z);
                  class_243 eyePos = mc.field_1724.method_33571();
                  y = targetPos.field_1352 - eyePos.field_1352;
                  z = targetPos.field_1351 - eyePos.field_1351;
                  double deltaZ = targetPos.field_1350 - eyePos.field_1350;
                  double hDistance = Math.sqrt(y * y + deltaZ * deltaZ);
                  double yaw = Math.atan2(deltaZ, y) * (double)180.0F / Math.PI - (double)90.0F;
                  double pitch = -(Math.atan2(z, hDistance) * (double)180.0F / Math.PI);
                  class_241 rot = new class_241((float)pitch, (float)yaw);
                  this.prevBodyYaw = this.bodyYaw;
                  this.prevBodyPitch = this.bodyPitch;
                  float yawDiff = class_3532.method_15393(rot.field_1342 - this.bodyYaw);
                  float pitchDiff = rot.field_1343 - this.bodyPitch;
                  this.bodyYaw += class_3532.method_15363(yawDiff, -45.0F, 45.0F);
                  this.bodyPitch = class_3532.method_15363(this.bodyPitch + pitchDiff, -45.0F, 45.0F);
                  this.prevHeadYaw = this.headYaw;
                  this.prevHeadPitch = this.headPitch;
                  pitchDiff = class_3532.method_15393(rot.field_1342 - this.headYaw);
                  float pitchDiff = rot.field_1343 - this.headPitch;
                  this.headYaw += class_3532.method_15363(pitchDiff, -50.0F, 50.0F);
                  this.headPitch = class_3532.method_15363(pitchDiff, -50.0F, 50.0F);
                  class_241 headRotation = new class_241(rot.field_1343 + this.randomPitchOffset, rot.field_1342 + this.randomYawOffset);
                  Manager.ROTATION.setSmooth(headRotation.field_1342, headRotation.field_1343, 0.8F, 60.0F, 90.0F, true);
                  if (canAttackNow && passRay && noPotion) {
                     this.attackTarget(mc.field_1724);
                  }

               }
            }
         } else if (this.mode.is("LonyGrief")) {
            class_243 tp = this.predictPos(t);
            double yawToTarget = Math.toDegrees(Math.atan2(tp.field_1350 - mc.field_1724.method_23321(), tp.field_1352 - mc.field_1724.method_23317())) - (double)90.0F;
            double yawDiff = (double)Math.abs(class_3532.method_15393((float)yawToTarget - currYaw));
            if (yawDiff <= (double)180.0F && canAttackNow && passRay && noPotion) {
               this.attackTarget(mc.field_1724);
            }

            Manager.ROTATION.set(mc.field_1724.method_36454(), mc.field_1724.method_36455());
         } else if (this.mode.is("FunTime")) {
            if (canAttackNow && this.canAttack() && noPotion) {
               if (passRay) {
                  this.attackTarget(mc.field_1724);
               }

               this.lastHitMs = System.currentTimeMillis();
            }

            if (System.currentTimeMillis() - this.lastHitMs < 450L) {
               this.funtime(t);
            } else {
               long currentTime = System.currentTimeMillis();
               if (this.shakeStartTime == 0L) {
                  this.shakeStartTime = currentTime;
               }

               float elapsedSec = (float)(currentTime - this.shakeStartTime) / 1000.0F;
               double angle = 15.079644737231007 * (double)elapsedSec;
               float yawOffset = (float)Math.sin(angle) * 24.0F;
               double angle2 = 0.5026548133391561 * (double)elapsedSec;
               double[] options = new double[]{(double)5.0F, (double)5.5F, 5.8, (double)6.0F};
               double randAmplitude = options[(int)(Math.random() * (double)options.length)];
               float yawOffset2 = (float)((double)((float)Math.sin(angle2)) * randAmplitude);
               float finalYaw = mc.field_1724.method_36454() + yawOffset + yawOffset2;
               float finalPitch = 0.0F + yawOffset2;
               Manager.ROTATION.setSmooth(finalYaw, finalPitch, 1.0F, 20.0F, 10.0F, true);
            }

         } else if (!this.mode.is("HollyWorld")) {
            if (this.mode.is("Snap")) {
               if (canAttackNow && this.canAttack() && passRay && noPotion) {
                  this.attackTarget(mc.field_1724);
                  this.lastHitMs = System.currentTimeMillis();
               }

               if (System.currentTimeMillis() - this.lastHitMs < (long)this.snapSpeed.get().floatValue()) {
                  this.setRotation(t, true);
               } else {
                  Manager.ROTATION.set(mc.field_1724.method_36454(), mc.field_1724.method_36455());
               }

            } else {
               if (canAttackNow && passRay && noPotion) {
                  this.attackTarget(mc.field_1724);
               }

               this.setRotation(t, true);
            }
         } else {
            if (canAttackNow && this.canAttack() && passRay && noPotion) {
               this.hollyworld(t, true);
               this.attackTarget(mc.field_1724);
            } else {
               this.hollyworld(t, false);
            }

         }
      } else {
         this.koopinVector(t, true);
         if (canAttackNow && passRay && noPotion) {
            this.attackTarget(mc.field_1724);
         }

      }
   }

   private void setRotation(class_1309 entity, boolean applyGcd) {
      class_243 tp = this.predictPos(entity);
      double dx = tp.field_1352 - mc.field_1724.method_23317();
      double dy = tp.field_1351 + (double)entity.method_18381(entity.method_18376()) / (double)2.0F - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
      double dz = tp.field_1350 - mc.field_1724.method_23321();
      float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
      Manager.ROTATION.setSmooth(yaw, pitch, 1.2F, 180.0F, 15.0F, applyGcd);
   }

   private void koopinVector(class_1309 entity, boolean attackContext) {
      class_243 head = entity.method_33571().method_1031((double)0.0F, (double)entity.method_17682(), (double)0.0F);
      class_243 chest = entity.method_33571().method_1031((double)0.0F, (double)(entity.method_5751() / 2.0F), (double)0.0F);
      class_243 legs = entity.method_33571().method_1031((double)0.0F, 0.05, (double)0.0F);
      class_243[] points = new class_243[]{head, chest, legs};
      float bestPitchDelta = Float.MAX_VALUE;
      class_243 best = chest;
      float currPitch = Manager.ROTATION.getPitch();
      float currYaw = Manager.ROTATION.getYaw();

      for(class_243 p : points) {
         class_243 eye = mc.field_1724.method_33571();
         double dx = p.field_1352 - eye.field_1352;
         double dy = p.field_1351 - eye.field_1351;
         double dz = p.field_1350 - eye.field_1350;
         float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
         float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
         float pitchDelta = Math.abs(pitch - currPitch);
         if (pitchDelta < bestPitchDelta) {
            bestPitchDelta = pitchDelta;
            best = p;
         }
      }

      class_243 eye = mc.field_1724.method_33571();
      double dx = best.field_1352 - eye.field_1352;
      double dy = best.field_1351 - eye.field_1351;
      double dz = best.field_1350 - eye.field_1350;
      double dst = Math.sqrt(dx * dx + dz * dz);
      float yawTo = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      float pitchTo = (float)(-Math.toDegrees(Math.atan2(dy, dst)));
      float yawDelta = class_3532.method_15393(yawTo - currYaw);
      float pitchDelta = pitchTo - currPitch;
      float addYaw = Math.min(Math.max(Math.abs(yawDelta), 1.0F), 80.0F);
      if (Math.abs(addYaw) <= 3.0F) {
         addYaw = 3.1F;
      }

      float addPitch = Math.max(attackContext ? Math.abs(pitchDelta) : 1.0F, 2.0F);
      float ny = currYaw + (yawDelta > 0.0F ? addYaw : -addYaw);
      float np = class_3532.method_15363(currPitch + (pitchDelta > 0.0F ? addPitch : -addPitch), -90.0F, 90.0F);
      Manager.ROTATION.set(ny, np);
   }

   private void funtime(class_1309 entity) {
      class_243 eye = mc.field_1724.method_33571();
      class_243 base = entity.method_19538();
      float[] points = new float[]{0.82F, 0.67F, 0.43F, 0.27F};
      float mul = points[(int)(System.currentTimeMillis() / 180L % (long)points.length)];
      class_243 targetPos = new class_243(base.field_1352, base.field_1351 + (double)(entity.method_17682() * mul), base.field_1350);
      double halfWidth = (double)entity.method_17681() / (double)2.0F;
      double sideOffset = this.swingSideRight ? halfWidth * (double)1.2F : -halfWidth * (double)1.0F;
      double yawToEntity = Math.atan2(entity.method_23321() - mc.field_1724.method_23321(), entity.method_23317() - mc.field_1724.method_23317());
      double offsetX = Math.cos(yawToEntity + (Math.PI / 2D)) * sideOffset;
      double offsetZ = Math.sin(yawToEntity + (Math.PI / 2D)) * sideOffset;
      targetPos = targetPos.method_1031(offsetX, (double)0.0F, offsetZ);
      double dx = targetPos.field_1352 - eye.field_1352;
      double dy = targetPos.field_1351 - eye.field_1351;
      double dz = targetPos.field_1350 - eye.field_1350;
      double dist = Math.sqrt(dx * dx + dz * dz);
      float baseYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      float basePitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
      long now = System.currentTimeMillis();
      if (now - this.lastSwitch > (long)(200 + this.random.nextInt(250))) {
         this.lastSwitch = now;
         this.swingSideRight = !this.swingSideRight;
         float distanceFactor = (float)class_3532.method_15350(dist / (double)6.0F, (double)0.4F, (double)1.0F);
         float maxDeviation = 4.0F * distanceFactor;
         this.jitterYawTarget = (this.swingSideRight ? maxDeviation : -maxDeviation) + (float)(this.random.nextGaussian() * (double)0.6F);
      }

      float diff = this.jitterYawTarget - this.jitterYaw;
      this.jitterYawSpeed += diff * 0.05F;
      this.jitterYawSpeed *= 0.88F;
      this.jitterYaw += this.jitterYawSpeed;
      this.jitterYaw *= 0.985F;
      if (now - this.lastBreathChange > (long)(2000 + this.random.nextInt(1500))) {
         this.lastBreathChange = now;
         this.swaySpeed = 0.035F + this.random.nextFloat() * 0.02F;
         this.swayAmplitude = 2.0F + this.random.nextFloat() * 1.2F;
      }

      this.swayPhase += this.swaySpeed;
      float sway = (float)Math.sin((double)this.swayPhase) * this.swayAmplitude;
      float totalYawOffset = (float)class_3532.method_15350((double)(this.jitterYaw + sway), -halfWidth * (double)8.5F, halfWidth * (double)8.5F);
      this.microJitter += (this.random.nextFloat() - 0.5F) * 0.25F;
      this.microJitter *= 0.85F;
      float finalYaw = baseYaw + totalYawOffset + this.microJitter;
      float finalPitch = basePitch + (float)Math.sin((double)(this.swayPhase * 0.8F)) * 0.5F;
      Manager.ROTATION.setSmooth(finalYaw, finalPitch, 1.1F, 180.0F, 15.0F, true);
   }

   private void hollyworld(class_1309 entity, boolean force) {
      class_243 eye = mc.field_1724.method_33571();
      class_243 base = entity.method_19538();
      float[] points = new float[]{0.85F, 0.65F, 0.35F, 0.25F};
      float mul = points[(int)(System.nanoTime() % (long)points.length)];
      class_243 aim = new class_243(base.field_1352, base.field_1351 + (double)(entity.method_17682() * mul), base.field_1350);
      double dx = aim.field_1352 - eye.field_1352;
      double dy = aim.field_1351 - eye.field_1351;
      double dz = aim.field_1350 - eye.field_1350;
      double hd = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, hd)));
      if (force) {
         Manager.ROTATION.set(yaw, class_3532.method_15363(pitch, -89.9F, 89.9F));
      } else {
         Manager.ROTATION.setSmooth(yaw, pitch, 0.25F, 45.0F, 12.0F, true);
      }

   }

   private boolean handleElytraRotation(class_1309 t) {
      ElytraTarget ely = Manager.FUNCTION_MANAGER.elytraTarget;
      if (ely.state && mc.field_1724.method_6128()) {
         if (ely.mode.is("Zaawansowany")) {
            ely.overtakingElytra(t, false);
         } else {
            ely.targetDefault(t, false);
         }

         return true;
      } else {
         return false;
      }
   }

   public void attackTarget(class_1657 player) {
      boolean sprintStop = false;
      boolean canStartSprint = mc.field_1724.field_3913.field_3905 > 0.0F && !mc.field_1724.method_6059(class_1294.field_5919) && !mc.field_1724.method_6128() && !mc.field_1724.method_6115() && !mc.field_1724.field_5976 && mc.field_1724.method_7344().method_7586() > 6 && !mc.field_1724.method_5715();
      if (this.setting.get("Zbijanie tarczy") && mc.field_1724.method_6039()) {
         mc.field_1761.method_2897(mc.field_1724);
      }

      if (!this.sprintreset.is("Legit") || !mc.field_1724.method_5624() && !this.canAttack() || !mc.field_1724.method_5624()) {
         if (this.sprintreset.is("Rage") && ((ClientPlayerEntityAccessor)mc.field_1724).getLastSprinting()) {
            mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12985));
            mc.field_1724.method_5728(false);
            sprintStop = true;
         }

         this.cpsLimit = System.currentTimeMillis() + 500L;
         mc.field_1761.method_2918(player, this.target);
         mc.field_1724.method_6104(class_1268.field_5808);
         ElytraTarget elytraTarget = Manager.FUNCTION_MANAGER.elytraTarget;
         if (elytraTarget.mode.is("Zaawansowany")) {
            elytraTarget.trueFireWork = true;
            if (elytraTarget.prefer.get()) {
               elytraTarget.nextPhase(this.target);
            }
         }

         if (this.setting.get("Rozbijać tarczę")) {
            this.shieldBreaker(false);
         }

         if (this.sprintreset.is("Rage") && sprintStop && canStartSprint && ((ClientPlayerEntityAccessor)mc.field_1724).getLastSprinting()) {
            mc.field_1724.field_3944.method_52787(new class_2848(mc.field_1724, class_2849.field_12981));
            mc.field_1724.method_5728(true);
         }

      }
   }

   private boolean shouldAttack(class_1309 e) {
      if (e != null && this.cpsLimit <= System.currentTimeMillis()) {
         return AuraUtil.getDistance(e) > this.distance.get().doubleValue() ? false : this.canAttack();
      } else {
         return false;
      }
   }

   private boolean canAttack() {
      if (this.noAttackIfEat.get() && mc.field_1724.method_6115() && !mc.field_1724.method_6030().method_31574(class_1802.field_8255)) {
         return false;
      } else if (System.currentTimeMillis() >= this.cpsLimit && (mc.field_1724.method_6047().method_31574(class_1802.field_49814) || !(mc.field_1724.method_7261(mc.method_61966().method_60637(true)) < 0.9F))) {
         boolean restrict = mc.field_1724.method_6059(class_1294.field_5919) || mc.field_1724.method_6059(class_1294.field_5902) || mc.field_1724.method_6059(class_1294.field_5906) || mc.field_1724.method_5771() || mc.field_1724.field_27857 || mc.field_1724.method_6101() || mc.field_1724.method_5765() || mc.field_1724.method_31549().field_7479 || mc.field_1724.method_52535() && !mc.field_1690.field_1903.method_1434() || MoveUtil.isInWeb();
         boolean needSpace = this.onlySpaceCritical.get() && mc.field_1724.method_24828() && !mc.field_1690.field_1903.method_1434();
         if (this.setting.get("Tylko trafienia krytyczne") && !restrict) {
            return needSpace || !mc.field_1724.method_24828() && mc.field_1724.field_6017 > 0.0F;
         } else {
            return true;
         }
      } else {
         return false;
      }
   }

   private boolean shieldBreaker(boolean instant) {
      int axeSlot = InventoryUtil.getAxe().slot();
      if (axeSlot == -1) {
         return false;
      } else if (!(this.target instanceof class_1657)) {
         return false;
      } else if (!((class_1657)this.target).method_6115() && !instant) {
         return false;
      } else if (((class_1657)this.target).method_6079().method_7909() != class_1802.field_8255 && ((class_1657)this.target).method_6047().method_7909() != class_1802.field_8255) {
         return false;
      } else {
         if (axeSlot >= 9) {
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, axeSlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
            mc.method_1562().method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
            mc.field_1761.method_2918(mc.field_1724, this.target);
            mc.field_1724.method_6104(class_1268.field_5808);
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, axeSlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
            mc.method_1562().method_52787(new class_2815(mc.field_1724.field_7512.field_7763));
         } else {
            mc.method_1562().method_52787(new class_2868(axeSlot));
            mc.field_1761.method_2918(mc.field_1724, this.target);
            mc.field_1724.method_6104(class_1268.field_5808);
            mc.method_1562().method_52787(new class_2868(mc.field_1724.method_31548().field_7545));
         }

         return true;
      }
   }

   private class_243 predictPos(class_1309 e) {
      class_243 p = e.method_19538();
      TargetStrafe ts = Manager.FUNCTION_MANAGER.targetStrafe;
      if (ts.state && ts.predictCheck.get()) {
         float pr = ts.predict.get().floatValue();
         if (pr > 0.0F) {
            class_243 v = e.method_18798();
            p = p.method_1031(v.field_1352 * (double)pr, v.field_1351 * (double)pr, v.field_1350 * (double)pr);
         }
      }

      return p;
   }
}
