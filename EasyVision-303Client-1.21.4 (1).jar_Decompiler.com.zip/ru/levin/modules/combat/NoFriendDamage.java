package ru.levin.modules.combat;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "NoFriendDamage",
   keywords = {"NFD", "FriendDamage"},
   type = Type.Combat,
   desc = "Wyłącza zadawanie obrażeń znajomym"
)
public class NoFriendDamage extends Function {
   public NoFriendDamage() {
      this.addSettings(new Setting[0]);
   }

   public void onEvent(Event event) {
   }
}
