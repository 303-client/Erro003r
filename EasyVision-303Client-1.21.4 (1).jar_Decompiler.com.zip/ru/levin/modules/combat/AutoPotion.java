package ru.levin.modules.combat;

import java.util.Arrays;
import java.util.Optional;
import net.minecraft.class_1268;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2246;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_6880;
import net.minecraft.class_7202;
import net.minecraft.class_7204;
import net.minecraft.class_9334;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.mixin.iface.ClientWorldAccessor;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "AutoPotion",
   keywords = {"AutoBuff"},
   type = Type.Combat,
   desc = "Automatycznie rzuca mikstury efektów pod siebie"
)
public class AutoPotion extends Function {
   private final BooleanSetting autoOff = new BooleanSetting("Automatyczne wyłączenie", false);
   public MultiSetting potions = new MultiSetting("Rzucaj", Arrays.asList("Siła", "Prędkość", "Odporność na ogień"), new String[]{"Siła", "Prędkość", "Odporność na ogień"});
   public final TimerUtil timer = new TimerUtil();
   private boolean spoofed = false;
   public boolean isActivePotion;
   private float rotprev;
   private int selectedSlot = -1;
   private final float pose = 90.0F;

   public AutoPotion() {
      this.addSettings(new Setting[]{this.potions, this.autoOff});
   }

   private boolean isEatingFood() {
      return mc.field_1724.method_6115() && !mc.field_1724.method_6030().method_31574(class_1802.field_8255) && !mc.field_1724.method_6030().method_31574(class_1802.field_8102) && !mc.field_1724.method_6030().method_31574(class_1802.field_8547);
   }

   private int findPotionSlot(PotionType type) {
      for(int i = 0; i < 9; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8436) {
            Optional<class_1844> potionComponent = Optional.ofNullable((class_1844)stack.method_57353().method_57829(class_9334.field_49651));
            if (potionComponent.isPresent()) {
               for(class_1293 effect : ((class_1844)potionComponent.get()).method_57397()) {
                  if (effect.method_5579() == type.effect) {
                     return i;
                  }
               }
            }
         }
      }

      return -1;
   }

   private boolean hasEffect(class_6880<class_1291> effect) {
      return mc.field_1724.method_6059(effect);
   }

   private boolean canBuff(PotionType type) {
      if (this.hasEffect(type.effect)) {
         return false;
      } else {
         return type.isEnabled(this) && this.findPotionSlot(type) != -1;
      }
   }

   private boolean canBuff() {
      return !this.isEatingFood() && (this.canBuff(AutoPotion.PotionType.STRENGTH) || this.canBuff(AutoPotion.PotionType.SPEED) || this.canBuff(AutoPotion.PotionType.FIRE_RESISTANCE)) && mc.field_1724.method_24828() && this.timer.hasTimeElapsed(500L);
   }

   private boolean shouldUsePotion() {
      return true;
   }

   private boolean isActive() {
      return this.isActivePotion || this.canBuff(AutoPotion.PotionType.STRENGTH) || this.canBuff(AutoPotion.PotionType.SPEED) || this.canBuff(AutoPotion.PotionType.FIRE_RESISTANCE);
   }

   public void onEvent(Event event) {
      if (event instanceof EventMotion eventAfterRotate) {
         if (this.shouldThrow()) {
            this.rotprev = mc.field_1724.method_36455();
            eventAfterRotate.setPitch(90.0F);
            this.spoofed = true;
            this.isActivePotion = true;
         }
      }

      if (event instanceof EventUpdate) {
         if (this.isActivePotion && !this.shouldThrow()) {
            this.isActivePotion = false;
            if (this.autoOff.get()) {
               this.toggle();
            }
         }

         if (this.shouldThrow() && this.spoofed) {
            this.throwPotion(AutoPotion.PotionType.STRENGTH);
            this.throwPotion(AutoPotion.PotionType.SPEED);
            this.throwPotion(AutoPotion.PotionType.FIRE_RESISTANCE);
            mc.field_1724.field_3944.method_52787(new class_2868(mc.field_1724.method_31548().field_7545));
            mc.field_1724.method_36457(this.rotprev);
            this.timer.reset();
            this.spoofed = false;
            this.isActivePotion = false;
            if (this.autoOff.get()) {
               this.toggle();
            }
         }
      }

   }

   private boolean shouldThrow() {
      return this.isActive() && this.canBuff() && mc.field_1687.method_8320(mc.field_1724.method_24515().method_10074()).method_26204() != class_2246.field_10124;
   }

   private void throwPotion(PotionType type) {
      if (type.isEnabled(this) && !this.hasEffect(type.effect)) {
         int slot = this.findPotionSlot(type);
         if (slot != -1) {
            this.selectedSlot = mc.field_1724.method_31548().field_7545;
            mc.field_1724.field_3944.method_52787(new class_2868(slot));
            float yaw = mc.field_1724.method_36454();
            float pitch = mc.field_1724.method_36455();
            this.sendSequencedPacket((id) -> new class_2886(class_1268.field_5808, id, yaw, pitch));
         }
      }
   }

   private void sendSequencedPacket(class_7204 packetCreator) {
      if (mc.field_1724.field_3944 != null && mc.field_1687 != null) {
         class_7202 pendingUpdateManager = ((ClientWorldAccessor)mc.field_1687).getPendingUpdateManager().method_41937();

         try {
            int sequence = pendingUpdateManager.method_41942();
            mc.field_1724.field_3944.method_52787(packetCreator.predict(sequence));
         } catch (Throwable var6) {
            if (pendingUpdateManager != null) {
               try {
                  pendingUpdateManager.close();
               } catch (Throwable var5) {
                  var6.addSuppressed(var5);
               }
            }

            throw var6;
         }

         if (pendingUpdateManager != null) {
            pendingUpdateManager.close();
         }

      }
   }

   private static enum PotionType {
      STRENGTH(5, class_1294.field_5910, "Siła"),
      SPEED(1, class_1294.field_5904, "Prędkość"),
      FIRE_RESISTANCE(12, class_1294.field_5918, "Odporność na ogień");

      final int id;
      final class_6880<class_1291> effect;
      final String settingName;

      private PotionType(int id, class_6880<class_1291> effect, String settingName) {
         this.id = id;
         this.effect = effect;
         this.settingName = settingName;
      }

      public boolean isEnabled(AutoPotion module) {
         return module.potions.get(this.settingName);
      }

      // $FF: synthetic method
      private static PotionType[] $values() {
         return new PotionType[]{STRENGTH, SPEED, FIRE_RESISTANCE};
      }
   }
}
