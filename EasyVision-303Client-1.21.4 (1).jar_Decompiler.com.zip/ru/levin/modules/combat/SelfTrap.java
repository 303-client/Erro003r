package ru.levin.modules.combat;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3965;
import org.joml.Vector2f;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "SelfTrap",
   keywords = {"Trap"},
   type = Type.Combat,
   desc = "Obudowuje nogi dowolnymi blokami"
)
public class SelfTrap extends Function {
   public final Vector2f rotate = new Vector2f(0.0F, 0.0F);
   private final class_2338[] baseOffsets;
   private List<class_2338> targets;
   private int index;
   private int originalSlot;
   public boolean active;
   private int tickDelay;
   private final Random rnd;

   public SelfTrap() {
      this.baseOffsets = new class_2338[]{class_2338.field_10980.method_10095(), class_2338.field_10980.method_10072(), class_2338.field_10980.method_10078(), class_2338.field_10980.method_10067()};
      this.targets = new ArrayList();
      this.index = 0;
      this.originalSlot = -1;
      this.active = false;
      this.tickDelay = 0;
      this.rnd = new Random();
   }

   public void onEnable() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         this.targets.clear();
         class_2338 base = mc.field_1724.method_24515();

         for(class_2338 off : this.baseOffsets) {
            this.targets.add(base.method_10081(off));
         }

         this.originalSlot = mc.field_1724.method_31548().field_7545;
         this.index = 0;
         this.active = true;
         this.tickDelay = 0;
      } else {
         this.toggle();
      }
   }

   public void onDisable() {
      if (mc.field_1724 != null && this.originalSlot != -1) {
         mc.field_1724.method_31548().field_7545 = this.originalSlot;
      }

      this.targets.clear();
      this.index = 0;
      this.active = false;
      this.tickDelay = 0;
   }

   public void onEvent(Event event) {
      if (this.active) {
         if (event instanceof EventUpdate || event instanceof EventMotion) {
            if (event instanceof EventUpdate) {
               if (this.tickDelay > 0) {
                  --this.tickDelay;
                  return;
               }

               if (this.index >= this.targets.size()) {
                  this.finish();
                  return;
               }

               class_2338 target = (class_2338)this.targets.get(this.index);
               if (!mc.field_1687.method_8320(target).method_26215() || this.isEntityBlocking(target)) {
                  ++this.index;
                  return;
               }

               class_2350 placeSide = this.findPlaceableSide(target);
               if (placeSide != null) {
                  class_2338 neighbor = target.method_10093(placeSide);
                  class_243 hitVec = class_243.method_24953(neighbor).method_1019(class_243.method_24954(placeSide.method_62675()).method_1021((double)0.5F));
                  int blockSlot = this.findAnyBlockInHotbar();
                  if (blockSlot == -1) {
                     this.finish();
                     return;
                  }

                  mc.field_1724.method_31548().field_7545 = blockSlot;
                  class_3965 hit = new class_3965(hitVec, placeSide.method_10153(), neighbor, false);
                  this.rotateTo(hit.method_17777());
                  mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
                  mc.field_1724.method_6104(class_1268.field_5808);
                  this.tickDelay = 1 + this.rnd.nextInt(3);
                  ++this.index;
                  return;
               }

               ++this.index;
            }

            if (event instanceof EventMotion) {
               EventMotion motion = (EventMotion)event;
               motion.setYaw(this.rotate.x);
               motion.setPitch(this.rotate.y);
            }

         }
      }
   }

   private void finish() {
      this.active = false;
      if (mc.field_1724 != null && this.originalSlot != -1) {
         mc.field_1724.method_31548().field_7545 = this.originalSlot;
      }

   }

   private int findAnyBlockInHotbar() {
      for(int i = 0; i < 9; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() instanceof class_1747) {
            class_2248 block = ((class_1747)stack.method_7909()).method_7711();
            if (block != class_2246.field_10124) {
               return i;
            }
         }
      }

      return -1;
   }

   private boolean isEntityBlocking(class_2338 pos) {
      class_238 box = new class_238(pos);

      for(class_1297 e : mc.field_1687.method_8335((class_1297)null, box)) {
         if (e != mc.field_1724) {
            return true;
         }
      }

      return false;
   }

   private class_2350 findPlaceableSide(class_2338 pos) {
      for(class_2350 dir : class_2350.values()) {
         class_2338 neighbor = pos.method_10093(dir);
         if (!mc.field_1687.method_8320(neighbor).method_26215() && mc.field_1687.method_8320(neighbor).method_26212(mc.field_1687, neighbor)) {
            return dir;
         }
      }

      return null;
   }

   private void rotateTo(class_2338 pos) {
      if (mc.field_1724 != null) {
         double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
         double dy = (double)pos.method_10264() + (double)0.5F - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
         double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
         double distXZ = Math.sqrt(dx * dx + dz * dz);
         float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
         float pitch = (float)(-Math.toDegrees(Math.atan2(dy, distXZ)));
         this.rotate.x = yaw;
         this.rotate.y = pitch;
      }
   }
}
