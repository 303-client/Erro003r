package ru.levin.modules.combat;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1511;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_3965;
import net.minecraft.class_7439;
import org.joml.Vector2f;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.input.EventKeyBoard;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.move.MoveUtil;
import ru.levin.util.player.InventoryUtil;
import ru.levin.util.player.TimerUtil;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "CrystalAura",
   type = Type.Combat,
   desc = "Inteligentne automatyczne stawianie i detonowanie kryształów (test)"
)
public class CrystalAura extends Function {
   private final MultiSetting options = new MultiSetting("Ustawienia", List.of("Nie rań siebie eksplozją", "Korekta ruchu", "Gracz w locie", "Podświetlenie bloku"), new String[]{"Nie rań siebie eksplozją", "Korekta ruchu", "Gracz w locie", "Podświetlenie bloku"});
   private final ModeSetting distanceMode = new ModeSetting("Typ zasięgu", "Własny", new String[]{"Własny", "Grim"});
   private final SliderSetting customDistance = new SliderSetting("Zasięg", (double)5.0F, (double)2.5F, (double)6.0F, (double)0.05F, () -> this.distanceMode.is("Własny"));
   private final SliderSetting breakDelay = new SliderSetting("Opóźnienie", (double)100.0F, (double)0.0F, (double)500.0F, (double)1.0F);
   public final BooleanSetting offHandCrystal = new BooleanSetting("Umieszczaj kryształ w lewej ręce", true);
   private final BooleanSetting renderBlock = new BooleanSetting("Podświetlenie bloku", true);
   private final BooleanSetting rgCheck = new BooleanSetting("Sprawdzanie regionu", true, "na serwery typu grief");
   private final BooleanSetting twoPlace = new BooleanSetting("Stawiaj w kilku miejscach", true);
   private class_2338 closestObsidian = null;
   public class_1511 closestCrystal = null;
   private class_243 obsidianVec = null;
   private final TimerUtil attackTimer = new TimerUtil();
   private final TimerUtil placeTimer = new TimerUtil();
   public final Vector2f rotate = new Vector2f(0.0F, 0.0F);
   private int originalSlot = -1;
   private boolean regionBlocked = false;
   private class_243 regionBlockPos = null;
   private static final double REGION_BLOCK_RADIUS = (double)12.0F;
   private static final double MIN_DISTANCE_BETWEEN_CRYSTALS = (double)2.5F;
   private final List<class_2338> multiPlaceTargets = new ArrayList();
   private class_1792 originalOffhandItem = null;

   public CrystalAura() {
      this.addSettings(new Setting[]{this.distanceMode, this.options, this.customDistance, this.breakDelay, this.offHandCrystal, this.renderBlock, this.rgCheck, this.twoPlace});
   }

   private double getEffectiveDistance() {
      return this.distanceMode.is("Grim") ? 3.6 : (double)this.customDistance.get().intValue();
   }

   public boolean check() {
      return (this.closestObsidian != null || this.closestCrystal != null) && this.rotate != null && this.options.get("Korekta ruchu");
   }

   public void onDisable() {
      this.reset();
      super.onDisable();
   }

   public void onEvent(Event event) {
      if (this.rgCheck.get() && event instanceof EventPacket eventPacket) {
         class_2596 var4 = eventPacket.getPacket();
         if (var4 instanceof class_7439 packet) {
            String message = packet.comp_763().getString();
            if (message.contains("can't place that block here")) {
               this.regionBlocked = true;
               this.regionBlockPos = mc.field_1724.method_19538();
            }
         }
      }

      if (event instanceof EventRender3D && this.renderBlock.get() && this.obsidianVec != null) {
         class_2338 pos = class_2338.method_49638(this.obsidianVec);
         RenderUtil.render3D.drawHoleOutline(new class_238(pos), ColorUtil.getColorStyle(360.0F), 2.0F);
         if (!this.multiPlaceTargets.isEmpty()) {
            for(class_2338 p : this.multiPlaceTargets) {
               RenderUtil.render3D.drawHoleOutline(new class_238(p), ColorUtil.getColorStyle(220.0F), 1.0F);
            }
         }
      }

      if (event instanceof EventKeyBoard input) {
         if (this.check()) {
            MoveUtil.fixMovement(input, this.rotate.x);
         }
      }

      if (event instanceof EventMotion motion) {
         if (this.offHandCrystal.get()) {
            float currentHp = mc.field_1724.method_6032();
            float minHp = Manager.FUNCTION_MANAGER.autoTotem.hp.get().floatValue();
            if (currentHp > minHp) {
               InventoryUtil.moveToOffhand(class_1802.field_8301);
            }
         }

         this.handleCrystalLogic(motion);
      }

   }

   private void handleCrystalLogic(EventMotion motion) {
      if (this.regionBlocked && this.regionBlockPos != null) {
         if (mc.field_1724.method_19538().method_1022(this.regionBlockPos) < (double)12.0F) {
            return;
         }

         this.regionBlocked = false;
         this.regionBlockPos = null;
      }

      double maxDist = this.getEffectiveDistance();
      this.closestCrystal = this.findNearestCrystal(maxDist);
      if (this.closestCrystal != null) {
         this.breakCrystal(this.closestCrystal, motion);
      } else {
         if (this.originalSlot == -1) {
            this.originalSlot = mc.field_1724.method_31548().field_7545;
         }

         int crystalSlot = InventoryUtil.getItem(class_1802.field_8301.getClass(), true);
         if (crystalSlot == -1 && !this.offHandCrystal.get()) {
            this.restoreOriginalSlot();
         } else {
            this.closestObsidian = null;
            double bestDamage = (double)0.0F;

            for(class_1297 e : Manager.SYNC_MANAGER.getEntities()) {
               if (e instanceof class_1309) {
                  class_1309 target = (class_1309)e;
                  if (e != mc.field_1724 && e.method_5805()) {
                     class_2338 pos = this.findBestCrystalPosition(target, maxDist);
                     if (pos != null) {
                        double damage = this.calculateCrystalDamage(pos, e);
                        if ((!this.options.get("Nie rań siebie eksplozją") || !(this.calculateCrystalDamage(pos, mc.field_1724) > (double)6.0F)) && damage > bestDamage) {
                           bestDamage = damage;
                           this.closestObsidian = pos;
                        }
                     }
                  }
               }
            }

            this.multiPlaceTargets.clear();
            if (this.closestObsidian != null) {
               this.obsidianVec = class_243.method_24953(this.closestObsidian);
               this.aimAt(this.obsidianVec, motion);
               this.multiPlaceTargets.add(this.closestObsidian);
               if (this.twoPlace.get()) {
                  List<class_2338> candidates = new ArrayList();
                  class_2338[] nearby = new class_2338[]{this.closestObsidian.method_10095(), this.closestObsidian.method_10072(), this.closestObsidian.method_10078(), this.closestObsidian.method_10067(), this.closestObsidian.method_10095().method_10078(), this.closestObsidian.method_10095().method_10067(), this.closestObsidian.method_10072().method_10078(), this.closestObsidian.method_10072().method_10067()};

                  for(class_2338 pos : nearby) {
                     if (this.canPlaceCrystal(pos, maxDist)) {
                        boolean tooClose = false;

                        for(class_2338 existing : this.multiPlaceTargets) {
                           if (existing.method_10262(pos) < (double)6.25F) {
                              tooClose = true;
                              break;
                           }
                        }

                        if (!tooClose) {
                           candidates.add(pos);
                        }
                     }
                  }

                  Collections.shuffle(candidates);

                  for(class_2338 pos : candidates) {
                     if (this.multiPlaceTargets.size() >= 3) {
                        break;
                     }

                     this.multiPlaceTargets.add(pos);
                  }
               }
            }

            if (!this.multiPlaceTargets.isEmpty() && this.placeTimer.hasTimeElapsed((long)this.breakDelay.get().doubleValue())) {
               if (!this.offHandCrystal.get()) {
                  mc.field_1724.method_31548().field_7545 = crystalSlot;
               }

               for(class_2338 pos : this.multiPlaceTargets) {
                  this.tryPlaceCrystal(pos, motion);
               }

               this.multiPlaceTargets.clear();
               this.placeTimer.reset();
            }

         }
      }
   }

   private void breakCrystal(class_1297 crystal, EventMotion motion) {
      if (crystal != null) {
         this.aimAt(crystal.method_19538().method_1031((double)0.0F, (double)0.5F, (double)0.0F), motion);
         if (this.attackTimer.hasTimeElapsed((long)this.breakDelay.get().doubleValue())) {
            mc.field_1724.method_6104(class_1268.field_5808);
            mc.method_1562().method_52787(class_2824.method_34206(crystal, mc.field_1724.method_5715()));
            this.attackTimer.reset();
         }

      }
   }

   private class_2338 findBestCrystalPosition(class_1309 target, double maxDist) {
      class_2338 base = target.method_24515();
      class_2338[] positions = new class_2338[]{base.method_10095(), base.method_10072(), base.method_10078(), base.method_10067(), base.method_10095().method_10078(), base.method_10095().method_10067(), base.method_10072().method_10078(), base.method_10072().method_10067(), base.method_10084(), base.method_10084().method_10095(), base.method_10084().method_10072(), base.method_10084().method_10078(), base.method_10084().method_10067(), base.method_10084().method_10095().method_10078(), base.method_10084().method_10095().method_10067(), base.method_10084().method_10072().method_10078(), base.method_10084().method_10072().method_10067()};
      class_2338 bestPos = null;
      double bestDamage = (double)0.0F;

      for(class_2338 airPos : positions) {
         class_2338 baseBlock = airPos.method_10074();
         if (!baseBlock.equals(mc.field_1724.method_24515().method_10074()) && this.canPlaceCrystal(baseBlock, maxDist)) {
            double damage = this.calculateCrystalDamage(baseBlock, target);
            double selfDamage = this.calculateCrystalDamage(baseBlock, mc.field_1724);
            if ((!this.options.get("Nie rań siebie eksplozją") || !(selfDamage > (double)6.0F)) && damage > bestDamage) {
               bestDamage = damage;
               bestPos = baseBlock;
            }
         }
      }

      return bestPos;
   }

   private boolean canPlaceCrystal(class_2338 baseBlock, double maxDist) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         if (mc.field_1687.method_8320(baseBlock).method_26204() != class_2246.field_10540 && mc.field_1687.method_8320(baseBlock).method_26204() != class_2246.field_9987) {
            return false;
         } else {
            class_2338 air1 = baseBlock.method_10084();
            class_2338 air2 = baseBlock.method_10086(2);
            if (mc.field_1687.method_8320(air1).method_26215() && mc.field_1687.method_8320(air2).method_26215()) {
               if (mc.field_1724.method_19538().method_1022(class_243.method_24953(baseBlock)) > maxDist) {
                  return false;
               } else {
                  class_238 placeBox = new class_238((double)air1.method_10263(), (double)air1.method_10264(), (double)air1.method_10260(), (double)(air1.method_10263() + 1), (double)(air1.method_10264() + 1), (double)(air1.method_10260() + 1));

                  for(class_1297 e : mc.field_1687.method_8335((class_1297)null, placeBox)) {
                     if (e instanceof class_1511) {
                        return false;
                     }
                  }

                  return true;
               }
            } else {
               return false;
            }
         }
      } else {
         return false;
      }
   }

   private void tryPlaceCrystal(class_2338 pos, EventMotion motion) {
      if (pos != null && mc.field_1724 != null && mc.field_1761 != null) {
         class_3965 hitResult = new class_3965(class_243.method_24954(pos).method_1031((double)0.5F, (double)1.0F, (double)0.5F), class_2350.field_11036, pos, false);
         mc.field_1761.method_2896(mc.field_1724, this.offHandCrystal.get() ? class_1268.field_5810 : class_1268.field_5808, hitResult);
         mc.field_1724.method_6104(this.offHandCrystal.get() ? class_1268.field_5810 : class_1268.field_5808);
         class_1511 newCrystal = null;

         for(class_1297 e : Manager.SYNC_MANAGER.getEntities()) {
            if (e instanceof class_1511 && e.method_5707(class_243.method_24953(pos.method_10084())) < 3.2) {
               newCrystal = (class_1511)e;
               break;
            }
         }

         if (newCrystal != null) {
            this.breakCrystal(newCrystal, motion);
         }

      }
   }

   private class_1511 findNearestCrystal(double maxDist) {
      class_1511 closest = null;
      double minDist = Double.MAX_VALUE;
      class_243 eyePos = mc.field_1724.method_33571();

      for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
         if (entity instanceof class_1511 crystal) {
            if (crystal.method_5805()) {
               double dist = mc.field_1724.method_5858(crystal);
               if (dist <= maxDist * maxDist && dist < minDist) {
                  closest = crystal;
                  minDist = dist;
               }
            }
         }
      }

      return closest;
   }

   private double calculateCrystalDamage(class_2338 pos, class_1297 target) {
      if (target != null && mc.field_1687 != null) {
         double distance = target.method_5707(class_243.method_24953(pos));
         if (distance > (double)12.0F) {
            return (double)0.0F;
         } else {
            double exposure = (double)1.0F - distance / (double)12.0F;
            double damage = exposure * (double)12.0F;
            return Math.max((double)0.0F, damage);
         }
      } else {
         return (double)0.0F;
      }
   }

   private void aimAt(class_243 vec, EventMotion motion) {
      float[] rot = rotations(vec);
      if (motion != null) {
         motion.setYaw(rot[0]);
         motion.setPitch(rot[1]);
      }

      this.rotate.set(rot[0], rot[1]);
   }

   private void restoreOriginalSlot() {
      if (this.originalSlot >= 0 && this.originalSlot <= 8) {
         mc.field_1724.method_31548().field_7545 = this.originalSlot;
         this.originalSlot = -1;
      }

   }

   public void reset() {
      this.restoreOriginalSlot();
      this.closestObsidian = null;
      this.closestCrystal = null;
      this.obsidianVec = null;
      this.multiPlaceTargets.clear();
      this.attackTimer.reset();
      this.placeTimer.reset();
      this.regionBlocked = false;
      this.regionBlockPos = null;
   }

   public static float[] rotations(class_243 vec) {
      double dx = vec.field_1352 - mc.field_1724.method_23317();
      double dy = vec.field_1351 - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
      double dz = vec.field_1350 - mc.field_1724.method_23321();
      double dist = Math.sqrt(dx * dx + dz * dz);
      float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - (double)90.0F);
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, dist)));
      return new float[]{yaw, pitch};
   }
}
