package ru.levin.modules.combat;

import ru.levin.events.Event;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.movement.Speed;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "TargetStrafe",
   type = Type.Combat,
   desc = "Strafe jak w cheat-kliencie"
)
public class TargetStrafe extends Function {
   public final SliderSetting speedSlider = new SliderSetting("Prędkość", (double)0.095F, (double)0.01F, (double)1.2F, (double)0.01F);
   public final ModeSetting ptytag = new ModeSetting("Metoda przyciągania", "Vector", new String[]{"Vector", "Motion / Velocity"});
   public final SliderSetting blocks = new SliderSetting("Zasięg przyciągania", (double)7.0F, (double)0.01F, (double)12.0F, (double)0.01F);
   public final SliderSetting hitbox = new SliderSetting("Hitbox do przyspieszenia", (double)0.095F, (double)0.01F, (double)50.0F, (double)0.01F);
   public final BooleanSetting predictCheck = new BooleanSetting("Przewidywanie", true);
   public final SliderSetting predict = new SliderSetting("Wartość przewidywania", (double)2.5F, (double)0.1F, (double)4.0F, (double)0.1F, () -> this.predictCheck.get());
   public final BooleanSetting predictView = new BooleanSetting("Pokazuj przewidywaną pozycję", false, "Na ekranie będziesz wyraźnie wyprzedzać przeciwnika");

   public TargetStrafe() {
      this.addSettings(new Setting[]{this.speedSlider, this.ptytag, this.blocks, this.hitbox, this.predictCheck, this.predict, this.predictView});
   }

   public void onEvent(Event event) {
   }

   protected void onDisable() {
      if (mc.field_1690.field_1894.method_1434()) {
         mc.field_1690.field_1894.method_23481(false);
      }

      super.onDisable();
   }

   public void onEnable() {
      Speed speed = Manager.FUNCTION_MANAGER.speed;
      if (speed.state) {
         speed.setState(false);
      }

      super.onEnable();
   }
}
