package ru.levin.modules.combat;

import java.util.Arrays;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1548;
import net.minecraft.class_1657;
import net.minecraft.class_1701;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1809;
import net.minecraft.class_2246;
import net.minecraft.class_490;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventEntitySpawn;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.player.InventoryUtil;

@FunctionAnnotation(
   name = "AutoTotem",
   desc = "Wybiera totem, gdy zdrowie spadnie poniżej ustawionej wartości",
   type = Type.Combat
)
public class AutoTotem extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Exosware", new String[]{"Exosware", "Fast"});
   private final MultiSetting threats = new MultiSetting("Używaj, gdy", Arrays.asList("Kryształ", "Gracz z buławą"), new String[]{"Kryształ", "Gracz z buławą", "Gdy w pobliżu jest creeper", "Obsydian", "Kotwica odrodzenia", "Upadek", "Wagonik"});
   private final SliderSetting HPElytra = new SliderSetting("Używaj wcześniej podczas lotu na elytrze", (double)5.0F, (double)2.0F, (double)6.0F, (double)1.0F);
   private final BooleanSetting back = new BooleanSetting("Przywracaj przedmiot", true);
   private final BooleanSetting noBallSwitch = new BooleanSetting("Nie używaj, gdy masz kulę", false);
   private final BooleanSetting saveEnchantedtotem = new BooleanSetting("Zachowuj zaklęte totemy", true);
   private final BooleanSetting absorptionCheck = new BooleanSetting("+ złote serca", false);
   public final SliderSetting hp = new SliderSetting("Zdrowie", (double)4.5F, (double)2.0F, (double)20.0F, (double)0.1F);
   private final SliderSetting crystalDistance = new SliderSetting("Próg dla kryształu", (double)4.0F, (double)2.0F, (double)6.0F, (double)1.0F, () -> this.threats.get("Kryształ"));
   private final SliderSetting anchorDistance = new SliderSetting("Próg dla kotwicy", (double)4.0F, (double)2.0F, (double)6.0F, (double)1.0F, () -> this.threats.get("Kotwica odrodzenia"));
   private final SliderSetting minecartDistance = new SliderSetting("Próg dla wagonika", (double)4.0F, (double)2.0F, (double)8.0F, (double)1.0F, () -> this.threats.get("Wagonik"));
   private final SliderSetting obsidianDistance = new SliderSetting("Próg dla obsydianu", (double)4.0F, (double)2.0F, (double)8.0F, (double)1.0F, () -> this.threats.get("Obsydian"));
   private int item = -1;
   private int fastWaitTicks;
   private boolean fastOpenedInventory;

   public AutoTotem() {
      this.addSettings(new Setting[]{this.mode, this.threats, this.hp, this.HPElytra, this.back, this.noBallSwitch, this.saveEnchantedtotem, this.absorptionCheck, this.crystalDistance, this.anchorDistance, this.minecartDistance, this.obsidianDistance});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.mode.is("Fast")) {
         this.handleFastMode();
      } else {
         if (event instanceof EventEntitySpawn) {
            EventEntitySpawn spawnEvent = (EventEntitySpawn)event;
            class_1297 e = spawnEvent.getEntity();
            if (this.threats.get("Kryształ") && e instanceof class_1511 && mc.field_1724 != null && e.method_5739(mc.field_1724) <= this.crystalDistance.get().floatValue()) {
               this.forceTotem();
            }

            if (this.threats.get("Wagonik") && e instanceof class_1701 && mc.field_1724 != null && e.method_5739(mc.field_1724) <= this.minecartDistance.get().floatValue()) {
               this.forceTotem();
            }
         }

         if (event instanceof EventUpdate) {
            int slot = this.getTotemSlot();
            class_1799 offhand = mc.field_1724.method_6079();
            boolean hasTotemInHand = offhand.method_7909() == class_1802.field_8288;
            if (this.condition()) {
               if (slot == -1) {
                  return;
               }

               if (this.saveEnchantedtotem.get() && offhand.method_7909() == class_1802.field_8288 && offhand.method_7942()) {
                  class_1799 candidate = mc.field_1724.method_31548().method_5438(slot);
                  if (candidate.method_7909() == class_1802.field_8288 && !candidate.method_7942()) {
                     InventoryUtil.swapSlotsUniversal(slot, 40, false, true);
                     this.item = slot;
                     return;
                  }
               }

               if (!hasTotemInHand) {
                  InventoryUtil.swapSlotsUniversal(slot, 40, false, true);
                  if (this.item == -1) {
                     this.item = slot;
                  }
               }
            } else if (this.item != -1 && this.back.get()) {
               InventoryUtil.swapSlotsUniversal(this.item, 40, false, true);
               this.item = -1;
            }
         }

      }
   }

   private void handleFastMode() {
      if (mc.field_1724 != null && mc.field_1761 != null && !mc.field_1724.method_6079().method_31574(class_1802.field_8288)) {
         if (mc.field_1755 == null || mc.field_1755 instanceof class_490) {
            if (mc.field_1755 == null) {
               mc.method_1507(new class_490(mc.field_1724));
               this.fastOpenedInventory = true;
               this.fastWaitTicks = 3;
            } else if (mc.field_1755 instanceof class_490 && mc.field_1724.field_7512 == mc.field_1724.field_7498 && mc.field_1724.field_7512.method_34255().method_7960()) {
               if (this.fastWaitTicks > 0) {
                  --this.fastWaitTicks;
               } else {
                  int inventorySlot = this.findFastTotemSlot();
                  if (inventorySlot == -1) {
                     this.closeFastInventory();
                  } else {
                     int handlerSlot = inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
                     int syncId = mc.field_1724.field_7512.field_7763;
                     mc.field_1761.method_2906(syncId, handlerSlot, 0, class_1713.field_7790, mc.field_1724);
                     mc.field_1761.method_2906(syncId, 45, 0, class_1713.field_7790, mc.field_1724);
                     mc.field_1761.method_2906(syncId, handlerSlot, 0, class_1713.field_7790, mc.field_1724);
                     this.closeFastInventory();
                  }
               }
            }
         }
      }
   }

   private int findFastTotemSlot() {
      for(int slot = 0; slot < 36; ++slot) {
         if (mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8288)) {
            return slot;
         }
      }

      return -1;
   }

   private void closeFastInventory() {
      if (this.fastOpenedInventory && mc.field_1755 instanceof class_490) {
         mc.field_1724.method_7346();
      }

      this.fastOpenedInventory = false;
      this.fastWaitTicks = 0;
   }

   private void forceTotem() {
      int slot = this.getTotemSlot();
      if (slot != -1) {
         class_1799 offhand = mc.field_1724.method_6079();
         if (offhand.method_7909() != class_1802.field_8288) {
            InventoryUtil.swapSlotsUniversal(slot, 40, false, true);
            this.item = slot;
         }

      }
   }

   private int getTotemSlot() {
      class_1799 offhand = mc.field_1724.method_6079();
      if (this.saveEnchantedtotem.get()) {
         if (offhand.method_7909() == class_1802.field_8288 && offhand.method_7942()) {
            int normalTotem = this.findTotem(false);
            return normalTotem != -1 ? normalTotem : -1;
         } else {
            int normalTotem = this.findTotem(false);
            if (normalTotem != -1) {
               return normalTotem;
            } else {
               int enchantedTotem = this.findTotem(true);
               return enchantedTotem != -1 ? enchantedTotem : -1;
            }
         }
      } else {
         return InventoryUtil.getItemSlot(class_1802.field_8288);
      }
   }

   private int findTotem(boolean enchanted) {
      for(int i = 0; i < mc.field_1724.method_31548().method_5439(); ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8288) {
            boolean hasEnchant = stack.method_7942();
            if (enchanted == hasEnchant) {
               return i;
            }
         }
      }

      return -1;
   }

   private boolean condition() {
      float absorption = this.absorptionCheck.get() && mc.field_1724.method_6059(class_1294.field_5898) ? mc.field_1724.method_6067() : 0.0F;
      if (mc.field_1724.method_6032() + absorption <= this.hp.get().floatValue()) {
         return true;
      } else {
         if (!this.isBall()) {
            if (this.crystal()) {
               return true;
            }

            if (this.anchor()) {
               return true;
            }

            if (this.macePlayer()) {
               return true;
            }

            if (this.creeper()) {
               return true;
            }

            if (this.obsidian()) {
               return true;
            }
         }

         return this.checkHPElytra() || this.checkFall();
      }
   }

   private boolean checkFall() {
      if (!this.threats.get("Upadek")) {
         return false;
      } else if (mc.field_1724.method_6128()) {
         return false;
      } else {
         return mc.field_1724.field_6017 > 10.0F;
      }
   }

   private boolean checkHPElytra() {
      return ((class_1799)mc.field_1724.method_31548().field_7548.get(2)).method_7909() == class_1802.field_8833 && mc.field_1724.method_6032() <= this.hp.get().floatValue() + this.HPElytra.get().floatValue();
   }

   private boolean isBall() {
      if (this.threats.get("Kotwica odrodzenia") && mc.field_1724.field_6017 > 5.0F) {
         return false;
      } else {
         return this.noBallSwitch.get() && mc.field_1724.method_6079().method_7909() instanceof class_1809;
      }
   }

   private boolean anchor() {
      if (!this.threats.get("Kotwica odrodzenia")) {
         return false;
      } else {
         return InventoryUtil.TotemUtil.getBlock(this.anchorDistance.get().floatValue(), class_2246.field_23152) != null;
      }
   }

   private boolean obsidian() {
      if (!this.threats.get("Obsydian")) {
         return false;
      } else {
         return InventoryUtil.TotemUtil.getBlock(this.obsidianDistance.get().floatValue(), class_2246.field_10540) != null;
      }
   }

   private boolean creeper() {
      if (!this.threats.get("Gdy w pobliżu jest creeper")) {
         return false;
      } else {
         for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
            if (entity instanceof class_1548) {
               class_1548 creeper = (class_1548)entity;
               if (mc.field_1724.method_5739(creeper) < 5.0F && creeper.method_7003(0.0F) > 0.0F) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private boolean macePlayer() {
      if (!this.threats.get("Gracz z buławą")) {
         return false;
      } else {
         for(class_1657 player : Manager.SYNC_MANAGER.getPlayers()) {
            if (player != mc.field_1724) {
               boolean hasMace = player.method_6047().method_7909() == class_1802.field_49814;
               double dy = player.method_23318() - mc.field_1724.method_23318();
               double yVel = player.method_18798().field_1351;
               double distance = (double)player.method_5739(mc.field_1724);
               boolean isAbove = dy > (double)1.5F;
               boolean isInAir = !player.method_24828() && !player.method_5799() && !player.method_6101();
               boolean fallingOrInAir = (yVel < -0.1 || yVel > 0.1) && isInAir;
               if (hasMace && isAbove && fallingOrInAir && distance < (double)24.0F) {
                  return true;
               }
            }
         }

         return false;
      }
   }

   private boolean crystal() {
      boolean checkCrystal = this.threats.get("Kryształ");
      boolean checkMinecart = this.threats.get("Wagonik");
      if (!checkCrystal && !checkMinecart) {
         return false;
      } else {
         for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
            if (checkCrystal && entity instanceof class_1511 && mc.field_1724.method_5739(entity) < this.crystalDistance.get().floatValue()) {
               return true;
            }

            if (checkMinecart && entity instanceof class_1701 && mc.field_1724.method_5739(entity) < this.minecartDistance.get().floatValue()) {
               return true;
            }
         }

         return false;
      }
   }

   private void reload() {
      this.item = -1;
   }

   protected void onEnable() {
      this.reload();
      super.onEnable();
   }

   protected void onDisable() {
      this.closeFastInventory();
      this.reload();
      super.onDisable();
   }
}
