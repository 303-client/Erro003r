package ru.levin.modules.combat;

import net.minecraft.class_2596;
import net.minecraft.class_2743;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;

@FunctionAnnotation(
   name = "Velocity",
   keywords = {"AKB", "AntiKnockBack"},
   type = Type.Combat,
   desc = "Wyłącza odrzut"
)
public class Velocity extends Function {
   public ModeSetting mode = new ModeSetting("Typ", "Cancel", new String[]{"Cancel"});

   public void onEvent(Event event) {
      if (event instanceof EventPacket eventPacket) {
         if (this.mode.is("Cancel")) {
            class_2596 var4 = eventPacket.getPacket();
            if (var4 instanceof class_2743) {
               class_2743 entityVelocityUpdateS2CPacket = (class_2743)var4;
               if (entityVelocityUpdateS2CPacket.method_11818() == mc.field_1724.method_5628()) {
                  eventPacket.setCancel(true);
               }
            }
         }
      }

   }
}
