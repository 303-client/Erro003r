package ru.levin.modules.combat;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1511;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import org.joml.Vector2f;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.input.EventKey;
import ru.levin.events.impl.input.EventKeyBoard;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.events.impl.world.EventObsidianPlace;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.MoveUtil;

@FunctionAnnotation(
   name = "AutoExplosion",
   type = Type.Combat,
   desc = "Automatycznie stawia kryształ na obsydianie"
)
public class AutoExplosion extends Function {
   private final BooleanSetting correction = new BooleanSetting("Korekta ruchu", true);
   private final SliderSetting delay = new SliderSetting("Opóźnienie", (double)100.0F, (double)50.0F, (double)300.0F, (double)1.0F);
   private final BooleanSetting sanya = new BooleanSetting("Stawiaj po naciśnięciu klawisza", false);
   private final BindSetting bind = new BindSetting("Klawisz", 0, () -> this.sanya.get());
   private final ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
   private class_2338 crystalPos = null;
   private class_1297 crystalEntity = null;
   private int previousSlot = -1;
   public Vector2f serverRot = null;
   private boolean rotating = false;

   public AutoExplosion() {
      this.addSettings(new Setting[]{this.correction, this.delay, this.sanya, this.bind});
   }

   public boolean check() {
      return this.correction.get() && this.crystalEntity != null && this.crystalPos != null && this.serverRot != null && this.state;
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey key) {
         if (this.sanya.get() && key.key == this.bind.getKey()) {
            this.schedulePlaceSequence();
         }
      }

      if (event instanceof EventKeyBoard input) {
         if (this.shouldCorrect()) {
            MoveUtil.fixMovement(input, this.serverRot.x);
         }
      }

      if (event instanceof EventMotion motion) {
         this.handleRotation(motion);
      }

      if (event instanceof EventObsidianPlace place) {
         this.scheduleCrystalPlace(place.getPos());
      }

      if (event instanceof EventUpdate) {
         this.updateLogic();
      }

   }

   private void schedulePlaceSequence() {
      class_2338 pos = this.getLookingBlockPos();
      if (pos != null) {
         int obsidianSlot = this.findObsidianSlot();
         if (obsidianSlot != -1) {
            this.previousSlot = mc.field_1724.method_31548().field_7545;
            mc.field_1724.method_31548().field_7545 = obsidianSlot;
            this.scheduler.schedule(() -> mc.execute(() -> {
                  this.placeBlock(pos);
                  mc.field_1724.method_31548().field_7545 = this.previousSlot;
                  this.scheduleCrystalPlace(pos);
               }), 50L, TimeUnit.MILLISECONDS);
         }
      }
   }

   private void placeBlock(class_2338 pos) {
      class_3965 bhr = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
      class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, bhr);
      if (result == class_1269.field_5812) {
         mc.field_1724.method_6104(class_1268.field_5808);
      }

   }

   private void scheduleCrystalPlace(class_2338 pos) {
      int crystalSlot = this.findCrystalSlot();
      if (crystalSlot != -1 && this.canPlaceCrystal(pos)) {
         this.scheduler.schedule(() -> mc.execute(() -> {
               this.previousSlot = mc.field_1724.method_31548().field_7545;
               mc.field_1724.method_31548().field_7545 = crystalSlot;
               class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
               class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
               if (result == class_1269.field_5812) {
                  mc.field_1724.method_6104(class_1268.field_5808);
                  this.crystalPos = pos;
               }

               mc.field_1724.method_31548().field_7545 = this.previousSlot;
            }), this.delay.get().longValue(), TimeUnit.MILLISECONDS);
      }
   }

   private boolean canPlaceCrystal(class_2338 pos) {
      class_2338 above = pos.method_10084();
      return mc.field_1687.method_22347(above);
   }

   private void updateLogic() {
      if (this.crystalPos != null) {
         if (mc.field_1724.method_19538().method_1022(class_243.method_24953(this.crystalPos)) > (double)6.0F) {
            this.reset();
         } else {
            List<class_1297> crystals = mc.field_1687.method_8335((class_1297)null, (new class_238(this.crystalPos)).method_1014((double)1.0F)).stream().filter((e) -> e instanceof class_1511).toList();
            if (!crystals.isEmpty()) {
               this.crystalEntity = (class_1297)crystals.get(0);
               this.tryAttack(this.crystalEntity);
            }

         }
      }
   }

   private void handleRotation(EventMotion event) {
      if (this.crystalEntity != null) {
         Vector2f targetRot = rotationToEntity(this.crystalEntity);
         if (this.serverRot == null) {
            this.serverRot = targetRot;
         }

         Vector2f var10000 = this.serverRot;
         var10000.x += this.clampRotation(targetRot.x - this.serverRot.x, 10.0F);
         var10000 = this.serverRot;
         var10000.y += this.clampRotation(targetRot.y - this.serverRot.y, 10.0F);
         event.setYaw(this.serverRot.x);
         event.setPitch(this.serverRot.y);
      }
   }

   private float clampRotation(float value, float maxStep) {
      if (value > maxStep) {
         return maxStep;
      } else {
         return value < -maxStep ? -maxStep : value;
      }
   }

   private void tryAttack(class_1297 entity) {
      if (entity != null && !(mc.field_1724.method_7261(0.0F) < 1.0F)) {
         mc.field_1761.method_2918(mc.field_1724, entity);
         mc.field_1724.method_6104(class_1268.field_5808);
         this.reset();
      }
   }

   private int findCrystalSlot() {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8301)) {
            return i;
         }
      }

      return -1;
   }

   private int findObsidianSlot() {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8281)) {
            return i;
         }
      }

      return -1;
   }

   private class_2338 getLookingBlockPos() {
      class_243 eyes = mc.field_1724.method_5836(1.0F);
      class_243 look = mc.field_1724.method_5828(1.0F).method_1021((double)4.0F);
      class_3965 bhr = mc.field_1687.method_17742(new class_3959(eyes, eyes.method_1019(look), class_3960.field_17559, class_242.field_1348, mc.field_1724));
      return bhr != null && bhr.method_17777() != null ? bhr.method_17777() : null;
   }

   private boolean shouldCorrect() {
      return this.correction.get() && this.crystalEntity != null && this.crystalPos != null && this.serverRot != null && this.state;
   }

   private void reset() {
      this.crystalEntity = null;
      this.crystalPos = null;
      this.serverRot = null;
      this.previousSlot = -1;
   }

   public static Vector2f rotationToEntity(class_1297 entity) {
      class_243 diff = entity.method_19538().method_1020(mc.field_1724.method_19538());
      double flatDist = Math.hypot(diff.field_1352, diff.field_1350);
      float yaw = (float)Math.toDegrees(Math.atan2(diff.field_1350, diff.field_1352)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(diff.field_1351, flatDist)));
      return new Vector2f(yaw, pitch);
   }

   protected void onDisable() {
      this.reset();
      super.onDisable();
   }
}
