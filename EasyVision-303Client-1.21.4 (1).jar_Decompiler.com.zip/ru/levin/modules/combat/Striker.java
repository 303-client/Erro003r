package ru.levin.modules.combat;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "Striker",
   desc = "Odwraca poziomy kierunek knockbacku przeciwnika",
   type = Type.Combat
)
public class Striker extends Function {
   public final SliderSetting strength = new SliderSetting("Siła", (double)1.0F, (double)0.1F, (double)2.0F, (double)0.1F);

   public Striker() {
      this.addSettings(new Setting[]{this.strength});
   }

   public void onEvent(Event event) {
   }
}
