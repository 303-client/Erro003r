package ru.levin.modules.combat;

import net.minecraft.class_2828;
import ru.levin.events.Event;
import ru.levin.events.impl.player.EventAttack;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "Criticals",
   type = Type.Combat,
   desc = "Zadaje trafienie krytyczne przy ataku bez skoku"
)
public class Criticals extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventAttack) {
         this.packet(0.01250004768372);
      }

   }

   private void packet(double y) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1724.method_24828() || mc.field_1724.method_31549().field_7479 || mc.field_1724.method_5799() || !mc.field_1724.method_5771() && !mc.field_1724.method_5869()) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318() + y, mc.field_1724.method_23321(), false, true));
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), false, true));
         }

      }
   }
}
