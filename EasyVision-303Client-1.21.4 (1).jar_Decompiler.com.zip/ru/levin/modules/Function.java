package ru.levin.modules;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import ru.levin.events.Event;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.Manager;
import ru.levin.manager.notificationManager.NotificationType;
import ru.levin.modules.misc.ClientSounds;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.util.localization.PolishLocalization;
import ru.levin.util.player.AudioUtil;

public abstract class Function implements IMinecraft {
   private final FunctionAnnotation initerFunctions = (FunctionAnnotation)this.getClass().getAnnotation(FunctionAnnotation.class);
   public String name;
   public String keywords;
   private Type category;
   public int bind;
   public String desc;
   public boolean state;
   public boolean expanded;
   private final ArrayList<Setting> settings = new ArrayList();

   public Function() {
      this.initializeProperties();
   }

   public Function(String name, Type category) {
      this.name = name;
      this.category = category;
      this.state = false;
      this.bind = 0;
   }

   private void initializeProperties() {
      this.name = this.initerFunctions.name();
      this.desc = this.initerFunctions.desc();
      this.category = this.initerFunctions.type();
      this.keywords = Arrays.toString(this.initerFunctions.keywords());
      this.state = false;
      this.bind = this.initerFunctions.key();
   }

   public abstract void onEvent(Event var1);

   public final void setState(boolean enabled) {
      if (this.state != enabled) {
         this.state = enabled;

         try {
            if (this.state) {
               this.onEnable();
            } else {
               this.onDisable();
            }
         } catch (Exception e) {
            e.printStackTrace();
         }

      }
   }

   protected void onEnable() {
   }

   protected void onDisable() {
   }

   public void addSettings(Setting... options) {
      this.settings.addAll(Arrays.asList(options));
   }

   public void toggle() {
      this.state = !this.state;

      try {
         if (this.state) {
            this.onEnable();
            this.playSound(true);
         } else {
            this.onDisable();
            this.playSound(false);
         }
      } catch (Exception e) {
         e.printStackTrace();
      }

      Manager.NOTIFICATION_MANAGER.add(this.state ? NotificationType.SUCCESS : NotificationType.REMOVED, this.name, "Moduł " + (this.state ? "włączony!" : "wyłączony!"), 2);
   }

   private void playSound(boolean enable) {
      ClientSounds clientSounds = Manager.FUNCTION_MANAGER.clientSounds;
      if (clientSounds.state) {
         String soundFile;
         switch (clientSounds.mode.get()) {
            case "Type-1" -> soundFile = enable ? "nuron.wav" : "nuroff.wav";
            case "Type-2" -> soundFile = enable ? "akron.wav" : "akroff.wav";
            case "Type-3" -> soundFile = enable ? "celon.wav" : "celoff.wav";
            case "Type-4" -> soundFile = enable ? "enableold.wav" : "disableold.wav";
            default -> {
               return;
            }
         }

         AudioUtil.playSound(soundFile);
      }
   }

   public Type getCategory() {
      return this.category;
   }

   public boolean isState() {
      return this.state;
   }

   public List<Setting> getSettings() {
      return this.settings;
   }

   public String getDisplayName() {
      return PolishLocalization.translate(this.name);
   }

   public String getDisplayDescription() {
      return PolishLocalization.translate(this.desc);
   }

   public int getBindCode() {
      return this.bind;
   }

   public void setBindCode(int key) {
      this.bind = key;
   }

   public JsonObject save() {
      JsonObject object = new JsonObject();
      object.addProperty("state", this.state);
      object.addProperty("keyIndex", this.bind);
      JsonObject propertiesObject = new JsonObject();

      for(Setting set : this.settings) {
         if (set instanceof BindBooleanSetting bbs) {
            JsonObject bbsObject = new JsonObject();
            bbsObject.addProperty("state", bbs.get());
            bbsObject.addProperty("bindKey", bbs.getBindKey());
            propertiesObject.add(bbs.getName(), bbsObject);
         } else if (set instanceof BooleanSetting bs) {
            propertiesObject.addProperty(set.getName(), bs.get());
         } else if (set instanceof MultiSetting ms) {
            propertiesObject.addProperty(set.getName(), ms.getConfigValue());
         } else if (set instanceof ModeSetting ms) {
            propertiesObject.addProperty(set.getName(), ms.get());
         } else if (set instanceof SliderSetting ss) {
            propertiesObject.addProperty(set.getName(), ss.get());
         } else if (set instanceof BindSetting bs) {
            propertiesObject.addProperty(set.getName(), bs.getKey());
         } else if (set instanceof TextSetting ts) {
            propertiesObject.addProperty(set.getName(), ts.getValue());
         }
      }

      object.add("Settings", propertiesObject);
      return object;
   }

   public void load(JsonObject object) {
      if (object != null) {
         if (object.has("state")) {
            this.setState(object.get("state").getAsBoolean());
         }

         if (object.has("keyIndex")) {
            this.setBindCode(object.get("keyIndex").getAsInt());
         }

         JsonElement settingsElement = object.get("Settings");
         if (settingsElement != null && settingsElement.isJsonObject()) {
            JsonObject propertiesObject = settingsElement.getAsJsonObject();

            for(Setting set : this.settings) {
               String name = set.getName();
               if (propertiesObject.has(name)) {
                  if (set instanceof BindBooleanSetting) {
                     BindBooleanSetting bbs = (BindBooleanSetting)set;
                     if (propertiesObject.get(name).isJsonObject()) {
                        JsonObject bbsObject = propertiesObject.getAsJsonObject(name);
                        if (bbsObject.has("state")) {
                           bbs.set(bbsObject.get("state").getAsBoolean());
                        }

                        if (bbsObject.has("bindKey")) {
                           bbs.setKey(bbsObject.get("bindKey").getAsInt());
                        }
                        continue;
                     }
                  }

                  if (set instanceof BooleanSetting) {
                     BooleanSetting bs = (BooleanSetting)set;
                     bs.set(propertiesObject.get(name).getAsBoolean());
                  } else if (set instanceof MultiSetting) {
                     MultiSetting ms = (MultiSetting)set;
                     ms.setConfigValue(propertiesObject.get(name).getAsString());
                  } else if (set instanceof ModeSetting) {
                     ModeSetting ms = (ModeSetting)set;
                     ms.set(propertiesObject.get(name).getAsString());
                  } else if (set instanceof SliderSetting) {
                     SliderSetting ss = (SliderSetting)set;
                     ss.set((double)propertiesObject.get(name).getAsFloat());
                  } else if (set instanceof BindSetting) {
                     BindSetting bs = (BindSetting)set;
                     bs.setKey(propertiesObject.get(name).getAsInt());
                  } else if (set instanceof TextSetting) {
                     TextSetting ts = (TextSetting)set;
                     ts.setValue(propertiesObject.get(name).getAsString());
                  }
               }
            }

         }
      }
   }
}
