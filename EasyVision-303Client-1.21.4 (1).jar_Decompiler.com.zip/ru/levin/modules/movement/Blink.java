package ru.levin.modules.movement;

import java.awt.Color;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2827;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.NetworkUtils;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "Blink",
   desc = "Opóźnia pakiety wysyłane na serwer",
   type = Type.Move
)
public class Blink extends Function {
   private final SliderSetting maxTicks = new SliderSetting("Maks. liczba ticków", (double)20.0F, (double)1.0F, (double)50.0F, (double)1.0F);
   private final CopyOnWriteArrayList<class_2596<?>> packetBuffer = new CopyOnWriteArrayList();
   private class_238 playerBoundingBox;
   private int currentTick = 0;

   public Blink() {
      this.addSettings(new Setting[]{this.maxTicks});
   }

   public void onEvent(Event event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (event instanceof EventPacket) {
            EventPacket packetEvent = (EventPacket)event;
            class_2596<?> packet = packetEvent.getPacket();
            if (packetEvent.isSendPacket() && !(packet instanceof class_2827)) {
               this.packetBuffer.add(packet);
               packetEvent.setCancel(true);
            }
         }

         if (event instanceof EventUpdate) {
            ++this.currentTick;
            if (this.currentTick >= this.maxTicks.get().intValue()) {
               this.send();
               this.currentTick = 0;
            }
         }

         if (event instanceof EventRender3D && this.playerBoundingBox != null) {
            RenderUtil.render3D.drawHoleOutline(this.playerBoundingBox, Color.WHITE.getRGB(), 2.0F);
         }

      } else {
         this.toggle();
      }
   }

   private void send() {
      if (mc.field_1724 != null && mc.field_1687 != null && !this.packetBuffer.isEmpty()) {
         for(class_2596<?> packet : this.packetBuffer) {
            NetworkUtils.sendSilentPacket(packet);
         }

         this.packetBuffer.clear();
         this.playerBoundingBox = mc.field_1724.method_5829();
      }
   }

   public void onDisable() {
      this.send();
      this.playerBoundingBox = null;
      this.currentTick = 0;
   }
}
