package ru.levin.modules.movement;

import net.minecraft.class_1293;
import net.minecraft.class_1294;
import ru.levin.events.Event;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.move.MoveUtil;

@FunctionAnnotation(
   name = "Strafe",
   desc = "Szybkie przenoszenie",
   type = Type.Move
)
public class Strafe extends Function {
   private final ModeSetting mode = new ModeSetting("Typ", "MetaHvH", new String[]{"MetaHvH"});

   public Strafe() {
      this.addSettings(new Setting[]{this.mode});
   }

   public void onEvent(Event event) {
      if (event instanceof EventMotion && mc.field_1724 != null && this.mode.is("MetaHvH") && !mc.field_1724.method_6128() && (!mc.field_1724.method_5799() || !mc.field_1724.method_5681()) && MoveUtil.isMoving()) {
         float motion = 0.19F;
         class_1293 speedEffect = mc.field_1724.method_6112(class_1294.field_5904);
         if (speedEffect != null) {
            int amplifier = speedEffect.method_5578();
            switch (amplifier) {
               case 0 -> motion = 0.25F;
               case 1 -> motion = 0.37F;
               case 2 -> motion = 0.46F;
               case 3 -> motion = 0.7F;
               default -> motion = 0.75F + (float)(amplifier - 3) * 0.05F;
            }
         }

         if (mc.field_1690.field_1903.method_1434()) {
            motion += 0.1F;
         }

         MoveUtil.setMotion((double)motion);
      }

   }
}
