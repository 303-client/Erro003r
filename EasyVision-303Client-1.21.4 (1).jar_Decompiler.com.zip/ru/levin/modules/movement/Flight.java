package ru.levin.modules.movement;

import net.minecraft.class_1802;
import net.minecraft.class_2848;
import net.minecraft.class_2848.class_2849;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.MoveUtil;
import ru.levin.util.player.InventoryUtil;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "Flight",
   desc = "",
   type = Type.Move
)
public class Flight extends Function {
   private final ModeSetting mode = new ModeSetting("Typ", "Motion", new String[]{"Motion", "ElytraRWOld"});
   private final SliderSetting xspeed = new SliderSetting("Prędkość X", (double)1.0F, (double)0.0F, (double)5.0F, (double)0.1F);
   private final SliderSetting yspeed = new SliderSetting("Prędkość Y", (double)1.0F, (double)0.0F, (double)5.0F, (double)0.1F);
   private final TimerUtil timerUtil = new TimerUtil();
   private final TimerUtil swapTimer = new TimerUtil();
   int item = -1;

   public Flight() {
      this.addSettings(new Setting[]{this.mode, this.xspeed, this.yspeed});
   }

   public void onEvent(Event event) {
      if (this.mode.is("Motion") && event instanceof EventMotion) {
         double y = (double)0.0F;
         if (mc.field_1690.field_1903.method_1434()) {
            y = (double)this.yspeed.get().floatValue();
         } else if (mc.field_1690.field_1832.method_1434()) {
            y = (double)(-this.yspeed.get().floatValue());
         }

         mc.field_1724.method_18800((double)0.0F, y, (double)0.0F);
         if (mc.field_1690.field_1867.method_1434()) {
            MoveUtil.setMotion((double)this.xspeed.get().floatValue());
         }
      }

      if (this.mode.is("ElytraRWOld") && event instanceof EventUpdate) {
         for(int i = 0; i < 9; ++i) {
            if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8833) && !mc.field_1724.method_24828() && !mc.field_1724.method_5869() && !mc.field_1724.method_5771() && !mc.field_1724.method_6128()) {
               int swapDelay = 520;
               if (this.timerUtil.hasTimeElapsed((long)swapDelay)) {
                  this.swapTimer.reset();
                  InventoryUtil.swapSlotsUniversal(6, i, false, false);
                  mc.method_1562().method_52787(new class_2848(mc.field_1724, class_2849.field_12982));
                  mc.field_1724.method_23669();
                  InventoryUtil.swapSlotsUniversal(6, i, false, false);
                  this.item = i;
                  this.timerUtil.reset();
               }

               if (mc.field_1724.method_6128()) {
                  InventoryUtil.inventorySwapClick2(class_1802.field_8639, true, false);
               }
            }
         }
      }

   }
}
