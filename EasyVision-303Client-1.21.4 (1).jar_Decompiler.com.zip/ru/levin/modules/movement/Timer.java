package ru.levin.modules.movement;

import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.ClientManager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "Timer",
   type = Type.Move,
   desc = "Przyspieszenie gry"
)
public class Timer extends Function {
   private final SliderSetting timerAmount = new SliderSetting("Prędkość", (double)2.0F, (double)0.0F, (double)10.0F, (double)0.01F);
   private final BooleanSetting smart = new BooleanSetting("Inteligentny", true);
   private final SliderSetting ticks = new SliderSetting("Szybkość spadania", (double)3.8F, (double)0.15F, (double)5.0F, (double)0.1F, () -> this.smart.get());
   private float maxViolation = 100.0F;
   private float violation = 0.0F;
   private boolean isCooldown = false;

   public Timer() {
      this.addSettings(new Setting[]{this.timerAmount, this.smart, this.ticks});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (!this.smart.get()) {
            ClientManager.TICK_TIMER = this.timerAmount.get().floatValue();
            return;
         }

         if (this.isCooldown) {
            this.violation -= this.ticks.get().floatValue();
            ClientManager.TICK_TIMER = 1.0F;
            if (this.violation <= 0.0F) {
               this.violation = 0.0F;
               this.isCooldown = false;
            }
         } else {
            ClientManager.TICK_TIMER = this.timerAmount.get().floatValue();
            this.violation += this.ticks.get().floatValue();
            if (this.violation >= this.maxViolation) {
               this.violation = this.maxViolation;
               this.isCooldown = true;
            }
         }
      }

   }

   public void onDisable() {
      ClientManager.TICK_TIMER = 1.0F;
      this.violation = 0.0F;
      this.isCooldown = false;
      super.onDisable();
   }

   public void onEnable() {
      this.violation = 0.0F;
      this.isCooldown = false;
      super.onEnable();
   }
}
