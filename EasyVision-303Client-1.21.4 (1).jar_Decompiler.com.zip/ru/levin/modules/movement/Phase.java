package ru.levin.modules.movement;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.util.move.NetworkUtils;

@FunctionAnnotation(
   name = "Phase",
   desc = "Pozwala poruszać się wewnątrz bloków na osiach X i Z na ReallyWorld",
   type = Type.Move
)
public class Phase extends Function {
   private final List<class_2596<?>> bufferedPackets = new CopyOnWriteArrayList();
   private boolean semiPacketSent;
   private boolean skipReleaseOnDisable;

   public void onEvent(Event event) {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         this.toggle();
      }

      if (event instanceof EventPacket ep) {
         if (ep.isSendPacket()) {
            class_2596<?> packet = ep.getPacket();
            if (packet instanceof class_2828) {
               this.bufferedPackets.add(packet);
               ep.setCancel(true);
            }
         }
      }

      if (event instanceof EventUpdate) {
         mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, (double)0.0F, mc.field_1724.method_18798().field_1350);
         class_238 box = mc.field_1724.method_5829().method_1014(0.001);
         int minX = class_3532.method_15357(box.field_1323);
         int minY = class_3532.method_15357(box.field_1322);
         int minZ = class_3532.method_15357(box.field_1321);
         int maxX = class_3532.method_15357(box.field_1320);
         int maxY = class_3532.method_15357(box.field_1325);
         int maxZ = class_3532.method_15357(box.field_1324);
         long totalStates = 0L;
         long solidStates = 0L;

         for(int x = minX; x <= maxX; ++x) {
            for(int y = minY; y <= maxY; ++y) {
               for(int z = minZ; z <= maxZ; ++z) {
                  class_2338 pos = new class_2338(x, y, z);
                  class_2680 state = mc.field_1687.method_8320(pos);
                  ++totalStates;
                  if (state.method_51367()) {
                     ++solidStates;
                  }
               }
            }
         }

         boolean noSolidInAABB = solidStates == 0L;
         boolean semiInsideBlock = solidStates > 0L && solidStates < totalStates;
         if (!this.semiPacketSent && semiInsideBlock) {
            double x = mc.field_1724.method_23317();
            double y = mc.field_1724.method_23318();
            double z = mc.field_1724.method_23321();
            float yaw = mc.field_1724.method_36454();
            float pitch = mc.field_1724.method_36455();
            boolean onGround = mc.field_1724.method_24828();

            for(int i = 0; i < 2; ++i) {
               mc.field_1724.field_3944.method_52787(new class_2828.class_2830(x, y, z, yaw, pitch, onGround, false));
            }

            this.semiPacketSent = true;
            return;
         }

         if (this.semiPacketSent && noSolidInAABB) {
            this.skipReleaseOnDisable = true;
            this.toggle();
         }
      }

   }

   public void onDisable() {
      if (!this.skipReleaseOnDisable && this.semiPacketSent) {
         double x = mc.field_1724.method_23317();
         double y = mc.field_1724.method_23318();
         double z = mc.field_1724.method_23321();
         float yaw = mc.field_1724.method_36454();
         float pitch = mc.field_1724.method_36455();
         mc.field_1724.field_3944.method_52787(new class_2828.class_2830(x - (double)5000.0F, y, z - (double)5000.0F, yaw, pitch, false, false));
         mc.field_1724.field_3944.method_52787(new class_2828.class_2830(x, y, z, yaw, pitch, mc.field_1724.method_24828(), false));
      }

      if (mc.field_1724 != null && mc.field_1724.field_3944 != null && !this.bufferedPackets.isEmpty()) {
         for(class_2596<?> packet : this.bufferedPackets) {
            NetworkUtils.sendSilentPacket(packet);
         }

         this.bufferedPackets.clear();
      }

      super.onDisable();
   }

   public void onEnable() {
      this.bufferedPackets.clear();
      this.semiPacketSent = false;
      this.skipReleaseOnDisable = false;
      super.onEnable();
   }
}
