package ru.levin.modules.movement;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1309;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2680;
import net.minecraft.class_2827;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_239.class_240;
import net.minecraft.class_2902.class_2903;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.move.NetworkUtils;
import ru.levin.util.player.InventoryUtil;
import ru.levin.util.player.TimerUtil;
import ru.levin.util.render.RenderAddon;
import ru.levin.util.render.RenderUtil;

@FunctionAnnotation(
   name = "ElytraTarget",
   desc = "Target players to elytra!",
   type = Type.Move
)
public class ElytraTarget extends Function {
   public final ModeSetting mode = new ModeSetting("Typ", "Zwykły", new String[]{"Zwykły", "Zaawansowany"});
   private final SliderSetting sila = new SliderSetting("Odlot", (double)8.0F, (double)5.0F, (double)40.0F, (double)1.0F, () -> this.mode.is("Zaawansowany"));
   private final SliderSetting silaTime = new SliderSetting("Czas odlotu", (double)400.0F, (double)200.0F, (double)1000.0F, (double)10.0F, () -> this.mode.is("Zaawansowany"));
   private final BindBooleanSetting perelet = new BindBooleanSetting("Przelot", true);
   private final SliderSetting predict = new SliderSetting("Przewidywanie", (double)2.6F, (double)0.1F, (double)6.0F, (double)0.1F, () -> this.perelet.get());
   private final BooleanSetting leaveHP = new BooleanSetting("Odleć", true, () -> this.mode.is("Zaawansowany"));
   private final MultiSetting leaveList = new MultiSetting("Odleć, gdy", Arrays.asList("Mało zdrowia", "Podczas używania przedmiotu", "Zbijanie tarczy"), List.of("Mało zdrowia", "Podczas używania przedmiotu"), () -> this.leaveHP.get() && this.mode.is("Zaawansowany"));
   private final BindBooleanSetting resolver = new BindBooleanSetting("Unik resolwera", true, "Nie pozwala przeciwnikowi cię trafić; działa tylko w powietrzu", () -> this.mode.is("Zaawansowany"));
   private final SliderSetting resolverStrength = new SliderSetting("Siła resolwera", (double)12.0F, (double)4.0F, (double)30.0F, (double)1.0F, () -> this.resolver.get() && this.mode.is("Zaawansowany"));
   public final BindBooleanSetting prefer = new BindBooleanSetting("Zmieniaj kierunek", true, "Zmieniaj kierunek lotu po trafieniu", () -> this.mode.is("Zaawansowany"));
   private final MultiSetting preferDir = new MultiSetting("Kierunek", Arrays.asList("Północ", "Południe", "Zachód", "Wschód", "Góra"), List.of("Północ", "Południe", "Zachód", "Wschód", "Góra", "Dół"), () -> this.mode.is("Zaawansowany") && this.prefer.get());
   private final BooleanSetting avoidWalls = new BooleanSetting("Unikaj ścian", true, "Zmienia tor lotu, gdy przed graczem znajduje się ściana", () -> this.mode.is("Zaawansowany"));
   private final BooleanSetting firework = new BooleanSetting("Wysyłanie fajerwerków", true, () -> this.mode.is("Zaawansowany"));
   private final SliderSetting fireworkTime = new SliderSetting("Czas wysłania", (double)800.0F, (double)100.0F, (double)2000.0F, (double)10.0F, () -> this.firework.get() && this.mode.is("Zaawansowany"));
   private final BooleanSetting fakelags = new BooleanSetting("Fake Lags", true, () -> this.mode.is("Zaawansowany"));
   private final SliderSetting fakelagsDistance = new SliderSetting("Zasięg flagowania", (double)10.0F, (double)5.0F, (double)20.0F, (double)0.5F, () -> this.fakelags.get() && this.mode.is("Zaawansowany"));
   private final SliderSetting fakelagsMaxDistance = new SliderSetting("Maksymalny zasięg flagowania", (double)30.0F, (double)15.0F, (double)50.0F, (double)1.0F, () -> this.fakelags.get() && this.mode.is("Zaawansowany"));
   private final CopyOnWriteArrayList<class_2596<?>> packetBuffer = new CopyOnWriteArrayList();
   private boolean isAccumulatingPackets = false;
   private boolean wasInFarRange = false;
   private class_1309 currentTarget = null;
   private class_243 defensivePos = null;
   private final TimerUtil defensiveTimer = new TimerUtil();
   private final BooleanSetting visual = new BooleanSetting("Wyświetlaj pozycję", false, () -> this.mode.is("Zaawansowany") || this.mode.is("Zwykły"));
   boolean defensiveActive;
   boolean lastDefensive;
   private int rotationPhase = 0;
   private int directionIndex = 0;
   private long lastHitTime = 0L;
   private class_1309 lastTarget = null;
   private long targetLastAttackTime = 0L;
   private final Map<String, class_243> namedDirections = Map.of("Północ", new class_243((double)0.0F, (double)0.0F, (double)-1.0F), "Południe", new class_243((double)0.0F, (double)0.0F, (double)1.0F), "Zachód", new class_243((double)-1.0F, (double)0.0F, (double)0.0F), "Wschód", new class_243((double)1.0F, (double)0.0F, (double)0.0F), "Góra", new class_243((double)0.0F, (double)1.0F, (double)0.0F), "Dół", new class_243((double)0.0F, (double)-1.0F, (double)0.0F));
   private List<class_243> airDirections = new ArrayList();
   private final TimerUtil fireworkTimer = new TimerUtil();
   private final TimerUtil sanyaEblan = new TimerUtil();
   public boolean trueFireWork = false;
   private int x;
   private int y;
   private int z;

   public ElytraTarget() {
      this.addSettings(new Setting[]{this.mode, this.sila, this.silaTime, this.perelet, this.predict, this.leaveHP, this.leaveList, this.resolver, this.resolverStrength, this.prefer, this.preferDir, this.avoidWalls, this.firework, this.fireworkTime, this.fakelags, this.fakelagsDistance, this.fakelagsMaxDistance, this.visual});
   }

   public void onEnable() {
      this.rebuildAirDirections();
      this.packetBuffer.clear();
      this.isAccumulatingPackets = false;
      this.wasInFarRange = false;
      this.currentTarget = null;
      this.defensivePos = null;
   }

   private void rebuildAirDirections() {
      this.airDirections.clear();
      boolean isFlying = mc.field_1724 != null && mc.field_1724.method_6128();

      for(String name : this.preferDir.getAvailableModes()) {
         if (this.preferDir.get(name) && (!name.equals("Dół") || isFlying)) {
            class_243 dir = (class_243)this.namedDirections.get(name);
            if (dir != null) {
               this.airDirections.add(dir);
            }
         }
      }

      if (this.airDirections.isEmpty()) {
         for(Map.Entry<String, class_243> entry : this.namedDirections.entrySet()) {
            if (!((String)entry.getKey()).equals("Dół") || isFlying) {
               this.airDirections.add((class_243)entry.getValue());
            }
         }
      }

      if (this.directionIndex >= this.airDirections.size()) {
         this.directionIndex = 0;
      }

   }

   public void onEvent(Event event) {
      if (this.mode.is("Zaawansowany") && mc.field_1724.method_6128()) {
         if (event instanceof EventPacket) {
            EventPacket packetEvent = (EventPacket)event;
            this.handlePacketEvent(packetEvent);
         }

         if (event instanceof EventUpdate) {
            this.updateFakeLagsState();
            if (this.firework.get() && this.fireworkTimer.hasTimeElapsed(this.fireworkTime.get().longValue())) {
               if (this.trueFireWork) {
                  InventoryUtil.inventorySwapClick2(class_1802.field_8639, true, false);
               }

               this.fireworkTimer.reset();
            }
         }

         if (event instanceof EventUpdate) {
            this.defensiveActive = this.shouldLeave();
            this.lastDefensive = this.defensiveActive;
            if (this.resolver.get() && this.rotationPhase != 0) {
               float evadePitch = (float)(Math.sin((double)System.currentTimeMillis() / (double)100.0F) * (double)this.resolverStrength.get().floatValue());
               float evadeYaw = (float)(Math.cos((double)System.nanoTime() / (double)100.0F) * (double)this.resolverStrength.get().floatValue());
               float cy = Manager.ROTATION.getYaw();
               float cp = Manager.ROTATION.getPitch();
               Manager.ROTATION.set(cy + evadeYaw, class_3532.method_15363(cp + evadePitch, -89.9F, 89.9F));
            }

            if (this.rotationPhase != 0 && (float)(System.currentTimeMillis() - this.lastHitTime) > this.silaTime.get().floatValue()) {
               this.rotationPhase = 0;
            }
         }

         if (event instanceof EventRender3D) {
            EventRender3D render = (EventRender3D)event;
            if (this.visual.get() && mc.field_1724.method_6128() && Manager.FUNCTION_MANAGER.attackAura.target != null) {
               class_2338 pos = new class_2338(this.x, this.y, this.z);
               class_2680 state = mc.field_1687.method_8320(pos);
               class_238 box = (new class_238(pos)).method_1011(0.01);
               RenderUtil.render3D.drawHoleOutline(box, ColorUtil.rgba(128, 255, 128, 255), 2.0F);
            }

            if (this.defensivePos != null && this.fakelags.get() && this.isAccumulatingPackets) {
               RenderAddon.renderFakePlayer(this.defensivePos, this.fakelags.get(), this.isAccumulatingPackets, render);
            }
         }
      }

   }

   private void handlePacketEvent(EventPacket packetEvent) {
      if (this.fakelags.get() && packetEvent.getPacket() instanceof class_2596) {
         if (this.isAccumulatingPackets && packetEvent.isSendPacket() && !(packetEvent.getPacket() instanceof class_2827)) {
            this.packetBuffer.add(packetEvent.getPacket());
            packetEvent.setCancel(true);
         }

      }
   }

   private void updateFakeLagsState() {
      if (!this.fakelags.get()) {
         if (this.isAccumulatingPackets) {
            this.sendBufferedPackets();
            this.isAccumulatingPackets = false;
         }

      } else {
         boolean isFlying = mc.field_1724.method_6128();
         class_1309 target = Manager.FUNCTION_MANAGER.attackAura.target;
         boolean hasTarget = target != null;
         if (target != null && !target.equals(this.currentTarget)) {
            this.currentTarget = target;
            if (this.isAccumulatingPackets) {
               this.sendBufferedPackets();
            }
         }

         if (isFlying && hasTarget && !this.perelet.get() && !this.defensiveActive) {
            double distanceToTarget = mc.field_1724.method_19538().method_1022(target.method_19538());
            double triggerDistance = this.fakelagsDistance.get().doubleValue();
            double maxDistance = this.fakelagsMaxDistance.get().doubleValue();
            if (distanceToTarget > maxDistance) {
               if (this.isAccumulatingPackets) {
                  this.sendBufferedPackets();
                  this.isAccumulatingPackets = false;
               }

               this.wasInFarRange = false;
               this.defensivePos = null;
            } else {
               if (distanceToTarget > triggerDistance && distanceToTarget <= maxDistance) {
                  if (!this.isAccumulatingPackets) {
                     this.isAccumulatingPackets = true;
                     this.defensivePos = mc.field_1724.method_19538();
                     this.defensiveTimer.reset();
                  }

                  this.wasInFarRange = true;
               } else if (distanceToTarget <= triggerDistance && this.wasInFarRange) {
                  this.sendBufferedPackets();
                  this.isAccumulatingPackets = false;
                  this.wasInFarRange = false;
                  this.defensivePos = null;
               } else if (distanceToTarget <= triggerDistance) {
                  this.isAccumulatingPackets = false;
                  this.wasInFarRange = false;
                  this.defensivePos = null;
               }

               if (this.isAccumulatingPackets && this.defensiveTimer.hasTimeElapsed(1500L)) {
                  this.sendBufferedPackets();
                  this.isAccumulatingPackets = true;
                  this.defensiveTimer.reset();
               }

            }
         } else {
            if (this.isAccumulatingPackets) {
               this.sendBufferedPackets();
               this.isAccumulatingPackets = false;
            }

            this.wasInFarRange = false;
            this.defensivePos = null;
         }
      }
   }

   private void sendBufferedPackets() {
      if (!this.packetBuffer.isEmpty()) {
         for(class_2596<?> packet : this.packetBuffer) {
            NetworkUtils.sendSilentPacket(packet);
         }

         this.packetBuffer.clear();
      }
   }

   public void onTargetAttack(class_1309 attacker) {
      if (attacker != null && attacker.equals(this.lastTarget)) {
         this.targetLastAttackTime = System.currentTimeMillis();
         if (this.fakelags.get()) {
            this.sendBufferedPackets();
            this.isAccumulatingPackets = false;
            this.wasInFarRange = false;
            this.defensivePos = null;
         }
      }

   }

   public void onDisable() {
      this.sendBufferedPackets();
      this.isAccumulatingPackets = false;
      this.wasInFarRange = false;
      this.currentTarget = null;
      this.defensivePos = null;
   }

   private boolean shouldLeave() {
      boolean lowHP = mc.field_1724.method_6032() <= 4.0F && this.leaveList.get("Mało zdrowia");
      boolean usingItem = mc.field_1724.method_6115() && !mc.field_1724.method_6030().method_31574(class_1802.field_8255) && this.leaveList.get("Podczas używania przedmiotu");
      return this.leaveHP.get() && (lowHP || usingItem);
   }

   public void nextPhase(class_1309 target) {
      this.lastTarget = target;
      this.lastHitTime = System.currentTimeMillis();
      this.rotationPhase = 1;
      if (this.fakelags.get()) {
         this.sendBufferedPackets();
         this.isAccumulatingPackets = false;
         this.wasInFarRange = false;
         this.defensivePos = null;
      }

      boolean isFlying = mc.field_1724 != null && mc.field_1724.method_6128();
      List<class_243> newDirections = new ArrayList();

      for(String name : this.preferDir.getAvailableModes()) {
         if (this.preferDir.get(name) && (!name.equals("Dół") || isFlying)) {
            class_243 dir = (class_243)this.namedDirections.get(name);
            if (dir != null) {
               newDirections.add(dir);
            }
         }
      }

      if (newDirections.isEmpty()) {
         for(Map.Entry<String, class_243> entry : this.namedDirections.entrySet()) {
            if (!((String)entry.getKey()).equals("Dół") || isFlying) {
               newDirections.add((class_243)entry.getValue());
            }
         }
      }

      int oldIndexInNew = -1;
      class_243 oldDir = null;
      if (!this.airDirections.isEmpty() && this.directionIndex >= 0 && this.directionIndex < this.airDirections.size()) {
         oldDir = (class_243)this.airDirections.get(this.directionIndex);
      }

      if (oldDir != null) {
         for(int i = 0; i < newDirections.size(); ++i) {
            class_243 v = (class_243)newDirections.get(i);
            if (Double.compare(v.field_1352, oldDir.field_1352) == 0 && Double.compare(v.field_1351, oldDir.field_1351) == 0 && Double.compare(v.field_1350, oldDir.field_1350) == 0) {
               oldIndexInNew = i;
               break;
            }
         }
      }

      int size = newDirections.size();
      int candidateIndex = oldIndexInNew == -1 ? 0 : (oldIndexInNew + 1) % size;
      int attempts = 0;
      int chosenIndex = candidateIndex;

      while(attempts < size) {
         class_243 dir = (class_243)newDirections.get(candidateIndex);
         if (this.resolver.get() && dir.field_1351 < (double)0.0F && !mc.field_1724.method_6128()) {
            candidateIndex = (candidateIndex + 1) % size;
            ++attempts;
         } else {
            class_243 candidatePos = target.method_19538().method_1019(dir.method_1029().method_1021((double)this.sila.get().floatValue()));
            class_243 tryBetter = this.findClosestValidPosAround(candidatePos, (double)4.5F);
            class_243 checkPos = tryBetter != null ? tryBetter : new class_243(candidatePos.field_1352, Math.max(candidatePos.field_1351, mc.field_1724.method_23318() + (double)6.0F), candidatePos.field_1350);
            if ((!this.avoidWalls.get() || !this.isObstructed(mc.field_1724.method_33571(), checkPos)) && this.isValidFlyPosition(checkPos)) {
               chosenIndex = candidateIndex;
               break;
            }

            candidateIndex = (candidateIndex + 1) % size;
            ++attempts;
         }
      }

      this.airDirections = newDirections;
      this.directionIndex = chosenIndex;
   }

   public void overtakingElytra(class_1309 base, boolean attack) {
      boolean leave = this.shouldLeave();
      boolean inEvasion = this.rotationPhase != 0 || leave;
      class_243 targetPos = base.method_19538().method_1031((double)0.0F, (double)base.method_17682() / (double)2.0F, (double)0.0F);
      class_243 modifiedPos;
      if (inEvasion) {
         class_243 dir = (class_243)this.airDirections.get(this.directionIndex);
         double strength = (double)this.sila.get().floatValue();
         class_243 candidatePos = targetPos.method_1019(dir.method_1029().method_1021(strength));
         class_243 tryBetter = this.findClosestValidPosAround(candidatePos, (double)10.0F);
         if (tryBetter != null) {
            this.trueFireWork = true;
            candidatePos = tryBetter;
         } else {
            candidatePos = new class_243(candidatePos.field_1352, Math.max(candidatePos.field_1351, mc.field_1724.method_23318() + (double)2.0F), candidatePos.field_1350);
         }

         modifiedPos = candidatePos;
         if (mc.field_1724.method_19538().method_1022(candidatePos) < (double)1.0F) {
            this.rotationPhase = 0;
         }
      } else {
         double bps;
         try {
            bps = Double.parseDouble(ClientManager.getBps(base));
         } catch (Exception var15) {
            bps = (double)0.0F;
         }

         boolean canPredict = this.perelet.get() && bps >= (double)20.0F && !mc.field_1724.method_5799() && !mc.field_1724.method_5869();
         if (canPredict) {
            class_243 motion = new class_243(base.method_23317() - base.field_6014, base.method_23318() - base.field_6036, base.method_23321() - base.field_5969);
            double predictFactor = (double)class_3532.method_15363(this.predict.get().floatValue(), 0.2F, 2.5F);
            class_243 predicted = motion.method_1021(predictFactor * (double)1.5F);
            if (predicted.method_1027() < 1.0E-4) {
               predicted = base.method_5663().method_1029().method_1021(predictFactor);
            }

            modifiedPos = base.method_19538().method_1019(predicted).method_1031((double)0.0F, (double)base.method_17682() / (double)2.0F, (double)0.0F);
         } else {
            modifiedPos = base.method_19538().method_1031((double)0.0F, (double)base.method_17682() / (double)2.0F, (double)0.0F);
         }
      }

      double dx = modifiedPos.field_1352 - mc.field_1724.method_23317();
      double dy = modifiedPos.field_1351 - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
      double dz = modifiedPos.field_1350 - mc.field_1724.method_23321();
      this.x = (int)modifiedPos.field_1352;
      this.y = (int)modifiedPos.field_1351;
      this.z = (int)modifiedPos.field_1350;
      float targetYaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      float targetPitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz))));
      Manager.ROTATION.setSmooth(targetYaw, targetPitch, 1.15F, 140.0F, 40.0F, true);
   }

   public void targetDefault(class_1309 base, boolean attack) {
      class_243 targetPos = base.method_19538();

      double bps;
      try {
         bps = Double.parseDouble(ClientManager.getBps(base));
      } catch (Exception var15) {
         bps = (double)0.0F;
      }

      boolean canPredict = this.perelet.get() && bps >= (double)20.0F && !mc.field_1724.method_5799() && !mc.field_1724.method_5869();
      if (canPredict) {
         class_243 motion = new class_243(base.method_23317() - base.field_6014, base.method_23318() - base.field_6036, base.method_23321() - base.field_5969);
         double predictFactor = (double)class_3532.method_15363(this.predict.get().floatValue(), 0.2F, 2.5F);
         class_243 predicted = motion.method_1021(predictFactor * (double)1.5F);
         if (predicted.method_1027() < 1.0E-4) {
            predicted = base.method_5663().method_1029().method_1021(predictFactor);
         }

         targetPos = targetPos.method_1019(predicted);
      }

      double diffX = targetPos.field_1352 - mc.field_1724.method_23317();
      double diffY = targetPos.field_1351 - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
      double diffZ = targetPos.field_1350 - mc.field_1724.method_23321();
      this.x = (int)targetPos.field_1352;
      this.y = (int)targetPos.field_1351;
      this.z = (int)targetPos.field_1350;
      float yaw = (float)(Math.toDegrees(Math.atan2(diffZ, diffX)) - (double)90.0F);
      float pitch = (float)(-Math.toDegrees(Math.atan2(diffY, Math.hypot(diffX, diffZ))));
      Manager.ROTATION.setSmooth(yaw, pitch, 1.15F, 140.0F, 40.0F, true);
   }

   private class_243 findClosestValidPosAround(class_243 center, double radius) {
      List<class_243> offsets = new ArrayList();

      for(int y = 2; y >= -1; --y) {
         for(int dx = -1; dx <= 1; ++dx) {
            for(int dz = -1; dz <= 1; ++dz) {
               if (dx != 0 || dz != 0 || y != 0) {
                  offsets.add(new class_243((double)dx, (double)y, (double)dz));
               }
            }
         }
      }

      class_243 best = null;
      double bestDist = Double.MAX_VALUE;

      for(class_243 offset : offsets) {
         if (this.isValidFlyPosition(center) && !this.isObstructed(mc.field_1724.method_33571(), center)) {
            double dist = center.method_1025(center);
            if (dist < bestDist) {
               best = center;
               bestDist = dist;
            }
         }
      }

      return best;
   }

   private boolean isObstructed(class_243 from, class_243 to) {
      return mc.field_1687.method_17742(new class_3959(from, to, class_3960.field_17558, class_242.field_1348, mc.field_1724)).method_17783() != class_240.field_1333;
   }

   private boolean isValidFlyPosition(class_243 pos) {
      class_243 head = new class_243(pos.field_1352, pos.field_1351 + (double)mc.field_1724.method_17682(), pos.field_1350);
      class_243 feet = new class_243(pos.field_1352, pos.field_1351, pos.field_1350);
      boolean obstructedVertically = mc.field_1687.method_17742(new class_3959(head, feet, class_3960.field_17558, class_242.field_1348, mc.field_1724)).method_17783() != class_240.field_1333;
      int blockX = (int)Math.floor(pos.field_1352);
      int blockY = (int)Math.floor(pos.field_1351);
      int blockZ = (int)Math.floor(pos.field_1350);
      boolean isBlockSolid = mc.field_1687.method_8320(new class_2338(blockX, blockY, blockZ)).method_26216();
      int groundY = mc.field_1687.method_8598(class_2903.field_13197, new class_2338(blockX, 0, blockZ)).method_10264();
      boolean belowGround = pos.field_1351 < (double)groundY + (double)1.0F;
      return !obstructedVertically && !isBlockSolid && !belowGround;
   }

   public boolean isDefensiveActive() {
      return this.defensiveActive;
   }

   public boolean isLastDefensive() {
      return this.lastDefensive;
   }
}
