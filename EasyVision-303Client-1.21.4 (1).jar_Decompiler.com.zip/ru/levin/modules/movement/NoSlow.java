package ru.levin.modules.movement;

import net.minecraft.class_1268;
import net.minecraft.class_2886;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventNoSlow;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "NoSlow",
   desc = "Zapobiega spowolnieniu podczas używania przedmiotów",
   type = Type.Move
)
public class NoSlow extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Grim", new String[]{"Grim", "ReallyWorld", "LonyGrief"});
   private int ticks;

   public NoSlow() {
      this.addSettings(new Setting[]{this.mode});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.mode.is("ReallyWorld") && !mc.field_1724.method_6128()) {
         if (mc.field_1724.method_6115()) {
            ++this.ticks;
         } else {
            this.ticks = 0;
         }
      }

      if (event instanceof EventNoSlow eventNoSlow) {
         if (this.mode.is("Grim")) {
            eventNoSlow.setCancel(true);
         } else if (this.mode.is("ReallyWorld")) {
            if (this.ticks == 1 || this.ticks == 2) {
               eventNoSlow.setCancel(true);
            }

            if (this.ticks >= 2) {
               this.ticks = 0;
            }

            if (this.ticks == 0) {
               eventNoSlow.setCancel(false);
            }
         }

         if (this.mode.is("LonyGrief")) {
            class_1268 active = mc.field_1724.method_6058();
            if (active != null) {
               class_1268 opposite = active == class_1268.field_5808 ? class_1268.field_5810 : class_1268.field_5808;
               mc.field_1724.field_3944.method_52787(new class_2886(opposite, 0, mc.field_1724.method_36454(), mc.field_1724.method_36455()));
               eventNoSlow.setCancel(true);
            }
         }
      }

   }
}
