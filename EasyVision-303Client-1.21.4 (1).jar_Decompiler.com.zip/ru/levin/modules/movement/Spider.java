package ru.levin.modules.movement;

import net.minecraft.class_1268;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2868;
import net.minecraft.class_2886;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "Spider",
   desc = "Automatycznie stawia wodę i wspina się po skoku",
   type = Type.Move
)
public class Spider extends Function {
   public final ModeSetting mode = new ModeSetting("Typ", "RwWater", new String[]{"RwWater", "Matrix"});
   private final TimerUtil timerUtil = new TimerUtil();
   private boolean climbing = false;
   private boolean switched = false;
   private int waterSlot = -1;
   private int originalSlot = -1;
   private int movedFromInvSlot = -1;

   public Spider() {
      this.addSettings(new Setting[]{this.mode});
   }

   public void onEvent(Event event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (event instanceof EventPacket) {
            EventPacket eventPacket = (EventPacket)event;
            class_2596 var4 = eventPacket.getPacket();
            if (var4 instanceof class_7439) {
               class_7439 packet = (class_7439)var4;
               String message = packet.comp_763().getString();
               if (message.contains("Nie możesz tutaj postawić bloku.")) {
                  eventPacket.setCancel(true);
               }
            }
         }

         if (event instanceof EventUpdate) {
            if (this.mode.is("RwWater")) {
               this.handleRwWater();
            } else if (this.mode.is("Matrix")) {
               this.handleMatrix();
            }
         }

         if (event instanceof EventMotion && this.climbing && this.mode.is("RwWater")) {
            class_243 eyePos = mc.field_1724.method_5836(1.0F);
            class_243 lookVec = mc.field_1724.method_5828(1.0F).method_1029();
            class_243 targetVec = eyePos.method_1019(lookVec);
            class_2338 targetBlock = new class_2338((int)targetVec.field_1352, (int)targetVec.field_1351 - 1, (int)targetVec.field_1350);
            float neededYaw = this.getNeededYaw(targetBlock.method_46558());
            float neededPitch = this.getNeededPitch(targetBlock.method_46558());
            mc.field_1724.method_36457(neededPitch);
            mc.field_1724.method_36456(neededYaw);
         }

      }
   }

   private void handleRwWater() {
      if (mc.field_1690.field_1903.method_1434() && mc.field_1724.field_5976 && !mc.field_1724.method_24828() && !this.climbing) {
         this.climbing = true;
         this.switched = false;
         this.originalSlot = mc.field_1724.method_31548().field_7545;
         this.waterSlot = this.ensureWaterBucketInHotbar();
      }

      if (this.climbing) {
         if (this.waterSlot == -1) {
            this.stopClimbing();
            return;
         }

         if (!mc.field_1724.field_5976 || mc.field_1724.method_24828()) {
            this.stopClimbing();
            return;
         }

         class_243 eyePos = mc.field_1724.method_5836(1.0F);
         class_243 lookVec = mc.field_1724.method_5828(1.0F).method_1029();
         class_243 targetVec = eyePos.method_1019(lookVec);
         class_2338 targetBlock = new class_2338((int)targetVec.field_1352, (int)targetVec.field_1351 - 1, (int)targetVec.field_1350);
         float neededYaw = this.getNeededYaw(targetBlock.method_46558());
         float neededPitch = this.getNeededPitch(targetBlock.method_46558());
         if (!this.switched) {
            mc.field_1724.field_3944.method_52787(new class_2868(this.waterSlot));
            this.switched = true;
         }

         if (this.timerUtil.hasTimeElapsed(20L, true)) {
            mc.field_1724.field_3944.method_52787(new class_2886(class_1268.field_5808, 0, neededYaw, neededPitch));
         }

         mc.field_1724.field_6017 = 0.0F;
         mc.field_1724.method_18800((double)0.0F, 0.3, (double)0.0F);
      }

   }

   private void handleMatrix() {
      if (mc.field_1690.field_1903.method_1434() && mc.field_1724.field_5976) {
         mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, 0.42, mc.field_1724.method_18798().field_1350);
         mc.field_1724.field_6017 = 0.0F;
      }

   }

   public void onDisable() {
      super.onDisable();
      this.stopClimbing();
      if (mc.field_1724 != null) {
         mc.field_1724.method_18800((double)0.0F, (double)0.0F, (double)0.0F);
      }

      this.timerUtil.reset();
   }

   private void stopClimbing() {
      if (this.climbing) {
         this.climbing = false;
         this.switched = false;
         if (this.originalSlot != -1 && mc.field_1724 != null) {
            mc.field_1724.field_3944.method_52787(new class_2868(this.originalSlot));
            this.originalSlot = -1;
         }

         if (this.waterSlot != -1 && this.movedFromInvSlot != -1 && mc.field_1724 != null) {
            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, this.waterSlot, this.movedFromInvSlot, class_1713.field_7791, mc.field_1724);
         }

         this.waterSlot = -1;
         this.movedFromInvSlot = -1;
      }
   }

   private int ensureWaterBucketInHotbar() {
      for(int i = 0; i < 9; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8705) {
            this.movedFromInvSlot = -1;
            return i;
         }
      }

      for(int i = 9; i < 36; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == class_1802.field_8705) {
            int freeHotbar = this.findFreeHotbarSlot();
            if (freeHotbar == -1) {
               freeHotbar = 0;
            }

            mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, i, freeHotbar, class_1713.field_7791, mc.field_1724);
            this.movedFromInvSlot = i;
            return freeHotbar;
         }
      }

      return -1;
   }

   private int findFreeHotbarSlot() {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_7960()) {
            return i;
         }
      }

      return -1;
   }

   private float getNeededYaw(class_243 target) {
      double dx = target.field_1352 - mc.field_1724.method_23317();
      double dz = target.field_1350 - mc.field_1724.method_23321();
      return (float)(Math.toDegrees(Math.atan2(dz, dx)) - (double)90.0F);
   }

   private float getNeededPitch(class_243 target) {
      double dx = target.field_1352 - mc.field_1724.method_23317();
      double dy = target.field_1351 - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
      double dz = target.field_1350 - mc.field_1724.method_23321();
      double dist = Math.sqrt(dx * dx + dz * dz);
      return (float)(-Math.toDegrees(Math.atan2(dy, dist)));
   }
}
