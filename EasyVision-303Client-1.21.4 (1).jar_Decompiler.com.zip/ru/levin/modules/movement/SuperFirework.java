package ru.levin.modules.movement;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "SuperFirework",
   desc = "Zwiększa przyspieszenie z fajerwerków",
   type = Type.Move
)
public class SuperFirework extends Function {
   public ModeSetting mode = new ModeSetting("Moduł", "BravoHvH", new String[]{"BravoHvH", "ReallyWorld", "PulseHVH", "Custom"});
   public final SliderSetting speed = new SliderSetting("Prędkość", (double)1.7F, (double)1.5F, (double)8.0F, (double)0.01F, () -> this.mode.is("Custom"));
   public final BooleanSetting nearBoost = new BooleanSetting("Przyspieszenie, gdy gracz jest w pobliżu", false, "Może zostać wykryty przez nowsze wersje GrimAC");
   public float speedXZ = 1.5F;
   public float speedY = 1.5F;
   public float diag1 = 5.0F;
   public float diag2 = 5.0F;
   public float diag3 = 5.0F;
   public float diag4 = 5.0F;
   public float diag5 = 5.0F;
   public float diag6 = 5.0F;
   public float diag7 = 5.0F;
   public float diag8 = 5.0F;
   public float diag9 = 5.0F;
   public float diag10 = 5.0F;
   public float speedD_1 = 1.5F;
   public float speedD_2 = 1.5F;
   public float speedD_3 = 1.5F;
   public float speedD_4 = 1.5F;
   public float speedD_5 = 1.5F;
   public float speedD_6 = 1.5F;
   public float speedD_7 = 1.5F;
   public float speedD_8 = 1.5F;
   public float speedD_9 = 1.5F;
   public float speedPitch = 1.5F;
   public float speedPitchY = 1.5F;
   public float speedNXZ = 1.5F;
   public float speedNY = 1.5F;

   public SuperFirework() {
      this.addSettings(new Setting[]{this.mode, this.speed, this.nearBoost});
   }

   public void onEvent(Event event) {
      this.speedXZ = 1.61F;
      this.speedY = 1.61F;
      this.diag1 = 4.0F;
      this.diag2 = 8.0F;
      this.diag3 = 12.0F;
      this.diag4 = 16.0F;
      this.diag5 = 20.0F;
      this.diag6 = 24.0F;
      this.diag7 = 28.0F;
      this.diag8 = 32.0F;
      this.diag9 = 36.0F;
      this.diag10 = 40.0F;
      this.speedPitch = 2.5F;
      this.speedPitchY = 2.5F;
      this.speedD_1 = 2.2F;
      this.speedD_2 = 2.06F;
      this.speedD_3 = 1.98F;
      this.speedD_4 = 1.87F;
      this.speedD_5 = 1.8F;
      this.speedD_6 = 1.74F;
      this.speedD_7 = 1.7F;
      this.speedD_8 = 1.65F;
      this.speedD_9 = 1.63F;
      this.speedNXZ = 1.66F;
      this.speedNY = 1.66F;
   }
}
