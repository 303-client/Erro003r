package ru.levin.modules.movement;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ElytraMotion",
   desc = "Zatrzymuje gracza podczas lotu na elytrze, gdy cel jest namierzony",
   type = Type.Move
)
public class ElytraMotion extends Function {
   private final SliderSetting distance = new SliderSetting("Zasięg działania", (double)3.0F, (double)0.1F, (double)5.0F, (double)0.1F);
   private boolean shouldFreeze;
   private class_243 freezePosition;

   public ElytraMotion() {
      this.freezePosition = class_243.field_1353;
      this.addSettings(new Setting[]{this.distance});
   }

   public void onEvent(Event event) {
      if (mc.field_1724 != null) {
         if (event instanceof EventUpdate) {
            if (mc.field_1724.method_6128()) {
               this.freezePosition = mc.field_1724.method_19538();
            }

            this.shouldFreeze = this.shouldFreeze();
         }

         if (event instanceof EventMotion) {
            EventMotion motion = (EventMotion)event;
            if (this.shouldFreeze) {
               mc.field_1724.method_33574(this.freezePosition);
               mc.field_1724.method_18799(class_243.field_1353);
               motion.setX((double)0.0F);
               motion.setY((double)0.0F);
               motion.setZ((double)0.0F);
            }
         }

      }
   }

   private boolean shouldFreeze() {
      if (!mc.field_1724.method_6128()) {
         return false;
      } else {
         AttackAura aura = Manager.FUNCTION_MANAGER.attackAura;
         if (aura == null) {
            return false;
         } else {
            class_1309 target = aura.target;
            if (target == null) {
               return false;
            } else {
               return target.method_5739(mc.field_1724) < this.distance.get().floatValue();
            }
         }
      }
   }

   public void onDisable() {
      this.shouldFreeze = false;
      super.onDisable();
   }
}
