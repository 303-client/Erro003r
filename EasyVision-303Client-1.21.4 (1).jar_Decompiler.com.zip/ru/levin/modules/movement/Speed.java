package ru.levin.modules.movement;

import ru.levin.events.Event;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.combat.TargetStrafe;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.MoveUtil;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "Speed",
   desc = "Przyspiesza śmierć",
   type = Type.Move
)
public class Speed extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Vanilla", new String[]{"Vanilla"});
   private final SliderSetting speed = new SliderSetting("Prędkość", (double)1.0F, (double)0.1F, (double)3.0F, (double)0.1F);
   private final TimerUtil timerUtil = new TimerUtil();

   public Speed() {
      this.addSettings(new Setting[]{this.mode, this.speed});
   }

   public void onEvent(Event event) {
      if (event instanceof EventMotion eventMotion) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         switch (this.mode.get()) {
            case "Vanilla" -> this.vanilla();
         }
      }

   }

   private void vanilla() {
      if (MoveUtil.isMoving() && !mc.field_1724.method_6128()) {
         MoveUtil.setSpeed(this.speed.get().floatValue());
      }

   }

   protected void onEnable() {
      TargetStrafe targetStrafe = Manager.FUNCTION_MANAGER.targetStrafe;
      if (targetStrafe.state) {
         targetStrafe.setState(false);
      }

      this.timerUtil.reset();
      super.onEnable();
   }

   public void onDisable() {
      ClientManager.TICK_TIMER = 1.0F;
      super.onDisable();
   }
}
