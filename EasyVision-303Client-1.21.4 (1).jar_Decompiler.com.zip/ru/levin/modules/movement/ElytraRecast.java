package ru.levin.modules.movement;

import net.minecraft.class_1294;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.mixin.iface.MixinLivingEntityAccessor;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.player.InventoryUtil;

@FunctionAnnotation(
   name = "ElytraRecast",
   desc = "Automatycznie ponownie zakłada elytrę",
   type = Type.Move
)
public class ElytraRecast extends Function {
   public BooleanSetting changePitch = new BooleanSetting("ChangePitch", true);
   public SliderSetting pitchValue = new SliderSetting("PitchValue", (double)55.0F, (double)-90.0F, (double)90.0F, (double)1.0F, () -> this.changePitch.get());
   public BooleanSetting autoJump = new BooleanSetting("AutoJump", true);

   public ElytraRecast() {
      this.addSettings(new Setting[]{this.changePitch, this.pitchValue, this.autoJump});
   }

   public void onEvent(Event event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (event instanceof EventMotion) {
            EventMotion em = (EventMotion)event;
            if (this.changePitch.get() && !mc.field_1724.method_6128() && this.checkElytra()) {
               em.setPitch(this.pitchValue.get().floatValue());
            }
         }

         if (event instanceof EventUpdate) {
            this.onUpdate();
         }

      }
   }

   protected void onDisable() {
      if (!mc.field_1690.field_1894.method_1434()) {
         mc.field_1690.field_1894.method_23481(false);
      }

      if (!mc.field_1690.field_1903.method_1434()) {
         mc.field_1690.field_1903.method_23481(false);
      }

   }

   private void onUpdate() {
      if (!mc.field_1724.method_6128() && this.checkElytra() && this.autoJump.get() && mc.field_1724.method_24828()) {
         mc.field_1724.method_6043();
      }

      if (!mc.field_1724.method_6128() && mc.field_1724.field_6017 > 0.0F && this.checkElytra()) {
         this.castElytra();
      }

      ((MixinLivingEntityAccessor)mc.field_1724).setLastJumpCooldown(0);
   }

   public boolean castElytra() {
      if (this.checkElytra() && this.check()) {
         InventoryUtil.startFly();
         return true;
      } else {
         return false;
      }
   }

   private boolean checkElytra() {
      class_1799 chestStack = mc.field_1724.method_6118(class_1304.field_6174);
      return chestStack.method_7909() == class_1802.field_8833 && isUsable(chestStack) && !mc.field_1724.method_31549().field_7479 && mc.field_1724.method_5854() == null && !mc.field_1724.method_6101();
   }

   public static boolean isUsable(class_1799 stack) {
      if (stack == null) {
         return false;
      } else if (stack.method_7960()) {
         return false;
      } else if (stack.method_7909() != class_1802.field_8833) {
         return false;
      } else {
         int maxDamage = stack.method_7936();
         int damage = stack.method_7919();
         return damage < maxDamage - 1;
      }
   }

   private boolean check() {
      return !mc.field_1724.method_7337() && !mc.field_1724.method_7325() && !mc.field_1724.method_6059(class_1294.field_5902);
   }
}
