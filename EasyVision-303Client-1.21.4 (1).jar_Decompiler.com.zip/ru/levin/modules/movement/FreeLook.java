package ru.levin.modules.movement;

import net.minecraft.class_5498;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventKey;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.movement.freelook.FreeLookState;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "FreeLook",
   desc = "Pozwala obracać kamerę bez zmiany kierunku ruchu",
   type = Type.Move
)
public class FreeLook extends Function {
   private final BindSetting bind = new BindSetting("Klawisz", 0);
   private class_5498 previousPerspective;

   public FreeLook() {
      this.addSettings(new Setting[]{this.bind});
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey keyEvent) {
         if (keyEvent.key == this.bind.getKey()) {
            if (mc != null && mc.field_1690 != null) {
               AttackAura attackAura = Manager.FUNCTION_MANAGER.attackAura;
               if (attackAura != null && attackAura.state && attackAura.target != null) {
                  ClientManager.message("Nie można używać razem z " + attackAura.name);
               } else {
                  FreeLookState.active = !FreeLookState.active;
                  if (FreeLookState.active) {
                     this.previousPerspective = mc.field_1690.method_31044();
                     if (this.previousPerspective != class_5498.field_26666) {
                        mc.field_1690.method_31043(class_5498.field_26666);
                     }
                  } else {
                     mc.field_1690.method_31043(this.previousPerspective != null ? this.previousPerspective : class_5498.field_26664);
                  }

               }
            }
         }
      }
   }

   public void onDisable() {
      FreeLookState.active = false;
      if (mc != null && mc.field_1690 != null) {
         mc.field_1690.method_31043(this.previousPerspective != null ? this.previousPerspective : class_5498.field_26664);
      }

      this.previousPerspective = null;
   }
}
