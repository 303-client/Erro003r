package ru.levin.modules.movement;

import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "AutoSprint",
   desc = "Automatycznie włącza sprint",
   type = Type.Move
)
public class AutoSprint extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         mc.field_1690.field_1867.method_23481(true);
      }

   }

   protected void onDisable() {
      mc.field_1690.field_1867.method_23481(false);
      super.onDisable();
   }
}
