package ru.levin.modules.movement;

import net.minecraft.class_243;
import ru.levin.events.Event;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "AirStuck",
   desc = "Pozwala zawisnąć w powietrzu",
   type = Type.Move
)
public class AirStuck extends Function {
   private BooleanSetting packet = new BooleanSetting("Blokuj ruch", true, "Blokuje wysyłanie pakietów ruchu na serwer");
   private class_243 freezePosition;

   public AirStuck() {
      this.freezePosition = class_243.field_1353;
      this.addSettings(new Setting[]{this.packet});
   }

   public void onEnable() {
      if (mc.field_1724 != null) {
         this.freezePosition = mc.field_1724.method_19538();
      }

   }

   public void onEvent(Event event) {
      if (event instanceof EventMotion eventMotion) {
         if (mc.field_1724 != null && this.freezePosition != class_243.field_1353) {
            if (this.packet.get()) {
               eventMotion.setCancel(true);
            }

            mc.field_1724.method_33574(this.freezePosition);
            mc.field_1724.method_18799(class_243.field_1353);
         }
      }

   }
}
