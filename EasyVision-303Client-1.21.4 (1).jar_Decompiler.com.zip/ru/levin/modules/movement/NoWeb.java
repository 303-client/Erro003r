package ru.levin.modules.movement;

import net.minecraft.class_243;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.MoveUtil;

@FunctionAnnotation(
   name = "NoWeb",
   type = Type.Move
)
public class NoWeb extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Custom", new String[]{"Custom", "ReallyWorld"});
   private final SliderSetting speedXZ = new SliderSetting("Prędkość w osiach X i Z", (double)0.1F, (double)0.1F, (double)1.0F, (double)0.1F, () -> this.mode.is("Custom"));
   private final SliderSetting speedY = new SliderSetting("Prędkość w osi Y", (double)0.1F, (double)0.1F, (double)4.0F, (double)0.1F, () -> this.mode.is("Custom"));

   public NoWeb() {
      this.addSettings(new Setting[]{this.mode, this.speedXZ, this.speedY});
   }

   public void onEvent(Event event) {
      if (this.mode.getIndex() == 0) {
         this.custom();
      }

      if (this.mode.getIndex() == 1) {
         this.reallyWorld();
      }

   }

   private void custom() {
      if (MoveUtil.isInWeb()) {
         class_243 velocity = mc.field_1724.method_18798();
         mc.field_1724.method_18800(velocity.field_1352, (double)0.0F, velocity.field_1350);
         if (mc.field_1690.field_1903.method_1434()) {
            mc.field_1724.method_18800(velocity.field_1352, (double)this.speedY.get().floatValue(), velocity.field_1350);
         }

         if (mc.field_1690.field_1832.method_1434()) {
            mc.field_1724.method_18800(velocity.field_1352, (double)(-this.speedY.get().floatValue()), velocity.field_1350);
         }

         MoveUtil.setSpeed(this.speedXZ.get().floatValue());
      }

   }

   private void reallyWorld() {
      if (MoveUtil.isInWeb()) {
         class_243 velocity = mc.field_1724.method_18798();
         mc.field_1724.method_18800(velocity.field_1352, (double)0.0F, velocity.field_1350);
         if (mc.field_1690.field_1903.method_1434()) {
            mc.field_1724.method_18800(velocity.field_1352, 0.9, velocity.field_1350);
         }

         if (mc.field_1690.field_1832.method_1434()) {
            mc.field_1724.method_18800(velocity.field_1352, -0.9, velocity.field_1350);
         }

         MoveUtil.setSpeed(0.21F);
      }

   }
}
