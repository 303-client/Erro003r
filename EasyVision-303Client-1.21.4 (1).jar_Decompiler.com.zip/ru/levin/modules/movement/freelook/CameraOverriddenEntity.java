package ru.levin.modules.movement.freelook;

public interface CameraOverriddenEntity {
   float getCameraPitch();

   float getCameraYaw();

   void setCameraPitch(float var1);

   void setCameraYaw(float var1);
}
