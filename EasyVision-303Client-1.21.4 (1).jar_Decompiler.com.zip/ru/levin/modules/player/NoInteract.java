package ru.levin.modules.player;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "NoInteract",
   desc = "Uniemożliwia otwieranie pojemników prawym przyciskiem myszy",
   type = Type.Player
)
public class NoInteract extends Function {
   public final BooleanSetting onlyAura = new BooleanSetting("Tylko z modułem AttackAura", false);

   public NoInteract() {
      this.addSettings(new Setting[]{this.onlyAura});
   }

   public void onEvent(Event event) {
   }
}
