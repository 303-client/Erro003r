package ru.levin.modules.player;

import net.minecraft.class_1802;
import net.minecraft.class_2828;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventKey;
import ru.levin.events.impl.input.EventMouse;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.InventoryUtil;

@FunctionAnnotation(
   name = "MiddleClickPearl",
   keywords = {"MCP"},
   desc = "Rzucanie perłą Endu rolką myszy",
   type = Type.Player
)
public class MiddleClickPearl extends Function {
   private final ModeSetting mode = new ModeSetting("Typ", "Zwykły", new String[]{"Zwykły", "Po naciśnięciu klawisza"});
   private final BindSetting bind = new BindSetting("Klawisz rzucania", 0, () -> this.mode.is("Po naciśnięciu klawisza"));
   private final BooleanSetting inventoryUse = new BooleanSetting("Używaj z ekwipunku", true, "Nie używaj na HollyWorld (grozi banem)");

   public MiddleClickPearl() {
      this.addSettings(new Setting[]{this.mode, this.bind, this.inventoryUse});
   }

   public void onEvent(Event event) {
      if (this.mode.is("Zwykły") && event instanceof EventMouse mouseTick) {
         if (mouseTick.getButton() == 2) {
            this.handleMouseTickEvent();
         }
      }

      if (this.mode.is("Po naciśnięciu klawisza") && event instanceof EventKey e) {
         if (e.key == this.bind.getKey()) {
            this.handleMouseTickEvent();
         }
      }

   }

   private void handleMouseTickEvent() {
      if (!mc.field_1724.method_7357().method_7904(class_1802.field_8634.method_7854())) {
         if (Manager.FUNCTION_MANAGER.attackAura.target != null) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2831(mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
         }

         InventoryUtil.inventorySwapClick2(class_1802.field_8634, this.inventoryUse.get(), true);
      }

   }
}
