package ru.levin.modules.player;

import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_490;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.input.EventKey;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ArmorEquipper",
   desc = "Zaklada lepszy pancerz z ekwipunku",
   type = Type.Player
)
public class ArmorEquipper extends Function {
   private final BindSetting equipKey = new BindSetting("Przycisk zakładania", 0);
   private final SliderSetting delay = new SliderSetting("Opóźnienie", (double)1.0F, (double)0.0F, (double)20.0F, (double)1.0F);
   private final int[] armorSlots = new int[]{8, 7, 6, 5};
   private int pendingSlot = -1;
   private int step;
   private int waitTicks;
   private boolean running;
   private boolean openedInventory;

   public ArmorEquipper() {
      this.addSettings(new Setting[]{this.equipKey, this.delay});
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey key) {
         if (key.key == this.equipKey.getKey()) {
            this.requestEquip();
         }
      }

      if (event instanceof EventUpdate && this.running) {
         this.tickEquip();
      }

   }

   private void requestEquip() {
      if (!this.running && mc.field_1724 != null && mc.field_1761 != null && mc.field_1755 == null) {
         if (mc.field_1724.field_7512 == mc.field_1724.field_7498) {
            mc.method_1507(new class_490(mc.field_1724));
            this.openedInventory = true;
            this.running = true;
            this.pendingSlot = -1;
            this.step = 0;
            this.waitTicks = 2;
         }
      }
   }

   private void tickEquip() {
      if (mc.field_1724 != null && mc.field_1761 != null && mc.field_1755 instanceof class_490 && mc.field_1724.field_7512 == mc.field_1724.field_7498) {
         if (this.waitTicks > 0) {
            --this.waitTicks;
         } else {
            if (this.pendingSlot == -1) {
               this.pendingSlot = this.findNextArmorSlot();
               this.step = 0;
               if (this.pendingSlot == -1) {
                  this.finish();
                  return;
               }
            }

            int source = this.findBestArmor(this.pendingSlot);
            if (source == -1) {
               this.pendingSlot = -1;
            } else {
               int syncId = mc.field_1724.field_7512.field_7763;
               int armorSlot = this.armorSlots[this.pendingSlot];
               int sourceHandlerSlot = source < 9 ? source + 36 : source;
               if (this.step == 0) {
                  mc.field_1761.method_2906(syncId, sourceHandlerSlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
                  this.step = 1;
               } else if (this.step == 1) {
                  mc.field_1761.method_2906(syncId, armorSlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
                  this.step = 2;
               } else {
                  mc.field_1761.method_2906(syncId, sourceHandlerSlot, mc.field_1724.method_31548().field_7545, class_1713.field_7791, mc.field_1724);
                  this.pendingSlot = -1;
                  this.step = 0;
               }

               this.waitTicks = this.delay.get().intValue();
            }
         }
      } else {
         this.reset();
      }
   }

   private int findNextArmorSlot() {
      for(int armorIndex = 0; armorIndex < this.armorSlots.length; ++armorIndex) {
         if (this.findBestArmor(armorIndex) != -1) {
            return armorIndex;
         }
      }

      return -1;
   }

   private int findBestArmor(int armorIndex) {
      class_1799 equipped = mc.field_1724.field_7512.method_7611(this.armorSlots[armorIndex]).method_7677();
      int bestSlot = -1;
      int bestMaterial = this.material(equipped.method_7909());

      for(int slot = 0; slot < 36; ++slot) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
         if (this.armorIndex(stack.method_7909()) == armorIndex) {
            int score = this.material(stack.method_7909());
            if (score > bestMaterial) {
               bestMaterial = score;
               bestSlot = slot;
            }
         }
      }

      return bestSlot;
   }

   private int armorIndex(class_1792 item) {
      if (item != class_1802.field_22030 && item != class_1802.field_8285) {
         if (item != class_1802.field_22029 && item != class_1802.field_8348) {
            if (item != class_1802.field_22028 && item != class_1802.field_8058) {
               return item != class_1802.field_22027 && item != class_1802.field_8805 ? -1 : 3;
            } else {
               return 2;
            }
         } else {
            return 1;
         }
      } else {
         return 0;
      }
   }

   private int material(class_1792 item) {
      if (item != class_1802.field_22030 && item != class_1802.field_22029 && item != class_1802.field_22028 && item != class_1802.field_22027) {
         return item != class_1802.field_8285 && item != class_1802.field_8348 && item != class_1802.field_8058 && item != class_1802.field_8805 ? 0 : 1;
      } else {
         return 2;
      }
   }

   private void finish() {
      if (this.openedInventory && mc.field_1755 instanceof class_490) {
         mc.field_1724.method_7346();
      }

      this.reset();
   }

   private void reset() {
      this.pendingSlot = -1;
      this.step = 0;
      this.waitTicks = 0;
      this.running = false;
      this.openedInventory = false;
   }

   protected void onDisable() {
      if (mc.field_1724 != null && this.openedInventory && mc.field_1755 instanceof class_490) {
         mc.field_1724.method_7346();
      }

      this.reset();
   }
}
