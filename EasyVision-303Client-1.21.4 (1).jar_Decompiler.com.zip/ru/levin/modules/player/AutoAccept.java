package ru.levin.modules.player;

import java.util.concurrent.atomic.AtomicReference;
import net.minecraft.class_2596;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "AutoAccept",
   keywords = {"TpaAccept"},
   type = Type.Player,
   desc = ""
)
public class AutoAccept extends Function {
   private final BooleanSetting onlyFriend = new BooleanSetting("Tylko znajomi", true);

   public AutoAccept() {
      this.addSettings(new Setting[]{this.onlyFriend});
   }

   public void onEvent(Event event) {
      if (event instanceof EventPacket eventPacket) {
         class_2596 var4 = eventPacket.getPacket();
         if (var4 instanceof class_7439 packet) {
            String message = packet.comp_763().getString();
            if (message.contains("chce się do ciebie teleportować.") || message.contains("prosi o teleportację do ciebie")) {
               String sender = this.extractName(message);
               String realName = nameCheck(sender);
               if (!this.onlyFriend.get() || Manager.FRIEND_MANAGER.isFriend(realName)) {
                  mc.field_1724.field_3944.method_45731("tpaccept");
               }
            }
         }
      }

   }

   private String extractName(String message) {
      String clean = message.replaceAll("§.", "");
      int spaceIndex = clean.indexOf(32);
      return spaceIndex != -1 ? clean.substring(0, spaceIndex) : "UNKNOWN";
   }

   public static String nameCheck(String notSolved) {
      AtomicReference<String> result = new AtomicReference(notSolved);
      if (mc.method_1562() != null) {
         mc.method_1562().method_45732().forEach((player) -> {
            if (notSolved.equalsIgnoreCase(player.method_2966().getName())) {
               result.set(player.method_2966().getName());
            }

         });
      }

      return (String)result.get();
   }
}
