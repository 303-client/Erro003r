package ru.levin.modules.player;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1890;
import net.minecraft.class_1893;
import net.minecraft.class_2189;
import net.minecraft.class_2338;
import net.minecraft.class_3965;
import net.minecraft.class_6880;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "AutoTool",
   desc = "Wybiera najlepsze narzędzie do kopania",
   type = Type.Player
)
public class AutoTool extends Function {
   public static int itemIndex;
   private boolean swap;
   private long swapDelay;
   private final List<Integer> lastItem = new ArrayList();

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (mc.field_1765 instanceof class_3965) {
            class_3965 result = (class_3965)mc.field_1765;
            if (result != null) {
               class_2338 pos = result.method_17777();
               if (pos != null && !mc.field_1687.method_8320(pos).method_26215()) {
                  int toolSlot = getBest(pos);
                  if (toolSlot != -1 && mc.field_1690.field_1886.method_1434()) {
                     this.lastItem.add(mc.field_1724.method_31548().field_7545);
                     mc.field_1724.method_31548().field_7545 = toolSlot;
                     itemIndex = toolSlot;
                     this.swap = true;
                     this.swapDelay = System.currentTimeMillis();
                  } else if (this.swap && !this.lastItem.isEmpty() && System.currentTimeMillis() >= this.swapDelay + 200L) {
                     mc.field_1724.method_31548().field_7545 = (Integer)this.lastItem.get(0);
                     itemIndex = (Integer)this.lastItem.get(0);
                     this.lastItem.clear();
                     this.swap = false;
                  }

               }
            }
         }
      }
   }

   public static int getBest(class_2338 pos) {
      if (pos == null) {
         return -1;
      } else {
         int index = -1;
         float currentFastest = 1.0F;

         for(int i = 0; i < 9; ++i) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack != class_1799.field_8037 && stack.method_7936() - stack.method_7919() > 10) {
               float digSpeed = (float)class_1890.method_8225((class_6880)mc.field_1687.method_30349().method_30530(class_1893.field_9131.method_58273()).method_10223(class_1893.field_9131.method_29177()).get(), stack);
               float destroySpeed = stack.method_7924(mc.field_1687.method_8320(pos));
               if (!(mc.field_1687.method_8320(pos).method_26204() instanceof class_2189) && digSpeed + destroySpeed > currentFastest) {
                  currentFastest = digSpeed + destroySpeed;
                  index = i;
               }
            }
         }

         return index;
      }
   }
}
