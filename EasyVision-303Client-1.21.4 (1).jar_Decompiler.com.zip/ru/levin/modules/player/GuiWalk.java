package ru.levin.modules.player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;
import net.minecraft.class_2813;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import net.minecraft.class_408;
import net.minecraft.class_490;
import net.minecraft.class_498;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "GuiWalk",
   keywords = {"InventoryMove", "GuiMove"},
   type = Type.Player
)
public class GuiWalk extends Function {
   public final ModeSetting bypass = new ModeSetting("Typ", "Zwykły", new String[]{"Zwykły", "FunTime"});
   private final Queue<class_2813> packetQueue = new ConcurrentLinkedQueue();
   private boolean wasInventoryOpen = false;
   private final TimerUtil timer = new TimerUtil();

   public GuiWalk() {
      this.addSettings(new Setting[]{this.bypass});
   }

   public void onEvent(Event event) {
      List<class_304> keyBindings = new ArrayList(Arrays.asList(mc.field_1690.field_1894, mc.field_1690.field_1881, mc.field_1690.field_1913, mc.field_1690.field_1849, mc.field_1690.field_1903));
      if (!(mc.field_1755 instanceof class_408) && !(mc.field_1755 instanceof class_498)) {
         if (this.bypass.is("FunTime") && !this.packetQueue.isEmpty() && !this.timer.hasTimeElapsed(100L)) {
            for(class_304 keyBinding : keyBindings) {
               keyBinding.method_23481(false);
            }

         } else {
            keyBindings.forEach(this::updateKeyBinding);
            boolean isInventoryOpen = mc.field_1755 instanceof class_490;
            if (this.bypass.is("FunTime")) {
               if (isInventoryOpen) {
                  this.wasInventoryOpen = true;
               } else if (this.wasInventoryOpen) {
                  this.sendQueuedPackets();
                  this.wasInventoryOpen = false;
                  this.timer.reset();
               }
            } else {
               this.packetQueue.clear();
            }

         }
      } else {
         for(class_304 keyBinding : keyBindings) {
            keyBinding.method_23481(false);
         }

      }
   }

   private void updateKeyBinding(class_304 keyBinding) {
      long handle = mc.method_22683().method_4490();
      int code = keyBinding.method_1429().method_1444();
      keyBinding.method_23481(class_3675.method_15987(handle, code));
   }

   public void queuePacket(class_2813 packet) {
      if (this.bypass.is("FunTime")) {
         this.packetQueue.add(packet);
      } else if (mc.method_1562() != null) {
         mc.method_1562().method_52787(packet);
      }

   }

   private void sendQueuedPackets() {
      (new Thread(() -> {
         try {
            Thread.sleep(80L);

            while(!this.packetQueue.isEmpty()) {
               class_2813 packet = (class_2813)this.packetQueue.poll();
               if (packet != null && mc.method_1562() != null) {
                  mc.method_1562().method_52787(packet);
               }
            }
         } catch (InterruptedException e) {
            e.printStackTrace();
         }

      })).start();
   }
}
