package ru.levin.modules.player;

import net.minecraft.class_1764;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1835;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2846;
import net.minecraft.class_2846.class_2847;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "PerfectTime",
   desc = "Automatycznie wypuszcza trójząb lub bełt z kuszy po pełnym naciągnięciu",
   type = Type.Player
)
public class PerfectTime extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1724.method_6115()) {
         class_1799 stack = mc.field_1724.method_6047();
         class_1792 item = stack.method_7909();
         int useTime = stack.method_7935(mc.field_1724) - mc.field_1724.method_6014();
         if (item instanceof class_1835 && useTime >= 10) {
            this.releaseUse();
         } else if (item instanceof class_1764 && useTime >= stack.method_7935(mc.field_1724) - 1) {
            this.releaseUse();
         }

      }
   }

   private void releaseUse() {
      mc.field_1724.field_3944.method_52787(new class_2846(class_2847.field_12974, class_2338.field_10980, class_2350.field_11033));
      mc.field_1724.method_6075();
   }
}
