package ru.levin.modules.player;

import java.util.Arrays;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "NoPush",
   desc = "Wyłącza kolizję z różnymi obiektami",
   type = Type.Player
)
public class NoPush extends Function {
   public final ModeSetting mode = new ModeSetting("Mode", "Exosware", new String[]{"Exosware", "Wicia"});
   public MultiSetting mods = new MultiSetting("Typy", Arrays.asList("Woda", "Gracze", "Bloki"), new String[]{"Woda", "Gracze", "Bloki"});

   public NoPush() {
      this.addSettings(new Setting[]{this.mode, this.mods});
   }

   public boolean isWiciaMode() {
      return this.mode.is("Wicia");
   }

   public boolean blocksEnabled() {
      return this.isWiciaMode() || this.mods.get("Bloki");
   }

   public boolean playersEnabled() {
      return this.isWiciaMode() || this.mods.get("Gracze");
   }

   public boolean waterEnabled() {
      return this.isWiciaMode() || this.mods.get("Woda");
   }

   public void onEvent(Event event) {
   }
}
