package ru.levin.modules.player;

import net.minecraft.class_2596;
import net.minecraft.class_2868;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "ItemFixSwap",
   keywords = {"NoSlotChange", "NoServerDesync", "Naprawa slotu"},
   desc = "Zapobiega wykrywaniu przez antycheat zmiany slotu",
   type = Type.Player
)
public class ItemFixSwap extends Function {
   public ItemFixSwap() {
      this.addSettings(new Setting[0]);
   }

   public void onEvent(Event event) {
      if (event instanceof EventPacket e) {
         if (e.isReceivePacket()) {
            class_2596 var4 = e.getPacket();
            if (var4 instanceof class_2868) {
               class_2868 packetHeldItemChange = (class_2868)var4;
               event.setCancel(true);
            }
         }
      }

   }
}
