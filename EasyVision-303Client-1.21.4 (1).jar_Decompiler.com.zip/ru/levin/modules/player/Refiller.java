package ru.levin.modules.player;

import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "Refiller",
   desc = "Uzupelnia wybrane itemy na hotbarze",
   type = Type.Player
)
public class Refiller extends Function {
   public final BooleanSetting obsidian = new BooleanSetting("Obsydian", true);
   public final BooleanSetting cobwebs = new BooleanSetting("Cobweby", true);
   public final BooleanSetting pearls = new BooleanSetting("Perły", true);
   public final SliderSetting threshold = new SliderSetting("Próg", (double)10.0F, (double)1.0F, (double)32.0F, (double)1.0F);
   public final SliderSetting pearlThreshold = new SliderSetting("Próg pereł", (double)2.0F, (double)1.0F, (double)16.0F, (double)1.0F);

   public Refiller() {
      this.addSettings(new Setting[]{this.obsidian, this.cobwebs, this.pearls, this.threshold, this.pearlThreshold});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         RefillerUtil.tick(this);
      }

   }
}
