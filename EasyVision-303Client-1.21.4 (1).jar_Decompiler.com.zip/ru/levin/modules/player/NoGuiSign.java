package ru.levin.modules.player;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "NoGuiSign",
   desc = "Nie otwiera edytora tabliczek",
   type = Type.Player
)
public class NoGuiSign extends Function {
   public void onEvent(Event event) {
   }
}
