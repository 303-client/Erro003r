package ru.levin.modules.player;

import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_490;
import ru.levin.manager.IMinecraft;

public final class RefillerUtil implements IMinecraft {
   private static int waitTicks;
   private static int targetHotbarSlot = -1;
   private static boolean openedByRefiller;

   private RefillerUtil() {
   }

   public static void tick(Refiller refiller) {
      if (refiller.state && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         if (mc.field_1755 != null && !openedByRefiller) {
            reset();
         } else if (openedByRefiller) {
            if (!(mc.field_1755 instanceof class_490)) {
               reset();
            } else if (waitTicks > 0) {
               --waitTicks;
            } else {
               if (refillInventory(refiller)) {
                  reset();
                  closeInventory();
               }

            }
         } else {
            int hotbarSlot = mc.field_1724.method_31548().field_7545;
            if (needsRefill(refiller, hotbarSlot)) {
               targetHotbarSlot = hotbarSlot;
               mc.method_1507(new class_490(mc.field_1724));
               openedByRefiller = true;
               waitTicks = 3;
            }
         }
      } else {
         reset();
      }
   }

   private static boolean needsRefill(Refiller refiller, int hotbarSlot) {
      class_1792 item = mc.field_1724.method_31548().method_5438(hotbarSlot).method_7909();
      int count = mc.field_1724.method_31548().method_5438(hotbarSlot).method_7947();
      if (item == class_1802.field_8281 && refiller.obsidian.get()) {
         return count <= refiller.threshold.get().intValue();
      } else if (item == class_1802.field_8786 && refiller.cobwebs.get()) {
         return count <= refiller.threshold.get().intValue();
      } else {
         return item == class_1802.field_8634 && refiller.pearls.get() && count <= refiller.pearlThreshold.get().intValue();
      }
   }

   private static boolean refillInventory(Refiller refiller) {
      if (targetHotbarSlot >= 0 && targetHotbarSlot <= 8) {
         class_1792 target = mc.field_1724.method_31548().method_5438(targetHotbarSlot).method_7909();
         int targetHandlerSlot = targetHotbarSlot + 36;
         int limit = target == class_1802.field_8634 ? refiller.pearlThreshold.get().intValue() : refiller.threshold.get().intValue();
         if (mc.field_1724.field_7512.method_7611(targetHandlerSlot).method_7677().method_7947() > limit) {
            return true;
         } else {
            int sourceSlot = findSourceSlot(target);
            if (sourceSlot == -1) {
               return true;
            } else {
               mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, sourceSlot, 0, class_1713.field_7794, mc.field_1724);
               waitTicks = 1;
               return false;
            }
         }
      } else {
         return true;
      }
   }

   private static int findSourceSlot(class_1792 target) {
      for(int slot = 9; slot < 36; ++slot) {
         if (mc.field_1724.field_7512.method_7611(slot).method_7677().method_31574(target)) {
            return slot;
         }
      }

      return -1;
   }

   private static void closeInventory() {
      if (mc.field_1755 instanceof class_490) {
         mc.field_1724.method_7346();
      }

   }

   private static void reset() {
      waitTicks = 0;
      targetHotbarSlot = -1;
      openedByRefiller = false;
   }
}
