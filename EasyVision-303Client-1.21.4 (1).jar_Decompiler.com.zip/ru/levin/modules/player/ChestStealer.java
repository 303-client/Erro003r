package ru.levin.modules.player;

import java.util.List;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_437;
import net.minecraft.class_476;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "ChestStealer",
   desc = "",
   type = Type.Player
)
public class ChestStealer extends Function {
   private final ModeSetting mode = new ModeSetting("Typ", "Zwykły", new String[]{"Zwykły", "Inteligentny"});
   private final SliderSetting stealDelay = new SliderSetting("Opóźnienie", (double)120.0F, (double)0.0F, (double)1000.0F, (double)1.0F);
   private final TimerUtil timer = new TimerUtil();
   private static final List<String> BLOCKED_TITLES = List.of("Aukcja", "Warp", "Warpy", "Menu", "Wybór zestawu", "Skrzynki", "Sklep");

   public ChestStealer() {
      this.addSettings(new Setting[]{this.mode, this.stealDelay});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         class_437 var3 = mc.field_1755;
         if (var3 instanceof class_476) {
            class_476 container = (class_476)var3;
            String var9 = container.method_25440().getString().toLowerCase();

            for(String blocked : BLOCKED_TITLES) {
               if (var9.contains(blocked.toLowerCase())) {
                  return;
               }
            }

            class_1707 handler = (class_1707)container.method_17577();
            int chestSize = handler.method_17388() * 9;
            boolean instant = this.stealDelay.get().floatValue() == 0.0F;

            for(int i = 0; i < chestSize; ++i) {
               class_1799 stack = handler.method_7611(i).method_7677();
               if (!stack.method_7960() && stack.method_7909() != class_1802.field_8162 && (!this.mode.is("Inteligentny") || Manager.CHESTSTEALER_MANAGER.isAllowed(stack.method_7909())) && (instant || this.timer.hasTimeElapsed(this.stealDelay.get().longValue()))) {
                  this.click(handler.field_7763, i);
                  if (!instant) {
                     this.timer.reset();
                  }

                  if (!instant) {
                     break;
                  }
               }
            }

            return;
         }
      }

   }

   private void click(int id, int slot) {
      mc.field_1761.method_2906(id, slot, 0, class_1713.field_7794, mc.field_1724);
   }
}
