package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_746;
import net.minecraft.class_2848.class_2849;
import ru.levin.manager.Manager;

public final class WiciaDripstoneUtil {
   private static final ThreadLocal<Boolean> INTERNAL = ThreadLocal.withInitial(() -> false);

   private WiciaDripstoneUtil() {
   }

   public static class_1269 onUseBlock(class_1657 player, class_1937 world, class_1268 hand, class_3965 hit) {
      if (!(Boolean)INTERNAL.get() && Manager.FUNCTION_MANAGER != null && player instanceof class_746 clientPlayer) {
         if (world != null && world.field_9236 && hand == class_1268.field_5808 && Manager.FUNCTION_MANAGER.wiciaDripstone.state && clientPlayer.method_6047().method_31574(class_1802.field_28042)) {
            class_2338 pos = hit.method_17777();
            class_2680 state = world.method_8320(pos);
            if (!(state.method_26204() instanceof class_2533)) {
               return null;
            }

            class_2338 belowPos = pos.method_10074();
            if (!world.method_8320(belowPos).method_45474()) {
               return null;
            }

            class_310 client = class_310.method_1551();
            if (client.field_1761 != null && client.method_1562() != null) {
               INTERNAL.set(true);
               boolean wasSneaking = clientPlayer.method_5715();

               class_1269.class_9860 var13;
               try {
                  if (!wasSneaking) {
                     clientPlayer.field_3944.method_52787(new class_2848(clientPlayer, class_2849.field_12979));
                     clientPlayer.method_5660(true);
                  }

                  class_3965 innerHit = new class_3965(new class_243((double)belowPos.method_10263() + (double)0.5F, (double)belowPos.method_10264() + (double)1.0F, (double)belowPos.method_10260() + (double)0.5F), class_2350.field_11036, belowPos, false);
                  class_1269 placed = client.field_1761.method_2896(clientPlayer, hand, innerHit);
                  if (!wasSneaking) {
                     clientPlayer.field_3944.method_52787(new class_2848(clientPlayer, class_2849.field_12984));
                     clientPlayer.method_5660(false);
                  }

                  class_1269 original = client.field_1761.method_2896(clientPlayer, hand, hit);
                  if (placed.method_23665() || original.method_23665()) {
                     clientPlayer.method_6104(hand);
                  }

                  var13 = class_1269.field_5812;
               } finally {
                  if (!wasSneaking && clientPlayer.method_5715()) {
                     clientPlayer.field_3944.method_52787(new class_2848(clientPlayer, class_2849.field_12984));
                     clientPlayer.method_5660(false);
                  }

                  INTERNAL.set(false);
               }

               return var13;
            }

            return null;
         }
      }

      return null;
   }
}
