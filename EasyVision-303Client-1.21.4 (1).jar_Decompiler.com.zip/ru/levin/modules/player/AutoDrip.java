package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_3532;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.SilentRotationUtil;

@FunctionAnnotation(
   name = "AutoDrip",
   desc = "Stawia pointed dripstone pod trapdoor i otwiera/zamyka go gdy celujesz (bypass antycheata)",
   type = Type.Player
)
public class AutoDrip extends Function {
   private static final double MAX_DISTANCE = (double)3.0F;
   private final ModeSetting speed = new ModeSetting("Speed", "Fast", new String[]{"Very Slow", "Slow", "Human", "Fast"});
   private class_2338 startPos;
   private class_2338 targetTrapdoor;
   private Step step;
   private long stepStartedAt;
   private long lastAction;
   private int failedChecks;
   private long lastSafeTick;

   public AutoDrip() {
      this.step = AutoDrip.Step.CHECK_TRAPDOOR;
      this.addSettings(new Setting[]{this.speed});
   }

   public void onEnable() {
      if (mc.field_1724 != null) {
         SilentRotationUtil.clear();
         this.startPos = mc.field_1724.method_24515();
         this.targetTrapdoor = null;
         this.step = AutoDrip.Step.CHECK_TRAPDOOR;
         this.stepStartedAt = System.currentTimeMillis();
         this.lastAction = 0L;
         this.failedChecks = 0;
         this.lastSafeTick = System.currentTimeMillis();
      }

   }

   public void onDisable() {
      SilentRotationUtil.clear();
      this.startPos = null;
      this.targetTrapdoor = null;
      this.step = AutoDrip.Step.CHECK_TRAPDOOR;
      this.stepStartedAt = 0L;
      this.failedChecks = 0;
      this.lastSafeTick = 0L;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.state) {
         if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
            if (!mc.field_1724.method_6115()) {
               if (this.hasPointedDripstoneInHotbar()) {
                  if (this.startPos != null && mc.field_1724.method_24515().method_10262(this.startPos) > (double)9.0F) {
                     this.setState(false);
                  } else {
                     this.targetTrapdoor = this.getTargetTrapdoor();
                     if (this.targetTrapdoor != null) {
                        this.lastSafeTick = System.currentTimeMillis();
                        this.executeBypassCycle(this.targetTrapdoor);
                     }
                  }
               }
            }
         }
      }
   }

   private void executeBypassCycle(class_2338 trapdoorPos) {
      if (mc.field_1724 != null) {
         long now = System.currentTimeMillis();
         class_2338 lowerBlock = trapdoorPos.method_10074();
         if (!this.isPlayerInLoopRange(trapdoorPos)) {
            this.attackAuraAim(trapdoorPos);
         } else if (now - this.stepStartedAt > 4000L) {
            ++this.failedChecks;
            if (this.failedChecks >= 3) {
               this.setState(false);
            } else {
               this.step = AutoDrip.Step.CHECK_TRAPDOOR;
               this.stepStartedAt = now;
            }
         } else {
            switch (this.step.ordinal()) {
               case 0:
                  this.attackAuraAim(trapdoorPos);
                  if (!this.isTrapdoorOpen(trapdoorPos)) {
                     this.failedChecks = 0;
                     this.step = AutoDrip.Step.PLACE_DRIPSTONE;
                     this.stepStartedAt = now;
                  } else {
                     this.toggleTrapdoor(trapdoorPos);
                     this.step = AutoDrip.Step.CLOSE_TRAPDOOR;
                     this.stepStartedAt = now;
                  }
                  break;
               case 1:
                  if (now - this.stepStartedAt < this.getPlaceDelayMs()) {
                     return;
                  }

                  this.attackAuraAim(lowerBlock);
                  if (this.isTargetReached(lowerBlock, 5.0F)) {
                     if (mc.field_1687.method_8320(lowerBlock).method_26204() == class_2246.field_28048) {
                        this.failedChecks = 0;
                        this.step = AutoDrip.Step.OPEN_TRAPDOOR;
                        this.stepStartedAt = now;
                        return;
                     }

                     if (mc.field_1687.method_8320(lowerBlock).method_45474()) {
                        this.placePointedDripstone(lowerBlock);
                     }

                     this.failedChecks = 0;
                     this.step = AutoDrip.Step.OPEN_TRAPDOOR;
                     this.stepStartedAt = now;
                  }
                  break;
               case 2:
                  if (now - this.stepStartedAt < this.getOpenDelayMs()) {
                     return;
                  }

                  this.attackAuraAim(trapdoorPos);
                  if (this.isTargetReached(trapdoorPos, 8.0F)) {
                     if (this.isTrapdoorOpen(trapdoorPos)) {
                        this.step = AutoDrip.Step.CLOSE_TRAPDOOR;
                        this.stepStartedAt = now;
                        return;
                     }

                     this.toggleTrapdoor(trapdoorPos);
                     this.failedChecks = 0;
                     this.step = AutoDrip.Step.CLOSE_TRAPDOOR;
                     this.stepStartedAt = now;
                  }
                  break;
               case 3:
                  if (now - this.stepStartedAt < this.getCloseDelayMs()) {
                     return;
                  }

                  this.attackAuraAim(trapdoorPos);
                  if (this.isTargetReached(trapdoorPos, 8.0F)) {
                     if (!this.isTrapdoorOpen(trapdoorPos)) {
                        if (mc.field_1687.method_8320(lowerBlock).method_26204() == class_2246.field_28048) {
                           this.step = AutoDrip.Step.PLACE_DRIPSTONE;
                           this.stepStartedAt = now;
                           this.lastAction = now;
                           return;
                        }

                        this.toggleTrapdoor(trapdoorPos);
                        this.failedChecks = 0;
                        this.step = AutoDrip.Step.PLACE_DRIPSTONE;
                        this.stepStartedAt = now;
                        this.lastAction = now;
                        return;
                     }

                     this.toggleTrapdoor(trapdoorPos);
                     this.failedChecks = 0;
                     this.step = AutoDrip.Step.PLACE_DRIPSTONE;
                     this.stepStartedAt = now;
                     this.lastAction = now;
                  }
                  break;
               default:
                  this.step = AutoDrip.Step.CHECK_TRAPDOOR;
                  this.stepStartedAt = now;
            }

         }
      }
   }

   private void attackAuraAim(class_2338 target) {
      if (mc.field_1724 != null) {
         double dx = (double)target.method_10263() + (double)0.5F - mc.field_1724.method_23317();
         double dy = (double)target.method_10264() + (double)0.5F - mc.field_1724.method_23320();
         double dz = (double)target.method_10260() + (double)0.5F - mc.field_1724.method_23321();
         double horizontal = Math.sqrt(dx * dx + dz * dz);
         float yaw = class_3532.method_15393((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
         float pitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);
         SilentRotationUtil.update(mc, yaw, pitch, (int)this.getDelayMs());
      }
   }

   private boolean isTargetReached(class_2338 pos, float toleranceDegrees) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         float yaw = this.getYawToBlock(pos);
         float pitch = this.getPitchToBlock(pos);
         float currentYaw = SilentRotationUtil.yaw();
         float currentPitch = SilentRotationUtil.pitch();
         float yawDiff = Math.abs(class_3532.method_15393(yaw - currentYaw));
         float pitchDiff = Math.abs(pitch - currentPitch);
         return yawDiff <= toleranceDegrees && pitchDiff <= toleranceDegrees;
      }
   }

   private boolean humanAimAndWait(class_2338 target, float strength, float jitterScale, float maxYawStep, float maxPitchStep, long waitMs) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         long now = System.currentTimeMillis();
         if (now - this.stepStartedAt < waitMs) {
            this.humanAim(target, strength, jitterScale, maxYawStep, maxPitchStep);
            return false;
         } else {
            this.humanAim(target, strength, jitterScale, maxYawStep, maxPitchStep);
            return this.isTargetReached(target, 1.3F);
         }
      }
   }

   private class_2338 findNextDripstonePosition(class_2338 trapdoorPos) {
      if (mc.field_1687 == null) {
         return null;
      } else {
         class_2338 cursor = trapdoorPos.method_10074();

         class_2338 next;
         for(int depth = 0; depth++ < 32 && mc.field_1687.method_8320(cursor).method_26204() == class_2246.field_28048; cursor = next) {
            next = cursor.method_10074();
            if (!mc.field_1687.method_8320(next).method_45474()) {
               return null;
            }
         }

         return mc.field_1687.method_8320(cursor).method_45474() ? cursor : null;
      }
   }

   private class_2338 findLowestDripstone(class_2338 trapdoorPos) {
      if (mc.field_1687 == null) {
         return null;
      } else {
         class_2338 cursor = trapdoorPos.method_10074();
         class_2338 lowest = null;

         for(int depth = 0; depth++ < 32 && mc.field_1687.method_8320(cursor).method_26204() == class_2246.field_28048; cursor = cursor.method_10074()) {
            lowest = cursor;
         }

         return lowest;
      }
   }

   private void clickPointedDripstone(class_2338 pos) {
      if (pos != null && mc.field_1724 != null && mc.field_1761 != null && mc.field_1687.method_8320(pos).method_26204() == class_2246.field_28048) {
         int slot = this.findBlockSlot(class_2246.field_28048);
         if (slot != -1) {
            int oldSlot = mc.field_1724.method_31548().field_7545;
            mc.field_1724.method_31548().field_7545 = slot;
            class_3965 hit = new class_3965(class_243.method_24953(pos), class_2350.field_11033, pos, false);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hit);
            mc.field_1724.method_31548().field_7545 = oldSlot;
         }
      }
   }

   private boolean aimAndWait(class_2338 target, float strength, float jitterScale, float maxYawStep, float maxPitchStep, long waitMs) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         long now = System.currentTimeMillis();
         if (now - this.stepStartedAt < waitMs) {
            this.followTarget(target, strength, jitterScale, maxYawStep, maxPitchStep);
            return false;
         } else {
            this.followTarget(target, strength, jitterScale, maxYawStep, maxPitchStep);
            return this.isTargetReached(target, 1.3F);
         }
      }
   }

   private void followTarget(class_2338 blockPos, float strength, float jitterScale, float maxYawStep, float maxPitchStep) {
      if (mc.field_1724 != null) {
         float targetYaw = this.getYawToBlock(blockPos);
         float targetPitch = this.getPitchToBlock(blockPos);
         long now = System.currentTimeMillis();
         float driftYaw = (float)(Math.sin((double)now / (double)180.0F + (double)blockPos.method_10263() * 0.31 + (double)blockPos.method_10260() * 0.23) * (0.6 + (double)jitterScale));
         float driftPitch = (float)(Math.cos((double)now / (double)240.0F + (double)blockPos.method_10264() * 0.48) * (0.35 + (double)jitterScale * 0.3));
         float finalYaw = targetYaw + driftYaw;
         float finalPitch = class_3532.method_15363(targetPitch + driftPitch, -89.9F, 89.9F);
         float currentYaw = Manager.ROTATION.getYaw();
         float currentPitch = Manager.ROTATION.getPitch();
         float yawDelta = class_3532.method_15393(finalYaw - currentYaw);
         float pitchDelta = finalPitch - currentPitch;
         float smoothYaw = currentYaw + yawDelta * (0.18F + strength * 0.22F);
         float smoothPitch = currentPitch + pitchDelta * (0.17F + strength * 0.2F);
         smoothPitch = class_3532.method_15363(smoothPitch, -89.9F, 89.9F);
         Manager.ROTATION.setSmooth(smoothYaw, smoothPitch, 0.72F + strength * 0.18F, maxYawStep, maxPitchStep, true);
      }
   }

   private void humanAim(class_2338 blockPos, float strength, float jitterScale, float maxYawStep, float maxPitchStep) {
      if (mc.field_1724 != null) {
         float targetYaw = this.getYawToBlock(blockPos);
         float targetPitch = this.getPitchToBlock(blockPos);
         long now = System.currentTimeMillis();
         float driftYaw = (float)(Math.sin((double)now / (double)180.0F + (double)blockPos.method_10263() * 0.31 + (double)blockPos.method_10260() * 0.23) * (0.8 + (double)jitterScale));
         float driftPitch = (float)(Math.cos((double)now / (double)240.0F + (double)blockPos.method_10264() * 0.48) * (0.4 + (double)jitterScale * 0.35));
         float finalYaw = targetYaw + driftYaw;
         float finalPitch = class_3532.method_15363(targetPitch + driftPitch, -89.9F, 89.9F);
         float currentYaw = Manager.ROTATION.getYaw();
         float currentPitch = Manager.ROTATION.getPitch();
         float yawDelta = class_3532.method_15393(finalYaw - currentYaw);
         float pitchDelta = finalPitch - currentPitch;
         float smoothYaw = currentYaw + yawDelta * (0.22F + strength * 0.24F);
         float smoothPitch = currentPitch + pitchDelta * (0.2F + strength * 0.22F);
         smoothPitch = class_3532.method_15363(smoothPitch, -89.9F, 89.9F);
         Manager.ROTATION.setSmooth(smoothYaw, smoothPitch, 0.8F + strength * 0.2F, maxYawStep, maxPitchStep, true);
      }
   }

   private float getYawToBlock(class_2338 pos) {
      if (mc.field_1724 == null) {
         return 0.0F;
      } else {
         double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
         double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
         return (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      }
   }

   private float getPitchToBlock(class_2338 pos) {
      if (mc.field_1724 == null) {
         return 0.0F;
      } else {
         double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
         double dy = (double)pos.method_10264() + (double)0.5F - (mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376()));
         double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
         double h = Math.hypot(dx, dz);
         return class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, h))), -89.9F, 89.9F);
      }
   }

   private boolean verifyCrosshair(class_2338 pos) {
      class_239 var3 = mc.field_1765;
      if (var3 instanceof class_3965 hit) {
         return hit.method_17777().equals(pos);
      } else {
         return false;
      }
   }

   private long getDelayMs() {
      long var10000;
      switch (this.speed.get()) {
         case "Very Slow" -> var10000 = 500L;
         case "Slow" -> var10000 = 300L;
         case "Fast" -> var10000 = 100L;
         default -> var10000 = 200L;
      }

      return var10000;
   }

   private long getAimDelayMs() {
      return Math.max(90L, this.getDelayMs() / 2L);
   }

   private long getPlaceDelayMs() {
      return Math.max(50L, this.getDelayMs() / 2L);
   }

   private long getOpenDelayMs() {
      return Math.max(30L, this.getDelayMs() / 3L);
   }

   private long getCloseDelayMs() {
      return Math.max(30L, this.getDelayMs() / 3L);
   }

   private class_2338 getTargetTrapdoor() {
      class_239 var2 = mc.field_1765;
      if (var2 instanceof class_3965 hit) {
         class_2338 pos = hit.method_17777();
         if (pos == null) {
            return null;
         } else {
            class_2680 state = mc.field_1687.method_8320(pos);
            return state.method_26204() instanceof class_2533 ? pos : null;
         }
      } else {
         return null;
      }
   }

   private void placePointedDripstone(class_2338 pos) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         if (mc.field_1687.method_8320(pos).method_45474()) {
            int slot = this.findBlockSlot(class_2246.field_28048);
            if (slot != -1) {
               int oldSlot = mc.field_1724.method_31548().field_7545;
               mc.field_1724.method_31548().field_7545 = slot;
               class_3965 result = new class_3965(class_243.method_24953(pos), class_2350.field_11033, pos, false);
               mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, result);
               mc.field_1724.method_31548().field_7545 = oldSlot;
            }
         }
      }
   }

   private void toggleTrapdoor(class_2338 pos) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_2680 state = mc.field_1687.method_8320(pos);
         if (state.method_26204() instanceof class_2533) {
            class_3965 result = new class_3965(class_243.method_24953(pos), class_2350.field_11036, pos, false);
            mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, result);
         }
      }
   }

   private boolean isTrapdoorOpen(class_2338 pos) {
      if (mc.field_1687 == null) {
         return false;
      } else {
         class_2680 state = mc.field_1687.method_8320(pos);
         class_2248 var4 = state.method_26204();
         boolean var10000;
         if (var4 instanceof class_2533) {
            class_2533 trapdoor = (class_2533)var4;
            if ((Boolean)state.method_11654(class_2533.field_11631)) {
               var10000 = true;
               return var10000;
            }
         }

         var10000 = false;
         return var10000;
      }
   }

   private boolean isPlayerAlignedToTrapdoor(class_2338 pos) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
         double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
         double dist = Math.hypot(dx, dz);
         return dist <= (double)4.5F;
      }
   }

   private boolean isPlayerInLoopRange(class_2338 pos) {
      if (mc.field_1724 == null) {
         return false;
      } else {
         double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
         double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
         double dist = Math.hypot(dx, dz);
         return dist <= 3.2 && Math.abs(mc.field_1724.method_23318() - ((double)pos.method_10264() + (double)0.5F)) <= (double)2.0F;
      }
   }

   private boolean hasPointedDripstoneInHotbar() {
      if (mc.field_1724 == null) {
         return false;
      } else {
         for(int i = 0; i < 9; ++i) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (stack != null && !stack.method_7960() && stack.method_31574(class_2246.field_28048.method_8389())) {
               return true;
            }
         }

         return false;
      }
   }

   private int findBlockSlot(class_2248 block) {
      for(int i = 0; i < 9; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack != null && !stack.method_7960() && stack.method_31574(block.method_8389())) {
            return i;
         }
      }

      return -1;
   }

   private static enum Step {
      CHECK_TRAPDOOR,
      PLACE_DRIPSTONE,
      OPEN_TRAPDOOR,
      CLOSE_TRAPDOOR;

      // $FF: synthetic method
      private static Step[] $values() {
         return new Step[]{CHECK_TRAPDOOR, PLACE_DRIPSTONE, OPEN_TRAPDOOR, CLOSE_TRAPDOOR};
      }
   }
}
