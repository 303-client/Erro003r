package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "AutoNielota",
   desc = "Automatycznie zarzuca wędkę na najbliższego gracza spoza friendów",
   type = Type.Player
)
public class AutoNielota extends Function {
   public final SliderSetting range = new SliderSetting("Zasięg", (double)10.0F, (double)2.0F, (double)40.0F, (double)1.0F);
   public final BooleanSetting ignoreFriends = new BooleanSetting("Ignoruj znajomych", true);
   private long nextThrowAt;

   public AutoNielota() {
      this.addSettings(new Setting[]{this.range, this.ignoreFriends});
   }

   public void onEnable() {
      this.nextThrowAt = 0L;
   }

   public void onDisable() {
      this.nextThrowAt = 0L;
   }

   private Rotation findTargetRotation(class_1657 player) {
      class_1657 target = this.findTarget(player);
      if (target == null) {
         return null;
      } else {
         class_243 eye = player.method_33571();
         class_243 targetPos = target.method_5829().method_1005();
         double dx = targetPos.field_1352 - eye.field_1352;
         double dy = targetPos.field_1351 - eye.field_1351;
         double dz = targetPos.field_1350 - eye.field_1350;
         double horizontal = Math.sqrt(dx * dx + dz * dz);
         float yaw = class_3532.method_15393((float)(Math.toDegrees(Math.atan2(dz, dx)) - (double)90.0F));
         float pitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);
         return new Rotation(yaw, pitch);
      }
   }

   private class_1657 findTarget(class_1657 player) {
      double maxRange = this.range.get().doubleValue();
      return (class_1657)player.method_37908().method_18456().stream().filter((candidate) -> candidate != player).filter(class_1309::method_5805).filter((candidate) -> !this.ignoreFriends.get() || !Manager.FRIEND_MANAGER.isFriend(candidate.method_5477().getString())).filter((candidate) -> player.method_5858(candidate) <= maxRange * maxRange).min((first, second) -> Double.compare(player.method_5858(first), player.method_5858(second))).orElse((Object)null);
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.state && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && this.findRodHand() != null) {
         long now = System.currentTimeMillis();
         if (now >= this.nextThrowAt && !mc.field_1724.method_7357().method_7904(class_1802.field_8378.method_7854())) {
            Rotation rotation = this.findTargetRotation(mc.field_1724);
            if (rotation != null) {
               float oldYaw = mc.field_1724.method_36454();
               float oldPitch = mc.field_1724.method_36455();

               try {
                  mc.field_1724.method_36456(rotation.yaw());
                  mc.field_1724.method_36457(rotation.pitch());
                  class_1268 rodHand = this.findRodHand();
                  if (rodHand != null) {
                     class_1269 result = mc.field_1761.method_2919(mc.field_1724, rodHand);
                     if (result.method_23665()) {
                        mc.field_1724.method_6104(rodHand);
                        this.nextThrowAt = now + 250L;
                     }

                     return;
                  }
               } finally {
                  mc.field_1724.method_36456(oldYaw);
                  mc.field_1724.method_36457(oldPitch);
               }

            }
         }
      }
   }

   private class_1268 findRodHand() {
      if (mc.field_1724.method_6079().method_31574(class_1802.field_8378)) {
         return class_1268.field_5810;
      } else {
         return mc.field_1724.method_6047().method_31574(class_1802.field_8378) ? class_1268.field_5808 : null;
      }
   }

   public static record Rotation(float yaw, float pitch) {
   }
}
