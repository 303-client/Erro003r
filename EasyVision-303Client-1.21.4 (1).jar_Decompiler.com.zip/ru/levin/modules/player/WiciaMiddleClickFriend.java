package ru.levin.modules.player;

import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_3966;
import net.minecraft.class_239.class_240;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventMouse;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "WiciaMiddleClickFriend",
   desc = "Dodawanie znajomych środkowym przyciskiem (wersja Wicia)",
   type = Type.Player
)
public class WiciaMiddleClickFriend extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventMouse mouseEvent) {
         if (this.state) {
            if (mc.field_1724 != null && mc.field_1687 != null) {
               if (mouseEvent.getButton() == 2) {
                  this.handleMiddleClick();
               }

            }
         }
      }
   }

   private void handleMiddleClick() {
      if (mc.field_1765 != null) {
         if (mc.field_1765.method_17783() == class_240.field_1331) {
            class_3966 entityHit = (class_3966)mc.field_1765;
            class_1297 entity = entityHit.method_17782();
            if (entity instanceof class_1657) {
               class_1657 player = (class_1657)entity;
               String playerName = player.method_5477().getString();
               if (Manager.FRIEND_MANAGER.isFriend(playerName)) {
                  Manager.FRIEND_MANAGER.removeFriend(playerName);
               } else {
                  Manager.FRIEND_MANAGER.addFriend(playerName);
               }
            }
         }

      }
   }
}
