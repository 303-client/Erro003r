package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "WiciaNielota",
   desc = "Automatyczne rzucanie nieloty w graczy (wersja Wicia)",
   type = Type.Player
)
public class WiciaNielota extends Function {
   public final SliderSetting range = new SliderSetting("Zasięg", (double)10.0F, (double)2.0F, (double)40.0F, (double)1.0F);
   public final BooleanSetting ignoreFriends = new BooleanSetting("Ignoruj znajomych", true);
   private boolean shouldThrowThisTick = false;
   private float targetYaw = 0.0F;
   private float targetPitch = 0.0F;
   private class_1268 throwingHand;
   private boolean cooldown;
   private boolean throwingInProgress;

   public WiciaNielota() {
      this.throwingHand = class_1268.field_5808;
      this.cooldown = false;
      this.throwingInProgress = false;
   }

   public void onEnable() {
      this.shouldThrowThisTick = false;
      this.targetYaw = 0.0F;
      this.targetPitch = 0.0F;
      this.throwingHand = class_1268.field_5808;
      this.cooldown = false;
      this.throwingInProgress = false;
   }

   public void onDisable() {
      this.shouldThrowThisTick = false;
      this.targetYaw = 0.0F;
      this.targetPitch = 0.0F;
      this.throwingHand = class_1268.field_5808;
      this.cooldown = false;
      this.throwingInProgress = false;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.state && mc.field_1724 != null && mc.field_1687 != null) {
         if (!this.throwingInProgress) {
            if (!this.cooldown) {
               if (mc.field_1724.field_7513 == null) {
                  class_1268 rodHand = this.findRodHand();
                  if (rodHand != null) {
                     class_1657 target = this.findTarget();
                     if (target != null) {
                        class_243 eyePos = mc.field_1724.method_33571();
                        class_243 targetPos = target.method_19538().method_1031((double)0.0F, (double)target.method_17682() / (double)2.0F, (double)0.0F);
                        double dx = targetPos.field_1352 - eyePos.field_1352;
                        double dy = targetPos.field_1351 - eyePos.field_1351;
                        double dz = targetPos.field_1350 - eyePos.field_1350;
                        double horizontalDistance = Math.sqrt(dx * dx + dz * dz);
                        float yaw = (float)(Math.toDegrees(Math.atan2(dz, dx)) - (double)90.0F);
                        float pitchOffset = (float)(horizontalDistance * (double)1.5F);
                        float pitch = (float)(-Math.toDegrees(Math.atan2(dy, horizontalDistance))) - pitchOffset;
                        this.targetYaw = class_3532.method_15393(yaw);
                        this.targetPitch = class_3532.method_15363(pitch, -90.0F, 90.0F);
                        this.throwingHand = rodHand;
                        this.shouldThrowThisTick = true;
                        this.cooldown = true;
                     }
                  }
               }
            }
         }
      }
   }

   public boolean shouldThrowThisTick() {
      return this.shouldThrowThisTick;
   }

   public float getTargetYaw() {
      return this.targetYaw;
   }

   public float getTargetPitch() {
      return this.targetPitch;
   }

   public class_1268 getThrowingHand() {
      return this.throwingHand;
   }

   public void clearCooldown() {
      this.cooldown = false;
   }

   public void setThrowingInProgress(boolean inProgress) {
      this.throwingInProgress = inProgress;
   }

   private class_1657 findTarget() {
      float maxRange = this.range.get().floatValue();
      return (class_1657)mc.field_1687.method_18456().stream().filter((player) -> player != mc.field_1724).filter(class_1309::method_5805).filter((player) -> !this.ignoreFriends.get() || !Manager.FRIEND_MANAGER.isFriend(player.method_5477().getString())).filter((player) -> mc.field_1724.method_5858(player) <= (double)(maxRange * maxRange)).min((a, b) -> Double.compare(mc.field_1724.method_5858(a), mc.field_1724.method_5858(b))).orElse((Object)null);
   }

   private class_1268 findRodHand() {
      if (mc.field_1724.method_6079().method_31574(class_1802.field_8378)) {
         return class_1268.field_5810;
      } else {
         return mc.field_1724.method_6047().method_31574(class_1802.field_8378) ? class_1268.field_5808 : null;
      }
   }
}
