package ru.levin.modules.player;

import net.minecraft.class_2596;
import net.minecraft.class_418;
import net.minecraft.class_437;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "AutoRespawn",
   desc = "Automatycznie odradza gracza po śmierci",
   type = Type.Player
)
public class AutoRespawn extends Function {
   private BooleanSetting autohome = new BooleanSetting("Automatycznie teleportuj do domu", true);
   private TextSetting home = new TextSetting("Nazwa punktu domu", "home", () -> this.autohome.get());

   public AutoRespawn() {
      this.addSettings(new Setting[]{this.autohome, this.home});
   }

   public void onEvent(Event event) {
      if (event instanceof EventPacket eventPacket) {
         class_2596 var4 = eventPacket.getPacket();
         if (var4 instanceof class_7439 packet) {
            String message = packet.comp_763().getString();
            if ((message.contains("Zostałeś zabity") || message.contains("zabici") || message.contains("utracono monet") || message.contains("utracono") || message.contains("na śmierć")) && this.autohome.get()) {
               mc.field_1724.field_3944.method_45729("/home " + this.home.getValue());
            }
         }
      }

      if (event instanceof EventUpdate eventUpdate) {
         if (mc.field_1755 instanceof class_418) {
            mc.field_1724.method_7331();
            mc.method_1507((class_437)null);
         }
      }

   }
}
