package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5689;
import net.minecraft.class_5691;
import net.minecraft.class_746;
import net.minecraft.class_2848.class_2849;
import ru.levin.manager.Manager;

public final class FastDripstoneUtil {
   private static final ThreadLocal<Boolean> BUSY = ThreadLocal.withInitial(() -> false);

   private FastDripstoneUtil() {
   }

   public static class_1269 onUseBlock(class_746 player, class_1268 hand, class_3965 hit) {
      class_310 mc = class_310.method_1551();
      if (!(Boolean)BUSY.get() && player != null && mc.field_1687 != null && mc.field_1761 != null && hand == class_1268.field_5808 && player.method_6047().method_31574(class_1802.field_28042) && Manager.FUNCTION_MANAGER != null && Manager.FUNCTION_MANAGER.fastDripstone.state) {
         class_1937 world = mc.field_1687;
         class_2338 targetPos = getTargetPos(world, hit.method_17777());
         if (targetPos == null) {
            return null;
         } else {
            class_2680 state = world.method_8320(targetPos);
            if (state.method_26204() instanceof class_5689 && state.method_11654(class_5689.field_28051) == class_5691.field_28065 && world.method_8320(targetPos.method_10074()).method_26215()) {
               if (mc.method_1562() == null) {
                  return null;
               } else {
                  BUSY.set(true);
                  boolean didSneak = false;

                  class_1269.class_9860 var21;
                  try {
                     if (!player.method_5715()) {
                        mc.method_1562().method_52787(new class_2848(player, class_2849.field_12979));
                        player.method_5660(true);
                        didSneak = true;
                     }

                     class_2350 dir = (class_2350)state.method_11654(class_5689.field_28050);
                     double yOffset = dir == class_2350.field_11036 ? 0.999 : 0.001;
                     class_3965 customHit = new class_3965(new class_243((double)targetPos.method_10263() + (double)0.5F, (double)targetPos.method_10264() + yOffset, (double)targetPos.method_10260() + (double)0.5F), class_2350.field_11036, targetPos, false);
                     class_1269 action1 = mc.field_1761.method_2896(player, hand, customHit);
                     if (didSneak) {
                        mc.method_1562().method_52787(new class_2848(player, class_2849.field_12984));
                        player.method_5660(false);
                        didSneak = false;
                     }

                     class_1269 action2 = mc.field_1761.method_2896(player, hand, hit);
                     if (action1.method_23665() || action2.method_23665()) {
                        player.method_6104(hand);
                     }

                     class_2338 abovePos = targetPos.method_10084();
                     if (world.method_8320(abovePos).method_26204() instanceof class_2533) {
                        class_243 hitPos = class_243.method_24953(abovePos);
                        class_3965 trapdoorHit = new class_3965(hitPos, class_2350.field_11033, abovePos, false);
                        mc.field_1761.method_2896(player, hand, trapdoorHit);
                     }

                     var21 = class_1269.field_5812;
                  } finally {
                     if (didSneak) {
                        mc.method_1562().method_52787(new class_2848(player, class_2849.field_12984));
                        player.method_5660(false);
                     }

                     BUSY.set(false);
                  }

                  return var21;
               }
            } else {
               return null;
            }
         }
      } else {
         return null;
      }
   }

   private static class_2338 getTargetPos(class_1937 world, class_2338 origin) {
      if (origin == null) {
         return null;
      } else if (world.method_8320(origin).method_26204() instanceof class_5689) {
         return origin;
      } else {
         for(class_2350 d : class_2350.values()) {
            class_2338 offset = origin.method_10093(d);
            if (world.method_8320(offset).method_26204() instanceof class_5689) {
               return offset;
            }
         }

         return null;
      }
   }
}
