package ru.levin.modules.player;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;

@FunctionAnnotation(
   name = "ClickAction",
   keywords = {"SwapAction"},
   desc = "Dostosowuje zamianę przedmiotów do wybranego typu serwera (aby uniknąć bana)",
   type = Type.Player
)
public class ClickAction extends Function {
   public final ModeSetting type = new ModeSetting("Typ", "ReallyWorld", new String[]{"ReallyWorld", "FunTime", "HollyWorld"});

   public void onEvent(Event event) {
   }

   public final boolean nonBatch() {
      return this.type.is("ReallyWorld");
   }

   public final boolean batch() {
      return this.type.is("FunTime") || this.type.is("HollyWorld");
   }
}
