package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_2680;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.player.EventUseBlock;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "WiciaDripstone",
   desc = "Automatyczne używanie dripstone z trapdoor do szybszego kopania",
   type = Type.Player
)
public class WiciaDripstone extends Function {
   private static final ThreadLocal<Boolean> isProcessing = ThreadLocal.withInitial(() -> false);

   public void onEvent(Event event) {
      if (event instanceof EventUseBlock useBlockEvent) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            return;
         }

         if ((Boolean)isProcessing.get()) {
            useBlockEvent.setCancel(true);
            return;
         }

         if (!this.state) {
            return;
         }

         if (useBlockEvent.getHand() != class_1268.field_5808) {
            return;
         }

         class_2338 pos = useBlockEvent.getBlockPos();
         class_2680 blockState = mc.field_1687.method_8320(pos);
         if (!(blockState.method_26204() instanceof class_2533)) {
            return;
         }

         class_1799 mainHandStack = mc.field_1724.method_6047();
         if (!mainHandStack.method_31574(class_1802.field_28042)) {
            return;
         }

         class_2338 belowPos = pos.method_10074();
         if (!mc.field_1687.method_8320(belowPos).method_45474()) {
            return;
         }

         isProcessing.set(true);

         try {
            boolean wasSneaking = mc.field_1724.method_5715();
            if (!wasSneaking) {
               mc.field_1724.method_5660(true);
            }

            class_3965 dripstoneHit = new class_3965(new class_243((double)belowPos.method_10263() + (double)0.5F, (double)belowPos.method_10264() + (double)1.0F, (double)belowPos.method_10260() + (double)0.5F), class_2350.field_11036, belowPos, false);
            class_1269 placeResult = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, dripstoneHit);
            if (!wasSneaking) {
               mc.field_1724.method_5660(false);
            }

            class_3965 originalHit = useBlockEvent.getHitResult();
            class_1269 originalClickResult = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, originalHit);
            if (placeResult.method_23665() || originalClickResult.method_23665()) {
               mc.field_1724.method_6104(class_1268.field_5808);
            }

            useBlockEvent.setCancel(true);
         } finally {
            isProcessing.set(false);
         }
      }

   }
}
