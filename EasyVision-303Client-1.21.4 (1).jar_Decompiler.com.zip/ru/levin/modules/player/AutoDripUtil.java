package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2848;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5689;
import net.minecraft.class_638;
import net.minecraft.class_746;
import net.minecraft.class_2848.class_2849;
import ru.levin.manager.Manager;

public final class AutoDripUtil {
   private static final ThreadLocal<Boolean> IN_USE = ThreadLocal.withInitial(() -> false);

   private AutoDripUtil() {
   }

   public static class_1269 onUseBlock(class_1657 player, class_1268 hand, class_3965 hitResult) {
      if (!(Boolean)IN_USE.get() && Manager.FUNCTION_MANAGER != null && player instanceof class_746 clientPlayer) {
         class_1937 var5 = clientPlayer.method_37908();
         if (var5 instanceof class_638 world) {
            if (clientPlayer.method_5998(hand).method_31574(class_1802.field_28042)) {
               AutoDrip autoDrip = Manager.FUNCTION_MANAGER.autoDrip;
               if (autoDrip.state && clientPlayer.method_5998(hand).method_31574(class_1802.field_28042)) {
                  class_2338 target = findDripstoneTarget(world, hitResult.method_17777());
                  if (target == null) {
                     return null;
                  }

                  class_2680 state = world.method_8320(target);
                  if (!(state.method_26204() instanceof class_5689)) {
                     return null;
                  }

                  class_2350 verticalDirection = (class_2350)state.method_11654(class_5689.field_28050);
                  class_2338 extension = verticalDirection == class_2350.field_11033 ? target.method_10074() : target.method_10084();
                  if (!world.method_8320(extension).method_45474()) {
                     return null;
                  }

                  class_310 client = class_310.method_1551();
                  if (client.field_1761 == null) {
                     return null;
                  }

                  IN_USE.set(true);
                  boolean wasSneaking = clientPlayer.method_5715();

                  Object var18;
                  try {
                     if (!wasSneaking) {
                        clientPlayer.field_3944.method_52787(new class_2848(clientPlayer, class_2849.field_12979));
                        clientPlayer.method_5660(true);
                     }

                     double y = verticalDirection == class_2350.field_11033 ? (double)target.method_10264() + 0.999 : (double)target.method_10264() + 0.001;
                     class_3965 innerHit = new class_3965(new class_243((double)target.method_10263() + (double)0.5F, y, (double)target.method_10260() + (double)0.5F), verticalDirection, target, false);
                     class_1269 innerResult = client.field_1761.method_2896(clientPlayer, hand, innerHit);
                     class_1269 originalResult = client.field_1761.method_2896(clientPlayer, hand, hitResult);
                     boolean accepted = innerResult.method_23665() || originalResult.method_23665();
                     if (accepted) {
                        clientPlayer.method_6104(hand);
                     }

                     var18 = accepted ? class_1269.field_5812 : originalResult;
                  } finally {
                     if (!wasSneaking) {
                        clientPlayer.field_3944.method_52787(new class_2848(clientPlayer, class_2849.field_12984));
                        clientPlayer.method_5660(false);
                     }

                     IN_USE.set(false);
                  }

                  return (class_1269)var18;
               }

               return null;
            }
         }
      }

      return null;
   }

   private static class_2338 findDripstoneTarget(class_638 world, class_2338 hit) {
      if (hit == null) {
         return null;
      } else if (world.method_8320(hit).method_26204() instanceof class_5689) {
         return hit;
      } else {
         for(class_2350 direction : class_2350.values()) {
            class_2338 candidate = hit.method_10093(direction);
            if (world.method_8320(candidate).method_26204() instanceof class_5689) {
               return candidate;
            }
         }

         return null;
      }
   }
}
