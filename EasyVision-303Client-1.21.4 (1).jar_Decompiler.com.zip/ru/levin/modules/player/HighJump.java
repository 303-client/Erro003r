package ru.levin.modules.player;

import net.minecraft.class_495;
import ru.levin.events.Event;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.MoveUtil;

@FunctionAnnotation(
   name = "HighJump",
   type = Type.Move
)
public class HighJump extends Function {
   private final SliderSetting sila = new SliderSetting("Siła", (double)2.0F, (double)0.0F, (double)5.0F, (double)0.1F);
   private boolean wasShulkerOpen = false;
   private long jumpStartTime = 0L;
   private long guiOpenTime = 0L;

   public HighJump() {
      this.addSettings(new Setting[]{this.sila});
   }

   public void onEvent(Event event) {
      if (event instanceof EventMotion) {
         mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, (double)this.sila.get().floatValue(), mc.field_1724.method_18798().field_1350);
         if (mc.field_1690.field_1867.method_1434()) {
            MoveUtil.setMotion((double)this.sila.get().floatValue());
         }

         long currentTime = System.currentTimeMillis();
         if (mc.field_1755 instanceof class_495 && this.guiOpenTime == 0L) {
            this.wasShulkerOpen = true;
            this.guiOpenTime = currentTime;
         }

         if (this.guiOpenTime != 0L && currentTime - this.guiOpenTime >= 800L) {
            mc.field_1724.method_3137();
            mc.field_1724.method_7346();
            this.guiOpenTime = 0L;
         }

         if (this.wasShulkerOpen && mc.field_1755 == null) {
            this.wasShulkerOpen = false;
            this.jumpStartTime = currentTime;
            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, (double)this.sila.get().floatValue(), mc.field_1724.method_18798().field_1350);
            if (mc.field_1690.field_1867.method_1434()) {
               MoveUtil.setMotion((double)this.sila.get().floatValue());
            }
         }

         if (this.jumpStartTime != 0L && currentTime - this.jumpStartTime >= 3000L) {
            this.jumpStartTime = 0L;
         }

      }
   }
}
