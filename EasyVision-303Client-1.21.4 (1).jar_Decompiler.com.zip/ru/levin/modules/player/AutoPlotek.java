package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2354;
import net.minecraft.class_243;
import net.minecraft.class_2544;
import net.minecraft.class_2680;
import net.minecraft.class_2868;
import net.minecraft.class_3532;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "AutoPlotek",
   desc = "Automatycznie niszczy plotek pod pajeczyna",
   type = Type.Player
)
public class AutoPlotek extends Function {
   private final SliderSetting cooldown = new SliderSetting("Cooldown", (double)80.0F, (double)1.0F, (double)500.0F, (double)1.0F);
   private final BooleanSetting ignoreCobweb = new BooleanSetting("Ignoruj cobweb", true);
   private final BooleanSetting honeyBlock = new BooleanSetting("Honey Block", true);
   private final BooleanSetting sculkSensor = new BooleanSetting("Sculk Sensor", true);
   private class_2338 target;
   private long nextAction;
   private int previousSlot = -1;

   public AutoPlotek() {
      this.addSettings(new Setting[]{this.cooldown, this.ignoreCobweb, this.honeyBlock, this.sculkSensor});
   }

   public boolean isBreakingCobweb() {
      return this.state && this.target != null;
   }

   public boolean ignoresCobweb() {
      return this.state && this.ignoreCobweb.get();
   }

   protected void onEnable() {
      this.target = null;
      this.nextAction = 0L;
      this.previousSlot = -1;
   }

   protected void onDisable() {
      this.restoreSlot();
      this.target = null;
      Manager.ROTATION.set(mc.field_1724 != null ? mc.field_1724.method_36454() : 0.0F, mc.field_1724 != null ? mc.field_1724.method_36455() : 0.0F);
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && mc.field_1755 == null) {
         class_2338 candidate = this.findTarget();
         if (candidate == null) {
            this.restoreSlot();
            this.target = null;
         } else {
            this.target = candidate;
            int toolSlot = this.findTool(candidate);
            if (toolSlot != -1) {
               this.selectSlot(toolSlot);
               this.aimAt(this.target);
               if (this.isAimedAt(this.target, 3.0F)) {
                  long now = System.currentTimeMillis();
                  if (now >= this.nextAction) {
                     if (mc.field_1761.method_2910(this.target, class_2350.field_11036)) {
                        mc.field_1724.method_6104(class_1268.field_5808);
                     }

                     mc.field_1761.method_2902(this.target, class_2350.field_11036);
                     this.nextAction = now + Math.max(1L, this.cooldown.get().longValue());
                  }
               }
            }
         }
      }
   }

   private class_2338 findTarget() {
      class_2338 feet = mc.field_1724.method_24515();
      if (!this.ignoreCobweb.get()) {
         return null;
      } else {
         boolean trapped = mc.field_1687.method_8320(feet).method_27852(class_2246.field_10343) || mc.field_1687.method_8320(feet.method_10084()).method_27852(class_2246.field_10343) || mc.field_1687.method_8320(feet.method_10074()).method_27852(class_2246.field_10343);
         if (!trapped) {
            return null;
         } else {
            class_2338 blockBelow = feet.method_10074();
            if (!this.isPlotek(mc.field_1687.method_8320(blockBelow))) {
               return null;
            } else {
               return mc.field_1724.method_5707(class_243.method_24953(blockBelow)) > (double)16.0F ? null : blockBelow.method_10062();
            }
         }
      }
   }

   private boolean isPlotek(class_2680 state) {
      return state.method_26204() instanceof class_2354 || state.method_26204() instanceof class_2544 || this.honeyBlock.get() && state.method_27852(class_2246.field_21211) || this.sculkSensor.get() && (state.method_27852(class_2246.field_28108) || state.method_27852(class_2246.field_43231));
   }

   private int findTool(class_2338 pos) {
      if (this.isSculkSensor(mc.field_1687.method_8320(pos))) {
         return this.findHoe();
      } else {
         return this.isPickaxeBlock(mc.field_1687.method_8320(pos)) ? this.findPickaxe() : this.findAxe();
      }
   }

   private boolean isPickaxeBlock(class_2680 state) {
      return state.method_27852(class_2246.field_10340) || state.method_27852(class_2246.field_10445) || state.method_27852(class_2246.field_29031) || state.method_27852(class_2246.field_28888) || state.method_27852(class_2246.field_23869) || state.method_27852(class_2246.field_23873) || state.method_27852(class_2246.field_27165) || state.method_27852(class_2246.field_10104) || state.method_27852(class_2246.field_10056) || state.method_27852(class_2246.field_10266) || state.method_27852(class_2246.field_10462);
   }

   private int findPickaxe() {
      for(int slot = 0; slot < 9; ++slot) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
         if ((stack.method_31574(class_1802.field_22024) || stack.method_31574(class_1802.field_8377) || stack.method_31574(class_1802.field_8403) || stack.method_31574(class_1802.field_8335) || stack.method_31574(class_1802.field_8387) || stack.method_31574(class_1802.field_8647)) && stack.method_7936() - stack.method_7919() > 1) {
            return slot;
         }
      }

      return -1;
   }

   private boolean isSculkSensor(class_2680 state) {
      return state.method_27852(class_2246.field_28108) || state.method_27852(class_2246.field_43231);
   }

   private int findAxe() {
      for(int slot = 0; slot < 9; ++slot) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
         if ((stack.method_31574(class_1802.field_22025) || stack.method_31574(class_1802.field_8556) || stack.method_31574(class_1802.field_8475) || stack.method_31574(class_1802.field_8825) || stack.method_31574(class_1802.field_8062) || stack.method_31574(class_1802.field_8406)) && stack.method_7936() - stack.method_7919() > 1) {
            return slot;
         }
      }

      return -1;
   }

   private int findHoe() {
      for(int slot = 0; slot < 9; ++slot) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(slot);
         if ((stack.method_31574(class_1802.field_22026) || stack.method_31574(class_1802.field_8527) || stack.method_31574(class_1802.field_8609) || stack.method_31574(class_1802.field_8303) || stack.method_31574(class_1802.field_8431) || stack.method_31574(class_1802.field_8167)) && stack.method_7936() - stack.method_7919() > 1) {
            return slot;
         }
      }

      return -1;
   }

   private void selectSlot(int slot) {
      if (this.previousSlot == -1) {
         this.previousSlot = mc.field_1724.method_31548().field_7545;
      }

      if (mc.field_1724.method_31548().field_7545 != slot) {
         mc.field_1724.method_31548().field_7545 = slot;
         mc.field_1724.field_3944.method_52787(new class_2868(slot));
      }

   }

   private void restoreSlot() {
      if (mc.field_1724 != null && this.previousSlot >= 0 && this.previousSlot <= 8) {
         mc.field_1724.method_31548().field_7545 = this.previousSlot;
         mc.field_1724.field_3944.method_52787(new class_2868(this.previousSlot));
         this.previousSlot = -1;
      }
   }

   private void aimAt(class_2338 pos) {
      double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
      double dy = (double)pos.method_10264() + (double)0.5F - mc.field_1724.method_23320();
      double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
      double horizontal = Math.sqrt(dx * dx + dz * dz);
      float yaw = class_3532.method_15393((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
      float pitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);
      Manager.ROTATION.setSmooth(yaw, pitch, 1.0F, 90.0F, 90.0F, true);
   }

   private boolean isAimedAt(class_2338 pos, float tolerance) {
      double dx = (double)pos.method_10263() + (double)0.5F - mc.field_1724.method_23317();
      double dy = (double)pos.method_10264() + (double)0.5F - mc.field_1724.method_23320();
      double dz = (double)pos.method_10260() + (double)0.5F - mc.field_1724.method_23321();
      double horizontal = Math.sqrt(dx * dx + dz * dz);
      float yaw = class_3532.method_15393((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
      float pitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);
      return Math.abs(class_3532.method_15393(yaw - Manager.ROTATION.getYaw())) <= tolerance && Math.abs(pitch - Manager.ROTATION.getPitch()) <= tolerance;
   }
}
