package ru.levin.modules.player;

import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_640;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.player.EventAttack;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.combat.AttackAura;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "AutoMessage",
   type = Type.Player,
   desc = "Automatyczna wiadomość na czacie lub w wiadomości prywatnej"
)
public class AutoMessage extends Function {
   private final ModeSetting mode = new ModeSetting("Wysyłaj", "Po zabójstwie", new String[]{"Po zabójstwie", "Podczas namierzania celu", "Z opóźnieniem"});
   private final SliderSetting timer = new SliderSetting("Opóźnienie", (double)5000.0F, (double)0.0F, (double)35000.0F, (double)1000.0F, () -> this.mode.is("Z opóźnieniem") || this.mode.is("Podczas namierzania celu") || this.mode.is("msg(Test)"));
   private final TextSetting text = new TextSetting("Wiadomość", "Cześć %target%!");
   private final TimerUtil delayTimer = new TimerUtil();
   private class_1309 lastTarget;
   private boolean waitingForDeath = false;
   private final Pattern pattern = Pattern.compile(".*");

   public AutoMessage() {
      this.addSettings(new Setting[]{this.mode, this.timer, this.text});
   }

   public void onEvent(Event event) {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         AttackAura aura = Manager.FUNCTION_MANAGER.attackAura;
         if (event instanceof EventAttack) {
            EventAttack attackEvent = (EventAttack)event;
            class_1297 var5 = attackEvent.getTarget();
            if (var5 instanceof class_1309) {
               class_1309 entity = (class_1309)var5;
               if (this.mode.is("Po zabójstwie")) {
                  this.lastTarget = entity;
                  this.waitingForDeath = true;
               }
            }
         }

         if (event instanceof EventUpdate) {
            if (this.mode.is("Z opóźnieniem")) {
               if (this.delayTimer.hasTimeElapsed(this.timer.get().longValue())) {
                  this.sendMessage(this.replaceTarget(this.text.getValue(), (class_1309)null));
                  this.delayTimer.reset();
               }

               return;
            }

            if (this.mode.is("Podczas namierzania celu")) {
               if (aura.target != null && this.delayTimer.hasTimeElapsed(this.timer.get().longValue())) {
                  this.sendMessage(this.replaceTarget(this.text.getValue(), aura.target));
                  this.delayTimer.reset();
               }

               return;
            }

            if (this.mode.is("Po zabójstwie") && this.waitingForDeath && this.lastTarget != null) {
               boolean dead = this.lastTarget.method_29504() || this.lastTarget.method_6032() <= 0.0F;
               boolean unloaded = mc.field_1687.method_8469(this.lastTarget.method_5628()) == null;
               if (dead || unloaded) {
                  this.sendMessage(this.replaceTarget(this.text.getValue(), this.lastTarget));
                  this.waitingForDeath = false;
                  this.lastTarget = null;
                  this.delayTimer.reset();
               }
            }
         }

      }
   }

   private void sendMessage(String msg) {
      if (msg != null && !msg.trim().isEmpty()) {
         mc.field_1724.field_3944.method_45729(msg);
      }
   }

   private String replaceTarget(String msg, class_1309 target) {
      return msg.replace("%target%", target != null ? target.method_5477().getString() : "świnka");
   }

   private List<String> getOnlinePlayers() {
      return (List)mc.field_1724.field_3944.method_2880().stream().map(class_640::method_2966).map(GameProfile::getName).filter((profileName) -> this.pattern.matcher(profileName).matches()).collect(Collectors.toList());
   }
}
