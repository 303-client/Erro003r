package ru.levin.modules.player;

import net.minecraft.class_1747;
import net.minecraft.class_1799;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "FastPlace",
   desc = "Zmniejsza opóźnienie stawiania bloków",
   type = Type.Player
)
public class FastPlace extends Function {
   public final SliderSetting delay = new SliderSetting("Opóźnienie (ms)", (double)0.0F, (double)0.0F, (double)500.0F, (double)5.0F);
   private long nextUseAt;

   public FastPlace() {
      this.addSettings(new Setting[]{this.delay});
   }

   public boolean shouldHandle(class_1799 stack) {
      return this.state && !stack.method_7960() && stack.method_7909() instanceof class_1747;
   }

   public boolean allowUse() {
      long now = System.currentTimeMillis();
      if (now < this.nextUseAt) {
         return false;
      } else {
         this.nextUseAt = now + this.delay.get().longValue();
         return true;
      }
   }

   public void resetTimer() {
      this.nextUseAt = 0L;
   }

   protected void onDisable() {
      this.resetTimer();
   }

   public void onEvent(Event event) {
   }
}
