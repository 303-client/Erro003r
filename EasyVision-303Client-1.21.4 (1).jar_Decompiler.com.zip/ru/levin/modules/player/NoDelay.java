package ru.levin.modules.player;

import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.mixin.iface.MinecraftClientAccessor;
import ru.levin.mixin.iface.MixinLivingEntityAccessor;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "NoDelay",
   desc = "Usuwa opóźnienie używania przedmiotów",
   type = Type.Player
)
public class NoDelay extends Function {
   private final BooleanSetting jump = new BooleanSetting("Skok", true);
   private final BooleanSetting xp = new BooleanSetting("Butelka doświadczenia", true);
   private final BooleanSetting crystal = new BooleanSetting("Kryształy", true);
   private final BooleanSetting place = new BooleanSetting("PPM", false);

   public NoDelay() {
      this.addSettings(new Setting[]{this.jump, this.xp, this.crystal, this.place});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (this.jump.get()) {
            ((MixinLivingEntityAccessor)mc.field_1724).setLastJumpCooldown(0);
         }

         if (this.check(mc.field_1724.method_6047().method_7909())) {
            ((MinecraftClientAccessor)mc).setUseCooldown(0);
         }
      }

   }

   private boolean check(class_1792 item) {
      return item instanceof class_1747 && this.place.get() || item == class_1802.field_8301 && this.crystal.get() || item == class_1802.field_8287 && this.xp.get();
   }
}
