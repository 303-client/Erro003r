package ru.levin.modules.player;

import net.minecraft.class_124;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_310;
import net.minecraft.class_418;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.ClientManager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "GodMode",
   type = Type.Player,
   desc = "GodMode — fatalny kod sklejony bez ładu"
)
public class GodMode extends Function {
   TimerUtil timerUtil = new TimerUtil();
   private long lastClickTime = 0L;
   private boolean firstClick = true;

   public GodMode() {
      this.addSettings(new Setting[0]);
   }

   public void onEvent(Event event) {
      if (event instanceof EventPacket eventPacket) {
         class_2596 var4 = eventPacket.getPacket();
         if (var4 instanceof class_7439 packet) {
            String message = packet.comp_763().getString();
            if (message.contains("Nie możesz teleportować się w trybie PvP") || message.contains("Przeteleportowano cię na warp farm!")) {
               eventPacket.setCancel(true);
            }
         }
      }

      if (event instanceof EventUpdate) {
         if (this.timerUtil.hasTimeElapsed(8000L)) {
            String var10000 = String.valueOf(class_124.field_1068);
            ClientManager.message(var10000 + "Gdy GodMode jest włączony" + String.valueOf(class_124.field_1061) + " NIE WOLNO " + String.valueOf(class_124.field_1068) + "zamieniać przedmiotów");
         }

         this.timerUtil.reset();
         if (mc.field_1755 instanceof class_418) {
            this.toggle();
         }
      }

      if (event instanceof EventUpdate && ClientManager.playerIsPVP()) {
         long currentTime = System.currentTimeMillis();
         if (currentTime - this.lastClickTime >= 35L) {
            this.lastClickTime = currentTime;
            class_310.method_1551().execute(() -> mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 1, 1, class_1713.field_7790, mc.field_1724));
         }
      }

   }

   public void onEnable() {
      this.firstClick = true;
      this.lastClickTime = System.currentTimeMillis();
      if (!ClientManager.playerIsPVP()) {
         mc.field_1724.field_3944.method_45731("warp");
         (new Thread(() -> {
            try {
               Thread.sleep(500L);
               class_310.method_1551().execute(() -> mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, 21, 1, class_1713.field_7790, mc.field_1724));
            } catch (InterruptedException e) {
               e.printStackTrace();
            }

         })).start();
         (new Thread(() -> {
            try {
               Thread.sleep(700L);
               class_310.method_1551().execute(() -> {
                  mc.field_1755 = null;
                  mc.field_1729.method_1612();
               });
            } catch (InterruptedException e) {
               e.printStackTrace();
            }

         })).start();
      }

   }
}
