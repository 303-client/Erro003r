package ru.levin.modules.player;

import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_239;
import net.minecraft.class_3966;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventMouse;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "MiddleClickFriend",
   keywords = {"MCF"},
   desc = "Zarządzanie znajomymi",
   type = Type.Player
)
public class MiddleClickFriend extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventMouse e) {
         if (e.getButton() == 2) {
            class_239 var4 = mc.field_1765;
            if (var4 instanceof class_3966) {
               class_3966 entityHitResult = (class_3966)var4;
               class_1297 var5 = entityHitResult.method_17782();
               if (var5 instanceof class_1657) {
                  class_1657 player = (class_1657)var5;
                  String name = player.method_5477().getString();
                  if (Manager.FRIEND_MANAGER.isFriend(name)) {
                     Manager.FRIEND_MANAGER.removeFriend(name);
                     String var10000 = String.valueOf(class_124.field_1080);
                     ClientManager.message(var10000 + name + String.valueOf(class_124.field_1061) + "usunięto ze znajomych");
                  } else {
                     Manager.FRIEND_MANAGER.addFriend(name);
                     String var8 = String.valueOf(class_124.field_1080);
                     ClientManager.message(var8 + name + String.valueOf(class_124.field_1060) + "dodano do znajomych");
                  }
               }
            }
         }
      }

   }
}
