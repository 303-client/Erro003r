package ru.levin.modules.player;

import net.minecraft.class_1802;
import net.minecraft.class_239;
import net.minecraft.class_239.class_240;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.util.BetterPaintingUtil;

@FunctionAnnotation(
   name = "FastBetterPainting",
   desc = "Ulepszone stawianie obrazów - pomija cobweb, glass, leaves (wersja FastClient)",
   type = Type.Player
)
public class FastBetterPainting extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            if (this.state) {
               if (mc.field_1724.method_6047().method_31574(class_1802.field_8892)) {
                  class_239 hit = mc.field_1765;
                  if (hit != null && hit.method_17783() == class_240.field_1332) {
                     if (BetterPaintingUtil.shouldHandlePainting(mc)) {
                     }

                  }
               }
            }
         }
      }
   }
}
