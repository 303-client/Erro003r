package ru.levin.modules.player;

import net.minecraft.class_1268;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2533;
import net.minecraft.class_310;
import net.minecraft.class_3965;
import net.minecraft.class_5689;
import ru.levin.events.Event;
import ru.levin.events.impl.player.EventUseBlock;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "BetterDripstone",
   desc = "Automatycznie otwiera/zamyka trapdoor gdy postawisz dripstone",
   type = Type.Player
)
public class FastDripstone extends Function {
   private final class_310 mc = class_310.method_1551();
   private long lastToggleTime = 0L;
   private static final long TOGGLE_DELAY = 50L;

   public void onEvent(Event event) {
      if (event instanceof EventUseBlock) {
         if (this.state) {
            if (this.mc.field_1687 != null && this.mc.field_1724 != null) {
               EventUseBlock useEvent = (EventUseBlock)event;
               if (this.mc.field_1724.method_6047().method_31574(class_1802.field_28042)) {
                  class_2338 pos = useEvent.getBlockPos();
                  if (this.mc.field_1687.method_8320(pos).method_26204() instanceof class_5689) {
                     class_2338 upPos = pos.method_10084();
                     if (this.mc.field_1687.method_8320(upPos).method_26204() instanceof class_2533) {
                        this.toggleTrapdoor(upPos);
                     }
                  }

               }
            }
         }
      }
   }

   private void toggleTrapdoor(class_2338 pos) {
      long now = System.currentTimeMillis();
      if (now - this.lastToggleTime >= 50L) {
         class_243 hitPos = class_243.method_24953(pos);
         class_3965 hit = new class_3965(hitPos, class_2350.field_11036, pos, false);
         this.mc.field_1761.method_2896(this.mc.field_1724, class_1268.field_5808, hit);
         this.lastToggleTime = now;
      }
   }
}
