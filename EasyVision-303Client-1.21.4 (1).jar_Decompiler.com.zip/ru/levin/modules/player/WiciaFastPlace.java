package ru.levin.modules.player;

import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_239;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "WiciaFastPlace",
   desc = "Szybkie stawianie bloków (wersja Wicia)",
   type = Type.Player
)
public class WiciaFastPlace extends Function {
   public final SliderSetting delay = new SliderSetting("Opóźnienie (ms)", (double)0.0F, (double)0.0F, (double)500.0F, (double)10.0F);
   private long lastPlaceTime = 0L;
   private int cachedDelay = -1;
   private boolean wasEnabled = false;

   public void onEnable() {
      this.lastPlaceTime = 0L;
      this.cachedDelay = -1;
      this.wasEnabled = false;
   }

   public void onDisable() {
      this.lastPlaceTime = 0L;
      this.cachedDelay = -1;
      this.wasEnabled = false;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.state) {
         if (mc.field_1724 == null || mc.field_1687 == null) {
            this.resetState();
         }
      } else {
         this.resetState();
      }
   }

   public boolean shouldPlaceBlock() {
      if (!this.state) {
         this.resetState();
         return true;
      } else if (!this.isPlacingBlock()) {
         return true;
      } else if (this.isExcludedItem(mc.field_1724)) {
         return true;
      } else {
         int delayMs = this.clampDelay(this.delay.get().intValue());
         if (this.wasEnabled != this.state || this.cachedDelay != delayMs) {
            this.lastPlaceTime = 0L;
            this.cachedDelay = delayMs;
            this.wasEnabled = true;
         }

         long currentTime = System.currentTimeMillis();
         if (delayMs <= 0) {
            return true;
         } else if (currentTime < this.lastPlaceTime) {
            return false;
         } else {
            this.lastPlaceTime = currentTime + (long)delayMs;
            return true;
         }
      }
   }

   private boolean isPlacingBlock() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         class_239 hit = mc.field_1765;
         if (!(hit instanceof class_3965)) {
            return false;
         } else {
            class_1799 mainHand = mc.field_1724.method_6047();
            class_1799 offHand = mc.field_1724.method_6079();
            if (!mainHand.method_7960() && mainHand.method_7909() instanceof class_1747) {
               return true;
            } else {
               return !offHand.method_7960() && offHand.method_7909() instanceof class_1747;
            }
         }
      } else {
         return false;
      }
   }

   private boolean isExcludedItem(class_1657 player) {
      if (player == null) {
         return false;
      } else {
         return this.isExcludedItemStack(player.method_6047()) || this.isExcludedItemStack(player.method_6079());
      }
   }

   private boolean isExcludedItemStack(class_1799 stack) {
      if (stack.method_7960()) {
         return false;
      } else {
         class_1792 item = stack.method_7909();
         if (item != class_1802.field_8301 && item != class_1802.field_8884 && item != class_1802.field_8814 && item != class_1802.field_8543) {
            if (item instanceof class_1747) {
               class_1747 blockItem = (class_1747)item;
               class_2248 block = blockItem.method_7711();
               if (block == class_2246.field_10540 || block == class_2246.field_22423 || block == class_2246.field_10343) {
                  return true;
               }
            }

            return false;
         } else {
            return true;
         }
      }
   }

   private void resetState() {
      this.lastPlaceTime = 0L;
      this.cachedDelay = -1;
      this.wasEnabled = false;
   }

   private int clampDelay(int delay) {
      return delay < 0 ? 0 : Math.min(delay, 500);
   }
}
