package ru.levin.modules.player;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "NoRayTrace",
   keywords = {"NoEntityTrace"},
   desc = "Usuwa hitboxy encji",
   type = Type.Player
)
public class NoRayTrace extends Function {
   public void onEvent(Event event) {
   }
}
