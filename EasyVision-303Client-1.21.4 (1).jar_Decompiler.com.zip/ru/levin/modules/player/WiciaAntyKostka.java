package ru.levin.modules.player;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.mojang.serialization.DataResult;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2520;
import net.minecraft.class_2960;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import net.minecraft.class_9279;
import net.minecraft.class_9334;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "WiciaAntyKostka",
   desc = "Zapisuje układ eq pod wybranym bindem (system zestawów)",
   type = Type.Player
)
public class WiciaAntyKostka extends Function {
   private static final Gson GSON = (new GsonBuilder()).setPrettyPrinting().create();
   private static final Path CONFIG_PATH = FabricLoader.getInstance().getConfigDir().resolve("wicia-antykostka.json");
   private KitData kitData = new KitData();
   private KitItem currentKit = null;

   public void onEnable() {
      this.loadConfig();
   }

   public void onDisable() {
      this.saveConfig();
   }

   public void onEvent(Event event) {
   }

   public boolean hasKits() {
      return !this.kitData.kits.isEmpty();
   }

   public int getKitCount() {
      return this.kitData.kits.size();
   }

   public List<KitDisplayItem> getCurrentKitItems() {
      List<KitDisplayItem> items = new ArrayList();
      if (this.currentKit == null) {
         this.currentKit = this.kitData.getCurrentKit();
      }

      if (this.currentKit != null) {
         for(KitItem kitItem : this.currentKit.items) {
            items.add(new KitDisplayItem(kitItem, kitItem.id.equals(this.kitData.currentKitId)));
         }
      }

      return items;
   }

   public KitDisplayItem getCurrentKit() {
      KitItem kit = this.kitData.getCurrentKit();
      return kit != null ? new KitDisplayItem(kit, kit.id.equals(this.kitData.currentKitId)) : null;
   }

   public boolean saveCurrentKit() {
      if (mc.field_1724 == null) {
         return false;
      } else {
         List<KitItem> items = this.scanPlayerInventory();
         KitItem newKit = new KitItem();
         newKit.id = UUID.randomUUID().toString();
         newKit.timestamp = System.currentTimeMillis();
         int var10001 = this.kitData.kits.size();
         newKit.name = "Zestaw " + (var10001 + 1);
         newKit.items = items;
         this.kitData.kits.add(0, newKit);
         this.kitData.currentKitId = newKit.id;
         this.currentKit = newKit;
         this.saveConfig();
         return true;
      }
   }

   public boolean selectKit(String kitId) {
      for(KitItem kit : this.kitData.kits) {
         if (kit.id.equals(kitId)) {
            this.kitData.currentKitId = kitId;
            this.currentKit = kit;
            this.saveConfig();
            return true;
         }
      }

      return false;
   }

   public boolean deleteKit(String kitId) {
      boolean removed = this.kitData.kits.removeIf((kit) -> kit.id.equals(kitId));
      if (!removed) {
         return false;
      } else {
         if (this.kitData.kits.isEmpty()) {
            this.kitData.currentKitId = "";
         } else if (this.kitData.currentKitId.equals(kitId)) {
            this.kitData.currentKitId = ((KitItem)this.kitData.kits.get(0)).id;
         }

         this.saveConfig();
         return true;
      }
   }

   public boolean renameKit(String kitId, String newName) {
      for(KitItem kit : this.kitData.kits) {
         if (kit.id.equals(kitId)) {
            kit.name = this.sanitizeName(newName);
            this.saveConfig();
            return true;
         }
      }

      return false;
   }

   public void loadKit(String kitId) {
      KitItem kit = this.kitData.getKitById(kitId);
      if (kit != null && mc.field_1724 != null) {
         this.loadKitToInventory(kit);
      }
   }

   private List<KitItem> scanPlayerInventory() {
      List<KitItem> items = new ArrayList();
      if (mc.field_1724 == null) {
         return items;
      } else {
         class_1661 inventory = mc.field_1724.method_31548();

         for(int i = 0; i < 36; ++i) {
            class_1799 stack = inventory.method_5438(i);
            items.add(this.createKitItem(i, false, stack, inventory));
         }

         class_1799 offhand = (class_1799)inventory.field_7544.get(0);
         items.add(this.createKitItem(40, true, offhand, inventory));
         return items;
      }
   }

   private KitItem createKitItem(int slot, boolean isOffhand, class_1799 stack, class_1661 inventory) {
      KitItem item = new KitItem();
      item.slot = slot;
      item.isOffhand = isOffhand;
      if (stack.method_7960()) {
         item.itemId = null;
         item.nbtData = null;
         return item;
      } else {
         try {
            class_2960 itemId = class_7923.field_41178.method_10221(stack.method_7909());
            item.itemId = itemId.toString();
            class_9279 nbtComponent = (class_9279)stack.method_57824(class_9334.field_49628);
            if (nbtComponent != null) {
               class_2487 nbt = nbtComponent.method_57461();
               class_6903<class_2520> ops = inventory.field_7546.method_37908().method_30349().method_57093(class_2509.field_11560);
               DataResult<class_2520> dataResult = class_1799.field_24671.encodeStart(ops, stack);
               dataResult.ifSuccess((data) -> item.nbtData = GSON.toJson(data));
            }
         } catch (Exception var11) {
            item.itemId = null;
            item.nbtData = null;
         }

         return item;
      }
   }

   private class_1799 createItemStack(KitItem kitItem, class_1661 inventory) {
      if (kitItem.itemId == null) {
         return class_1799.field_8037;
      } else {
         try {
            class_2960 itemId = class_2960.method_12829(kitItem.itemId);
            if (itemId == null) {
               return class_1799.field_8037;
            } else {
               class_1792 item = (class_1792)class_7923.field_41178.method_63535(itemId);
               if (item == null) {
                  return class_1799.field_8037;
               } else {
                  class_1799 stack = new class_1799(item);
                  if (kitItem.nbtData != null && !kitItem.nbtData.isEmpty()) {
                     try {
                        JsonElement json = (JsonElement)GSON.fromJson(kitItem.nbtData, JsonElement.class);
                        class_9279 nbtComponent = (class_9279)stack.method_57824(class_9334.field_49628);
                        if (nbtComponent != null) {
                           class_2487 var8 = nbtComponent.method_57461();
                        }
                     } catch (Exception var9) {
                     }
                  }

                  return stack;
               }
            }
         } catch (Exception var10) {
            return class_1799.field_8037;
         }
      }
   }

   private void loadKitToInventory(KitItem kit) {
      if (mc.field_1724 != null) {
         class_1661 inventory = mc.field_1724.method_31548();

         for(KitItem kitItem : kit.items) {
            class_1799 stack = this.createItemStack(kitItem, inventory);
            if (kitItem.isOffhand) {
               inventory.field_7544.set(0, stack);
            } else if (kitItem.slot >= 0 && kitItem.slot < 36) {
               inventory.field_7547.set(kitItem.slot, stack);
            }
         }

      }
   }

   private String sanitizeName(String name) {
      if (name == null) {
         return "";
      } else {
         String cleaned = name.replace('\n', ' ').replace('\r', ' ').trim();
         if (cleaned.length() > 32) {
            cleaned = cleaned.substring(0, 32).trim();
         }

         return cleaned;
      }
   }

   private void loadConfig() {
      if (!Files.exists(CONFIG_PATH, new LinkOption[0])) {
         this.kitData = new KitData();
      } else {
         try {
            BufferedReader reader = Files.newBufferedReader(CONFIG_PATH);
            this.kitData = (KitData)GSON.fromJson(reader, KitData.class);
            reader.close();
            if (this.kitData == null) {
               this.kitData = new KitData();
            }

            if (this.kitData.kits == null) {
               this.kitData.kits = new ArrayList();
            }
         } catch (Exception var2) {
            this.kitData = new KitData();
         }

      }
   }

   private void saveConfig() {
      try {
         Files.createDirectories(CONFIG_PATH.getParent());
         BufferedWriter writer = Files.newBufferedWriter(CONFIG_PATH);
         GSON.toJson(this.kitData, writer);
         writer.close();
      } catch (Exception e) {
         System.err.println("[WiciaAntyKostka] Błąd zapisu configu: " + e.getMessage());
      }

   }

   private static class KitData {
      String currentKitId = "";
      List<KitItem> kits = new ArrayList();

      KitItem getCurrentKit() {
         if (this.kits.isEmpty()) {
            return null;
         } else {
            for(KitItem kit : this.kits) {
               if (kit.id.equals(this.currentKitId)) {
                  return kit;
               }
            }

            return (KitItem)this.kits.get(0);
         }
      }

      KitItem getKitById(String id) {
         for(KitItem kit : this.kits) {
            if (kit.id.equals(id)) {
               return kit;
            }
         }

         return null;
      }
   }

   private static class KitItem {
      String id;
      long timestamp;
      String name;
      List<KitItem> items = new ArrayList();
      int slot;
      boolean isOffhand;
      String itemId;
      String nbtData;
   }

   public static class KitDisplayItem {
      private final KitItem kitItem;
      private final boolean isCurrent;

      public KitDisplayItem(KitItem kitItem, boolean isCurrent) {
         this.kitItem = kitItem;
         this.isCurrent = isCurrent;
      }

      public String getId() {
         return this.kitItem.id;
      }

      public String getName() {
         return this.kitItem.name;
      }

      public long getTimestamp() {
         return this.kitItem.timestamp;
      }

      public boolean isCurrent() {
         return this.isCurrent;
      }

      public int getItemCount() {
         return this.kitItem.items.size();
      }
   }
}
