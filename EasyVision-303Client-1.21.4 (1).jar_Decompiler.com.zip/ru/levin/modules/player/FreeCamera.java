package ru.levin.modules.player;

import net.minecraft.class_1309;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import net.minecraft.class_3532;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.input.EventKeyBoard;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.math.MathUtil;

@FunctionAnnotation(
   name = "FreeCamera",
   desc = "Wolna kamera",
   type = Type.Player
)
public class FreeCamera extends Function {
   private final ModeSetting mode = new ModeSetting("Mode", "Exosware", new String[]{"Exosware", "Wicia", "Fast"});
   private final SliderSetting speed = new SliderSetting("Prędkość X", (double)1.0F, (double)0.1F, (double)3.0F, (double)0.1F);
   private final SliderSetting yspeed = new SliderSetting("Prędkość Y", (double)0.42F, (double)0.1F, (double)3.0F, (double)0.1F);
   private float fakeYaw;
   private float fakePitch;
   private float prevFakeYaw;
   private float prevFakePitch;
   private double fakeX;
   private double fakeY;
   private double fakeZ;
   private double prevFakeX;
   private double prevFakeY;
   private double prevFakeZ;
   public class_1309 trackEntity;
   private class_243 freezePosition;
   private boolean previousChunkCulling;

   public FreeCamera() {
      this.freezePosition = class_243.field_1353;
      this.addSettings(new Setting[]{this.mode, this.speed, this.yspeed});
   }

   public boolean isWiciaMode() {
      return this.mode.is("Wicia");
   }

   public boolean isFastMode() {
      return this.mode.is("Fast");
   }

   public void handleFastLook(double deltaX, double deltaY) {
      this.fakeYaw += (float)deltaX * 0.15F;
      this.fakePitch = class_3532.method_15363(this.fakePitch + (float)deltaY * 0.15F, -90.0F, 90.0F);
   }

   public class_3965 fastRaycast(double range, boolean includeFluids) {
      if (mc.field_1687 == null) {
         return null;
      } else {
         double yaw = Math.toRadians((double)this.fakeYaw);
         double pitch = Math.toRadians((double)this.fakePitch);
         class_243 direction = new class_243(-Math.sin(yaw) * Math.cos(pitch), -Math.sin(pitch), Math.cos(yaw) * Math.cos(pitch));
         class_243 start = new class_243(this.getFakeX(), this.getFakeY(), this.getFakeZ());
         return mc.field_1687.method_17742(new class_3959(start, start.method_1019(direction.method_1021(range)), class_3960.field_17559, includeFluids ? class_242.field_1347 : class_242.field_1348, mc.field_1724));
      }
   }

   public void onEvent(Event event) {
      if (mc.field_1724 == null || mc.field_1687 == null) {
         this.toggle();
      }

      if (event instanceof EventPacket eventPacket) {
         if (this.isFastMode() && eventPacket.isSendPacket() && eventPacket.getPacket() instanceof class_2828) {
            eventPacket.setCancel(true);
         }
      }

      if (event instanceof EventKeyBoard) {
         if (mc.field_1724 == null) {
            return;
         }

         if (this.trackEntity == null) {
            EventKeyBoard input = (EventKeyBoard)event;
            double forward = (double)input.getMovementForward();
            double strafe = (double)input.getMovementStrafe();
            double length = Math.sqrt(forward * forward + strafe * strafe);
            if (length > (double)1.0F) {
               forward /= length;
               strafe /= length;
            }

            double yaw = Math.toRadians(this.isFastMode() ? (double)this.fakeYaw : (double)mc.field_1724.method_36454());
            double motionX = (forward * -Math.sin(yaw) + strafe * Math.cos(yaw)) * this.speed.get().doubleValue();
            double motionZ = (forward * Math.cos(yaw) + strafe * Math.sin(yaw)) * this.speed.get().doubleValue();
            this.prevFakeX = this.fakeX;
            this.prevFakeY = this.fakeY;
            this.prevFakeZ = this.fakeZ;
            this.fakeX += motionX;
            this.fakeZ += motionZ;
            if (input.isJump()) {
               this.fakeY += (double)this.yspeed.get().floatValue();
            }

            if (input.isSneak()) {
               this.fakeY -= (double)this.yspeed.get().floatValue();
            }
         }

         mc.field_1724.field_3913.field_3905 = 0.0F;
         mc.field_1724.field_3913.field_3907 = 0.0F;
      }

      if (event instanceof EventMotion eventMotion) {
         if (mc.field_1724 != null && this.freezePosition != class_243.field_1353) {
            eventMotion.setCancel(true);
            mc.field_1724.method_33574(this.freezePosition);
            mc.field_1724.method_18799(class_243.field_1353);
         }

         this.prevFakeYaw = this.fakeYaw;
         this.prevFakePitch = this.fakePitch;
         if (this.trackEntity != null) {
            this.fakeYaw = this.trackEntity.method_36454();
            this.fakePitch = this.trackEntity.method_36455();
            this.prevFakeX = this.fakeX;
            this.prevFakeY = this.fakeY;
            this.prevFakeZ = this.fakeZ;
            this.fakeX = this.trackEntity.method_23317();
            this.fakeY = this.trackEntity.method_23318() + (double)this.trackEntity.method_18381(this.trackEntity.method_18376());
            this.fakeZ = this.trackEntity.method_23321();
         } else if (!this.isFastMode()) {
            this.fakeYaw = mc.field_1724.method_36454();
            this.fakePitch = mc.field_1724.method_36455();
         }
      }

      if (event instanceof EventMotion eventMove) {
         eventMove.setX((double)0.0F);
         eventMove.setY((double)0.0F);
         eventMove.setZ((double)0.0F);
         eventMove.setCancel(true);
      }

   }

   public void onEnable() {
      if (mc.field_1724 != null) {
         this.freezePosition = mc.field_1724.method_19538();
      }

      this.previousChunkCulling = mc.field_1730;
      mc.field_1730 = false;
      this.trackEntity = null;
      this.fakePitch = mc.field_1724.method_36455();
      this.fakeYaw = mc.field_1724.method_36454();
      this.prevFakePitch = this.fakePitch;
      this.prevFakeYaw = this.fakeYaw;
      this.fakeX = mc.field_1724.method_23317();
      this.fakeY = mc.field_1724.method_23318() + (double)mc.field_1724.method_18381(mc.field_1724.method_18376());
      this.fakeZ = mc.field_1724.method_23321();
      this.prevFakeX = mc.field_1724.method_23317();
      this.prevFakeY = this.fakeY;
      this.prevFakeZ = mc.field_1724.method_23321();
   }

   public void onDisable() {
      mc.field_1730 = this.previousChunkCulling;
      this.freezePosition = class_243.field_1353;
   }

   public float getFakeYaw() {
      return (float)interpolate((double)this.prevFakeYaw, (double)this.fakeYaw, (double)mc.method_61966().method_60637(true));
   }

   public float getFakePitch() {
      return (float)interpolate((double)this.prevFakePitch, (double)this.fakePitch, (double)mc.method_61966().method_60637(true));
   }

   public double getFakeX() {
      return MathUtil.interpolate(this.prevFakeX, this.fakeX, (double)mc.method_61966().method_60637(true));
   }

   public double getFakeY() {
      return MathUtil.interpolate(this.prevFakeY, this.fakeY, (double)mc.method_61966().method_60637(true));
   }

   public double getFakeZ() {
      return MathUtil.interpolate(this.prevFakeZ, this.fakeZ, (double)mc.method_61966().method_60637(true));
   }

   public static double interpolate(double oldValue, double newValue, double interpolationValue) {
      return oldValue + (newValue - oldValue) * interpolationValue;
   }
}
