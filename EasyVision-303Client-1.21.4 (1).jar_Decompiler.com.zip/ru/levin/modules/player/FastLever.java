package ru.levin.modules.player;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_3610;
import net.minecraft.class_3612;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "FastLever",
   desc = "Automatycznie używa dźwigni do niszczenia źródeł płynów wrogów (wersja FastClient)",
   type = Type.Player
)
public class FastLever extends Function {
   private final SliderSetting speed = new SliderSetting("Szybkość", (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F);
   private int cooldown = 0;
   private boolean isRotating = false;
   private float oldYaw;
   private float oldPitch;
   private final Map<class_2338, Long> FRIENDLY_FLUID = new HashMap();
   private final Set<class_2338> OWNED_FLUID = new HashSet();
   private final Set<class_2338> LAST_SOURCES = new HashSet();
   private long lastSelfPlaceMs = 0L;
   private class_2338 lastSelfPlacePos = null;
   private static final long SELF_WINDOW_MS = 2000L;
   private static final int SELF_RADIUS = 2;
   private static final long FRIENDLY_PROPAGATE_MS = 10000L;
   private static final long FRIENDLY_GRACE_MS = 2500L;

   public FastLever() {
      this.addSettings(new Setting[]{this.speed});
   }

   protected void onEnable() {
      this.reset();
   }

   protected void onDisable() {
      this.reset();
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null) {
         if (this.cooldown > 0) {
            --this.cooldown;
            if (this.cooldown == 0) {
               this.restoreRotation();
            }
         }

         this.updateFriendlySources();
         if (!this.isHoldingAnyBucket(mc.field_1724) && mc.field_1755 == null && this.cooldown <= 0 && this.hasLever(mc.field_1724) && !this.shouldYieldToFriendlyWater() && this.isOpponentWithBucketNearby()) {
            class_2338 targetPos = this.findFluidTarget();
            if (targetPos != null) {
               this.executeAction(targetPos);
            }
         }

      }
   }

   private void reset() {
      this.restoreRotation();
      this.cooldown = 0;
   }

   private void restoreRotation() {
      if (this.isRotating) {
         if (mc.field_1724 != null) {
            mc.field_1724.method_36456(this.oldYaw);
            mc.field_1724.method_36457(this.oldPitch);
         }

         this.isRotating = false;
      }

   }

   private boolean hasLever(class_1657 player) {
      if (player.method_6047().method_31574(class_1802.field_8865)) {
         return true;
      } else {
         for(int i = 0; i < 9; ++i) {
            if (player.method_31548().method_5438(i).method_31574(class_1802.field_8865)) {
               return true;
            }
         }

         return false;
      }
   }

   private boolean isOpponentWithBucketNearby() {
      for(class_1657 player : mc.field_1687.method_18456()) {
         if (player != mc.field_1724) {
            String name = player.method_5477().getString().toLowerCase();
            if (!Manager.FRIEND_MANAGER.isFriend(name) && mc.field_1724.method_5858(player) <= (double)25.0F && this.isHoldingAnyBucket(player)) {
               return true;
            }
         }
      }

      return false;
   }

   private boolean shouldYieldToFriendlyWater() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         for(class_1657 player : mc.field_1687.method_18456()) {
            if (player != null && player != mc.field_1724) {
               String name = player.method_5477().getString().toLowerCase();
               if (Manager.FRIEND_MANAGER.isFriend(name) && mc.field_1724.method_5858(player) <= (double)25.0F && this.isHoldingAnyBucket(player)) {
                  return true;
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private boolean isHoldingAnyBucket(class_1657 player) {
      return player.method_6047().method_31574(class_1802.field_8550) || player.method_6047().method_31574(class_1802.field_8705) || player.method_6047().method_31574(class_1802.field_8187) || player.method_6079().method_31574(class_1802.field_8550) || player.method_6079().method_31574(class_1802.field_8705) || player.method_6079().method_31574(class_1802.field_8187);
   }

   private class_2338 findFluidTarget() {
      class_2338 pPos = mc.field_1724.method_24515();
      class_2338 best = null;
      double bestDist = Double.MAX_VALUE;

      for(class_2338 pos : class_2338.method_10097(pPos.method_10069(-5, -3, -5), pPos.method_10069(5, 3, 5))) {
         if (this.isFreeFluidSource(pos) && !this.isFriendlyFluid(pos)) {
            double dist = mc.field_1724.method_33571().method_1025(class_243.method_24953(pos));
            if (dist <= (double)20.25F && this.canSee(pos) && dist < bestDist) {
               bestDist = dist;
               best = pos.method_10062();
            }
         }
      }

      return best;
   }

   private boolean canSee(class_2338 pos) {
      class_243 eyePos = mc.field_1724.method_33571();
      class_243 targetPos = class_243.method_24953(pos);
      double dist = eyePos.method_1025(targetPos);
      return dist <= (double)100.0F;
   }

   private void executeAction(class_2338 fluidPos) {
      class_2338 solidPos = this.findAdjacentSolidBlock(fluidPos);
      if (solidPos != null && mc.field_1724.method_33571().method_1025(class_243.method_24953(solidPos)) <= (double)20.25F && this.canSee(solidPos)) {
         if (!this.isRotating) {
            this.oldYaw = mc.field_1724.method_36454();
            this.oldPitch = mc.field_1724.method_36455();
            this.isRotating = true;
         }

         this.rotateToBlock(solidPos);
         class_3965 hit = this.raycastToBlock(solidPos);
         if (hit == null) {
            this.restoreRotation();
         } else {
            this.performAction(hit);
         }
      }

   }

   private void performAction(class_3965 bhr) {
      if (mc.field_1761 != null) {
         class_1268 hand = mc.field_1724.method_6047().method_31574(class_1802.field_8865) ? class_1268.field_5810 : class_1268.field_5808;
         if (hand == class_1268.field_5808) {
            int slot = this.findLeverSlot();
            if (slot == -1) {
               return;
            }

            mc.field_1724.method_31548().field_7545 = slot;
         }

         class_1269 result = mc.field_1761.method_2896(mc.field_1724, hand, bhr);
         if (result.method_23665()) {
            mc.field_1724.method_6104(hand);
         }

         this.cooldown = this.computeCooldown();
      }

   }

   private int findLeverSlot() {
      for(int i = 0; i < 9; ++i) {
         if (mc.field_1724.method_31548().method_5438(i).method_31574(class_1802.field_8865)) {
            return i;
         }
      }

      return -1;
   }

   private class_2338 findAdjacentSolidBlock(class_2338 pos) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         if (this.hasBlockAboveHead()) {
            class_2338 down = this.findSolidNeighbor(pos, new class_2350[]{class_2350.field_11033});
            if (down != null) {
               return down;
            } else {
               class_2338 side = this.findSolidNeighbor(pos, new class_2350[]{class_2350.field_11043, class_2350.field_11035, class_2350.field_11039, class_2350.field_11034});
               if (side != null) {
                  return side;
               } else {
                  class_2338 up = this.findSolidNeighbor(pos, new class_2350[]{class_2350.field_11036});
                  return up;
               }
            }
         } else {
            for(class_2350 d : class_2350.values()) {
               class_2338 neighbor = pos.method_10093(d);
               if (mc.field_1687.method_8320(neighbor).method_26212(mc.field_1687, neighbor)) {
                  return neighbor;
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private class_2338 findSolidNeighbor(class_2338 pos, class_2350[] dirs) {
      for(class_2350 d : dirs) {
         class_2338 neighbor = pos.method_10093(d);
         if (mc.field_1687.method_8320(neighbor).method_26212(mc.field_1687, neighbor)) {
            return neighbor;
         }
      }

      return null;
   }

   private boolean hasBlockAboveHead() {
      class_2338 above = mc.field_1724.method_24515().method_10086(2);
      return mc.field_1687.method_8320(above).method_26212(mc.field_1687, above);
   }

   private boolean isFriendlyFluid(class_2338 pos) {
      return this.OWNED_FLUID.contains(pos) || this.FRIENDLY_FLUID.containsKey(pos);
   }

   private void updateFriendlySources() {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         long now = System.currentTimeMillis();
         class_2338 pPos = mc.field_1724.method_24515();
         Set<class_2338> current = new HashSet();

         for(class_2338 pos : class_2338.method_10097(pPos.method_10069(-5, -3, -5), pPos.method_10069(5, 3, 5))) {
            if (this.isFreeFluidSource(pos)) {
               class_2338 bp = pos.method_10062();
               current.add(bp);
               if (!this.LAST_SOURCES.contains(bp) && this.isLikelyFriendPlaced(bp)) {
                  this.FRIENDLY_FLUID.put(bp, now);
                  this.OWNED_FLUID.add(bp);
               } else if (!this.LAST_SOURCES.contains(bp) && this.isLikelySelfPlaced(bp, now)) {
                  this.FRIENDLY_FLUID.put(bp, now);
                  this.OWNED_FLUID.add(bp);
               } else if (!this.LAST_SOURCES.contains(bp) && this.isAdjacentToRecentFriendly(bp, now)) {
                  this.FRIENDLY_FLUID.put(bp, now);
               }
            }
         }

         this.LAST_SOURCES.clear();
         this.LAST_SOURCES.addAll(current);
         this.pruneFriendlyFluid();
      } else {
         this.FRIENDLY_FLUID.clear();
         this.OWNED_FLUID.clear();
         this.LAST_SOURCES.clear();
      }
   }

   private boolean isLikelySelfPlaced(class_2338 pos, long now) {
      if (this.lastSelfPlacePos == null) {
         return false;
      } else if (now - this.lastSelfPlaceMs > 2000L) {
         return false;
      } else {
         return this.lastSelfPlacePos.method_10262(pos) <= (double)4.0F;
      }
   }

   private boolean isAdjacentToRecentFriendly(class_2338 pos, long now) {
      for(class_2350 d : class_2350.values()) {
         class_2338 n = pos.method_10093(d);
         if (this.OWNED_FLUID.contains(n)) {
            return true;
         }

         Long t = (Long)this.FRIENDLY_FLUID.get(n);
         if (t != null && now - t <= 10000L) {
            return true;
         }
      }

      return false;
   }

   private boolean isLikelyFriendPlaced(class_2338 pos) {
      class_243 center = class_243.method_24953(pos);

      for(class_1657 player : mc.field_1687.method_18456()) {
         if (player != null && player != mc.field_1724) {
            String name = player.method_5477().getString().toLowerCase();
            if (Manager.FRIEND_MANAGER.isFriend(name) && player.method_5707(center) <= (double)49.0F && this.isHoldingAnyBucket(player)) {
               return true;
            }
         }
      }

      return false;
   }

   private void pruneFriendlyFluid() {
      if (mc.field_1687 != null) {
         long now = System.currentTimeMillis();
         Iterator<Map.Entry<class_2338, Long>> it = this.FRIENDLY_FLUID.entrySet().iterator();

         while(it.hasNext()) {
            Map.Entry<class_2338, Long> e = (Map.Entry)it.next();
            if (!this.isFreeFluidSource((class_2338)e.getKey()) && now - (Long)e.getValue() > 2500L) {
               it.remove();
            }
         }

         for(class_2338 pos : this.OWNED_FLUID) {
            if (!this.isFreeFluidSource(pos)) {
               Long t = (Long)this.FRIENDLY_FLUID.get(pos);
               if (t == null || now - t > 2500L) {
                  this.OWNED_FLUID.remove(pos);
               }
            }
         }

      }
   }

   private boolean isFreeFluidSource(class_2338 pos) {
      if (mc.field_1687 != null && pos != null) {
         class_3610 fluid = mc.field_1687.method_8316(pos);
         if ((fluid.method_15772() == class_3612.field_15910 || fluid.method_15772() == class_3612.field_15908) && fluid.method_15771()) {
            return !this.isWaterlogged(mc.field_1687.method_8320(pos));
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   private boolean isWaterlogged(class_2680 state) {
      return state.method_26227().method_15772() == class_3612.field_15910;
   }

   private class_3965 raycastToBlock(class_2338 pos) {
      class_243 eyePos = mc.field_1724.method_33571();
      class_243 targetPos = class_243.method_24953(pos);
      return new class_3965(targetPos, class_2350.field_11036, pos, false);
   }

   private void rotateToBlock(class_2338 pos) {
      class_243 target = class_243.method_24953(pos);
      class_243 eye = mc.field_1724.method_33571();
      double dx = target.field_1352 - eye.field_1352;
      double dy = target.field_1351 - eye.field_1351;
      double dz = target.field_1350 - eye.field_1350;
      float yaw = (float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F;
      float pitch = (float)(-Math.toDegrees(Math.atan2(dy, Math.sqrt(dx * dx + dz * dz))));
      mc.field_1724.method_36456(yaw);
      mc.field_1724.method_36457(pitch);
   }

   private int computeCooldown() {
      float speedVal = this.speed.get().floatValue();
      if (Float.isNaN(speedVal) || Float.isInfinite(speedVal)) {
         speedVal = 100.0F;
      }

      speedVal = Math.max(0.0F, Math.min(100.0F, speedVal));
      int cd = (int)(9.0F - speedVal / 12.0F);
      if (cd < 1) {
         cd = 1;
      }

      return cd;
   }
}
