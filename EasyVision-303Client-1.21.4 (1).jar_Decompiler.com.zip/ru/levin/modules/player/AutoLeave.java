package ru.levin.modules.player;

import net.minecraft.class_2561;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "AutoLeave",
   desc = "Automatycznie opuszcza serwer",
   type = Type.Player
)
public class AutoLeave extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Gracz w pobliżu", new String[]{"Gracz w pobliżu", "Mało HP"});
   private final SliderSetting heal = new SliderSetting("Zdrowie", (double)3.0F, (double)1.0F, (double)20.0F, (double)1.0F, () -> this.mode.is("Mało HP"));
   private final SliderSetting radius = new SliderSetting("Odległość od gracza", (double)60.0F, (double)20.0F, (double)150.0F, (double)1.0F, () -> this.mode.is("Gracz w pobliżu"));
   private final ModeSetting run = new ModeSetting("Działanie", "Opuść serwer", new String[]{"Opuść serwer", "/hub", "Teleportacja do domu"});
   private final TextSetting homeName = new TextSetting("Nazwa punktu domu", "home", () -> this.run.is("Teleportacja do domu"));
   private final BooleanSetting pvpNoLeave = new BooleanSetting("Nie opuszczaj serwera w trybie PvP", true, () -> this.run.is("Opuść serwer") || this.run.is("/hub"));
   private boolean triggered = false;

   public AutoLeave() {
      this.addSettings(new Setting[]{this.mode, this.heal, this.radius, this.run, this.homeName, this.pvpNoLeave});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            if (!this.pvpNoLeave.get() || !ClientManager.playerIsPVP()) {
               boolean shouldTrigger = false;
               if (this.mode.is("Mało HP") && mc.field_1724.method_6032() <= this.heal.get().floatValue()) {
                  shouldTrigger = true;
               } else if (this.mode.is("Gracz w pobliżu")) {
                  shouldTrigger = Manager.SYNC_MANAGER.getPlayers().stream().anyMatch((other) -> other != mc.field_1724 && mc.field_1724.method_5739(other) <= this.radius.get().floatValue());
               }

               if (shouldTrigger && !this.triggered) {
                  this.executeAction();
                  this.triggered = true;
               } else if (!shouldTrigger) {
                  this.triggered = false;
               }

            }
         }
      }
   }

   private void executeAction() {
      if (mc.field_1724 != null) {
         if (this.run.is("Opuść serwer")) {
            mc.field_1724.field_3944.method_48296().method_10747(class_2561.method_43470("AutoLeave"));
         } else if (this.run.is("/hub")) {
            mc.field_1724.field_3944.method_45730("hub");
         } else if (this.run.is("Teleportacja do domu")) {
            mc.field_1724.field_3944.method_45730("home " + this.homeName.getValue());
         }

         this.toggle();
      }
   }
}
