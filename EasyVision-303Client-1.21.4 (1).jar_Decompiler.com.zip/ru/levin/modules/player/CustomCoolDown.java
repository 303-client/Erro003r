package ru.levin.modules.player;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.ClientManager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "CustomCoolDown",
   type = Type.Player,
   desc = "Automatycznie ustawia czas odnowienia przedmiotów"
)
public class CustomCoolDown extends Function {
   private final MultiSetting items = new MultiSetting("Opóźnienie", Arrays.asList("Złote jabłko", "Owoc chorus", "Perła Endu"), new String[]{"Złote jabłko", "Owoc chorus", "Perła Endu"});
   private final SliderSetting appleTime = new SliderSetting("Czas odnowienia złotego jabłka", (double)4.6F, (double)1.0F, (double)16.0F, (double)0.1F, () -> this.items.get("Złote jabłko"));
   private final SliderSetting pearlTime = new SliderSetting("Czas odnowienia perły Endu", (double)13.5F, (double)1.0F, (double)16.0F, (double)0.1F, () -> this.items.get("Perła Endu"));
   private final SliderSetting horusTime = new SliderSetting("Czas odnowienia owocu chorus", (double)3.5F, (double)1.0F, (double)16.0F, (double)0.1F, () -> this.items.get("Owoc chorus"));
   public BooleanSetting PVPonly = new BooleanSetting("Tylko w trybie PvP", false);
   public final Map<class_1792, Long> lastUseMap = new HashMap();

   public CustomCoolDown() {
      this.addSettings(new Setting[]{this.items, this.appleTime, this.pearlTime, this.horusTime, this.PVPonly});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null) {
         if (!this.PVPonly.get() || ClientManager.playerIsPVP()) {
            Iterator<Map.Entry<class_1792, Long>> iterator = this.lastUseMap.entrySet().iterator();

            while(iterator.hasNext()) {
               Map.Entry<class_1792, Long> entry = (Map.Entry)iterator.next();
               float delay = this.getCooldownForItem((class_1792)entry.getKey()) * 1000.0F;
               if ((float)(System.currentTimeMillis() - (Long)entry.getValue()) >= delay) {
                  iterator.remove();
               }
            }

            if (mc.field_1724.method_6115()) {
               class_1799 activeStack = mc.field_1724.method_6030();
               class_1792 item = activeStack.method_7909();
               if (this.isItemEnabled(item) && this.lastUseMap.containsKey(item)) {
                  mc.field_1724.method_6021();
               }
            }

         }
      }
   }

   public float getCooldownForItem(class_1792 item) {
      if (item == class_1802.field_8463) {
         return this.appleTime.get().floatValue();
      } else if (item == class_1802.field_8634) {
         return this.pearlTime.get().floatValue();
      } else {
         return item == class_1802.field_8233 ? this.horusTime.get().floatValue() : 0.0F;
      }
   }

   public boolean isItemEnabled(class_1792 item) {
      if (item == class_1802.field_8463) {
         return this.items.get("Złote jabłko");
      } else if (item == class_1802.field_8634) {
         return this.items.get("Perła Endu");
      } else {
         return item == class_1802.field_8233 ? this.items.get("Owoc chorus") : false;
      }
   }

   public void setCooldown(class_1792 item) {
      this.lastUseMap.put(item, System.currentTimeMillis());
   }
}
