package ru.levin.modules.player;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ItemScroll",
   desc = "Szybkie przenoszenie",
   type = Type.Player
)
public class ItemScroller extends Function {
   public SliderSetting scroll = new SliderSetting("Opóźnienie", (double)100.0F, (double)1.0F, (double)100.0F, (double)1.0F);

   public ItemScroller() {
      this.addSettings(new Setting[]{this.scroll});
   }

   public void onEvent(Event event) {
   }
}
