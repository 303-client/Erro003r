package ru.levin.modules.misc;

import net.minecraft.class_124;
import net.minecraft.class_418;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.ClientManager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "DeathCoords",
   type = Type.Misc,
   desc = "Wysyła współrzędne po śmierci"
)
public class DeathCoords extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.isPlayerDead()) {
         int positionX = (int)mc.field_1724.method_23317();
         int positionY = (int)mc.field_1724.method_23318();
         int positionZ = (int)mc.field_1724.method_23321();
         if (mc.field_1724.field_6213 < 1) {
            String message = "Współrzędne: " + String.valueOf(class_124.field_1080) + "X: " + positionX + " Y: " + positionY + " Z: " + positionZ + String.valueOf(class_124.field_1070);
            ClientManager.message(message);
         }
      }

   }

   private boolean isPlayerDead() {
      return mc.field_1724.method_6032() < 1.0F && mc.field_1755 instanceof class_418;
   }
}
