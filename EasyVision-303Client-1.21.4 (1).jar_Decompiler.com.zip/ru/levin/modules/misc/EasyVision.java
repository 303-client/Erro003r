package ru.levin.modules.misc;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.util.render.EasyVisionUtil;

@FunctionAnnotation(
   name = "EasyVision",
   desc = "Pokazuje tylko wybrane bloki",
   type = Type.Render
)
public final class EasyVision extends Function {
   private final TextSetting blocks = new TextSetting("Bloki (ID po przecinku)", "minecraft:diamond_ore,minecraft:deepslate_diamond_ore");

   public EasyVision() {
      this.addSettings(new Setting[]{this.blocks});
   }

   public void onEvent(Event var1) {
      EasyVisionUtil.refresh(this);
   }

   protected void onEnable() {
      EasyVisionUtil.refresh(this);
   }

   protected void onDisable() {
      EasyVisionUtil.refresh(this);
   }

   public String getBlockIds() {
      return this.blocks.getValue();
   }
}
