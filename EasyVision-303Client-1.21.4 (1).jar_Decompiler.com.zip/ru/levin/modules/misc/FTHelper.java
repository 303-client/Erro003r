package ru.levin.modules.misc;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import ru.levin.events.Event;
import ru.levin.events.impl.input.EventKey;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.InventoryUtil;

@FunctionAnnotation(
   name = "FTHelper",
   desc = "Szybka obsługa przedmiotów na FunTime",
   type = Type.Misc
)
public class FTHelper extends Function {
   private final BindSetting trapka = new BindSetting("Klawisz pułapki", 0);
   private final BindSetting disorientation = new BindSetting("Klawisz dezorientacji", 0);
   private final BindSetting plast = new BindSetting("Klawisz ładunku", 0);
   private final BindSetting godaura = new BindSetting("Klawisz boskiej aury", 0);
   private final BooleanSetting inventoryUse = new BooleanSetting("Używaj z ekwipunku", true);
   private final Map<BindSetting, class_1792> binds = new LinkedHashMap();

   public FTHelper() {
      this.addSettings(new Setting[]{this.trapka, this.disorientation, this.plast, this.godaura, this.inventoryUse});
      this.binds.put(this.trapka, class_1802.field_22021);
      this.binds.put(this.disorientation, class_1802.field_8449);
      this.binds.put(this.plast, class_1802.field_8551);
      this.binds.put(this.godaura, class_1802.field_8614);
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey eventKey) {
         if (mc.field_1724 != null) {
            int pressedKey = eventKey.key;

            for(Map.Entry<BindSetting, class_1792> entry : this.binds.entrySet()) {
               if (pressedKey == ((BindSetting)entry.getKey()).getKey()) {
                  this.useItem((class_1792)entry.getValue());
                  return;
               }
            }

            return;
         }
      }

   }

   private void useItem(class_1792 item) {
      int[] slots = this.findSlots(item);
      InventoryUtil.use(slots[0], slots[1], this.inventoryUse.get());
   }

   private int[] findSlots(class_1792 item) {
      if (mc.field_1724 == null) {
         return new int[]{-1, -1};
      } else {
         class_1661 inv = mc.field_1724.method_31548();
         int size = inv.method_5439();
         int hotbarSlot = -1;
         int inventorySlot = -1;

         for(int i = 0; i < size; ++i) {
            class_1799 stack = inv.method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
               if (i < 9) {
                  if (hotbarSlot == -1) {
                     hotbarSlot = i;
                  }

                  if (inventorySlot == -1) {
                     inventorySlot = i + 36;
                  }
               } else if (inventorySlot == -1) {
                  inventorySlot = i;
               }

               if (hotbarSlot != -1 && inventorySlot != -1) {
                  break;
               }
            }
         }

         return new int[]{hotbarSlot, inventorySlot};
      }
   }
}
