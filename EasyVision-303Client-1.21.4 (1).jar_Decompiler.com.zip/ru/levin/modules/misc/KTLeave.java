package ru.levin.modules.misc;

import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1690;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2661;
import net.minecraft.class_2684;
import net.minecraft.class_2692;
import net.minecraft.class_2740;
import net.minecraft.class_2824;
import net.minecraft.class_2827;
import net.minecraft.class_2828;
import net.minecraft.class_2833;
import net.minecraft.class_2851;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.player.EventPlayerTravel;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.move.MoveUtil;
import ru.levin.util.move.NetworkUtils;

@FunctionAnnotation(
   name = "KTLeave",
   desc = "Zostałeś użytkownikiem Calestium",
   type = Type.Misc
)
public class KTLeave extends Function {
   private final ModeSetting mode = new ModeSetting("Moduł", "Motion", new String[]{"Motion", "Packet"});
   private final BooleanSetting phase = new BooleanSetting("Phase", false);
   private final BooleanSetting gravity = new BooleanSetting("Gravity", false);
   private final BooleanSetting automount = new BooleanSetting("AutoMount", false);
   private final BooleanSetting allowShift = new BooleanSetting("AllowShift", false);
   private final SliderSetting speed = new SliderSetting("Speed", (double)2.0F, (double)0.0F, (double)25.0F, (double)0.1F);
   private final SliderSetting yspeed = new SliderSetting("YSpeed", (double)1.0F, (double)0.0F, (double)10.0F, (double)0.1F);
   private final BooleanSetting cancel = new BooleanSetting("Cancel", false);
   private final BooleanSetting stopunloaded = new BooleanSetting("StopUnloaded", false);
   private final BooleanSetting cancelrotations = new BooleanSetting("CancelRotations", false);
   private final BooleanSetting limit = new BooleanSetting("Limit", false);
   private final SliderSetting jitter = new SliderSetting("Jitter", (double)0.1F, (double)0.0F, (double)10.0F, (double)0.1F);
   private final BooleanSetting spoofpackets = new BooleanSetting("SpoofPackets", false);
   private final BooleanSetting ongroundpacket = new BooleanSetting("OnGroundPacket", false);
   private final CopyOnWriteArrayList<class_2833> vehiclePackets = new CopyOnWriteArrayList();
   private int ticksEnabled = 0;
   private int enableDelay = 0;
   private boolean waitedCooldown = false;
   private boolean returnGravity = false;
   private boolean jitterSwitch = false;

   public KTLeave() {
      this.addSettings(new Setting[]{this.mode, this.phase, this.gravity, this.automount, this.allowShift, this.speed, this.yspeed, this.cancel, this.stopunloaded, this.cancelrotations, this.limit, this.jitter, this.spoofpackets, this.ongroundpacket});
   }

   private boolean fullNullCheck() {
      return mc.field_1724 == null || mc.field_1687 == null;
   }

   public void onEnable() {
      if (this.fullNullCheck()) {
         this.toggle();
      } else {
         if (this.automount.get()) {
            this.mountToBoat();
         }

      }
   }

   public void onDisable() {
      this.vehiclePackets.clear();
      this.waitedCooldown = false;
      if (mc.field_1724 != null) {
         if (this.phase.get() && this.mode.is("Motion")) {
            if (mc.field_1724.method_49694() != null) {
               mc.field_1724.method_49694().field_5960 = false;
            }

            mc.field_1724.field_5960 = false;
         }

         if (mc.field_1724.method_49694() != null) {
            mc.field_1724.method_49694().method_5875(false);
         }

         mc.field_1724.method_5875(false);
      }
   }

   private float randomizeYOffset() {
      this.jitterSwitch = !this.jitterSwitch;
      return this.jitterSwitch ? this.jitter.get().floatValue() : -this.jitter.get().floatValue();
   }

   private void sendMovePacket(class_2833 pac) {
      this.vehiclePackets.add(pac);
      this.send(pac);
   }

   private void teleportToGround(class_1297 boat) {
      if (boat != null && mc.field_1687 != null) {
         class_2338 blockPos = class_2338.method_49638(boat.method_19538());

         for(int i = 0; i < 255; ++i) {
            if (!mc.field_1687.method_8320(blockPos).method_45474() || mc.field_1687.method_8320(blockPos).method_26204() == class_2246.field_10382) {
               boat.method_5814(boat.method_23317(), (double)(blockPos.method_10264() + 1), boat.method_23321());
               this.sendMovePacket(class_2833.method_65307(boat));
               boat.method_5814(boat.method_23317(), boat.method_23318(), boat.method_23321());
               break;
            }

            blockPos = blockPos.method_10074();
         }

      }
   }

   private void mountToBoat() {
      if (mc.field_1724 != null && mc.field_1687 != null) {
         for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
            if (entity instanceof class_1690 && !(mc.field_1724.method_5858(entity) > (double)25.0F)) {
               this.send(class_2824.method_34207(entity, false, class_1268.field_5808));
               break;
            }
         }

      }
   }

   public void onEvent(Event event) {
      if (event instanceof EventPlayerTravel ev) {
         if (!ev.isPre() || this.fullNullCheck()) {
            return;
         }

         class_1297 entity = mc.field_1724.method_49694();
         if (entity == null) {
            if (this.automount.get()) {
               this.mountToBoat();
            }

            return;
         }

         if (this.phase.get() && this.mode.is("Motion")) {
            entity.field_5960 = true;
            entity.method_5875(true);
            mc.field_1724.field_5960 = true;
         }

         if (!this.returnGravity) {
            entity.method_5875(!this.gravity.get());
            mc.field_1724.method_5875(!this.gravity.get());
         }

         if ((!mc.field_1687.method_8393((int)entity.method_23317() >> 4, (int)entity.method_23321() >> 4) || entity.method_23318() < (double)-60.0F) && this.stopunloaded.get()) {
            this.returnGravity = true;
            return;
         }

         entity.method_36456(mc.field_1724.method_36454());
         double[] boatMotion = MoveUtil.forward((double)this.speed.get().floatValue());
         double predictedX = entity.method_23317() + boatMotion[0];
         double predictedZ = entity.method_23321() + boatMotion[1];
         double predictedY = entity.method_23318();
         if ((!mc.field_1687.method_8393((int)predictedX >> 4, (int)predictedZ >> 4) || predictedY < (double)-60.0F) && this.stopunloaded.get()) {
            this.returnGravity = true;
            return;
         }

         this.returnGravity = false;
         if (this.mode.is("Motion")) {
            entity.method_18800(boatMotion[0], entity.method_18798().field_1351, boatMotion[1]);
         }

         if (mc.field_1690.field_1903.method_1434()) {
            if (this.mode.is("Motion")) {
               entity.method_18800(entity.method_18798().field_1352, entity.method_18798().field_1351 + (double)this.yspeed.get().floatValue(), entity.method_18798().field_1350);
            } else {
               predictedY += (double)this.yspeed.get().floatValue();
            }
         } else if (mc.field_1690.field_1832.method_1434()) {
            if (this.mode.is("Motion")) {
               entity.method_18800(entity.method_18798().field_1352, entity.method_18798().field_1351 - (double)this.yspeed.get().floatValue(), entity.method_18798().field_1350);
            } else {
               predictedY -= (double)this.yspeed.get().floatValue();
            }
         }

         if (!MoveUtil.isMoving()) {
            entity.method_18800((double)0.0F, entity.method_18798().field_1351, (double)0.0F);
         }

         if (this.ongroundpacket.get()) {
            this.teleportToGround(entity);
         }

         if (this.mode.is("Packet")) {
            entity.method_5814(predictedX, predictedY, predictedZ);
            this.sendMovePacket(class_2833.method_65307(entity));
         }

         ev.setCancel(true);
         ++this.ticksEnabled;
      }

      if (event instanceof EventPacket eventPacket) {
         if (eventPacket.isReceivePacket()) {
            if (this.fullNullCheck()) {
               return;
            }

            if (eventPacket.getPacket() instanceof class_2661) {
               this.toggle();
            }

            if (!mc.field_1724.method_3144() || this.returnGravity || this.waitedCooldown) {
               return;
            }

            if (this.cancel.get() && (eventPacket.getPacket() instanceof class_2692 || eventPacket.getPacket() instanceof class_2684 || eventPacket.getPacket() instanceof class_2740 || !(eventPacket.getPacket() instanceof class_2827))) {
               eventPacket.setCancel(true);
            }
         }
      }

      if (event instanceof EventPacket eventPacket2) {
         if (eventPacket2.isSendPacket()) {
            if (this.fullNullCheck()) {
               return;
            }

            if ((eventPacket2.getPacket() instanceof class_2828.class_2831 && this.cancelrotations.get() || eventPacket2.getPacket() instanceof class_2851) && mc.field_1724.method_3144()) {
               eventPacket2.setCancel(true);
            }

            if (this.returnGravity && eventPacket2.getPacket() instanceof class_2833) {
               eventPacket2.setCancel(true);
            }

            if (eventPacket2.getPacket() instanceof class_2851 && this.allowShift.get()) {
               eventPacket2.setCancel(true);
            }

            if (mc.field_1724.method_49694() == null || this.returnGravity || this.waitedCooldown) {
               return;
            }

            class_243 boatPos = mc.field_1724.method_49694().method_19538();
            if ((!mc.field_1687.method_8393((int)boatPos.field_1352 >> 4, (int)boatPos.field_1350 >> 4) || boatPos.field_1351 < (double)-60.0F) && this.stopunloaded.get()) {
               return;
            }

            class_2596 var15 = eventPacket2.getPacket();
            if (var15 instanceof class_2833) {
               class_2833 pac = (class_2833)var15;
               if (this.limit.get() && this.mode.is("Packet")) {
                  if (this.vehiclePackets.contains(pac)) {
                     this.vehiclePackets.remove(pac);
                  } else {
                     eventPacket2.setCancel(true);
                  }
               }
            }
         }
      }

   }

   private void send(class_2596<?> packet) {
      if (mc.field_1724 != null && mc.field_1724.field_3944 != null) {
         NetworkUtils.sendSilentPacket(packet);
      }

   }
}
