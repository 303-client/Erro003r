package ru.levin.modules.misc;

import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1533;
import net.minecraft.class_1534;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3532;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "AutoBreak",
   desc = "Automatycznie niszczy ramki i obrazy",
   type = Type.Misc
)
public class AutoBreak extends Function {
   private final SliderSetting range = new SliderSetting("Zasięg", (double)3.0F, (double)1.0F, (double)6.0F, (double)1.0F);
   private final SliderSetting cooldown = new SliderSetting("Cooldown", (double)350.0F, (double)50.0F, (double)1000.0F, (double)10.0F);
   private final BooleanSetting itemFrames = new BooleanSetting("Ramki", true);
   private final BooleanSetting paintings = new BooleanSetting("Obrazy", true);
   private final BooleanSetting ignoreFriends = new BooleanSetting("Ignoruj znajomych", true);
   private long nextAttack;

   public AutoBreak() {
      this.addSettings(new Setting[]{this.range, this.cooldown, this.itemFrames, this.paintings, this.ignoreFriends});
   }

   protected void onEnable() {
      this.nextAttack = 0L;
   }

   protected void onDisable() {
      this.nextAttack = 0L;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && mc.field_1755 == null) {
         long now = System.currentTimeMillis();
         if (now >= this.nextAttack) {
            class_1297 target = this.findTarget();
            if (target != null) {
               this.aimAt(target);
               if (this.isAimedAt(target, 6.0F)) {
                  mc.field_1761.method_2918(mc.field_1724, target);
                  mc.field_1724.method_6104(class_1268.field_5808);
                  this.nextAttack = now + Math.max(50L, this.cooldown.get().longValue());
               }
            }
         }
      }
   }

   private class_1297 findTarget() {
      double maxDistance = this.range.get().doubleValue();
      class_238 searchBox = mc.field_1724.method_5829().method_1014(maxDistance);
      class_1297 nearest = null;
      double nearestDistance = Double.MAX_VALUE;
      if (this.itemFrames.get()) {
         nearest = this.findNearest(mc.field_1687.method_8390(class_1533.class, searchBox, (entity) -> entity.method_5805() && this.canAttack(entity)), nearest, nearestDistance);
         if (nearest != null) {
            nearestDistance = mc.field_1724.method_5858(nearest);
         }
      }

      if (this.paintings.get()) {
         nearest = this.findNearest(mc.field_1687.method_8390(class_1534.class, searchBox, (entity) -> entity.method_5805() && this.canAttack(entity)), nearest, nearestDistance);
      }

      return nearest;
   }

   private class_1297 findNearest(Iterable<? extends class_1297> entities, class_1297 current, double currentDistance) {
      class_1297 nearest = current;
      double distance = currentDistance;

      for(class_1297 entity : entities) {
         double candidateDistance = mc.field_1724.method_5858(entity);
         if (candidateDistance < distance) {
            distance = candidateDistance;
            nearest = entity;
         }
      }

      return nearest;
   }

   private boolean canAttack(class_1297 entity) {
      if (this.ignoreFriends.get() && Manager.FRIEND_MANAGER != null) {
         boolean var10000;
         if (entity instanceof class_1657) {
            class_1657 player = (class_1657)entity;
            if (Manager.FRIEND_MANAGER.isFriend(player.method_5477().getString())) {
               var10000 = true;
               return !var10000;
            }
         }

         var10000 = false;
         return !var10000;
      } else {
         return true;
      }
   }

   private void aimAt(class_1297 entity) {
      class_243 target = entity.method_5829().method_1005();
      class_243 eye = mc.field_1724.method_33571();
      double dx = target.field_1352 - eye.field_1352;
      double dy = target.field_1351 - eye.field_1351;
      double dz = target.field_1350 - eye.field_1350;
      double horizontal = Math.sqrt(dx * dx + dz * dz);
      float yaw = class_3532.method_15393((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
      float pitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);
      Manager.ROTATION.setSmooth(yaw, pitch, 1.0F, 90.0F, 90.0F, true);
   }

   private boolean isAimedAt(class_1297 entity, float tolerance) {
      class_243 target = entity.method_5829().method_1005();
      class_243 eye = mc.field_1724.method_33571();
      double dx = target.field_1352 - eye.field_1352;
      double dy = target.field_1351 - eye.field_1351;
      double dz = target.field_1350 - eye.field_1350;
      double horizontal = Math.sqrt(dx * dx + dz * dz);
      float yaw = class_3532.method_15393((float)Math.toDegrees(Math.atan2(dz, dx)) - 90.0F);
      float pitch = class_3532.method_15363((float)(-Math.toDegrees(Math.atan2(dy, horizontal))), -90.0F, 90.0F);
      return Math.abs(class_3532.method_15393(yaw - Manager.ROTATION.getYaw())) <= tolerance && Math.abs(pitch - Manager.ROTATION.getPitch()) <= tolerance;
   }
}
