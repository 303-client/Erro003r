package ru.levin.modules.misc;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.DosFileAttributeView;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;
import ru.levin.events.Event;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.screens.unhook.UnHookScreen;

@FunctionAnnotation(
   name = "UnHook",
   keywords = {"SelfDestruct"},
   desc = "Wyłącza klienta na czas kontroli",
   type = Type.Misc
)
public class UnHook extends Function {
   public static BindSetting unHookKey = new BindSetting("Klawisz powrotu", 260);
   public static final List<Function> functionsToBack = new CopyOnWriteArrayList();

   public UnHook() {
      this.addSettings(new Setting[]{unHookKey});
   }

   public void onEvent(Event event) {
   }

   protected void onEnable() {
      mc.method_1507(new UnHookScreen());
      super.onEnable();
   }

   public void onUnhook() {
      functionsToBack.clear();

      for(int i = 0; i < Manager.FUNCTION_MANAGER.getFunctions().size(); ++i) {
         Function function = (Function)Manager.FUNCTION_MANAGER.getFunctions().get(i);
         if (function.state && function != this) {
            functionsToBack.add(function);
            function.setState(false);
         }
      }

      File folder = new File("C:\\ExosWare");
      if (folder.exists()) {
         try {
            Path folderPathObj = folder.toPath();
            DosFileAttributeView attributes = (DosFileAttributeView)Files.getFileAttributeView(folderPathObj, DosFileAttributeView.class);
            attributes.setHidden(true);
         } catch (IOException var4) {
         }
      }

      this.toggle();
   }
}
