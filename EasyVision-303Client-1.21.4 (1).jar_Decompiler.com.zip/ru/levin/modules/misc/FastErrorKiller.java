package ru.levin.modules.misc;

import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.ErrorKillerUtil;

@FunctionAnnotation(
   name = "FastErrorKiller",
   desc = "Automatyczne usuwanie pułapek - wylewa płyn i stawia cobweb/obsydian (wersja FastClient)",
   type = Type.Misc
)
public class FastErrorKiller extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Fast", new String[]{"Fast", "Auto"});
   private final ModeSetting replacement = new ModeSetting("Zamiennik", "Auto", new String[]{"Auto", "Cobweb", "Obsydian"});

   public FastErrorKiller() {
      this.addSettings(new Setting[]{this.mode, this.replacement});
   }

   protected void onEnable() {
      ErrorKillerUtil.requestAction(mc, ErrorKillerUtil.Mode.COBWEB);
   }

   protected void onDisable() {
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
            if (this.state) {
               if (this.mode.is("Fast")) {
                  ErrorKillerUtil.tick(mc);
               } else if (mc.field_1690.field_1904.method_1434()) {
                  ErrorKillerUtil.requestAction(mc, this.replacement.is("Cobweb") ? ErrorKillerUtil.Mode.COBWEB : ErrorKillerUtil.Mode.OBSIDIAN);
               }

            }
         }
      }
   }
}
