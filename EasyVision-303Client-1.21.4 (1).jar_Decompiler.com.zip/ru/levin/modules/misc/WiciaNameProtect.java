package ru.levin.modules.misc;

import ru.levin.events.Event;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "WiciaNameProtect",
   desc = "Ochrona nazwy gracza (wersja Wicia)",
   type = Type.Misc
)
public class WiciaNameProtect extends Function {
   public final TextSetting text = new TextSetting("Nazwa", "WiciaUser");
   public final BooleanSetting friend = new BooleanSetting("Ukrywaj znajomych", true);
   public final BooleanSetting hideSelf = new BooleanSetting("Ukrywaj siebie", true);

   public WiciaNameProtect() {
      this.addSettings(new Setting[]{this.text, this.friend, this.hideSelf});
   }

   public String getCustomName() {
      return this.state ? this.text.getValue().replaceAll("&", "§") : mc.method_53462().getName();
   }

   public String getProtectedName(String originalName) {
      if (!this.state) {
         return originalName;
      } else if (this.hideSelf.get() && this.isSelf(originalName)) {
         return this.applyFormatting(this.text.getValue());
      } else {
         return this.friend.get() && Manager.FRIEND_MANAGER.isFriend(originalName) ? this.applyFormatting(this.text.getValue()) : originalName;
      }
   }

   private String applyFormatting(String name) {
      return name.replace('&', '§');
   }

   private boolean isSelf(String name) {
      return name.equals(mc.method_1548().method_1676());
   }

   public void onEvent(Event event) {
   }
}
