package ru.levin.modules.misc;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "AutoLever",
   desc = "Natychmiast stawia dźwignię przy źródle wody",
   type = Type.Misc
)
public class AutoLever extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Exosware", new String[]{"Exosware", "Fast"});
   private final SliderSetting range = new SliderSetting("Zasięg", (double)4.0F, (double)1.0F, (double)6.0F, (double)1.0F);
   private final SliderSetting fastSpeed = new SliderSetting("Fast speed", (double)100.0F, (double)0.0F, (double)100.0F, (double)1.0F);
   private final BooleanSetting lava = new BooleanSetting("Lawa", true);
   private final BooleanSetting protectMyWater = new BooleanSetting("Nie zabieraj mojej wody", true);
   private final BooleanSetting protectFriendsWater = new BooleanSetting("Nie zabieraj wody znajomych", true);
   private long nextFastAction;

   public AutoLever() {
      this.addSettings(new Setting[]{this.mode, this.range, this.fastSpeed, this.lava, this.protectMyWater, this.protectFriendsWater});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && mc.field_1755 == null) {
         if (this.mode.is("Fast")) {
            this.runFastMode();
         } else {
            LeverHand leverHand = this.findLeverHand();
            if (leverHand != null) {
               WaterTarget target = this.findTarget();
               if (target != null) {
                  int previousSlot = mc.field_1724.method_31548().field_7545;
                  if (leverHand.slot() != -1) {
                     mc.field_1724.method_31548().field_7545 = leverHand.slot();
                     mc.field_1724.field_3944.method_52787(new class_2868(leverHand.slot()));
                  }

                  try {
                     class_3965 hit = new class_3965(class_243.method_24953(target.support()).method_1019(new class_243((double)target.face().method_10148() * (double)0.5F, (double)target.face().method_10164() * (double)0.5F, (double)target.face().method_10165() * (double)0.5F)), target.face(), target.support(), false);
                     class_1269 result = mc.field_1761.method_2896(mc.field_1724, leverHand.hand(), hit);
                     if (result.method_23665()) {
                        mc.field_1724.method_6104(leverHand.hand());
                     }
                  } finally {
                     mc.field_1724.method_31548().field_7545 = previousSlot;
                     mc.field_1724.field_3944.method_52787(new class_2868(previousSlot));
                  }

               }
            }
         }
      }
   }

   private void runFastMode() {
      if (!mc.field_1724.method_6047().method_31574(class_1802.field_8705) && !mc.field_1724.method_6047().method_31574(class_1802.field_8187) && !mc.field_1724.method_6079().method_31574(class_1802.field_8705) && !mc.field_1724.method_6079().method_31574(class_1802.field_8187)) {
         class_1657 bucketPlayer = this.findBucketPlayer();
         if (bucketPlayer != null) {
            WaterTarget target = this.findTargetAround(bucketPlayer);
            if (target != null && !AutoDrain.isOwnedSource(target.water())) {
               LeverHand leverHand = this.findLeverHand();
               if (leverHand != null) {
                  long now = System.currentTimeMillis();
                  if (now >= this.nextFastAction) {
                     int previousSlot = mc.field_1724.method_31548().field_7545;
                     if (leverHand.slot() != -1) {
                        mc.field_1724.method_31548().field_7545 = leverHand.slot();
                        mc.field_1724.field_3944.method_52787(new class_2868(leverHand.slot()));
                     }

                     try {
                        class_3965 hit = new class_3965(class_243.method_24953(target.support()).method_1019(new class_243((double)target.face().method_10148() * (double)0.5F, (double)target.face().method_10164() * (double)0.5F, (double)target.face().method_10165() * (double)0.5F)), target.face(), target.support(), false);
                        class_1269 result = mc.field_1761.method_2896(mc.field_1724, leverHand.hand(), hit);
                        if (result.method_23665()) {
                           mc.field_1724.method_6104(leverHand.hand());
                        }
                     } finally {
                        mc.field_1724.method_31548().field_7545 = previousSlot;
                        mc.field_1724.field_3944.method_52787(new class_2868(previousSlot));
                     }

                     this.nextFastAction = now + Math.max(1L, 9L - (long)Math.round(this.fastSpeed.get().floatValue() / 12.0F));
                  }
               }
            }
         }
      }
   }

   private class_1657 findBucketPlayer() {
      return (class_1657)mc.field_1687.method_18456().stream().filter((player) -> player != mc.field_1724 && player.method_5805()).filter((player) -> Manager.FRIEND_MANAGER == null || !Manager.FRIEND_MANAGER.isFriend(player.method_5477().getString())).filter((player) -> player.method_6047().method_31574(class_1802.field_8705) || player.method_6047().method_31574(class_1802.field_8187) || player.method_6079().method_31574(class_1802.field_8705) || player.method_6079().method_31574(class_1802.field_8187)).filter((player) -> mc.field_1724.method_5858(player) <= (double)625.0F).min((first, second) -> Double.compare(mc.field_1724.method_5858(first), mc.field_1724.method_5858(second))).orElse((Object)null);
   }

   private LeverHand findLeverHand() {
      if (mc.field_1724.method_6079().method_31574(class_1802.field_8865)) {
         return new LeverHand(class_1268.field_5810, -1);
      } else if (mc.field_1724.method_6047().method_31574(class_1802.field_8865)) {
         return new LeverHand(class_1268.field_5808, -1);
      } else {
         for(int slot = 0; slot < 9; ++slot) {
            if (mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8865)) {
               return new LeverHand(class_1268.field_5808, slot);
            }
         }

         return null;
      }
   }

   private WaterTarget findTarget() {
      return this.findTargetAround(mc.field_1724);
   }

   private WaterTarget findTargetAround(class_1657 owner) {
      class_2338 origin = owner.method_24515();
      int radius = this.range.get().intValue();
      WaterTarget nearest = null;
      double nearestDistance = Double.MAX_VALUE;

      for(int x = -radius; x <= radius; ++x) {
         for(int y = -radius; y <= radius; ++y) {
            for(int z = -radius; z <= radius; ++z) {
               class_2338 waterPos = origin.method_10069(x, y, z);
               class_3610 fluid = mc.field_1687.method_8316(waterPos);
               boolean isWater = fluid.method_15767(class_3486.field_15517);
               boolean isLava = fluid.method_15767(class_3486.field_15518);
               if ((isWater || isLava && this.lava.get()) && fluid.method_15771() && !this.isProtectedWater(waterPos)) {
                  for(class_2350 direction : class_2350.values()) {
                     class_2338 support = waterPos.method_10093(direction);
                     if (mc.field_1687.method_8320(support).method_26212(mc.field_1687, support) && mc.field_1687.method_8320(waterPos).method_45474()) {
                        double distance = mc.field_1724.method_19538().method_1025(class_243.method_24953(waterPos));
                        if (distance < nearestDistance) {
                           nearestDistance = distance;
                           nearest = new WaterTarget(waterPos.method_10062(), support.method_10062(), direction.method_10153());
                        }
                     }
                  }
               }
            }
         }
      }

      return nearest;
   }

   private boolean isProtectedWater(class_2338 waterPos) {
      return AutoDrain.isOwnedSource(waterPos) ? this.protectMyWater.get() : this.protectFriendsWater.get();
   }

   private static record WaterTarget(class_2338 water, class_2338 support, class_2350 face) {
   }

   private static record LeverHand(class_1268 hand, int slot) {
   }
}
