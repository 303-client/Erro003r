package ru.levin.modules.misc;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.input.EventKey;
import ru.levin.manager.ClientManager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "AntyKostka",
   desc = "Zapisuje układ ekwipunku i przywraca go z powrotem",
   type = Type.Misc
)
public class AntyKostka extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Exosware", new String[]{"Exosware", "WiciaHard"});
   private final BindSetting saveKey = new BindSetting("Zapisz układ", 0);
   private final BindSetting restoreKey = new BindSetting("Przywróć układ", 0);
   private final BooleanSetting autoRestore = new BooleanSetting("Auto-przywracanie", false);
   private final Map<Integer, class_1799> savedLayout = new LinkedHashMap();

   public AntyKostka() {
      this.addSettings(new Setting[]{this.mode, this.saveKey, this.restoreKey, this.autoRestore});
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey key) {
         if (key.key == this.saveKey.getKey()) {
            this.saveInventory();
         }

         if (key.key == this.restoreKey.getKey()) {
            this.restoreInventory();
         }
      }

      if (event instanceof EventUpdate && this.autoRestore.get() && this.state && !this.savedLayout.isEmpty()) {
         this.restoreInventory();
      }

   }

   private void saveInventory() {
      if (mc.field_1724 != null) {
         this.savedLayout.clear();
         class_1661 inventory = mc.field_1724.method_31548();

         for(int i = 0; i < inventory.method_5439(); ++i) {
            class_1799 stack = inventory.method_5438(i);
            if (!stack.method_7960()) {
               this.savedLayout.put(i, stack.method_7972());
            }
         }

         ClientManager.message("[AntyKostka] Zapisano układ ekwipunku.");
      }
   }

   private void restoreInventory() {
      if (mc.field_1724 != null && !this.savedLayout.isEmpty()) {
         if (this.mode.is("WiciaHard")) {
            this.restoreWiciaHard();
         } else {
            class_1661 inventory = mc.field_1724.method_31548();

            for(int slot = 0; slot < inventory.method_5439(); ++slot) {
               class_1799 expected = (class_1799)this.savedLayout.get(slot);
               if (expected != null) {
                  inventory.method_5447(slot, expected.method_7972());
               }
            }

            ClientManager.message("[AntyKostka] Układ ekwipunku przywrócony.");
         }
      } else {
         if (mc.field_1724 != null) {
            ClientManager.message("[AntyKostka] Brak zapisanego układu.");
         }

      }
   }

   private void restoreWiciaHard() {
      if (mc.field_1761 != null && mc.field_1724.field_7512 != null) {
         boolean[] occupied = new boolean[mc.field_1724.field_7512.field_7761.size()];
         int syncId = mc.field_1724.field_7512.field_7763;

         for(Map.Entry<Integer, class_1799> entry : this.savedLayout.entrySet()) {
            int targetSlot = this.toHandlerSlot((Integer)entry.getKey());
            if (targetSlot >= 0 && targetSlot < occupied.length) {
               class_1799 current = mc.field_1724.field_7512.method_7611(targetSlot).method_7677();
               if (class_1799.method_7973(current, (class_1799)entry.getValue())) {
                  occupied[targetSlot] = true;
               } else {
                  int sourceSlot = this.findMatchingSlot((class_1799)entry.getValue(), occupied, targetSlot);
                  if (sourceSlot != -1) {
                     this.clickPickup(syncId, sourceSlot);
                     this.clickPickup(syncId, targetSlot);
                     this.clickPickup(syncId, sourceSlot);
                     occupied[targetSlot] = true;
                  }
               }
            }
         }

         ClientManager.message("[AntyKostka] WiciaHard przywrócił układ kliknięciami slotów.");
      }
   }

   private int findMatchingSlot(class_1799 expected, boolean[] occupied, int targetSlot) {
      for(int slot = 9; slot < mc.field_1724.field_7512.field_7761.size(); ++slot) {
         if (slot != targetSlot && !occupied[slot] && class_1799.method_7973(mc.field_1724.field_7512.method_7611(slot).method_7677(), expected)) {
            return slot;
         }
      }

      return -1;
   }

   private void clickPickup(int syncId, int slot) {
      mc.field_1761.method_2906(syncId, slot, 0, class_1713.field_7790, mc.field_1724);
   }

   private int toHandlerSlot(int inventorySlot) {
      return inventorySlot < 9 ? inventorySlot + 36 : inventorySlot;
   }
}
