package ru.levin.modules.misc;

import java.util.LinkedHashMap;
import java.util.Map;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.input.EventKey;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.InventoryUtil;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "HWHelper",
   desc = "Szybka obsługa przedmiotów na HollyWorld",
   type = Type.Misc
)
public class HWHelper extends Function {
   private final BindSetting trapka = new BindSetting("Klawisz pułapki", 0);
   private final BindSetting trapkaBax = new BindSetting("Klawisz wybuchowej pułapki", 0);
   private final BindSetting stan = new BindSetting("Klawisz ogłuszenia", 0);
   private final BindSetting snow = new BindSetting("Klawisz śnieżki", 0);
   private final BindSetting babax = new BindSetting("Klawisz ładunku wybuchowego", 0);
   private final BooleanSetting bypass = new BooleanSetting("Obejście", true, "Spowalnia gracza podczas zamiany przedmiotu");
   private final BooleanSetting inventoryUse = new BooleanSetting("Używaj z ekwipunku", true);
   private final TimerUtil timer = new TimerUtil();
   private boolean bypassActive = false;
   private boolean awaitingSwap = false;
   private int hotbarSlot = -1;
   private int invSlot = -1;
   private final Map<BindSetting, class_1792> binds = new LinkedHashMap();

   public HWHelper() {
      this.addSettings(new Setting[]{this.trapka, this.trapkaBax, this.stan, this.snow, this.babax, this.bypass, this.inventoryUse});
      this.binds.put(this.trapka, class_1802.field_8882);
      this.binds.put(this.trapkaBax, class_1802.field_8662);
      this.binds.put(this.stan, class_1802.field_8137);
      this.binds.put(this.snow, class_1802.field_8543);
      this.binds.put(this.babax, class_1802.field_8814);
   }

   public void onEvent(Event event) {
      if (event instanceof EventKey eventKey) {
         this.handleKey(eventKey.key);
      }

      if (event instanceof EventUpdate) {
         this.handleBypass();
      }

   }

   private void handleKey(int pressedKey) {
      for(Map.Entry<BindSetting, class_1792> entry : this.binds.entrySet()) {
         if (pressedKey == ((BindSetting)entry.getKey()).getKey()) {
            int[] slots = this.findSlots((class_1792)entry.getValue());
            if (this.bypass.get()) {
               this.timer.reset();
               this.bypassActive = true;
               this.awaitingSwap = true;
               this.hotbarSlot = slots[0];
               this.invSlot = slots[1];
            } else {
               InventoryUtil.use(slots[0], slots[1], this.inventoryUse.get());
            }

            return;
         }
      }

   }

   private void handleBypass() {
      if (this.bypassActive) {
         this.setMovementKeys(false);
         if (this.awaitingSwap && this.timer.hasTimeElapsed(90L)) {
            this.awaitingSwap = false;
            if (this.hotbarSlot != -1 || this.invSlot != -1) {
               InventoryUtil.use(this.hotbarSlot, this.invSlot, this.inventoryUse.get());
            }
         }

         if (this.timer.hasTimeElapsed(150L)) {
            this.bypassActive = false;
            this.awaitingSwap = false;
            this.setMovementKeys(true);
         }

      }
   }

   private int[] findSlots(class_1792 item) {
      if (mc.field_1724 == null) {
         return new int[]{-1, -1};
      } else {
         int hotbarSlot = -1;
         int inventorySlot = -1;

         for(int i = 0; i < mc.field_1724.method_31548().method_5439(); ++i) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            if (!stack.method_7960() && stack.method_7909() == item) {
               if (i < 9) {
                  hotbarSlot = i;
               } else {
                  inventorySlot = i;
               }

               if (hotbarSlot != -1 && inventorySlot != -1) {
                  break;
               }
            }
         }

         return new int[]{hotbarSlot, inventorySlot};
      }
   }

   private void setMovementKeys(boolean restore) {
      class_304[] keys = new class_304[]{mc.field_1690.field_1894, mc.field_1690.field_1881, mc.field_1690.field_1913, mc.field_1690.field_1849, mc.field_1690.field_1867};

      for(class_304 key : keys) {
         if (restore) {
            this.updateKeyBinding(key);
         } else {
            key.method_23481(false);
         }
      }

   }

   private void updateKeyBinding(class_304 keyMapping) {
      keyMapping.method_23481(class_3675.method_15987(mc.method_22683().method_4490(), keyMapping.method_1429().method_1444()));
   }
}
