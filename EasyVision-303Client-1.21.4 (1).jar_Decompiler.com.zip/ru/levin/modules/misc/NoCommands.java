package ru.levin.modules.misc;

import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "NoCommands",
   desc = "Wyłącza polecenia rozpoczynające się od kropki",
   type = Type.Misc
)
public class NoCommands extends Function {
   public void onEvent(Event event) {
   }
}
