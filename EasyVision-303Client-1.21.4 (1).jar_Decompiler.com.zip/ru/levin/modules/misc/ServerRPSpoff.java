package ru.levin.modules.misc;

import net.minecraft.class_2596;
import net.minecraft.class_2720;
import net.minecraft.class_2856;
import net.minecraft.class_634;
import net.minecraft.class_2856.class_2857;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "ServerRPSpoff",
   desc = "",
   type = Type.Misc
)
public class ServerRPSpoff extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventPacket packetEvent) {
         class_2596 var4 = packetEvent.getPacket();
         if (var4 instanceof class_2720 packet) {
            class_634 networkHandler = mc.method_1562();
            if (networkHandler != null) {
               networkHandler.method_52787(new class_2856(packet.comp_2158(), class_2857.field_13016));
               networkHandler.method_52787(new class_2856(packet.comp_2158(), class_2857.field_13017));
            }

            event.setCancel(true);
         }
      }

   }
}
