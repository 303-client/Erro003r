package ru.levin.modules.misc;

import java.text.Normalizer;
import java.text.Normalizer.Form;
import java.util.Locale;
import net.minecraft.class_2596;
import net.minecraft.class_3417;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "Tpaccept Sounds",
   desc = "Odtwarza dzwiek po zaakceptowaniu teleportacji",
   type = Type.Misc
)
public class TpacceptSounds extends Function {
   public void onEvent(Event event) {
      if (event instanceof EventPacket packetEvent) {
         class_2596 var4 = packetEvent.getPacket();
         if (var4 instanceof class_7439 packet) {
            if (mc.field_1724 != null) {
               if (this.isAcceptedTeleport(packet.comp_763().getString())) {
                  mc.field_1724.method_5783(class_3417.field_14709, 1.8F, 1.7F);
               }

               return;
            }
         }
      }

   }

   private boolean isAcceptedTeleport(String message) {
      if (message != null && !message.isBlank()) {
         String normalized = Normalizer.normalize(message, Form.NFD).replaceAll("\\p{M}", "").toLowerCase(Locale.ROOT).trim();
         if (!normalized.startsWith("gracz ")) {
            return false;
         } else if (!normalized.contains("nie zaakcept") && !normalized.contains("niezaakcept") && !normalized.contains("odrzu") && !normalized.contains("odmow") && !normalized.contains("anulow")) {
            return normalized.contains("zaakceptowal twoja prosbe o telepor") || normalized.contains("zaakceptow") && (normalized.contains("telepor") || normalized.contains("tpa"));
         } else {
            return false;
         }
      } else {
         return false;
      }
   }
}
