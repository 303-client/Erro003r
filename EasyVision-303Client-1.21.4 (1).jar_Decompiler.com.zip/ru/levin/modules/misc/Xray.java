package ru.levin.modules.misc;

import java.awt.Color;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender3D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.render.XrayUtil;

@FunctionAnnotation(
   name = "Xray",
   desc = "X-ray",
   type = Type.Misc
)
public class Xray extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Exosware", new String[]{"Exosware", "Fast"});
   public static SliderSetting radius = new SliderSetting("Zasięg", (double)20.0F, (double)1.0F, (double)30.0F, (double)1.0F);
   public static BooleanSetting ancient = new BooleanSetting("Netheryt", true);
   public static BooleanSetting diamond = new BooleanSetting("Diamenty", true);
   public static BooleanSetting emerald = new BooleanSetting("Szmaragdy", true);
   public static BooleanSetting gold = new BooleanSetting("Złoto", true);
   public static BooleanSetting iron = new BooleanSetting("Żelazo", true);
   public static BooleanSetting coal = new BooleanSetting("Węgiel", true);
   public static BooleanSetting redstone = new BooleanSetting("Redstone", true);
   public static BooleanSetting lapise = new BooleanSetting("Lazuryt", true);

   public Xray() {
      this.addSettings(new Setting[]{radius, this.mode, ancient, diamond, emerald, gold, iron, coal, redstone, lapise});
   }

   public void onEvent(Event event) {
      XrayUtil.tick(this);
      if (!this.mode.is("Fast")) {
         if (event instanceof EventRender3D) {
            EventRender3D e = (EventRender3D)event;

            for(int x = (int)(mc.field_1724.method_23317() - (double)30.0F); (double)x <= mc.field_1724.method_23317() + (double)radius.get().floatValue(); ++x) {
               for(int y = (int)(mc.field_1724.method_23318() - (double)30.0F); (double)y <= mc.field_1724.method_23318() + (double)radius.get().floatValue(); ++y) {
                  for(int z = (int)(mc.field_1724.method_23321() - (double)30.0F); (double)z <= mc.field_1724.method_23321() + (double)radius.get().floatValue(); ++z) {
                     class_2338 pos = new class_2338(x, y, z);
                     class_2680 state = mc.field_1687.method_8320(pos);
                     class_238 box = (new class_238(pos)).method_1011(0.01);
                     new class_4587();
                     if (ancient.get() && state.method_26204() == class_2246.field_22109) {
                        RenderUtil.render3D.drawHoleOutline(box, Color.green.getRGB(), 2.0F);
                     }

                     if (diamond.get() && state.method_26204() == class_2246.field_10442) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(0, 255, 255, 80)).getRGB(), 2.0F);
                     }

                     if (emerald.get() && state.method_26204() == class_2246.field_10013) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(0, 128, 0, 80)).getRGB(), 2.0F);
                     }

                     if (gold.get() && state.method_26204() == class_2246.field_10571) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(255, 255, 0, 80)).getRGB(), 2.0F);
                     }

                     if (iron.get() && state.method_26204() == class_2246.field_10212) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(192, 192, 192, 80)).getRGB(), 2.0F);
                     }

                     if (coal.get() && state.method_26204() == class_2246.field_10418) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(0, 0, 0, 80)).getRGB(), 2.0F);
                     }

                     if (redstone.get() && state.method_26204() == class_2246.field_10080) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(255, 0, 0, 80)).getRGB(), 2.0F);
                     }

                     if (lapise.get() && state.method_26204() == class_2246.field_10090) {
                        RenderUtil.render3D.drawHoleOutline(box, (new Color(0, 0, 255, 80)).getRGB(), 2.0F);
                     }
                  }
               }
            }
         }

      }
   }

   public boolean isFastMode() {
      return this.mode.is("Fast");
   }

   public String blockConfig() {
      boolean var10000 = ancient.get();
      return var10000 + ":" + diamond.get() + ":" + emerald.get() + ":" + gold.get() + ":" + iron.get() + ":" + coal.get() + ":" + redstone.get() + ":" + lapise.get();
   }
}
