package ru.levin.modules.misc;

import net.minecraft.class_4063;
import net.minecraft.class_5365;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "Optimizer",
   desc = "Optymalizuje Minecrafta i zwiększa liczbę FPS",
   type = Type.Misc
)
public class Optimizer extends Function {
   private final BooleanSetting memory = new BooleanSetting("Free memory", true);
   private final BooleanSetting graphics = new BooleanSetting("Low graphics", true);
   private final BooleanSetting boostFPS = new BooleanSetting("Max FPS", true);
   private final TimerUtil timerHelper = new TimerUtil();

   public Optimizer() {
      this.addSettings(new Setting[]{this.memory, this.graphics, this.boostFPS});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (this.memory.get() && this.timerHelper.hasTimeElapsed(300000L)) {
            System.gc();
            Runtime.getRuntime().freeMemory();
            this.timerHelper.reset();
         }

         if (this.graphics.get() && mc.field_1687 != null) {
            mc.field_1690.method_42528().method_41748(class_4063.field_18162);
            mc.field_1690.method_42534().method_41748(class_5365.field_25427);
         }

         if (this.boostFPS.get()) {
            mc.field_1690.method_42433().method_41748(false);
            mc.field_1690.method_42524().method_41748(260);
         }
      }

   }
}
