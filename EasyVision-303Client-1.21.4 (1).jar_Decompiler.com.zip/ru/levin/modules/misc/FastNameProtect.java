package ru.levin.modules.misc;

import net.minecraft.class_2561;
import ru.levin.events.Event;
import ru.levin.events.impl.render.EventRender2D;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.util.NameProtectUtil;

@FunctionAnnotation(
   name = "FastNameProtect",
   desc = "Ukrywanie nazw graczy 1:1 jak w FastClient (wersja FastClient)",
   type = Type.Misc
)
public class FastNameProtect extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Wszyscy", new String[]{"Wszyscy", "Ja"});
   private final TextSetting alias = new TextSetting("Alias", "Gracz");
   private final BooleanSetting changeStats = new BooleanSetting("Zmień statystyki", false);
   private final TextSetting statTime = new TextSetting("Czas gry", "00:00:00");
   private final TextSetting statMoney = new TextSetting("Pieniądze", "0");
   private final TextSetting statKills = new TextSetting("Zabójstwa", "0");
   private final TextSetting statDeaths = new TextSetting("Śmierci", "0");

   public FastNameProtect() {
      this.addSettings(new Setting[]{this.mode, this.alias, this.changeStats, this.statTime, this.statMoney, this.statKills, this.statDeaths});
   }

   public String getModeValue() {
      return this.mode.is("Ja") ? "Ja" : "Wszyscy";
   }

   public void onEvent(Event event) {
      if (event instanceof EventRender2D) {
         if (this.state) {
            ;
         }
      }
   }

   public String getAlias() {
      return this.alias.getValue();
   }

   public boolean shouldChangeStats() {
      return this.changeStats.get();
   }

   public String getStatTime() {
      return this.statTime.getValue();
   }

   public String getStatMoney() {
      return this.statMoney.getValue();
   }

   public String getStatKills() {
      return this.statKills.getValue();
   }

   public String getStatDeaths() {
      return this.statDeaths.getValue();
   }

   public String replaceString(String text) {
      return text != null && !text.isEmpty() ? NameProtectUtil.replaceString(text) : text;
   }

   public class_2561 replaceText(class_2561 text) {
      return text == null ? text : text;
   }
}
