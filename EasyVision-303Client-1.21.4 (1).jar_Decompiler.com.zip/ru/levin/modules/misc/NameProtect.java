package ru.levin.modules.misc;

import ru.levin.events.Event;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "NameProtect",
   desc = "",
   type = Type.Misc
)
public class NameProtect extends Function {
   public final TextSetting text = new TextSetting("Gracz", "levin1337");
   public final BooleanSetting friend = new BooleanSetting("Ukrywaj znajomych", true);
   public final TextSetting statTime = new TextSetting("Stat Time", "");
   public final TextSetting statMoney = new TextSetting("Stat Money", "");
   public final TextSetting statKills = new TextSetting("Stat Kills", "");
   public final TextSetting statDeaths = new TextSetting("Stat Deaths", "");
   public final BooleanSetting changeStats = new BooleanSetting("Change Stats", false);

   public NameProtect() {
      this.addSettings(new Setting[]{this.text, this.friend, this.statTime, this.statMoney, this.statKills, this.statDeaths, this.changeStats});
   }

   public String getCustomName() {
      return Manager.FUNCTION_MANAGER.nameProtect.state ? this.text.getValue().replaceAll("&", "§") : mc.method_53462().getName();
   }

   public String getProtectedName(String originalName) {
      if (!Manager.FUNCTION_MANAGER.nameProtect.state) {
         return originalName;
      } else if (this.isSelf(originalName)) {
         return this.applyFormatting(this.text.getValue());
      } else {
         return this.friend.get() && Manager.FRIEND_MANAGER.isFriend(originalName) ? this.applyFormatting(this.text.getValue()) : originalName;
      }
   }

   private String applyFormatting(String name) {
      return name.replace('&', '§');
   }

   private boolean isSelf(String name) {
      return name.equals(mc.method_1548().method_1676());
   }

   public void onEvent(Event event) {
   }
}
