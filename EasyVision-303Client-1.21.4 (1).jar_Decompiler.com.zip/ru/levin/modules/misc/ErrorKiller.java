package ru.levin.modules.misc;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1661;
import net.minecraft.class_1747;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_2269;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_2401;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "ErrorKiller",
   desc = "Szybko zamienia dźwignię na cobweb lub obsydian",
   type = Type.Misc
)
public class ErrorKiller extends Function {
   private final ModeSetting mode = new ModeSetting("Tryb", "Exosware", new String[]{"Exosware", "Fast"});
   private final ModeSetting replacement = new ModeSetting("Zamiennik", "Auto", new String[]{"Auto", "Cobweb", "Obsydian"});
   private Stage stage;
   private Target target;
   private HeldItem waterHand;
   private int previousSlot;
   private int waitTicks;
   private int sequenceTicks;
   private boolean useWasPressed;

   public ErrorKiller() {
      this.stage = ErrorKiller.Stage.IDLE;
      this.addSettings(new Setting[]{this.mode, this.replacement});
   }

   protected void onEnable() {
      this.reset();
   }

   protected void onDisable() {
      this.reset();
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null && mc.field_1755 == null) {
         boolean usePressed = mc.field_1690.field_1904.method_1434();
         boolean fastTrigger = usePressed && !this.useWasPressed;
         this.useWasPressed = usePressed;
         if (!this.mode.is("Fast") || this.stage != ErrorKiller.Stage.IDLE || fastTrigger && this.isFastItemHeld()) {
            if (this.waitTicks > 0) {
               --this.waitTicks;
            } else if (this.stage != ErrorKiller.Stage.IDLE && ++this.sequenceTicks > 12) {
               this.reset();
            } else {
               if (this.stage == ErrorKiller.Stage.IDLE) {
                  Target aimedTarget;
                  try {
                     aimedTarget = this.findTarget();
                  } catch (RuntimeException var7) {
                     this.reset();
                     return;
                  }

                  if (aimedTarget == null) {
                     return;
                  }

                  HeldItem water = this.findFluidBucket();
                  if (water == null) {
                     return;
                  }

                  this.target = aimedTarget;
                  this.waterHand = water;
                  this.previousSlot = mc.field_1724.method_31548().field_7545;
                  this.stage = ErrorKiller.Stage.POUR;
               }

               try {
                  switch (this.stage.ordinal()) {
                     case 0:
                     default:
                        break;
                     case 1:
                        this.pourWater();
                        break;
                     case 2:
                        this.pickupWater();
                        break;
                     case 3:
                        this.placeReplacement();
                  }
               } catch (RuntimeException var6) {
                  this.reset();
               }

            }
         }
      }
   }

   private void pourWater() {
      if (this.target != null && mc.field_1687.method_8320(this.target.lever()).method_26204() instanceof class_2401 && this.waterHand != null && this.select(this.waterHand)) {
         class_1269 result = this.interact(this.waterHand.hand(), new class_3965(class_243.method_24953(this.target.support()), this.target.face(), this.target.support(), false));
         if (!result.method_23665()) {
            this.reset();
         } else {
            this.stage = ErrorKiller.Stage.PICKUP;
            this.waitTicks = 1;
         }
      } else {
         this.reset();
      }
   }

   private void pickupWater() {
      if (this.target != null && this.waterHand != null && this.select(this.waterHand) && mc.field_1724.method_5998(this.waterHand.hand()).method_31574(class_1802.field_8550)) {
         class_1269 result = this.interact(this.waterHand.hand(), new class_3965(class_243.method_24953(this.target.support()), this.target.face(), this.target.support(), false));
         if (!result.method_23665()) {
            this.reset();
         } else {
            this.stage = ErrorKiller.Stage.REPLACE;
            this.waitTicks = 1;
         }
      } else {
         this.reset();
      }
   }

   private void placeReplacement() {
      if (this.target != null && !(mc.field_1687.method_8320(this.target.lever()).method_26204() instanceof class_2401) && mc.field_1687.method_8316(this.target.lever()).method_15769()) {
         HeldItem block = this.findReplacement();
         if (block != null && this.select(block)) {
            class_1269 result = this.interact(block.hand(), new class_3965(class_243.method_24953(this.target.support()).method_1019(new class_243((double)this.target.face().method_10148() * (double)0.5F, (double)this.target.face().method_10164() * (double)0.5F, (double)this.target.face().method_10165() * (double)0.5F)), this.target.face(), this.target.support(), false));
            if (result.method_23665()) {
               mc.field_1724.method_6104(block.hand());
            }

            this.reset();
         } else {
            this.reset();
         }
      } else {
         this.waitTicks = 1;
      }
   }

   private class_1269 interact(class_1268 hand, class_3965 hit) {
      class_1269 result = mc.field_1761.method_2896(mc.field_1724, hand, hit);
      if (result.method_23665()) {
         mc.field_1724.method_6104(hand);
      }

      return result;
   }

   private HeldItem findHeldItem(class_1792 item) {
      if (mc.field_1724.method_6079().method_31574(item)) {
         return new HeldItem(class_1268.field_5810, -1);
      } else if (mc.field_1724.method_6047().method_31574(item)) {
         return new HeldItem(class_1268.field_5808, -1);
      } else {
         class_1661 inventory = mc.field_1724.method_31548();

         for(int slot = 0; slot < 9; ++slot) {
            if (inventory.method_5438(slot).method_31574(item)) {
               return new HeldItem(class_1268.field_5808, slot);
            }
         }

         return null;
      }
   }

   private HeldItem findFluidBucket() {
      HeldItem water = this.findHeldItem(class_1802.field_8705);
      return water != null ? water : this.findHeldItem(class_1802.field_8187);
   }

   private boolean isFastItemHeld() {
      return mc.field_1724.method_6047().method_31574(class_1802.field_8786) || mc.field_1724.method_6047().method_31574(class_1802.field_8281) || mc.field_1724.method_6047().method_7909() instanceof class_1747;
   }

   private HeldItem findReplacement() {
      if (this.mode.is("Fast")) {
         if (mc.field_1724.method_6047().method_31574(class_1802.field_8786)) {
            return new HeldItem(class_1268.field_5808, -1);
         }

         if (mc.field_1724.method_6047().method_31574(class_1802.field_8281)) {
            return new HeldItem(class_1268.field_5808, -1);
         }
      }

      if (this.replacement.is("Cobweb")) {
         return this.findHeldItem(class_1802.field_8786);
      } else if (this.replacement.is("Obsydian")) {
         return this.findHeldItem(class_1802.field_8281);
      } else {
         HeldItem cobweb = this.findHeldItem(class_1802.field_8786);
         return cobweb != null ? cobweb : this.findHeldItem(class_1802.field_8281);
      }
   }

   private boolean select(HeldItem item) {
      if (item.slot() == -1) {
         return true;
      } else {
         mc.field_1724.method_31548().field_7545 = item.slot();
         mc.field_1724.field_3944.method_52787(new class_2868(item.slot()));
         return true;
      }
   }

   private Target findTarget() {
      class_239 var2 = mc.field_1765;
      if (var2 instanceof class_3965 hit) {
         class_2338 aimed = hit.method_17777();
         if (aimed == null) {
            return null;
         } else if (this.isTriggerBlock(aimed)) {
            return this.createTarget(aimed, (class_2338)null);
         } else {
            for(class_2350 direction : class_2350.values()) {
               class_2338 candidate = aimed.method_10093(direction);
               if (this.isTriggerBlock(candidate)) {
                  return this.createTarget(candidate, aimed);
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private boolean isTriggerBlock(class_2338 pos) {
      return mc.field_1687.method_8320(pos).method_26204() instanceof class_2401 || mc.field_1687.method_8320(pos).method_26204() instanceof class_2269;
   }

   private Target createTarget(class_2338 lever, class_2338 preferredSupport) {
      if (lever != null && mc.field_1687 != null) {
         if (preferredSupport != null && mc.field_1687.method_8320(preferredSupport).method_26212(mc.field_1687, preferredSupport)) {
            int dx = lever.method_10263() - preferredSupport.method_10263();
            int dy = lever.method_10264() - preferredSupport.method_10264();
            int dz = lever.method_10260() - preferredSupport.method_10260();
            class_2350 face = dx > 0 ? class_2350.field_11034 : (dx < 0 ? class_2350.field_11039 : (dy > 0 ? class_2350.field_11036 : (dy < 0 ? class_2350.field_11033 : (dz > 0 ? class_2350.field_11035 : class_2350.field_11043))));
            return new Target(lever.method_10062(), preferredSupport.method_10062(), face);
         } else {
            for(class_2350 direction : class_2350.values()) {
               class_2338 support = lever.method_10093(direction);
               if (mc.field_1687.method_8320(support).method_26212(mc.field_1687, support)) {
                  return new Target(lever.method_10062(), support.method_10062(), direction.method_10153());
               }
            }

            return null;
         }
      } else {
         return null;
      }
   }

   private boolean isTargetStillSelected() {
      if (this.target != null) {
         class_239 var2 = mc.field_1765;
         if (var2 instanceof class_3965) {
            class_3965 hit = (class_3965)var2;
            class_2338 aimed = hit.method_17777();
            return aimed.equals(this.target.lever()) || aimed.equals(this.target.support());
         }
      }

      return false;
   }

   private void reset() {
      if (mc.field_1724 != null && this.previousSlot >= 0 && this.previousSlot < 9) {
         mc.field_1724.method_31548().field_7545 = this.previousSlot;
         mc.field_1724.field_3944.method_52787(new class_2868(this.previousSlot));
      }

      this.stage = ErrorKiller.Stage.IDLE;
      this.target = null;
      this.waterHand = null;
      this.previousSlot = -1;
      this.useWasPressed = false;
      this.waitTicks = 0;
      this.sequenceTicks = 0;
      this.useWasPressed = false;
   }

   private static enum Stage {
      IDLE,
      POUR,
      PICKUP,
      REPLACE;

      // $FF: synthetic method
      private static Stage[] $values() {
         return new Stage[]{IDLE, POUR, PICKUP, REPLACE};
      }
   }

   private static record HeldItem(class_1268 hand, int slot) {
   }

   private static record Target(class_2338 lever, class_2338 support, class_2350 face) {
   }
}
