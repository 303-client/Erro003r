package ru.levin.modules.misc;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.IMinecraft;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "WiciaMsgSpammer",
   desc = "Automatyczne wysyłanie wiadomości (wersja Wicia)",
   type = Type.Misc
)
public class WiciaMsgSpammer extends Function {
   public final TextSetting message = new TextSetting("Wiadomość", "Wiadomość");
   public final TextSetting targetPlayer = new TextSetting("Gracz celowy", "");
   public final SliderSetting delay = new SliderSetting("Opóźnienie (ms)", (double)500.0F, (double)50.0F, (double)5000.0F, (double)50.0F);
   public final BooleanSetting autoSwing = new BooleanSetting("Auto machanie", false);
   public final SliderSetting swingDelay = new SliderSetting("Opóźnienie machania (s)", (double)3.0F, (double)1.0F, (double)10.0F, (double)1.0F);
   private boolean shouldSend = false;
   private long lastSendTime = 0L;
   private int swingCounter = 0;
   private int lastSwingSlot = -1;
   private final PlayerTracker playerTracker = new PlayerTracker();

   public void onEnable() {
      this.shouldSend = false;
      this.lastSendTime = 0L;
      this.swingCounter = 0;
      this.lastSwingSlot = -1;
      this.playerTracker.reset();
   }

   public void onDisable() {
      this.shouldSend = false;
      this.lastSendTime = 0L;
      this.swingCounter = 0;
      this.lastSwingSlot = -1;
      this.playerTracker.reset();
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && this.state) {
         if (mc.field_1724 != null && mc.field_1687 != null) {
            if (this.shouldSend) {
               this.handleAutoSwing();
               this.processMessageSending();
            } else {
               this.playerTracker.trackPlayers();
            }

         } else {
            this.resetState();
         }
      } else {
         this.resetState();
      }
   }

   private void handleAutoSwing() {
      if (!this.autoSwing.get()) {
         this.swingCounter = 0;
         this.lastSwingSlot = -1;
      } else {
         int swingInterval = this.swingDelay.get().intValue() * 20;
         ++this.swingCounter;
         if (this.swingCounter >= swingInterval) {
            this.swingCounter = 0;
            if (mc.field_1724 != null) {
               int currentSlot = mc.field_1724.method_31548().field_7545;
               if (this.lastSwingSlot != -1 && this.lastSwingSlot != currentSlot) {
                  mc.field_1724.method_31548().field_7545 = this.lastSwingSlot;
               }

               mc.field_1724.method_6104(class_1268.field_5808);
               this.lastSwingSlot = currentSlot;
            }
         }

      }
   }

   private void processMessageSending() {
      long currentTime = System.currentTimeMillis();
      int delayMs = this.delay.get().intValue();
      if (currentTime - this.lastSendTime >= (long)delayMs) {
         String targetName = this.targetPlayer.getValue().trim();
         String msgText = this.message.getValue().trim();
         if (!targetName.isEmpty() && !msgText.isEmpty()) {
            this.sendToPlayer(targetName, msgText);
         } else if (!msgText.isEmpty()) {
            UUID targetUuid = this.playerTracker.getMostRecentPlayer();
            if (targetUuid != null) {
               class_1657 target = this.findPlayerByUuid(targetUuid);
               if (target != null) {
                  this.sendToPlayer(target.method_5477().getString(), msgText);
                  this.playerTracker.removePlayer(targetUuid);
               }
            }
         }

         this.lastSendTime = currentTime;
      }
   }

   private void sendToPlayer(String playerName, String messageText) {
      if (mc.field_1724 != null) {
         String cleanPlayerName = this.sanitizeString(playerName);
         String cleanMessage = this.sanitizeString(messageText);
         if (!cleanPlayerName.isEmpty() && !cleanMessage.isEmpty()) {
            String command = "msg " + cleanPlayerName + " " + cleanMessage;
            if (command.length() > 256) {
               command = command.substring(0, 256);
            }

            mc.field_1724.field_3944.method_45730(command);
         }
      }
   }

   private class_1657 findPlayerByUuid(UUID uuid) {
      if (mc.field_1687 == null) {
         return null;
      } else {
         for(class_1657 player : mc.field_1687.method_18456()) {
            if (player.method_5667().equals(uuid)) {
               return player;
            }
         }

         return null;
      }
   }

   private String sanitizeString(String input) {
      if (input == null) {
         return "";
      } else {
         StringBuilder cleaned = new StringBuilder(input.length());

         for(int i = 0; i < input.length(); ++i) {
            char c = input.charAt(i);
            if (c >= ' ' && c != 127 && c != 167) {
               cleaned.append(c);
            }
         }

         return cleaned.toString().trim();
      }
   }

   private void resetState() {
      this.shouldSend = false;
      this.lastSendTime = 0L;
      this.swingCounter = 0;
      this.lastSwingSlot = -1;
   }

   public void setShouldSend(boolean value) {
      this.shouldSend = value;
      if (value) {
         this.lastSendTime = System.currentTimeMillis();
      }

   }

   public boolean isShouldSend() {
      return this.shouldSend;
   }

   public void setAutoSwing(boolean value) {
      this.autoSwing.set(value);
   }

   public boolean isAutoSwing() {
      return this.autoSwing.get();
   }

   public PlayerTracker getPlayerTracker() {
      return this.playerTracker;
   }

   private static class PlayerTracker {
      private final Map<UUID, Long> playerTimestamps = new HashMap();
      private static final double MAX_DISTANCE = (double)80.0F;

      public void trackPlayers() {
         if (IMinecraft.mc.field_1724 != null && IMinecraft.mc.field_1687 != null) {
            long currentTime = System.currentTimeMillis();

            for(class_1657 player : IMinecraft.mc.field_1687.method_18456()) {
               if (player != IMinecraft.mc.field_1724 && player.method_5805()) {
                  double distance = IMinecraft.mc.field_1724.method_5858(player);
                  if (!(distance > (double)6400.0F)) {
                     this.playerTimestamps.put(player.method_5667(), currentTime);
                  }
               }
            }

            this.playerTimestamps.entrySet().removeIf((entry) -> currentTime - (Long)entry.getValue() > 30000L);
         }
      }

      public UUID getMostRecentPlayer() {
         return this.playerTimestamps.isEmpty() ? null : (UUID)this.playerTimestamps.entrySet().stream().max(Entry.comparingByValue()).map(Map.Entry::getKey).orElse((Object)null);
      }

      public void removePlayer(UUID uuid) {
         this.playerTimestamps.remove(uuid);
      }

      public void reset() {
         this.playerTimestamps.clear();
      }
   }
}
