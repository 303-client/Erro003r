package ru.levin.modules.misc;

import ru.levin.com.discord.DiscordEventHandlers;
import ru.levin.com.discord.DiscordRPC;
import ru.levin.com.discord.DiscordRichPresence;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;

@FunctionAnnotation(
   name = "DiscordRPC",
   desc = "Status w Discordzie",
   type = Type.Misc
)
public class DiscordRCP extends Function {
   private final DiscordRPC rpc;
   private volatile boolean started;
   private Thread thread;
   private final DiscordRichPresence presence;

   public DiscordRCP() {
      this.rpc = DiscordRPC.INSTANCE;
      this.started = false;
      this.presence = new DiscordRichPresence();
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         this.startRpc();
      }

   }

   public synchronized void startRpc() {
      if (!this.started) {
         this.started = true;
         DiscordEventHandlers handlers = new DiscordEventHandlers();
         this.rpc.Discord_Initialize("1384873696375603281", handlers, true, "");
         this.presence.startTimestamp = System.currentTimeMillis() / 1000L;
         this.presence.largeImageText = "https://t.me/exosware";
         this.updatePresenceFields();
         this.rpc.Discord_UpdatePresence(this.presence);
         this.thread = new Thread(() -> {
            try {
               while(!Thread.currentThread().isInterrupted()) {
                  this.rpc.Discord_RunCallbacks();
                  this.updatePresenceFields();
                  this.rpc.Discord_UpdatePresence(this.presence);
                  Thread.sleep(2000L);
               }
            } catch (InterruptedException var2) {
            }

         }, "TH-RPC-Handler");
         this.thread.setDaemon(true);
         this.thread.start();
      }
   }

   private void updatePresenceFields() {
      this.presence.details = "User: " + Manager.USER_PROFILE.getName();
      this.presence.state = "Role: " + Manager.USER_PROFILE.getRole();
      this.presence.button_label_1 = "Kup";
      this.presence.button_url_1 = "https://exosware.ru";
      this.presence.button_label_2 = "Telegram";
      this.presence.button_url_2 = "https://t.me/exosware";
      this.presence.largeImageKey = "https://api.exosware.ru/api/loader/discord.gif";
   }

   public void onDisable() {
      this.started = false;
      if (this.thread != null && this.thread.isAlive()) {
         this.thread.interrupt();
      }

      this.rpc.Discord_Shutdown();
   }
}
