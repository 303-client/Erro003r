package ru.levin.modules.misc;

import com.google.common.collect.Lists;
import com.mojang.authlib.GameProfile;
import java.util.List;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_2596;
import net.minecraft.class_640;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.misc.autoduel.Counter;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "AutoDuel",
   type = Type.Misc,
   desc = "Automatycznie wysyła zaproszenie na pojedynek"
)
public class AutoDuel extends Function {
   private final Pattern pattern = Pattern.compile("^\\w{3,16}$");
   private final ModeSetting mode = new ModeSetting("Tryb", "Kule", new String[]{"Kule", "Tarcza", "Ciernie III", "Zbroja z netherytu", "Raj cheaterów", "Łuk", "Klasyczny", "Totemy", "NoDebuff"});
   private SliderSetting slowTime = new SliderSetting("Częstotliwość wysyłania", (double)500.0F, (double)300.0F, (double)1000.0F, (double)100.0F);
   private final BooleanSetting babki = new BooleanSetting("Graj o pieniądze", false);
   private TextSetting money = new TextSetting("Monet", "10000", () -> this.babki.get());
   private double lastPosX;
   private double lastPosY;
   private double lastPosZ;
   private final List<String> sent = Lists.newArrayList();
   private final Counter counter = Counter.create();
   private final Counter counter2 = Counter.create();
   private final Counter counterChoice = Counter.create();
   private final Counter counterTo = Counter.create();

   public AutoDuel() {
      this.addSettings(new Setting[]{this.mode, this.slowTime, this.babki, this.money});
   }

   public void onEnable() {
      this.counter.reset();
      this.counter2.reset();
      this.counterChoice.reset();
      this.counterTo.reset();
      this.sent.clear();
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         this.xuesos();
      }

      if (event instanceof EventPacket eventPacket) {
         this.pidor(eventPacket);
      }

   }

   private void xuesos() {
      List<String> players = this.getOnlinePlayers();
      double distance = Math.sqrt(Math.pow(this.lastPosX - mc.field_1724.method_23317(), (double)2.0F) + Math.pow(this.lastPosY - mc.field_1724.method_23318(), (double)2.0F) + Math.pow(this.lastPosZ - mc.field_1724.method_23321(), (double)2.0F));
      if (distance > (double)500.0F) {
         this.toggle();
      }

      this.lastPosX = mc.field_1724.method_23317();
      this.lastPosY = mc.field_1724.method_23318();
      this.lastPosZ = mc.field_1724.method_23321();
      if (this.counter2.hasReached(800L * (long)players.size())) {
         this.sent.clear();
         this.counter2.reset();
      }

      for(String player : players) {
         if (!this.sent.contains(player) && !player.equals(mc.field_1724.method_7334().getName()) && this.counter.hasReached(this.slowTime.get().longValue())) {
            if (this.babki.get()) {
               mc.field_1724.field_3944.method_45731("duel " + player + " " + this.money.getValue());
            } else {
               mc.field_1724.field_3944.method_45731("duel " + player);
            }

            this.sent.add(player);
            this.counter.reset();
         }
      }

      if (mc.field_1755 != null) {
         class_1703 title = mc.field_1724.field_7512;
         if (title instanceof class_1703) {
            class_1703 chest = title;
            String title = mc.field_1755.method_25440().getString();
            if (title.contains("Wybór zestawu (1/1)")) {
               int slotID = -1;
               if (this.counterChoice.hasReached(150L)) {
                  if (this.mode.is("Tarcza")) {
                     slotID = 0;
                  }

                  if (this.mode.is("Ciernie III")) {
                     slotID = 1;
                  }

                  if (this.mode.is("Łuk")) {
                     slotID = 2;
                  }

                  if (this.mode.is("Totemy")) {
                     slotID = 3;
                  }

                  if (this.mode.is("NoDebuff")) {
                     slotID = 4;
                  }

                  if (this.mode.is("Kule")) {
                     slotID = 5;
                  }

                  if (this.mode.is("Klasyczny")) {
                     slotID = 6;
                  }

                  if (this.mode.is("Raj cheaterów")) {
                     slotID = 7;
                  }

                  if (this.mode.is("Zbroja z netherytu")) {
                     slotID = 8;
                  }

                  if (slotID >= 0) {
                     mc.field_1761.method_2906(mc.field_1724.field_7512.field_7763, slotID, 0, class_1713.field_7794, mc.field_1724);
                  }

                  this.counterChoice.reset();
               }
            } else if (title.contains("Ustawienia pojedynku") && this.counterTo.hasReached(150L)) {
               mc.field_1761.method_2906(chest.field_7763, 0, 0, class_1713.field_7794, mc.field_1724);
               this.counterTo.reset();
            }
         }
      }

   }

   private void pidor(EventPacket event) {
      if (event.isReceivePacket()) {
         class_2596<?> packet = event.getPacket();
         if (packet instanceof class_7439) {
            class_7439 chat = (class_7439)packet;
            String text = chat.comp_763().toString();
            if (text.contains("początek") && text.contains("za") && text.contains("sekund!") || text.equals("Pojedynki » podczas walki nie można używać poleceń")) {
               this.toggle();
            }
         }
      }

   }

   private List<String> getOnlinePlayers() {
      List<String> result = (List)mc.field_1724.field_3944.method_2880().stream().map(class_640::method_2966).map(GameProfile::getName).filter((profileName) -> this.pattern.matcher(profileName).matches()).collect(Collectors.toList());
      return result;
   }
}
