package ru.levin.modules.misc;

import net.minecraft.class_124;
import net.minecraft.class_1304;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.input.EventKey;
import ru.levin.manager.ClientManager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.player.InventoryUtil;

@FunctionAnnotation(
   name = "ElytraHelper",
   desc = "Szybka obsługa elytry",
   type = Type.Misc
)
public class ElytraHelper extends Function {
   private final BindSetting elytraKey = new BindSetting("Klawisz elytry", 0);
   private final BindSetting fireworkKey = new BindSetting("Klawisz fajerwerku", 0);
   private final BooleanSetting autoTakeoff = new BooleanSetting("Automatyczny start", true);
   private int takeoffTicks = 0;
   private boolean waitingToGlide = false;

   public ElytraHelper() {
      this.addSettings(new Setting[]{this.elytraKey, this.fireworkKey, this.autoTakeoff});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && this.autoTakeoff.get()) {
         this.handleAutoTakeoff();
      }

      if (event instanceof EventKey e) {
         if (mc.field_1724 != null) {
            class_1799 equipped = mc.field_1724.method_6118(class_1304.field_6174);
            if (e.key == this.elytraKey.getKey()) {
               int chestPlateSlot = this.findChestplate();
               int elytraSlot = this.findItemSlot(class_1802.field_8833);
               if (equipped.method_7909() == class_1802.field_8833) {
                  if (chestPlateSlot != -1) {
                     this.swapSlots(chestPlateSlot, 6);
                     ClientManager.message("Założono " + String.valueOf(class_124.field_1075) + "napierśnik");
                  } else {
                     this.swapSlots(elytraSlot == -1 ? 6 : elytraSlot, 6);
                     ClientManager.message(String.valueOf(class_124.field_1054) + "Elytra została zdjęta (brak napierśnika)");
                  }
               } else if (elytraSlot != -1) {
                  this.swapSlots(elytraSlot, 6);
                  ClientManager.message("Założono " + String.valueOf(class_124.field_1061) + "elytrę");
               } else {
                  ClientManager.message(String.valueOf(class_124.field_1061) + "Nie znaleziono elytry!");
               }
            }

            if (e.key == this.fireworkKey.getKey() && equipped.method_7909() == class_1802.field_8833) {
               InventoryUtil.inventorySwapClick2(class_1802.field_8639, true, false);
            }
         }
      }

   }

   private void handleAutoTakeoff() {
      class_1799 chest = mc.field_1724.method_6118(class_1304.field_6174);
      if (chest.method_7909() != class_1802.field_8833) {
         this.waitingToGlide = false;
         this.takeoffTicks = 0;
      } else if (mc.field_1724.method_6128()) {
         this.waitingToGlide = false;
         this.takeoffTicks = 0;
      } else if (mc.field_1724.method_24828() && !this.waitingToGlide) {
         mc.field_1724.method_6043();
         this.waitingToGlide = true;
         this.takeoffTicks = 0;
      } else {
         if (this.waitingToGlide) {
            ++this.takeoffTicks;
            if (this.takeoffTicks >= 2 && mc.field_1724.method_18798().field_1351 < -0.08 && !mc.field_1724.method_6128()) {
               InventoryUtil.startFly();
               this.waitingToGlide = false;
               this.takeoffTicks = 0;
            }

            if (this.takeoffTicks > 10) {
               this.waitingToGlide = false;
               this.takeoffTicks = 0;
            }
         }

      }
   }

   private int findItemSlot(class_1792 item) {
      for(int i = 0; i < mc.field_1724.method_31548().method_5439(); ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (stack.method_7909() == item) {
            return i;
         }
      }

      return -1;
   }

   private int findChestplate() {
      class_1792[] chestplates = new class_1792[]{class_1802.field_22028, class_1802.field_8058, class_1802.field_8523, class_1802.field_8678, class_1802.field_8873, class_1802.field_8577};

      for(class_1792 item : chestplates) {
         int slot = this.findItemSlot(item);
         if (slot != -1) {
            return slot;
         }
      }

      return -1;
   }

   private void swapSlots(int from, int armorSlot) {
      int slot = from < 9 ? from + 36 : from;
      mc.field_1761.method_2906(0, slot, 0, class_1713.field_7791, mc.field_1724);
      mc.field_1761.method_2906(0, armorSlot, 0, class_1713.field_7791, mc.field_1724);
      mc.field_1761.method_2906(0, slot, 0, class_1713.field_7791, mc.field_1724);
   }

   protected void onEnable() {
      ClientManager.message("Ustaw wersję 1.17 w ViaFabricPlus, aby zamiana przedmiotów działała poprawnie");
      super.onEnable();
   }
}
