package ru.levin.modules.misc;

import ru.levin.events.Event;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.move.MoveUtil;

@FunctionAnnotation(
   name = "RWHelper",
   desc = "",
   type = Type.Misc
)
public class RWHelper extends Function {
   private final BindBooleanSetting dragonFly = new BindBooleanSetting("DragonFly", "Pozwala szybciej latać na smoku", true);

   public RWHelper() {
      this.addSettings(new Setting[]{this.dragonFly});
   }

   public void onEvent(Event event) {
      if (event instanceof EventMotion) {
         if (this.dragonFly.get() && mc.field_1724.method_31549().field_7479) {
            MoveUtil.setSpeed(1.0F);
            float y = 0.0F;
            boolean noForward = mc.field_1724.field_6250 == 0.0F && !mc.field_1690.field_1913.method_1434() && !mc.field_1690.field_1849.method_1434();
            if (mc.field_1690.field_1903.method_1434()) {
               y = noForward ? 0.5F : 0.25F;
            } else if (mc.field_1690.field_1832.method_1434()) {
               y = noForward ? -0.5F : -0.25F;
            }

            mc.field_1724.method_18800(mc.field_1724.method_18798().field_1352, (double)y, mc.field_1724.method_18798().field_1350);
         }
      }
   }
}
