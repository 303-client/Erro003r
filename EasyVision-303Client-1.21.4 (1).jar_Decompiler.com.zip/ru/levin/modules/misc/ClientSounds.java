package ru.levin.modules.misc;

import java.util.Arrays;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.MultiSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "ClientSounds",
   desc = "Dźwięki",
   type = Type.Misc
)
public class ClientSounds extends Function {
   public final MultiSetting check = new MultiSetting("Wybierz", Arrays.asList("Uruchomiono klienta"), new String[]{"Uruchomiono klienta"});
   public final ModeSetting mode = new ModeSetting("Moduł", "Type-1", new String[]{"Type-1", "Type-2", "Type-3", "Type-4"});
   public final SliderSetting volume = new SliderSetting("Głośność", (double)100.0F, (double)1.0F, (double)100.0F, (double)1.0F);

   public ClientSounds() {
      this.addSettings(new Setting[]{this.check, this.mode, this.volume});
   }

   public void onEvent(Event event) {
   }
}
