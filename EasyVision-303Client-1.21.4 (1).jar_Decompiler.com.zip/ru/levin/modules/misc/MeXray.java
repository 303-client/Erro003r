package ru.levin.modules.misc;

import java.util.HashSet;
import java.util.Set;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import ru.levin.events.Event;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;

@FunctionAnnotation(
   name = "MeXray",
   desc = "Widoczne tylko wybrane bloki",
   type = Type.Misc
)
public class MeXray extends Function {
   private final TextSetting blocksList = new TextSetting("Bloki (oddzielone przecinkiem)", "diamond_ore, iron_ore, gold_ore");
   private Set<class_2248> visibleBlocks = new HashSet();
   private String lastConfig = "";

   public MeXray() {
      this.addSettings(new Setting[]{this.blocksList});
   }

   protected void onEnable() {
      this.rebuildBlockList();
      if (mc.field_1769 != null) {
         mc.field_1769.method_3279();
      }

   }

   protected void onDisable() {
      this.visibleBlocks.clear();
      if (mc.field_1769 != null) {
         mc.field_1769.method_3279();
      }

   }

   public void onEvent(Event event) {
      String currentConfig = this.blocksList.getValue();
      if (!currentConfig.equals(this.lastConfig)) {
         this.lastConfig = currentConfig;
         this.rebuildBlockList();
         if (mc.field_1769 != null) {
            mc.field_1769.method_3279();
         }
      }

   }

   private void rebuildBlockList() {
      this.visibleBlocks.clear();
      String[] blockNames = this.blocksList.getValue().split(",");

      for(String name : blockNames) {
         String trimmed = name.trim();
         if (!trimmed.isEmpty()) {
            try {
               class_2960 id = class_2960.method_12829(trimmed);
               if (id != null) {
                  class_2248 block = (class_2248)class_7923.field_41175.method_63535(id);
                  if (block != null && block != class_2246.field_10124) {
                     this.visibleBlocks.add(block);
                  }
               }
            } catch (Exception var9) {
            }
         }
      }

   }

   public boolean shouldRender(class_2248 block) {
      return !this.state ? true : this.visibleBlocks.contains(block);
   }

   public boolean isBlockVisible(class_2248 block) {
      return this.visibleBlocks.contains(block);
   }
}
