package ru.levin.modules.misc;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3965;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "AutoDrain",
   desc = "Automatycznie zbiera najbliższe źródła wody i lawy",
   type = Type.Misc
)
public class AutoDrain extends Function {
   private static final Set<class_2338> OWNED_SOURCES = ConcurrentHashMap.newKeySet();
   private final SliderSetting range = new SliderSetting("Zasięg", (double)5.0F, (double)1.0F, (double)8.0F, (double)1.0F);
   private final BooleanSetting water = new BooleanSetting("Woda", true);
   private final BooleanSetting lava = new BooleanSetting("Lawa", true);
   private final BooleanSetting takeMyWater = new BooleanSetting("Zabieraj moją wodę", false);
   private final BooleanSetting takeFriendsWater = new BooleanSetting("Zabieraj wodę znajomych", false);
   private int cooldown;

   public AutoDrain() {
      this.addSettings(new Setting[]{this.range, this.water, this.lava, this.takeMyWater, this.takeFriendsWater});
   }

   public static void recordBucketPlacement(class_1657 player, class_1268 hand, class_3965 hit) {
      if (player != null && hit != null && (player.method_5998(hand).method_31574(class_1802.field_8705) || player.method_5998(hand).method_31574(class_1802.field_8187))) {
         class_2338 placed = hit.method_17777().method_10093(hit.method_17780()).method_10062();
         OWNED_SOURCES.add(placed);
         OWNED_SOURCES.add(hit.method_17777().method_10062());
         OWNED_SOURCES.add(placed.method_10074());
         OWNED_SOURCES.add(placed.method_10084());
         OWNED_SOURCES.add(placed.method_10095());
         OWNED_SOURCES.add(placed.method_10072());
         OWNED_SOURCES.add(placed.method_10078());
         OWNED_SOURCES.add(placed.method_10067());
      }
   }

   public static boolean isOwnedSource(class_2338 pos) {
      return OWNED_SOURCES.contains(pos);
   }

   protected void onEnable() {
      this.cooldown = 0;
   }

   protected void onDisable() {
      this.cooldown = 0;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         if (this.cooldown > 0) {
            --this.cooldown;
         } else {
            int bucketSlot = this.findEmptyBucket();
            class_2338 source = this.findNearestSource();
            if (bucketSlot != -1 && source != null) {
               int previousSlot = mc.field_1724.method_31548().field_7545;
               mc.field_1724.method_31548().field_7545 = bucketSlot;
               mc.field_1724.field_3944.method_52787(new class_2868(bucketSlot));

               try {
                  class_243 hitPosition = class_243.method_24953(source).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
                  class_3965 hitResult = new class_3965(hitPosition, class_2350.field_11036, source, false);
                  class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
                  if (result.method_23665()) {
                     mc.field_1724.method_6104(class_1268.field_5808);
                     this.cooldown = 4;
                  }
               } finally {
                  mc.field_1724.method_31548().field_7545 = previousSlot;
                  mc.field_1724.field_3944.method_52787(new class_2868(previousSlot));
               }

            }
         }
      }
   }

   private int findEmptyBucket() {
      for(int slot = 0; slot < 9; ++slot) {
         if (mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8550)) {
            return slot;
         }
      }

      return -1;
   }

   private class_2338 findNearestSource() {
      class_2338 origin = mc.field_1724.method_24515();
      int radius = this.range.get().intValue();
      class_2338 nearest = null;
      double nearestDistance = Double.MAX_VALUE;

      for(int x = -radius; x <= radius; ++x) {
         for(int y = -radius; y <= radius; ++y) {
            for(int z = -radius; z <= radius; ++z) {
               class_2338 candidate = origin.method_10069(x, y, z);
               class_3610 fluid = mc.field_1687.method_8316(candidate);
               boolean isWater = fluid.method_15767(class_3486.field_15517);
               boolean isLava = fluid.method_15767(class_3486.field_15518);
               if (fluid.method_15771() && (!isWater || this.water.get()) && (!isLava || this.lava.get()) && (isWater || isLava) && !this.isProtectedFluid(candidate)) {
                  double distance = mc.field_1724.method_19538().method_1025(class_243.method_24953(candidate));
                  if (distance < nearestDistance) {
                     nearestDistance = distance;
                     nearest = candidate.method_10062();
                  }
               }
            }
         }
      }

      return nearest;
   }

   private boolean isProtectedFluid(class_2338 fluidPos) {
      boolean mine = OWNED_SOURCES.contains(fluidPos);
      if (mine) {
         return !this.takeMyWater.get();
      } else {
         return !this.takeFriendsWater.get();
      }
   }
}
