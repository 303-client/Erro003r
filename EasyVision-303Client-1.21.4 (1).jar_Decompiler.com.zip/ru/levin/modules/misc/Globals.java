package ru.levin.modules.misc;

import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_1657;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.apiManager.ClientAPI;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.Setting;

@FunctionAnnotation(
   name = "Globals",
   type = Type.Misc
)
public class Globals extends Function {
   private ClientAPI clientAPI;
   private final int port = 13599;
   private String playerName;
   public final Map<UUID, Boolean> isClientUserCache = new ConcurrentHashMap();

   public Globals() {
      this.addSettings(new Setting[0]);
   }

   public void onEnable() {
      super.onEnable();
      this.clientAPI = new ClientAPI("1.4.3", 13599);
      this.isClientUserCache.clear();
      if (mc.field_1724 != null) {
         this.playerName = mc.field_1724.method_7334().getName();
         this.clientAPI.addPlayer(this.playerName);
         ClientManager.message("[Globals] ClientAPI включён");
      }

   }

   public void onDisable() {
      super.onDisable();
      this.clear();
      ClientManager.message("[Globals] ClientAPI выключен");
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (mc.field_1724 != null && this.clientAPI != null) {
            if (mc.field_1724.field_6012 % 30 == 0) {
               Set<UUID> active = ConcurrentHashMap.newKeySet();

               for(class_1657 player : Manager.SYNC_MANAGER.getPlayers()) {
                  if (player != null) {
                     UUID uuid = player.method_5667();
                     active.add(uuid);
                     String name = player.method_7334().getName();
                     this.clientAPI.isClientUserAsync(name, (result) -> {
                        if (result) {
                           this.isClientUserCache.put(uuid, true);
                        } else {
                           this.isClientUserCache.remove(uuid);
                        }

                     });
                  }
               }

               this.isClientUserCache.keySet().removeIf((uuidx) -> !active.contains(uuidx));
            }

         }
      }
   }

   public void clear() {
      this.removePlayer();
      if (this.clientAPI != null) {
         this.clientAPI.shutdown();
      }

      this.clientAPI = null;
      this.isClientUserCache.clear();
   }

   private void removePlayer() {
      if (this.clientAPI != null && this.playerName != null) {
         this.clientAPI.removePlayer(this.playerName);
         this.playerName = null;
      }

   }
}
