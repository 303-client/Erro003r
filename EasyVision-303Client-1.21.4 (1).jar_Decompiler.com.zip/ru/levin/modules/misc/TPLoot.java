package ru.levin.modules.misc;

import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1738;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1809;
import net.minecraft.class_1829;
import net.minecraft.class_2338;
import net.minecraft.class_2828;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.manager.Manager;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.TextSetting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "TPLoot",
   desc = "Teleportuje w miejsce, w którym leżą przedmioty",
   type = Type.Misc
)
public class TPLoot extends Function {
   private final ModeSetting lootEnd = new ModeSetting("Po zdobyciu łupu", "Nic", new String[]{"Nic", "/hub", "/spawn", "home", "Własna"});
   private final TextSetting text = new TextSetting("Polecenie", "/home home", () -> this.lootEnd.is("home"));
   private final TextSetting custom = new TextSetting("Polecenie", "/test", () -> this.lootEnd.is("Własna"));
   private final TimerUtil timerUtil = new TimerUtil();
   private boolean check;

   public TPLoot() {
      this.addSettings(new Setting[]{this.lootEnd, this.text, this.custom});
   }

   private boolean isValuable(class_1799 stack) {
      if (stack != null && !stack.method_7960()) {
         class_1792 item = stack.method_7909();
         return item instanceof class_1829 || item instanceof class_1809 || item instanceof class_1738 || item == class_1802.field_8288 || item == class_1802.field_8634 || item == class_1802.field_8301 || item == class_1802.field_8639 || item == class_1802.field_8833 || item == class_1802.field_8463 || item == class_1802.field_8367 || item == class_1802.field_8696 || item == class_1802.field_8135 || item == class_1802.field_22421;
      } else {
         return false;
      }
   }

   private boolean isHotbar() {
      for(int i = 0; i < 9; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (this.isValuable(stack)) {
            return true;
         }
      }

      return false;
   }

   private boolean isInv() {
      for(int i = 9; i < 36; ++i) {
         class_1799 stack = mc.field_1724.method_31548().method_5438(i);
         if (this.isValuable(stack)) {
            return true;
         }
      }

      return false;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         for(class_1297 entity : Manager.SYNC_MANAGER.getEntities()) {
            if (entity instanceof class_1542) {
               class_1542 itemEntity = (class_1542)entity;
               class_1799 stack = itemEntity.method_6983();
               if (this.isValuable(stack)) {
                  double itemY = itemEntity.method_23318();
                  class_2338 blockBelow = itemEntity.method_24515().method_10074();
                  if (!mc.field_1687.method_8320(blockBelow).method_26215() && itemY - (double)blockBelow.method_10264() <= (double)1.0F) {
                     double x = itemEntity.method_23317() + (double)0.5F;
                     double y = itemEntity.method_23318();
                     double z = itemEntity.method_23321() + (double)0.5F;
                     mc.field_1724.field_3944.method_52787(new class_2828.class_2830(x, y, z, mc.field_1724.method_36454(), mc.field_1724.method_36455(), false, true));
                     this.check = true;
                  }
               }
            }
         }

         if (this.check && this.timerUtil.hasTimeElapsed(100L) && (this.isHotbar() || this.isInv())) {
            String var15 = this.lootEnd.get();
            byte var16 = -1;
            switch (var15.hashCode()) {
               case 1503846:
                  if (var15.equals("/hub")) {
                     var16 = 0;
                  }
                  break;
               case 3208415:
                  if (var15.equals("home")) {
                     var16 = 2;
                  }
                  break;
               case 32555970:
                  if (var15.equals("Własna")) {
                     var16 = 3;
                  }
                  break;
               case 1455208620:
                  if (var15.equals("/spawn")) {
                     var16 = 1;
                  }
            }

            switch (var16) {
               case 0 -> mc.field_1724.field_3944.method_45729("/hub");
               case 1 -> mc.field_1724.field_3944.method_45729("/spawn");
               case 2 -> mc.field_1724.field_3944.method_45729(this.text.getValue());
               case 3 -> mc.field_1724.field_3944.method_45729(this.custom.getValue());
            }

            this.check = false;
            this.timerUtil.reset();
         }

      }
   }
}
