package ru.levin.modules.misc;

import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_243;
import net.minecraft.class_2868;
import net.minecraft.class_3486;
import net.minecraft.class_3610;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3959.class_242;
import net.minecraft.class_3959.class_3960;
import ru.levin.events.Event;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.BooleanSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;

@FunctionAnnotation(
   name = "FastDrain",
   desc = "Porusza się realnie do źródeł wody i lawy i zbiera je",
   type = Type.Misc
)
public class FastDrain extends Function {
   private final SliderSetting range = new SliderSetting("Zasięg", (double)10.0F, (double)1.0F, (double)20.0F, (double)1.0F);
   private final SliderSetting speed = new SliderSetting("Prędkość", (double)0.5F, 0.1, (double)1.0F, 0.1);
   private final BooleanSetting water = new BooleanSetting("Woda", true);
   private final BooleanSetting lava = new BooleanSetting("Lawa", true);
   private final BooleanSetting autoJump = new BooleanSetting("Auto skok", true);
   private class_2338 targetSource = null;
   private int cooldown = 0;
   private int state = 0;

   public FastDrain() {
      this.addSettings(new Setting[]{this.range, this.speed, this.water, this.lava, this.autoJump});
   }

   protected void onEnable() {
      this.cooldown = 0;
      this.state = 0;
      this.targetSource = null;
   }

   protected void onDisable() {
      this.cooldown = 0;
      this.state = 0;
      this.targetSource = null;
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate && mc.field_1724 != null && mc.field_1687 != null && mc.field_1761 != null) {
         if (this.cooldown > 0) {
            --this.cooldown;
         } else {
            switch (this.state) {
               case 0:
                  this.targetSource = this.findNearestSource();
                  if (this.targetSource != null) {
                     this.state = 1;
                  }
                  break;
               case 1:
                  if (this.targetSource == null) {
                     this.state = 0;
                  } else if (this.moveToSource()) {
                     this.state = 2;
                     this.cooldown = 2;
                  }
                  break;
               case 2:
                  if (this.targetSource == null) {
                     this.state = 0;
                  } else if (this.collectSource()) {
                     this.state = 0;
                     this.targetSource = null;
                     this.cooldown = 5;
                  } else {
                     this.state = 0;
                  }
            }

         }
      }
   }

   private class_2338 findNearestSource() {
      class_2338 origin = mc.field_1724.method_24515();
      int radius = this.range.get().intValue();
      class_2338 nearest = null;
      double nearestDistance = Double.MAX_VALUE;

      for(int x = -radius; x <= radius; ++x) {
         for(int y = -radius; y <= radius; ++y) {
            for(int z = -radius; z <= radius; ++z) {
               class_2338 candidate = origin.method_10069(x, y, z);
               class_3610 fluid = mc.field_1687.method_8316(candidate);
               boolean isWater = fluid.method_15767(class_3486.field_15517);
               boolean isLava = fluid.method_15767(class_3486.field_15518);
               if (fluid.method_15771() && (!isWater || this.water.get()) && (!isLava || this.lava.get()) && (isWater || isLava) && this.isSourceVisible(candidate)) {
                  double distance = mc.field_1724.method_19538().method_1025(class_243.method_24953(candidate));
                  if (distance < nearestDistance) {
                     nearestDistance = distance;
                     nearest = candidate.method_10062();
                  }
               }
            }
         }
      }

      return nearest;
   }

   private boolean isSourceVisible(class_2338 sourcePos) {
      class_243 playerEyePos = mc.field_1724.method_33571();
      class_243 sourceCenter = class_243.method_24953(sourcePos);
      class_3965 raycast = mc.field_1687.method_17742(new class_3959(playerEyePos, sourceCenter, class_3960.field_17558, class_242.field_1348, mc.field_1724));
      class_2338 hitPos = raycast.method_17777();
      if (!hitPos.equals(sourcePos)) {
         return false;
      } else {
         class_2338 playerPos = mc.field_1724.method_24515();
         int yDiff = sourcePos.method_10264() - playerPos.method_10264();
         return Math.abs(yDiff) <= 3;
      }
   }

   private boolean moveToSource() {
      if (this.targetSource == null) {
         return false;
      } else {
         class_243 playerPos = mc.field_1724.method_19538();
         class_243 targetPos = class_243.method_24953(this.targetSource);
         double distance = playerPos.method_1022(targetPos);
         if (distance <= (double)2.0F) {
            return true;
         } else {
            class_243 direction = targetPos.method_1020(playerPos).method_1029();
            double moveSpeed = this.speed.get().doubleValue();
            double var10002 = direction.field_1352 * moveSpeed;
            double var10004 = direction.field_1350 * moveSpeed;
            class_243 velocity = new class_243(var10002, mc.field_1724.method_18798().field_1351, var10004);
            mc.field_1724.method_18799(velocity);
            if (this.autoJump.get() && mc.field_1724.field_5976) {
               mc.field_1724.method_6043();
            }

            return false;
         }
      }
   }

   private boolean collectSource() {
      int bucketSlot = this.findEmptyBucket();
      if (bucketSlot == -1) {
         return false;
      } else {
         int previousSlot = mc.field_1724.method_31548().field_7545;
         mc.field_1724.method_31548().field_7545 = bucketSlot;
         mc.field_1724.field_3944.method_52787(new class_2868(bucketSlot));

         boolean var6;
         try {
            class_243 hitPosition = class_243.method_24953(this.targetSource).method_1031((double)0.0F, (double)0.5F, (double)0.0F);
            class_3965 hitResult = new class_3965(hitPosition, class_2350.field_11036, this.targetSource, false);
            class_1269 result = mc.field_1761.method_2896(mc.field_1724, class_1268.field_5808, hitResult);
            if (!result.method_23665()) {
               return false;
            }

            mc.field_1724.method_6104(class_1268.field_5808);
            var6 = true;
         } finally {
            mc.field_1724.method_31548().field_7545 = previousSlot;
            mc.field_1724.field_3944.method_52787(new class_2868(previousSlot));
         }

         return var6;
      }
   }

   private int findEmptyBucket() {
      for(int slot = 0; slot < 9; ++slot) {
         if (mc.field_1724.method_31548().method_5438(slot).method_31574(class_1802.field_8550)) {
            return slot;
         }
      }

      return -1;
   }
}
