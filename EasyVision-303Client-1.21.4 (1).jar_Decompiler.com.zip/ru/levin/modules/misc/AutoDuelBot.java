package ru.levin.modules.misc;

import net.minecraft.class_2561;
import net.minecraft.class_7439;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionAnnotation;
import ru.levin.modules.Type;
import ru.levin.modules.setting.ModeSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.modules.setting.SliderSetting;
import ru.levin.util.player.TimerUtil;

@FunctionAnnotation(
   name = "AutoDuelBot",
   type = Type.Misc,
   desc = "Test"
)
public class AutoDuelBot extends Function {
   private final ModeSetting chat = new ModeSetting("Czat", "Lokalny", new String[]{"Lokalny", "Globalny"});
   private final SliderSetting fromMoney = new SliderSetting("Minimalna liczba monet", (double)1000.0F, (double)1000.0F, (double)1000000.0F, (double)1000.0F);
   private final SliderSetting beforeMoney = new SliderSetting("Maksymalna liczba monet", (double)1000000.0F, (double)1000.0F, (double)1000000.0F, (double)1000.0F);
   private final SliderSetting messageDelay = new SliderSetting("Opóźnienie wiadomości", (double)5000.0F, (double)3000.0F, (double)30000.0F, (double)1000.0F);
   private final TimerUtil timerUtil = new TimerUtil();
   private String lastNick = null;
   private int lastBet = -1;

   public AutoDuelBot() {
      this.addSettings(new Setting[]{this.chat, this.fromMoney, this.beforeMoney, this.messageDelay});
   }

   public void onEvent(Event event) {
      if (event instanceof EventUpdate) {
         if (this.timerUtil.hasTimeElapsed(this.messageDelay.get().longValue())) {
            int var10000 = this.fromMoney.get().intValue();
            String msg = "all Wysyłajcie wyzwania od " + var10000 + " do " + this.beforeMoney.get().intValue() + " monet";
            if (this.chat.is("Globalny")) {
               msg = "! " + msg;
            }

            mc.field_1724.field_3944.method_45729(msg);
            this.timerUtil.reset();
         }

         if (this.lastNick != null && this.lastBet >= 0) {
            if (this.lastBet >= this.fromMoney.get().intValue() && this.lastBet <= this.beforeMoney.get().intValue()) {
               mc.field_1724.field_3944.method_45729("/duel accept " + this.lastNick);
            }

            this.lastNick = null;
            this.lastBet = -1;
         }
      } else if (event instanceof EventPacket) {
         EventPacket eventPacket = (EventPacket)event;
         if (eventPacket.getPacket() instanceof class_7439) {
            class_2561 message = ((class_7439)eventPacket.getPacket()).comp_763();
            String text = message.getString();
            if (text.startsWith("➝ Gracz: ")) {
               this.lastNick = text.replace("➝ Gracz: ", "").trim();
            } else if (text.startsWith("➝ Stawka: ")) {
               try {
                  this.lastBet = Integer.parseInt(text.replace("➝ Stawka: ", "").trim());
               } catch (NumberFormatException var6) {
               }
            }
         }
      }

   }
}
