package ru.levin.modules;

public enum Type {
   Combat("f"),
   Move("w"),
   Render("E"),
   Player("r"),
   Misc("v");

   public final String icon;

   private Type(String icon) {
      this.icon = icon;
   }

   // $FF: synthetic method
   private static Type[] $values() {
      return new Type[]{Combat, Move, Render, Player, Misc};
   }
}
