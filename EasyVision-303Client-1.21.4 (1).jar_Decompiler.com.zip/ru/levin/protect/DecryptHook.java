package ru.levin.protect;

public class DecryptHook {
   public static void main(String[] args) {
      String hook = "Pu11pRLGmzQ/jHzBizY9N0WIl4lkbqWLI06mVwVTlWgbqfxRTdM3R15WGOIlIOKNxH4Itr0oDmmU5UQK5AOBXTo2pgwOw4opfOomn/CH+FO+hKfmLKM0hfji3DJZEyETY7Ug6ZI4BgnK7xzrrD0CkvONZVcxZSZM9pE28Hk3CsM=";

      try {
         System.out.println(AES.decrypt(hook));
      } catch (Exception e) {
         e.printStackTrace();
      }

   }
}
