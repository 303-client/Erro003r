package ru.levin.protect.loader;

public class NativeProfile {
   private static String username = System.getProperty("levin.username", "N/A");
   private static String role = System.getProperty("levin.role", "Unknown role");
   private static String expiryDate = System.getProperty("levin.expiry", "Unknown date!");

   public NativeProfile(String name, String role, String expiry) {
      username = name;
      NativeProfile.role = role;
      expiryDate = expiry;
   }

   public static String getName() {
      return username;
   }

   public static String getRole() {
      return role;
   }

   public static String getExpiryDate() {
      return expiryDate;
   }
}
