package ru.levin.protect;

import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

public class AES {
   private static final String secretKey = "2B7E151628AED2A6ABF7158809CF4F3C";
   private static final String algorithm = "AES";

   public static String encrypt(String plainText) throws Exception {
      SecretKeySpec keySpec = new SecretKeySpec("2B7E151628AED2A6ABF7158809CF4F3C".getBytes(), "AES");
      Cipher cipher = Cipher.getInstance("AES");
      cipher.init(1, keySpec);
      byte[] encryptedBytes = cipher.doFinal(plainText.getBytes());
      return Base64.getEncoder().encodeToString(encryptedBytes);
   }

   public static String decrypt(String encryptedText) throws Exception {
      SecretKeySpec keySpec = new SecretKeySpec("2B7E151628AED2A6ABF7158809CF4F3C".getBytes(), "AES");
      Cipher cipher = Cipher.getInstance("AES");
      cipher.init(2, keySpec);
      byte[] encryptedBytes = Base64.getDecoder().decode(encryptedText);
      byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
      return new String(decryptedBytes);
   }
}
