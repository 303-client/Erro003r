package ru.levin.manager.modulesManager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashSet;
import java.util.Objects;
import java.util.Set;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_7923;

public class ChestStealerManager {
   private final File file;
   private final Set<class_1792> whitelist = new HashSet();

   public ChestStealerManager() {
      this.file = new File(new File((File)Objects.requireNonNull(class_310.method_1551().field_1697), "files/modules"), "cheststealer.ew");
      this.load();
      if (this.whitelist.isEmpty()) {
         this.addDefaultItems();
         this.save();
      }

   }

   private void addDefaultItems() {
      this.addItem("minecraft:totem_of_undying");
      this.addItem("minecraft:player_head");
   }

   public boolean addItem(String name) {
      class_2960 id = class_2960.method_12829(name);
      if (id != null && class_7923.field_41178.method_10250(id)) {
         class_1792 item = (class_1792)class_7923.field_41178.method_63535(id);
         if (this.whitelist.add(item)) {
            this.save();
            return true;
         }
      }

      return false;
   }

   public boolean removeItem(String name) {
      class_2960 id = class_2960.method_12829(name);
      if (id != null && class_7923.field_41178.method_10250(id)) {
         class_1792 item = (class_1792)class_7923.field_41178.method_63535(id);
         if (this.whitelist.remove(item)) {
            this.save();
            return true;
         }
      }

      return false;
   }

   public boolean isAllowed(class_1792 item) {
      return this.whitelist.contains(item);
   }

   public Set<class_1792> getWhitelist() {
      return this.whitelist;
   }

   private void save() {
      try {
         this.file.getParentFile().mkdirs();
         BufferedWriter writer = new BufferedWriter(new FileWriter(this.file));

         try {
            for(class_1792 item : this.whitelist) {
               class_2960 id = class_7923.field_41178.method_10221(item);
               writer.write(id.toString());
               writer.newLine();
            }
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   private void load() {
      this.whitelist.clear();
      if (this.file.exists()) {
         try {
            BufferedReader reader = new BufferedReader(new FileReader(this.file));

            String line;
            try {
               while((line = reader.readLine()) != null) {
                  class_2960 id = class_2960.method_12829(line.trim());
                  if (id != null && class_7923.field_41178.method_10250(id)) {
                     this.whitelist.add((class_1792)class_7923.field_41178.method_63535(id));
                  }
               }
            } catch (Throwable var5) {
               try {
                  reader.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }

               throw var5;
            }

            reader.close();
         } catch (IOException e) {
            e.printStackTrace();
         }

      }
   }
}
