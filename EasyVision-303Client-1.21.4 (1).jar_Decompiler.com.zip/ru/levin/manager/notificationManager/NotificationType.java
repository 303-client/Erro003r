package ru.levin.manager.notificationManager;

import net.minecraft.class_4587;
import ru.levin.util.render.RenderUtil;

public enum NotificationType {
   INFO("info.png"),
   SUCCESS("add.png"),
   REMOVED("remove.png");

   private final String texture;

   private NotificationType(String texture) {
      this.texture = texture;
   }

   public int renderIcon(class_4587 matrixStack, float x, float y, int color) {
      RenderUtil.drawTexture(matrixStack, "images/state/" + this.texture, x, y, 16.0F, 16.0F, 8.0F, color);
      return 0;
   }

   public String getTexture() {
      return this.texture;
   }

   // $FF: synthetic method
   private static NotificationType[] $values() {
      return new NotificationType[]{INFO, SUCCESS, REMOVED};
   }
}
