package ru.levin.manager.notificationManager;

import java.util.concurrent.CopyOnWriteArrayList;
import net.minecraft.class_332;
import net.minecraft.class_2350.class_2352;
import ru.levin.manager.IMinecraft;
import ru.levin.util.math.MathUtil;

public class NotificationManager implements IMinecraft {
   private final CopyOnWriteArrayList<Notification> notifications = new CopyOnWriteArrayList();

   public void add(NotificationType type, String name, String desc, int time) {
      this.notifications.add(new Notification(type, name, desc, time));
   }

   public void draw(class_332 context) {
      int yoffset = 0;

      for(Notification notification : this.notifications) {
         long timePassed = System.currentTimeMillis() - notification.getTime();
         long totalDuration = (long)notification.times * 1000L;
         if (timePassed > totalDuration - 222L) {
            notification.animation.setDirection(class_2352.field_11060);
         }

         notification.alpha = (float)notification.animation.getOutput();
         if (timePassed > totalDuration) {
            notification.animationy.setDirection(class_2352.field_11060);
         }

         if (notification.animationy.finished(class_2352.field_11060)) {
            this.notifications.remove(notification);
         } else {
            float fixedRightPadding = 8.0F;
            float width = notification.getWidth();
            float baseX = (float)mc.method_22683().method_4486() - width - fixedRightPadding;
            float baseY = (float)(mc.method_22683().method_4502() - 30);
            notification.animationy.setEndPoint((double)((float)yoffset * 1.1F));
            notification.animationy.setDuration(300);
            float y;
            if (notification.animationy.getDirection() == class_2352.field_11060) {
               y = baseY - (float)((double)notification.draw(context) * notification.animationy.getOutput());
            } else {
               y = baseY - notification.draw(context) * (float)yoffset * 1.1F;
            }

            float x = baseX;
            if (notification.animation.getDirection() == class_2352.field_11060) {
               double output = notification.animation.getOutput();
               x = baseX + (float)((double)width * ((double)1.0F - output));
            }

            notification.setX(x);
            if (y <= notification.getY()) {
               notification.setY(y);
            } else {
               notification.setY(MathUtil.fast(notification.getY(), y, 10.0F));
            }

            ++yoffset;
         }
      }

   }
}
