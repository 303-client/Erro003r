package ru.levin.manager.commandManager;

import com.mojang.brigadier.CommandDispatcher;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2172;
import net.minecraft.class_634;
import net.minecraft.class_637;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.commandManager.impl.BindCommand;
import ru.levin.manager.commandManager.impl.BlockESPCommand;
import ru.levin.manager.commandManager.impl.ChestStealerCommand;
import ru.levin.manager.commandManager.impl.ConfigCommand;
import ru.levin.manager.commandManager.impl.DragCommand;
import ru.levin.manager.commandManager.impl.FriendCommand;
import ru.levin.manager.commandManager.impl.GpsCommand;
import ru.levin.manager.commandManager.impl.HclipCommand;
import ru.levin.manager.commandManager.impl.IrcCommand;
import ru.levin.manager.commandManager.impl.MacroCommand;
import ru.levin.manager.commandManager.impl.PanicCommand;
import ru.levin.manager.commandManager.impl.ParseCommand;
import ru.levin.manager.commandManager.impl.StaffCommand;
import ru.levin.manager.commandManager.impl.UnHookCommand;
import ru.levin.manager.commandManager.impl.VclipCommand;
import ru.levin.manager.commandManager.impl.WayPointCommand;

public class CommandManager implements IMinecraft {
   private String prefix = ".";
   private final CommandDispatcher<class_2172> dispatcher = new CommandDispatcher();
   private final class_2172 source;
   private final List<Command> commands;

   public CommandManager() {
      this.source = new class_637((class_634)null, mc);
      this.commands = new ArrayList();
      this.register(new FriendCommand());
      this.register(new GpsCommand());
      this.register(new WayPointCommand());
      this.register(new UnHookCommand());
      this.register(new ConfigCommand());
      this.register(new ChestStealerCommand());
      this.register(new StaffCommand());
      this.register(new BlockESPCommand());
      this.register(new BindCommand());
      this.register(new DragCommand());
      this.register(new IrcCommand());
      this.register(new MacroCommand());
      this.register(new PanicCommand());
      this.register(new ParseCommand());
      this.register(new VclipCommand());
      this.register(new HclipCommand());
   }

   public void register(Command command) {
      if (command != null) {
         command.register(this.dispatcher);
         this.commands.add(command);
      }
   }

   public final CommandDispatcher getDispatcher() {
      return this.dispatcher;
   }

   public final class_2172 getSource() {
      return this.source;
   }

   public final String getPrefix() {
      return this.prefix;
   }
}
