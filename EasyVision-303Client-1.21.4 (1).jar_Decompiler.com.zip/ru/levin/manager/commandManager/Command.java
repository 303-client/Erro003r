package ru.levin.manager.commandManager;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.minecraft.class_2172;
import org.jetbrains.annotations.NotNull;
import ru.levin.manager.IMinecraft;

public abstract class Command implements IMinecraft {
   private final String command;

   protected Command(String command) {
      this.command = command;
   }

   public void register(CommandDispatcher<class_2172> dispatcher) {
      LiteralArgumentBuilder<class_2172> builder = LiteralArgumentBuilder.literal(this.command);
      this.execute(builder);
      dispatcher.register(builder);
   }

   public abstract void execute(LiteralArgumentBuilder<class_2172> var1);

   protected static <T> @NotNull RequiredArgumentBuilder<class_2172, T> arg(String name, ArgumentType<T> type) {
      return RequiredArgumentBuilder.argument(name, type);
   }

   protected static @NotNull LiteralArgumentBuilder<class_2172> literal(String name) {
      return LiteralArgumentBuilder.literal(name);
   }
}
