package ru.levin.manager.commandManager.impl.args;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import ru.levin.manager.IMinecraft;

public class PlayerArgumentType implements ArgumentType<String>, IMinecraft {
   public static PlayerArgumentType create() {
      return new PlayerArgumentType();
   }

   public String parse(StringReader reader) throws CommandSyntaxException {
      return reader.readString();
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
      List<String> onlinePlayers = mc.field_1724.field_3944.method_2880().stream().map((entry) -> entry.method_2966().getName()).toList();
      return class_2172.method_9265(onlinePlayers, builder);
   }

   public Collection<String> getExamples() {
      return List.of("Steve", "Alex", "Notch", "levinPaster");
   }
}
