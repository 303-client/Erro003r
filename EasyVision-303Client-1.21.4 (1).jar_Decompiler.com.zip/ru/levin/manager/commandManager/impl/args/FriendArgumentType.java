package ru.levin.manager.commandManager.impl.args;

import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.exceptions.DynamicCommandExceptionType;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.Collection;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import ru.levin.manager.Manager;

public class FriendArgumentType implements ArgumentType<String> {
   private static final DynamicCommandExceptionType NOT_FRIEND_EXCEPTION = new DynamicCommandExceptionType((name) -> class_2561.method_43470("У тебя нет друга " + String.valueOf(name)));

   public static FriendArgumentType create() {
      return new FriendArgumentType();
   }

   public String parse(StringReader reader) throws CommandSyntaxException {
      String name = reader.readString();
      if (!Manager.FRIEND_MANAGER.isFriend(name)) {
         throw NOT_FRIEND_EXCEPTION.create(name);
      } else {
         return name;
      }
   }

   public <S> CompletableFuture<Suggestions> listSuggestions(CommandContext<S> context, SuggestionsBuilder builder) {
      List<String> friendNames = Manager.FRIEND_MANAGER.getFriends().stream().map((f) -> f.getName()).toList();
      return class_2172.method_9265(friendNames, builder);
   }

   public Collection<String> getExamples() {
      return Manager.FRIEND_MANAGER.getFriends().stream().limit(5L).map((f) -> f.getName()).toList();
   }
}
