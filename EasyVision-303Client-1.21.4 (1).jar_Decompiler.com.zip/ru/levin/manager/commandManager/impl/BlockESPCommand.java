package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.awt.Color;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_7923;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;

public class BlockESPCommand extends Command {
   private static final Map<String, Color> COLOR_NAMES;

   public BlockESPCommand() {
      super("blockesp");
   }

   public void execute(LiteralArgumentBuilder<class_2172> root) {
      root.then(literal("add").then(arg("block", StringArgumentType.word()).suggests(this::suggestBlocks).then(arg("color", StringArgumentType.word()).suggests(this::suggestColors).executes((ctx) -> this.addBlock(ctx)))));
      root.then(literal("remove").then(arg("block", StringArgumentType.word()).suggests(this::suggestBlocks).executes((ctx) -> this.removeBlock(ctx))));
   }

   private int addBlock(CommandContext<class_2172> ctx) {
      String blockName = StringArgumentType.getString(ctx, "block");
      String colorStr = StringArgumentType.getString(ctx, "color").toLowerCase();
      if (!blockName.contains(":")) {
         blockName = "minecraft:" + blockName;
      }

      Color color = (Color)COLOR_NAMES.get(colorStr);
      if (color == null) {
         try {
            if (!colorStr.startsWith("#")) {
               colorStr = "#" + colorStr;
            }

            color = Color.decode(colorStr);
         } catch (NumberFormatException var6) {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Неверный цвет. Используй название цвета или HEX (например, ff00ff)");
            return 1;
         }
      }

      color = new Color(color.getRed(), color.getGreen(), color.getBlue(), 150);
      Manager.FUNCTION_MANAGER.blockESP.addCustomBlock(blockName, color);
      ClientManager.message(String.valueOf(class_124.field_1060) + "Добавлен блок " + blockName + " с цветом " + colorStr);
      return 1;
   }

   private int removeBlock(CommandContext<class_2172> ctx) {
      String blockName = StringArgumentType.getString(ctx, "block");
      if (!blockName.contains(":")) {
         blockName = "minecraft:" + blockName;
      }

      Manager.FUNCTION_MANAGER.blockESP.removeCustomBlock(blockName);
      String var10000 = String.valueOf(class_124.field_1060);
      ClientManager.message(var10000 + "Удалён блок " + blockName + " из подсветки");
      return 1;
   }

   private CompletableFuture<Suggestions> suggestColors(CommandContext<class_2172> ctx, SuggestionsBuilder builder) {
      return class_2172.method_9265(COLOR_NAMES.keySet(), builder);
   }

   private CompletableFuture<Suggestions> suggestBlocks(CommandContext<class_2172> ctx, SuggestionsBuilder builder) {
      return class_2172.method_9265(class_7923.field_41175.method_10220().map((b) -> class_7923.field_41175.method_10221(b).method_12832()).toList(), builder);
   }

   static {
      COLOR_NAMES = Map.ofEntries(Map.entry("white", Color.WHITE), Map.entry("black", Color.BLACK), Map.entry("red", Color.RED), Map.entry("green", Color.GREEN), Map.entry("blue", Color.BLUE), Map.entry("yellow", Color.YELLOW), Map.entry("cyan", Color.CYAN), Map.entry("magenta", Color.MAGENTA), Map.entry("gray", Color.GRAY), Map.entry("darkgray", Color.DARK_GRAY), Map.entry("lightgray", Color.LIGHT_GRAY), Map.entry("orange", Color.ORANGE), Map.entry("pink", Color.PINK), Map.entry("белый", Color.WHITE), Map.entry("чёрный", Color.BLACK), Map.entry("черный", Color.BLACK), Map.entry("красный", Color.RED), Map.entry("зелёный", Color.GREEN), Map.entry("зеленый", Color.GREEN), Map.entry("синий", Color.BLUE), Map.entry("жёлтый", Color.YELLOW), Map.entry("желтый", Color.YELLOW), Map.entry("голубой", Color.CYAN), Map.entry("пурпурный", Color.MAGENTA), Map.entry("серый", Color.GRAY), Map.entry("тёмно-серый", Color.DARK_GRAY), Map.entry("темно-серый", Color.DARK_GRAY), Map.entry("светло-серый", Color.LIGHT_GRAY), Map.entry("оранжевый", Color.ORANGE), Map.entry("розовый", Color.PINK));
   }
}
