package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.awt.Color;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_3532;
import net.minecraft.class_4587;
import net.minecraft.class_7833;
import org.joml.Vector2f;
import ru.levin.manager.ClientManager;
import ru.levin.manager.commandManager.Command;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.util.render.RenderUtil;

public class GpsCommand extends Command {
   private static boolean enabled;
   private static class_2338 GPS_POSITION;
   private static float smoothYaw = 0.0F;

   public GpsCommand() {
      super("gps");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      RequiredArgumentBuilder<class_2172, Integer> xArg = arg("x", IntegerArgumentType.integer());
      RequiredArgumentBuilder<class_2172, Integer> zArg = arg("z", IntegerArgumentType.integer());
      zArg.executes((context) -> {
         int x = IntegerArgumentType.getInteger(context, "x");
         int z = IntegerArgumentType.getInteger(context, "z");
         setGps(x, z);
         return 1;
      });
      xArg.then(zArg);
      builder.then(xArg);
      builder.then(literal("set").then(arg("x", IntegerArgumentType.integer()).then(arg("z", IntegerArgumentType.integer()).executes((context) -> {
         int x = IntegerArgumentType.getInteger(context, "x");
         int z = IntegerArgumentType.getInteger(context, "z");
         setGps(x, z);
         return 1;
      }))));
      builder.then(literal("off").executes((context) -> {
         enabled = false;
         GPS_POSITION = null;
         ClientManager.message(String.valueOf(class_124.field_1080) + "GPS выключен!");
         return 1;
      }));
   }

   private static void setGps(int x, int z) {
      GPS_POSITION = new class_2338(x, (int)mc.field_1724.method_23318(), z);
      enabled = true;
      String var10000 = String.valueOf(class_124.field_1080);
      ClientManager.message(var10000 + "GPS на координаты X: " + x + ", Y: " + mc.field_1724.method_23318() + ", Z: " + z);
   }

   private static int getDistance(class_2338 pos) {
      double dx = mc.field_1724.method_23317() - (double)pos.method_10263();
      double dz = mc.field_1724.method_23321() - (double)pos.method_10260();
      return (int)class_3532.method_15355((float)(dx * dx + dz * dz));
   }

   private static float getYaw(Vector2f target) {
      double dx = (double)target.x - mc.field_1724.method_23317();
      double dz = (double)target.y - mc.field_1724.method_23321();
      return (float)(-(Math.atan2(dx, dz) * (180D / Math.PI)));
   }

   public static void render(class_4587 matrixStack) {
      if (enabled && GPS_POSITION != null && mc.field_1724 != null) {
         float screenWidth = (float)mc.method_22683().method_4486() / 2.0F;
         float screenHeight = (float)mc.method_22683().method_4502() / 2.0F;
         float targetYaw = getYaw(new Vector2f((float)GPS_POSITION.method_10263(), (float)GPS_POSITION.method_10260())) - mc.field_1724.method_36454();
         targetYaw = class_3532.method_15393(targetYaw);
         float maxStep = 4.0F;
         float delta = class_3532.method_15393(targetYaw - smoothYaw);
         smoothYaw += class_3532.method_15363(delta, -maxStep, maxStep);
         int distance = getDistance(GPS_POSITION);
         if (distance < 1) {
            FontUtils.durman[15].centeredDraw(matrixStack, "Вы на месте!", screenWidth, screenHeight - 105.0F, -1);
         } else {
            matrixStack.method_22903();
            matrixStack.method_46416(screenWidth, screenHeight - 120.0F, 0.0F);
            matrixStack.method_22907(class_7833.field_40718.rotationDegrees(smoothYaw));
            RenderUtil.drawTexture(matrixStack, "images/triangle2.png", -12.0F, -12.0F, 25.0F, 25.0F, 0.0F, Color.white.getRGB());
            matrixStack.method_22909();
            FontUtils.durman[15].centeredDraw(matrixStack, distance + "m", screenWidth, screenHeight - 105.0F, -1);
         }
      }
   }
}
