package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2561;
import net.minecraft.class_268;
import net.minecraft.class_634;
import net.minecraft.class_640;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;
import ru.levin.manager.commandManager.Command;

public class ParseCommand extends Command implements IMinecraft {
   private static final File PARSE_DIR;
   private static final Map<String, String> PRIVILEGE_REPLACEMENTS;

   public ParseCommand() {
      super("parse");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("start").executes((context) -> {
         this.parsePlayers();
         return 1;
      }));
      builder.then(literal("dir").executes((context) -> {
         this.openDirectory();
         return 1;
      }));
   }

   private void parsePlayers() {
      if (!PARSE_DIR.exists() && !PARSE_DIR.mkdirs()) {
         ClientManager.message(String.valueOf(class_124.field_1061) + "Ошибка создания директории!");
      } else {
         class_634 networkHandler = mc.method_1562();
         if (networkHandler == null) {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Вы не подключены к серверу!");
         } else {
            Collection<class_640> playerEntries = networkHandler.method_2880();
            Map<String, List<String>> privilegeGroups = new LinkedHashMap();
            String serverIp = "unknown";
            if (mc.method_1558() != null) {
               serverIp = mc.method_1558().field_3761;
            } else if (mc.field_1687 != null) {
               serverIp = "localhost";
            }

            File file = this.getUniqueFileName(serverIp);

            try {
               FileWriter fileWriter = new FileWriter(file);

               label98: {
                  try {
                     for(class_640 entry : playerEntries) {
                        class_268 team = entry.method_2955();
                        if (team != null) {
                           class_2561 prefix = team.method_1144();
                           if (prefix != null) {
                              String privilege = this.replaceChineseSymbols(prefix.getString());
                              privilegeGroups.computeIfAbsent(privilege, (k) -> new ArrayList());
                           }
                        }
                     }

                     if (!privilegeGroups.isEmpty()) {
                        for(class_640 entry : playerEntries) {
                           class_268 team = entry.method_2955();
                           if (team != null) {
                              class_2561 prefix = team.method_1144();
                              if (prefix != null) {
                                 String privilege = this.replaceChineseSymbols(prefix.getString());
                                 String playerName = entry.method_2966().getName();
                                 ((List)privilegeGroups.getOrDefault(privilege, new ArrayList())).add(playerName);
                              }
                           }
                        }

                        for(Map.Entry<String, List<String>> group : privilegeGroups.entrySet()) {
                           if (!((List)group.getValue()).isEmpty()) {
                              fileWriter.write("// Привилегия: " + (String)group.getKey() + "\n\n");

                              for(String player : (List)group.getValue()) {
                                 fileWriter.write(player + "\n");
                              }

                              fileWriter.write("\n");
                           }
                        }

                        String var25 = String.valueOf(class_124.field_1060);
                        ClientManager.message(var25 + "Успешно! Спаршено " + privilegeGroups.values().stream().mapToInt(List::size).sum() + " игроков по " + privilegeGroups.size() + " привилегиям");
                        var25 = String.valueOf(class_124.field_1080);
                        ClientManager.message(var25 + "Файл сохранен как: " + file.getName());
                        break label98;
                     }

                     ClientManager.message(String.valueOf(class_124.field_1054) + "Привилегии в табе не найдены!");
                  } catch (Throwable var14) {
                     try {
                        fileWriter.close();
                     } catch (Throwable var13) {
                        var14.addSuppressed(var13);
                     }

                     throw var14;
                  }

                  fileWriter.close();
                  return;
               }

               fileWriter.close();
            } catch (Exception e) {
               String var10000 = String.valueOf(class_124.field_1061);
               ClientManager.message(var10000 + "Ошибка: " + e.getMessage());
               e.printStackTrace();
            }

         }
      }
   }

   private File getUniqueFileName(String baseName) {
      File file = new File(PARSE_DIR, baseName + ".txt");
      if (!file.exists()) {
         return file;
      } else {
         int counter = 2;

         while(true) {
            file = new File(PARSE_DIR, baseName + "_" + counter + ".txt");
            if (!file.exists()) {
               return file;
            }

            ++counter;
         }
      }
   }

   private String replaceChineseSymbols(String privilege) {
      for(Map.Entry<String, String> entry : PRIVILEGE_REPLACEMENTS.entrySet()) {
         if (privilege.contains((CharSequence)entry.getKey())) {
            return (String)entry.getValue();
         }
      }

      return privilege;
   }

   private void openDirectory() {
      try {
         Runtime.getRuntime().exec("explorer \"" + PARSE_DIR.getAbsolutePath() + "\"");
      } catch (IOException e) {
         String var10000 = String.valueOf(class_124.field_1061);
         ClientManager.message(var10000 + "Ошибка открытия директории: " + e.getMessage());
      }

   }

   static {
      PARSE_DIR = new File(mc.field_1697, "files\\parser");
      PRIVILEGE_REPLACEMENTS = new HashMap();
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔥ §7§7", "MODER");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔥ §7§7", "MODER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔥ §7§7", "MODER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔉ §7§7", "HELPER");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔉ §7§7", "HELPER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔉ §7§7", "HELPER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔁ §7§7", "MEDIA");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔁ §7§7", "MEDIA");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔁ §7§7", "MEDIA");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꕠ §7§7", "D.HELPER");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꕠ §7§7", "D.HELPER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꕠ §7§7", "D.HELPER");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꕒ §7§7", "RABBIT");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꕒ §7§7", "RABBIT");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꕒ §7§7", "RABBIT");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꕄ §7§7", "DRACULA");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꕄ §7§7", "DRACULA");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꕄ §7§7", "DRACULA");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꕈ §7§7", "COBRA");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꕈ §7§7", "COBRA");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꕈ §7§7", "COBRA");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꕀ §7§7", "HYDRA");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꕀ §7§7", "HYDRA");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꕀ §7§7", "HYDRA");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꕖ §7§7", "BUNNY");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꕖ §7§7", "BUNNY");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꕖ §7§7", "BUNNY");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔶ §7§7", "TIGER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔶ §7§7", "TIGER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔶ §7§7", "TIGER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔨ §7§7", "DRAGON");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔨ §7§7", "DRAGON");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔨ §7§7", "DRAGON");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔤ §7§7", "IMPERATOR");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔤ §7§7", "IMPERATOR");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔤ §7§7", "IMPERATOR");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔠ §7§7", "MAGISTER");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔠ §7§7", "MAGISTER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔠ §7§7", "MAGISTER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔖ §7§7", "OVERLORD");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔖ §7§7", "OVERLORD");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔖ §7§7", "OVERLORD");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔒ §7§7", "AVENGER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔒ §7§7", "AVENGER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔒ §7§7", "AVENGER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔈ §7§7", "TITAN");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔈ §7§7", "TITAN");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔈ §7§7", "TITAN");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔄ §7§7", "HERO");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔄ §7§7", "HERO");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔄ §7§7", "HERO");
      PRIVILEGE_REPLACEMENTS.put("§c●§f §fꔀ §7§7", "PLAYER");
      PRIVILEGE_REPLACEMENTS.put("§a●§f §fꔀ §7§7", "PLAYER");
      PRIVILEGE_REPLACEMENTS.put("§6●§f §fꔀ §7§7", "PLAYER");
   }
}
