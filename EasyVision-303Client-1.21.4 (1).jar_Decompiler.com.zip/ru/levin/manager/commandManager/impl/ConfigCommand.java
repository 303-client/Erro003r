package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import java.io.IOException;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;
import ru.levin.manager.configManager.ConfigManager;

public class ConfigCommand extends Command {
   public ConfigCommand() {
      super("cfg");
   }

   public void execute(LiteralArgumentBuilder<class_2172> root) {
      root.then(literal("save").then(arg("name", StringArgumentType.word()).suggests((ctx, builder) -> {
         Manager.CONFIG_MANAGER.getAllConfigurations().forEach((s) -> builder.suggest(s.replace(".json", "")));
         return builder.buildFuture();
      }).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name").toUpperCase();
         Manager.CONFIG_MANAGER.saveConfiguration(name);
         ClientManager.message("Конфиг с именем " + name + " сохранён");
         return 1;
      })));
      root.then(literal("load").then(arg("name", StringArgumentType.word()).suggests((ctx, builder) -> {
         Manager.CONFIG_MANAGER.getAllConfigurations().forEach((s) -> builder.suggest(s.replace(".json", "")));
         return builder.buildFuture();
      }).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name").toUpperCase();
         Manager.CONFIG_MANAGER.loadConfiguration(name, false);
         return 1;
      })));
      root.then(literal("remove").then(arg("name", StringArgumentType.word()).suggests((ctx, builder) -> {
         Manager.CONFIG_MANAGER.getAllConfigurations().forEach((s) -> builder.suggest(s.replace(".json", "")));
         return builder.buildFuture();
      }).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name").toUpperCase();
         Manager.CONFIG_MANAGER.deleteConfig(name);
         ClientManager.message("Конфиг " + name + " удалён");
         return 1;
      })));
      root.then(literal("list").executes((ctx) -> {
         List<String> configs = Manager.CONFIG_MANAGER.getAllConfigurations();
         if (configs.isEmpty()) {
            ClientManager.message("Список конфигов пуст");
         } else {
            ClientManager.message("Список конфигов:");
            configs.forEach((s) -> ClientManager.message(s.replace(".json", "")));
         }

         return 1;
      }));
      root.then(literal("reset").executes((ctx) -> {
         Manager.FUNCTION_MANAGER.getFunctions().stream().filter((f) -> f.state).forEach((f) -> f.setState(false));
         ClientManager.message("Конфиг сброшен");
         return 1;
      }));
      root.then(literal("dir").executes((ctx) -> {
         try {
            Runtime.getRuntime().exec("explorer " + Manager.CONFIG_MANAGER.CONFIG_DIR.getAbsolutePath());
         } catch (IOException e) {
            ClientManager.message("Ошибка при открытии папки: " + e.getMessage());
         }

         return 1;
      }));
      root.then(literal("clear").executes((ctx) -> {
         List<String> configs = Manager.CONFIG_MANAGER.getAllConfigurations();
         if (configs.isEmpty()) {
            ClientManager.message("Список конфигов пуст");
            return 1;
         } else {
            ConfigManager var10001 = Manager.CONFIG_MANAGER;
            Objects.requireNonNull(var10001);
            configs.forEach(var10001::deleteConfig);
            ClientManager.message("Все конфиги удалены");
            return 1;
         }
      }));
   }
}
