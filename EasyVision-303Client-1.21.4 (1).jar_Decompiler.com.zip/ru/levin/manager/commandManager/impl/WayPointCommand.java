package ru.levin.manager.commandManager.impl;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import java.awt.Color;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.LinkOption;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import org.joml.Vector3d;
import ru.levin.manager.ClientManager;
import ru.levin.manager.commandManager.Command;
import ru.levin.manager.fontManager.FontUtils;
import ru.levin.util.render.RenderUtil;
import ru.levin.util.vector.VectorUtil;

public class WayPointCommand extends Command {
   private final Path FILE;
   private final Gson GSON;
   private final Type TYPE;
   private static Map<String, class_2338> waypoints = new ConcurrentHashMap();

   public WayPointCommand() {
      super("way");
      this.FILE = Paths.get(mc.field_1697.getAbsolutePath(), "files\\modules", "waypoints.ew");
      this.GSON = new Gson();
      this.TYPE = (new TypeToken<Map<String, class_2338>>() {
      }).getType();
      this.load();
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("add").then(((RequiredArgumentBuilder)arg("name", StringArgumentType.word()).executes((ctx) -> {
         class_2338 pos = mc.field_1724.method_24515();
         String name = StringArgumentType.getString(ctx, "name");
         waypoints.put(name, pos);
         this.save();
         ClientManager.message("§aТочка §f" + name + " §aсохранена: " + pos.method_23854());
         return 1;
      })).then(arg("x", IntegerArgumentType.integer()).then(arg("y", IntegerArgumentType.integer()).then(arg("z", IntegerArgumentType.integer()).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name");
         int x = IntegerArgumentType.getInteger(ctx, "x");
         int y = IntegerArgumentType.getInteger(ctx, "y");
         int z = IntegerArgumentType.getInteger(ctx, "z");
         class_2338 pos = new class_2338(x, y, z);
         waypoints.put(name, pos);
         this.save();
         ClientManager.message("§aТочка §f" + name + " §aсохранена: " + pos.method_23854());
         return 1;
      }))))));
      builder.then(literal("remove").then(arg("name", StringArgumentType.word()).suggests((ctx, suggestionsBuilder) -> {
         Set var10000 = waypoints.keySet();
         Objects.requireNonNull(suggestionsBuilder);
         var10000.forEach(suggestionsBuilder::suggest);
         return suggestionsBuilder.buildFuture();
      }).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name");
         if (waypoints.remove(name) != null) {
            this.save();
            ClientManager.message("§aТочка §f" + name + " §aудалена!");
         } else {
            ClientManager.message("§cТакой точки нет!");
         }

         return 1;
      })));
      builder.then(literal("list").executes((ctx) -> {
         if (waypoints.isEmpty()) {
            ClientManager.message("Нет сохранённых точек.");
         } else {
            ClientManager.message("Список точек:");
            waypoints.forEach((n, pos) -> ClientManager.message("§f" + n + " §7→ " + pos.method_23854()));
         }

         return 1;
      }));
   }

   public static void render(class_4587 matrices) {
      if (!waypoints.isEmpty()) {
         class_4184 camera = mc.field_1773.method_19418();
         class_243 camPos = camera.method_19326();
         int sw = mc.method_22683().method_4486();
         int sh = mc.method_22683().method_4502();
         waypoints.forEach((name, pos) -> {
            Vector3d sp = VectorUtil.toScreen((double)pos.method_10263() + (double)0.5F, (double)pos.method_10264() + (double)1.5F, (double)pos.method_10260() + (double)0.5F);
            if (!(sp.z() <= (double)0.0F) && !(sp.x() < (double)0.0F) && !(sp.x() > (double)sw) && !(sp.y() < (double)0.0F) && !(sp.y() > (double)sh)) {
               int dist = (int)camPos.method_1022(class_243.method_24954(pos));
               String text = name + " [" + dist + "m]";
               float tw = FontUtils.durman[15].getWidth(text);
               float th = FontUtils.durman[15].getHeight();
               float px = 4.0F;
               float py = 1.5F;
               RenderUtil.drawRoundedRect(matrices, (float)sp.x() - tw / 2.0F - px, (float)sp.y() - th / 2.0F - py, tw + px * 2.0F, th + py * 2.0F, 1.5F, (new Color(30, 30, 30, 150)).getRGB());
               FontUtils.durman[15].centeredDraw(matrices, text, (float)sp.x(), (float)sp.y() - th / 2.0F - 0.5F, Color.WHITE.getRGB());
            }
         });
      }
   }

   private void save() {
      try {
         Files.createDirectories(this.FILE.getParent());
         Files.writeString(this.FILE, this.GSON.toJson(waypoints, this.TYPE), StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   private void load() {
      if (Files.exists(this.FILE, new LinkOption[0])) {
         try {
            String json = Files.readString(this.FILE, StandardCharsets.UTF_8);
            waypoints = (Map)this.GSON.fromJson(json, this.TYPE);
            if (waypoints == null) {
               waypoints = new ConcurrentHashMap();
            }
         } catch (IOException e) {
            e.printStackTrace();
         }

      }
   }
}
