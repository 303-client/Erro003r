package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;
import ru.levin.manager.macroManager.Macro;
import ru.levin.util.KeyMappings;

public class MacroCommand extends Command {
   public MacroCommand() {
      super("macro");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      SuggestionProvider<class_2172> keySuggestions = (context, builder1) -> {
         for(String key : KeyMappings.getAllKeys()) {
            builder1.suggest(key);
         }

         return builder1.buildFuture();
      };
      SuggestionProvider<class_2172> macroSuggestions = (context, builder1) -> {
         for(Macro macro : Manager.MACROS_MANAGER.getMacros()) {
            String keyName = KeyMappings.keyMappings(macro.getKey());
            if (keyName != null) {
               builder1.suggest(keyName);
            }
         }

         return builder1.buildFuture();
      };
      RequiredArgumentBuilder<class_2172, String> addKeyArg = arg("key", StringArgumentType.word()).suggests(keySuggestions);
      RequiredArgumentBuilder<class_2172, String> addMessageArg = (RequiredArgumentBuilder)arg("message", StringArgumentType.greedyString()).executes((ctx) -> {
         String keyName = StringArgumentType.getString(ctx, "key").toUpperCase();
         Integer key = KeyMappings.keyCode(keyName);
         if (key == null) {
            String var4 = String.valueOf(class_124.field_1061);
            ClientManager.message(var4 + "Не найдена кнопка " + keyName);
            return 1;
         } else {
            String message = StringArgumentType.getString(ctx, "message");
            Manager.MACROS_MANAGER.addMacros(new Macro(message, key));
            String var10000 = String.valueOf(class_124.field_1060);
            ClientManager.message(var10000 + "Добавлен макрос для кнопки " + String.valueOf(class_124.field_1061) + keyName + String.valueOf(class_124.field_1068) + " с командой " + String.valueOf(class_124.field_1061) + message);
            return 1;
         }
      });
      addKeyArg.then(addMessageArg);
      builder.then(literal("add").then(addKeyArg));
      RequiredArgumentBuilder<class_2172, String> removeKeyArg = (RequiredArgumentBuilder)arg("key", StringArgumentType.word()).suggests(macroSuggestions).executes((ctx) -> {
         String keyName = StringArgumentType.getString(ctx, "key").toUpperCase();
         Integer key = KeyMappings.keyCode(keyName);
         if (key == null) {
            String var5 = String.valueOf(class_124.field_1061);
            ClientManager.message(var5 + "Не найдена кнопка " + keyName);
            return 1;
         } else {
            Macro macro = Manager.MACROS_MANAGER.getMacroByKey(key);
            if (macro == null) {
               String var4 = String.valueOf(class_124.field_1061);
               ClientManager.message(var4 + "На кнопке " + keyName + " нет макроса.");
               return 1;
            } else {
               Manager.MACROS_MANAGER.deleteMacro(key);
               String var10000 = String.valueOf(class_124.field_1060);
               ClientManager.message(var10000 + "Макрос удален с кнопки " + String.valueOf(class_124.field_1061) + keyName);
               return 1;
            }
         }
      });
      builder.then(literal("remove").then(removeKeyArg));
      builder.then(literal("list").executes((ctx) -> {
         if (Manager.MACROS_MANAGER.getMacros().isEmpty()) {
            ClientManager.message("Список макросов пуст");
         } else {
            ClientManager.message(String.valueOf(class_124.field_1060) + "Список макросов:");
            Manager.MACROS_MANAGER.getMacros().forEach((macro) -> {
               String keyName = KeyMappings.keyMappings(macro.getKey());
               String var10000 = String.valueOf(class_124.field_1068);
               ClientManager.message(var10000 + "Команда: " + String.valueOf(class_124.field_1061) + macro.getMessage() + String.valueOf(class_124.field_1068) + ", Кнопка: " + String.valueOf(class_124.field_1061) + keyName);
            });
         }

         return 1;
      }));
      builder.then(literal("clear").executes((ctx) -> {
         if (Manager.MACROS_MANAGER.getMacros().isEmpty()) {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Список макросов пуст");
         } else {
            Manager.MACROS_MANAGER.getMacros().clear();
            Manager.MACROS_MANAGER.updateFile();
            ClientManager.message(String.valueOf(class_124.field_1060) + "Список макросов успешно очищен");
         }

         return 1;
      }));
   }
}
