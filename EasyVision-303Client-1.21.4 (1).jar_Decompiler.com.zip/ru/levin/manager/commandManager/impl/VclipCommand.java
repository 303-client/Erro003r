package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_2338;
import net.minecraft.class_2828;
import ru.levin.manager.ClientManager;
import ru.levin.manager.commandManager.Command;

public class VclipCommand extends Command {
   public VclipCommand() {
      super("vclip");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("up").executes((context) -> {
         double offset = this.findFreeSpace(true);
         this.teleport(offset);
         return 1;
      }));
      builder.then(literal("down").executes((context) -> {
         double offset = this.findFreeSpace(false);
         this.teleport(offset);
         return 1;
      }));
      builder.then(arg("offset", DoubleArgumentType.doubleArg()).executes((context) -> {
         double offset = DoubleArgumentType.getDouble(context, "offset");
         this.teleport(offset);
         return 1;
      }));
   }

   private void teleport(double offset) {
      if (offset == (double)0.0F) {
         ClientManager.message(String.valueOf(class_124.field_1061) + "Свободное место не найдено!");
      } else {
         double startY = mc.field_1724.method_23318();
         double endY = startY + offset;

         for(int i = 0; i < 19; ++i) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), startY, mc.field_1724.method_23321(), false, true));
         }

         for(int i = 0; i < 19; ++i) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), endY, mc.field_1724.method_23321(), false, true));
         }

         mc.field_1724.method_5814(mc.field_1724.method_23317(), endY, mc.field_1724.method_23321());
         String var10000 = String.valueOf(class_124.field_1060);
         ClientManager.message(var10000 + "Вы телепортировались на " + (offset > (double)0.0F ? "вверх" : "вниз") + " (" + (int)offset + " блоков).");
      }
   }

   private double findFreeSpace(boolean up) {
      class_2338 start = mc.field_1724.method_24515();
      int step = up ? 1 : -1;

      for(int i = 1; i < 256; ++i) {
         class_2338 checkPos = start.method_10069(0, i * step, 0);
         class_2338 checkPosAbove = checkPos.method_10084();
         if (mc.field_1687.method_22347(checkPos) && mc.field_1687.method_22347(checkPosAbove)) {
            return (double)(i * step);
         }
      }

      return (double)0.0F;
   }
}
