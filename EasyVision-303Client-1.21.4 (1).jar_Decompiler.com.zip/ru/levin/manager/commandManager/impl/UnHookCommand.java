package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.commandManager.Command;

public class UnHookCommand extends Command {
   public static final File CUSTOM_PATH_FILE;

   public UnHookCommand() {
      super("unhook");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("path").then(arg("folder", StringArgumentType.greedyString()).suggests(this::suggestFolders).executes((context) -> {
         String path = StringArgumentType.getString(context, "folder");
         this.savePath(path);
         return 1;
      })));
   }

   private CompletableFuture<Suggestions> suggestFolders(CommandContext<class_2172> context, SuggestionsBuilder builder) {
      String input = builder.getRemaining();
      File base = (new File(input.isEmpty() ? "." : input)).getParentFile();
      if (base != null && base.exists() && base.isDirectory()) {
         File[] files = base.listFiles(File::isDirectory);
         if (files != null) {
            for(File f : files) {
               builder.suggest(f.getAbsolutePath());
            }
         }
      }

      return builder.buildFuture();
   }

   private void savePath(String path) {
      try {
         if (!CUSTOM_PATH_FILE.exists()) {
            CUSTOM_PATH_FILE.getParentFile().mkdirs();
            CUSTOM_PATH_FILE.createNewFile();
         }

         FileWriter writer = new FileWriter(CUSTOM_PATH_FILE, false);

         try {
            writer.write(path.trim());
            String var8 = String.valueOf(class_124.field_1060);
            ClientManager.message(var8 + "Путь сохранён: " + String.valueOf(class_124.field_1068) + path);
         } catch (Throwable var6) {
            try {
               writer.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         writer.close();
      } catch (IOException e) {
         String var10000 = String.valueOf(class_124.field_1061);
         ClientManager.message(var10000 + "Ошибка при сохранении пути: " + e.getMessage());
      }

   }

   static {
      CUSTOM_PATH_FILE = new File(mc.field_1697, "files\\modules\\UnHook.ew");
   }
}
