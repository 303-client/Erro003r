package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_1792;
import net.minecraft.class_2172;
import net.minecraft.class_7923;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;

public class ChestStealerCommand extends Command {
   public ChestStealerCommand() {
      super("cheststealer");
   }

   public void execute(LiteralArgumentBuilder<class_2172> root) {
      root.then(literal("add").then(arg("item", StringArgumentType.word()).suggests((ctx, builder) -> {
         for(class_1792 item : class_7923.field_41178) {
            String id = class_7923.field_41178.method_10221(item).toString();
            builder.suggest(id.replace("minecraft:", ""));
         }

         return builder.buildFuture();
      }).executes((ctx) -> {
         String input = StringArgumentType.getString(ctx, "item");
         String itemName = input.contains(":") ? input : "minecraft:" + input;
         if (Manager.CHESTSTEALER_MANAGER.addItem(itemName)) {
            String var10000 = String.valueOf(class_124.field_1060);
            ClientManager.message(var10000 + "Добавлен предмет " + itemName + " в список ChestStealer");
         } else {
            String var3 = String.valueOf(class_124.field_1061);
            ClientManager.message(var3 + "Не удалось добавить предмет: " + itemName);
         }

         return 1;
      })));
      root.then(literal("remove").then(arg("item", StringArgumentType.word()).suggests((ctx, builder) -> {
         for(class_1792 item : Manager.CHESTSTEALER_MANAGER.getWhitelist()) {
            String id = class_7923.field_41178.method_10221(item).toString();
            builder.suggest(id.replace("minecraft:", ""));
         }

         return builder.buildFuture();
      }).executes((ctx) -> {
         String input = StringArgumentType.getString(ctx, "item");
         String itemName = input.contains(":") ? input : "minecraft:" + input;
         if (Manager.CHESTSTEALER_MANAGER.removeItem(itemName)) {
            String var10000 = String.valueOf(class_124.field_1060);
            ClientManager.message(var10000 + "Удалён предмет " + itemName + " из списка ChestStealer");
         } else {
            String var3 = String.valueOf(class_124.field_1061);
            ClientManager.message(var3 + "Не удалось удалить предмет: " + itemName);
         }

         return 1;
      })));
      root.then(literal("list").executes((ctx) -> {
         if (Manager.CHESTSTEALER_MANAGER.getWhitelist().isEmpty()) {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Добавленных предметов нет!");
         } else {
            ClientManager.message(String.valueOf(class_124.field_1060) + "Список whitelisted предметов:");

            for(class_1792 item : Manager.CHESTSTEALER_MANAGER.getWhitelist()) {
               String var10000 = String.valueOf(class_124.field_1080);
               ClientManager.message(var10000 + "- " + String.valueOf(class_124.field_1068) + class_7923.field_41178.method_10221(item).toString());
            }
         }

         return 1;
      }));
   }
}
