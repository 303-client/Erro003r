package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;

public class StaffCommand extends Command {
   public StaffCommand() {
      super("staff");
   }

   public void execute(LiteralArgumentBuilder<class_2172> root) {
      root.then(literal("add").then(arg("name", StringArgumentType.word()).suggests(this::suggestOnlinePlayers).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name");
         if (Manager.STAFF_MANAGER.getStaffNames().contains(name)) {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Этот игрок уже в Staff List!");
         } else {
            Manager.STAFF_MANAGER.addStaff(name);
            String var10000 = String.valueOf(class_124.field_1060);
            ClientManager.message(var10000 + "Ник " + String.valueOf(class_124.field_1068) + name + String.valueOf(class_124.field_1060) + " добавлен в Staff List");
         }

         return 1;
      })));
      root.then(literal("remove").then(arg("name", StringArgumentType.word()).suggests(this::suggestExistingStaff).executes((ctx) -> {
         String name = StringArgumentType.getString(ctx, "name");
         if (Manager.STAFF_MANAGER.getStaffNames().contains(name)) {
            Manager.STAFF_MANAGER.removeStaff(name);
            String var10000 = String.valueOf(class_124.field_1060);
            ClientManager.message(var10000 + "Ник " + String.valueOf(class_124.field_1068) + name + String.valueOf(class_124.field_1060) + " удален из Staff List");
         } else {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Этого игрока нет в Staff List!");
         }

         return 1;
      })));
      root.then(literal("clear").executes((ctx) -> {
         if (Manager.STAFF_MANAGER.getStaffNames().isEmpty()) {
            ClientManager.message(String.valueOf(class_124.field_1061) + "Staff List пуст!");
         } else {
            Manager.STAFF_MANAGER.clearStaffs();
            ClientManager.message(String.valueOf(class_124.field_1060) + "Staff List очищен");
         }

         return 1;
      }));
      root.then(literal("list").executes((ctx) -> {
         ClientManager.message(String.valueOf(class_124.field_1080) + "Список Staff:");

         for(String name : Manager.STAFF_MANAGER.getStaffNames()) {
            String var10000 = String.valueOf(class_124.field_1068);
            ClientManager.message(var10000 + name);
         }

         return 1;
      }));
      root.then(literal("reload").executes((ctx) -> {
         Manager.STAFF_MANAGER.reload();
         ClientManager.message(String.valueOf(class_124.field_1060) + "Список был перезагружен");
         return 1;
      }));
   }

   private CompletableFuture<Suggestions> suggestExistingStaff(CommandContext<class_2172> context, SuggestionsBuilder builder) {
      List<String> staffNames = Manager.STAFF_MANAGER.getStaffNames();
      return class_2172.method_9265(staffNames, builder);
   }

   private CompletableFuture<Suggestions> suggestOnlinePlayers(CommandContext<class_2172> context, SuggestionsBuilder builder) {
      if (mc.field_1724.field_3944 == null) {
         return builder.buildFuture();
      } else {
         List<String> playerNames = (List)mc.field_1724.field_3944.method_2880().stream().map((p) -> p.method_2966().getName()).collect(Collectors.toList());
         return class_2172.method_9265(playerNames, builder);
      }
   }
}
