package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;
import ru.levin.manager.commandManager.impl.args.FriendArgumentType;
import ru.levin.manager.commandManager.impl.args.PlayerArgumentType;
import ru.levin.manager.friendManager.FriendManager;

public class FriendCommand extends Command {
   public FriendCommand() {
      super("friend");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(literal("add").then(arg("player", PlayerArgumentType.create()).executes((context) -> {
         String name = (String)context.getArgument("player", String.class);
         if (Manager.FRIEND_MANAGER.isFriend(name)) {
            ClientManager.message("Уже добавлен " + name);
            return 1;
         } else {
            Manager.FRIEND_MANAGER.addFriend(name);
            ClientManager.message(name + " добавлен в друзья");
            return 1;
         }
      })));
      builder.then(literal("remove").then(arg("player", FriendArgumentType.create()).executes((context) -> {
         String name = (String)context.getArgument("player", String.class);
         Manager.FRIEND_MANAGER.removeFriend(name);
         ClientManager.message(name + " удален из друзей");
         return 1;
      })));
      builder.then(literal("clear").executes((context) -> {
         this.clearFriendList();
         return 1;
      }));
      builder.then(literal("list").executes((context) -> {
         if (Manager.FRIEND_MANAGER.getFriends().isEmpty()) {
            ClientManager.message("Список друзей пуст");
         } else {
            String friendsList = (String)Manager.FRIEND_MANAGER.getFriends().stream().map((f) -> f.getName()).reduce((a, b) -> a + ", " + b).orElse("");
            ClientManager.message("Друзья: " + friendsList);
         }

         return 1;
      }));
   }

   private void clearFriendList() {
      FriendManager friendManager = Manager.FRIEND_MANAGER;
      if (friendManager.getFriends().isEmpty()) {
         ClientManager.message("Список друзей пуст");
      } else {
         friendManager.clearFriends();
         ClientManager.message("Список друзей успешно очищен");
      }
   }
}
