package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;

public class DragCommand extends Command {
   public DragCommand() {
      super("drag");
   }

   public void execute(LiteralArgumentBuilder<class_2172> root) {
      root.then(literal("reset").executes((ctx) -> {
         Manager.DRAG_MANAGER.reset();
         ClientManager.message(String.valueOf(class_124.field_1060) + "Позиции элементов на экране были сброшены");
         return 1;
      }));
      root.then(literal("save").executes((ctx) -> {
         Manager.DRAG_MANAGER.save();
         ClientManager.message(String.valueOf(class_124.field_1060) + "Элементы на экране были сохранены");
         return 1;
      }));
   }
}
