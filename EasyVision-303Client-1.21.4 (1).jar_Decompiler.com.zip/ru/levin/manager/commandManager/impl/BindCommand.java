package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.suggestion.Suggestions;
import com.mojang.brigadier.suggestion.SuggestionsBuilder;
import java.util.List;
import java.util.Objects;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;
import ru.levin.modules.Function;
import ru.levin.modules.FunctionManager;
import ru.levin.modules.setting.BindBooleanSetting;
import ru.levin.modules.setting.BindSetting;
import ru.levin.modules.setting.Setting;
import ru.levin.util.KeyMappings;

public class BindCommand extends Command {
   public BindCommand() {
      super("bind");
   }

   public void execute(LiteralArgumentBuilder<class_2172> root) {
      root.then(literal("add").then(arg("module", StringArgumentType.word()).suggests(this::suggestModules).then(arg("key", StringArgumentType.word()).suggests(this::suggestKeys).executes((ctx) -> {
         String moduleName = StringArgumentType.getString(ctx, "module");
         String keyName = StringArgumentType.getString(ctx, "key").toUpperCase();
         this.addKeyBinding(moduleName, keyName);
         return 1;
      }))));
      root.then(literal("remove").then(arg("module", StringArgumentType.word()).suggests(this::suggestModules).then(arg("key", StringArgumentType.word()).suggests(this::suggestKeys).executes((ctx) -> {
         String moduleName = StringArgumentType.getString(ctx, "module");
         String keyName = StringArgumentType.getString(ctx, "key").toUpperCase();
         this.removeKeyBinding(moduleName, keyName);
         return 1;
      }))));
      root.then(literal("list").executes((ctx) -> {
         this.listBoundKeys();
         return 1;
      }));
      root.then(literal("clear").executes((ctx) -> {
         this.clearAllBindings();
         return 1;
      }));
   }

   private CompletableFuture<Suggestions> suggestModules(CommandContext<class_2172> context, SuggestionsBuilder builder) {
      Manager.FUNCTION_MANAGER.getFunctions().forEach((f) -> builder.suggest(f.name));
      return builder.buildFuture();
   }

   private CompletableFuture<Suggestions> suggestKeys(CommandContext<class_2172> context, SuggestionsBuilder builder) {
      List var10000 = KeyMappings.getAllKeys();
      Objects.requireNonNull(builder);
      var10000.forEach(builder::suggest);
      return builder.buildFuture();
   }

   private void listBoundKeys() {
      ClientManager.message(String.valueOf(class_124.field_1080) + "Список всех модулей с клавишами:");

      for(Function f : Manager.FUNCTION_MANAGER.getFunctions()) {
         if (f.bind != 0) {
            String keyName = KeyMappings.keyMappings(f.bind);
            String var10000 = f.name;
            ClientManager.message(var10000 + " [" + String.valueOf(class_124.field_1080) + keyName + String.valueOf(class_124.field_1070) + "]");
         }
      }

   }

   private void clearAllBindings() {
      for(Function f : Manager.FUNCTION_MANAGER.getFunctions()) {
         if (f != Manager.FUNCTION_MANAGER.clickGUI) {
            f.bind = 0;

            for(Setting setting : f.getSettings()) {
               if (setting instanceof BindBooleanSetting) {
                  BindBooleanSetting bindBooleanSetting = (BindBooleanSetting)setting;
                  bindBooleanSetting.setKey(0);
               }

               if (setting instanceof BindSetting) {
                  BindSetting bindSetting = (BindSetting)setting;
                  bindSetting.setKey(-1);
               }
            }
         }
      }

      ClientManager.message(String.valueOf(class_124.field_1060) + "Все клавиши были отвязаны (кроме ClickGUI)");
   }

   private void addKeyBinding(String moduleName, String keyName) {
      FunctionManager var10000 = Manager.FUNCTION_MANAGER;
      Function module = FunctionManager.get(moduleName);
      int key = KeyMappings.keyCode(keyName);
      if (module == null) {
         ClientManager.message("Модуль " + moduleName + " не найден!");
      } else if (key == -1) {
         ClientManager.message("Клавиша " + keyName + " не найдена!");
      } else {
         module.bind = key;
         String var5 = String.valueOf(class_124.field_1080);
         ClientManager.message("Клавиша " + var5 + keyName + String.valueOf(class_124.field_1068) + " была привязана к модулю " + String.valueOf(class_124.field_1080) + module.name);
      }
   }

   private void removeKeyBinding(String moduleName, String keyName) {
      FunctionManager var10000 = Manager.FUNCTION_MANAGER;
      Function module = FunctionManager.get(moduleName);
      if (module == null) {
         ClientManager.message("Модуль " + moduleName + " не найден!");
      } else {
         module.bind = 0;
         String var4 = String.valueOf(class_124.field_1080);
         ClientManager.message("Клавиша " + var4 + keyName + String.valueOf(class_124.field_1068) + " была отвязана от модуля " + String.valueOf(class_124.field_1080) + module.name);
      }
   }
}
