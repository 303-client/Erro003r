package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.builder.RequiredArgumentBuilder;
import net.minecraft.class_2172;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;

public class IrcCommand extends Command {
   public IrcCommand() {
      super("irc");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      RequiredArgumentBuilder<class_2172, String> ignoreArg = (RequiredArgumentBuilder)RequiredArgumentBuilder.argument("nick", StringArgumentType.word()).executes((context) -> {
         String nick = StringArgumentType.getString(context, "nick");
         Manager.IRC_MANAGER.ignoreNick(nick);
         Manager.IRC_MANAGER.messageClient(nick + " добавлен в игнор");
         return 1;
      });
      builder.then(literal("ignore").then(ignoreArg));
      RequiredArgumentBuilder<class_2172, String> unignoreArg = (RequiredArgumentBuilder)RequiredArgumentBuilder.argument("nick", StringArgumentType.word()).executes((context) -> {
         String nick = StringArgumentType.getString(context, "nick");
         Manager.IRC_MANAGER.unignoreNick(nick);
         Manager.IRC_MANAGER.messageClient(nick + " удалён из игнора");
         return 1;
      });
      builder.then(literal("unignore").then(unignoreArg));
      builder.then(literal("ignorelist").executes((context) -> {
         if (Manager.IRC_MANAGER.getIgnoredNicks().isEmpty()) {
            Manager.IRC_MANAGER.messageClient("Список игнора пуст");
         } else {
            Manager.IRC_MANAGER.messageClient("Игнор-лист: " + String.join(", ", Manager.IRC_MANAGER.getIgnoredNicks()));
         }

         return 1;
      }));
      RequiredArgumentBuilder<class_2172, String> msgArg = (RequiredArgumentBuilder)RequiredArgumentBuilder.argument("message", StringArgumentType.greedyString()).executes((context) -> {
         String message = StringArgumentType.getString(context, "message");
         if (message.matches("(https?://|www\\.)\\S+")) {
            Manager.IRC_MANAGER.messageClient("Ваше сообщение содержит ссылку.");
            return 1;
         } else {
            if (Manager.FUNCTION_MANAGER.irc.state) {
               Manager.IRC_MANAGER.messageHost(message);
            } else {
               Manager.IRC_MANAGER.messageClient("Пожалуйста включите модуль IRC");
            }

            return 1;
         }
      });
      builder.then(msgArg);
   }
}
