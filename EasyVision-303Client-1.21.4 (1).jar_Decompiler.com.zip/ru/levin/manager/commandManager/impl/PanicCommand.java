package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_2172;
import ru.levin.manager.ClientManager;
import ru.levin.manager.Manager;
import ru.levin.manager.commandManager.Command;

public class PanicCommand extends Command {
   public PanicCommand() {
      super("panic");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.executes((context) -> {
         Manager.FUNCTION_MANAGER.getFunctions().stream().filter((function) -> function.state).forEach((function) -> function.setState(false));
         ClientManager.message("Выключил все модули!");
         return 1;
      });
   }
}
