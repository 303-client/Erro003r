package ru.levin.manager.commandManager.impl;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraft.class_124;
import net.minecraft.class_2172;
import net.minecraft.class_243;
import net.minecraft.class_2828;
import ru.levin.manager.ClientManager;
import ru.levin.manager.commandManager.Command;

public class HclipCommand extends Command {
   public HclipCommand() {
      super("hclip");
   }

   public void execute(LiteralArgumentBuilder<class_2172> builder) {
      builder.then(arg("offset", DoubleArgumentType.doubleArg()).executes((context) -> {
         double offset = DoubleArgumentType.getDouble(context, "offset");
         this.teleport(offset);
         return 1;
      }));
   }

   private void teleport(double offset) {
      if (offset == (double)0.0F) {
         ClientManager.message(String.valueOf(class_124.field_1061) + "Смещение не может быть 0!");
      } else {
         class_243 look = mc.field_1724.method_5828(1.0F).method_1029();
         double x = mc.field_1724.method_23317() + look.field_1352 * offset;
         double z = mc.field_1724.method_23321() + look.field_1350 * offset;
         double y = mc.field_1724.method_23318();

         for(int i = 0; i < 19; ++i) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(mc.field_1724.method_23317(), y, mc.field_1724.method_23321(), false, true));
         }

         for(int i = 0; i < 19; ++i) {
            mc.field_1724.field_3944.method_52787(new class_2828.class_2829(x, y, z, false, true));
         }

         mc.field_1724.method_5814(x, y, z);
         String var10000 = String.valueOf(class_124.field_1060);
         ClientManager.message(var10000 + "Вы телепортировались на " + String.valueOf(class_124.field_1061) + offset + String.valueOf(class_124.field_1068) + " блоков вперёд.");
      }
   }
}
