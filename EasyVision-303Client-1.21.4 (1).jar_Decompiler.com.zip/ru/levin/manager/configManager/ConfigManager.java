package ru.levin.manager.configManager;

import com.google.gson.GsonBuilder;
import com.google.gson.JsonElement;
import com.google.gson.JsonParseException;
import com.google.gson.JsonParser;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;

public final class ConfigManager implements IMinecraft {
   public final File CONFIG_DIR;
   private final File autoCfgDir;
   private final JsonParser jsonParser;

   public ConfigManager() {
      this.CONFIG_DIR = new File(class_310.method_1551().field_1697, "\\files\\configs");
      this.autoCfgDir = new File(class_310.method_1551().field_1697, "\\files\\configs\\AUTOCFG.cfg");
      this.jsonParser = new JsonParser();
   }

   public void init() throws Exception {
      if (!this.CONFIG_DIR.exists()) {
         this.CONFIG_DIR.mkdirs();
      } else if (this.autoCfgDir.exists()) {
         this.loadConfiguration("AUTOCFG", true);
         System.out.println("[+] Загружаю AutoCfg...");
      } else {
         System.out.println("[-] AutoCfg не найден");
         this.autoCfgDir.createNewFile();
      }

   }

   public List<String> getAllConfigurations() {
      List<String> configurations = new ArrayList();
      File[] files = this.CONFIG_DIR.listFiles();
      if (files != null) {
         for(File file : files) {
            if (file.isFile() && file.getName().endsWith(".cfg")) {
               String configName = file.getName().substring(0, file.getName().lastIndexOf(".cfg"));
               configurations.add(configName);
            }
         }
      }

      return configurations;
   }

   public void loadConfiguration(String configuration, boolean start) {
      Config config = this.findConfig(configuration);
      if (config == null) {
         ClientManager.message("Конфиг " + configuration + " не был найден!");
      } else {
         try {
            JsonElement element = this.readJsonFromFile(config.getFile());
            if (element != null && element.isJsonObject()) {
               config.load(element.getAsJsonObject(), configuration, start);
               ClientManager.message("Конфиг " + configuration + " успешно загружен.");
            } else {
               this.saveConfiguration(configuration);
               ClientManager.message("Конфиг " + configuration + " был создан, так как отсутствовал или был повреждён.");
            }
         } catch (JsonParseException var5) {
            ClientManager.message("Ошибка разбора JSON-строки в конфиге " + configuration + "!");
         } catch (NullPointerException var6) {
            ClientManager.message("Конфиг " + configuration + " устарел и не может быть загружен!");
         } catch (ClassCastException var7) {
            ClientManager.message("Конфиг " + configuration + " пустой или содержит неправильные данные!");
         }

      }
   }

   private JsonElement readJsonFromFile(File file) {
      try {
         Reader reader = new InputStreamReader(new FileInputStream(file), StandardCharsets.UTF_8);

         JsonElement var3;
         try {
            var3 = this.jsonParser.parse(reader);
         } catch (Throwable var6) {
            try {
               reader.close();
            } catch (Throwable var5) {
               var6.addSuppressed(var5);
            }

            throw var6;
         }

         reader.close();
         return var3;
      } catch (IOException e) {
         e.printStackTrace();
         return null;
      }
   }

   public void saveConfiguration(String configuration) {
      Config config = this.findConfig(configuration);
      if (config == null) {
         config = new Config(configuration);
      }

      this.writeJsonToFile(config.getFile(), config.save());
      System.out.println("[+] Конфиг " + configuration + " сохранён");
   }

   private void writeJsonToFile(File file, JsonElement jsonElement) {
      try {
         Writer writer = new OutputStreamWriter(new FileOutputStream(file), StandardCharsets.UTF_8);

         try {
            String jsonString = (new GsonBuilder()).setPrettyPrinting().create().toJson(jsonElement);
            writer.write(jsonString);
         } catch (Throwable var7) {
            try {
               writer.close();
            } catch (Throwable var6) {
               var7.addSuppressed(var6);
            }

            throw var7;
         }

         writer.close();
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   public Config findConfig(String configName) {
      if (configName == null) {
         return null;
      } else {
         return (new File(this.CONFIG_DIR, configName + ".cfg")).exists() ? new Config(configName) : null;
      }
   }

   public void deleteConfig(String configName) {
      if (configName != null) {
         Config config = this.findConfig(configName);
         if (config != null) {
            File file = config.getFile();
            if (file.exists()) {
               boolean deleted = file.delete();
               if (!deleted) {
                  System.out.println("Не удалось удалить конфиг " + file.getAbsolutePath());
               }
            }
         }

      }
   }
}
