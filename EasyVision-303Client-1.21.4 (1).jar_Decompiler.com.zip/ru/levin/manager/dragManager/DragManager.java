package ru.levin.manager.dragManager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.util.LinkedHashMap;
import net.minecraft.class_310;
import ru.levin.manager.IMinecraft;

public class DragManager implements IMinecraft {
   public static LinkedHashMap<String, Dragging> draggables = new LinkedHashMap();
   public final File DRAG_DATA;
   private final Gson GSON;

   public DragManager() {
      this.DRAG_DATA = new File(class_310.method_1551().field_1697, "\\files\\drag.ew");
      this.GSON = (new GsonBuilder()).setPrettyPrinting().excludeFieldsWithoutExposeAnnotation().create();
   }

   public void init() {
      if (!this.DRAG_DATA.exists()) {
         System.out.println("Файл с позициями draggable не найден. Будет создан новый файл после сохранения.");
      } else {
         try {
            Dragging[] loadedDrags = (Dragging[])this.GSON.fromJson(Files.readString(this.DRAG_DATA.toPath()), Dragging[].class);
            if (loadedDrags != null) {
               for(Dragging dragging : loadedDrags) {
                  if (dragging != null) {
                     Dragging currentDrag = (Dragging)draggables.get(dragging.getName());
                     if (currentDrag != null) {
                        currentDrag.setX(dragging.getX());
                        currentDrag.setY(dragging.getY());
                        draggables.put(dragging.getName(), currentDrag);
                     } else {
                        draggables.put(dragging.getName(), dragging);
                     }
                  }
               }

               System.out.println("Позиции draggable элементов загружены из файла.");
            } else {
               System.out.println("Данные в файле пусты или повреждены.");
            }
         } catch (IOException ex) {
            ex.printStackTrace();
         }

      }
   }

   public void save() {
      if (!this.DRAG_DATA.exists()) {
         this.DRAG_DATA.getParentFile().mkdirs();
      }

      try {
         FileWriter writer = new FileWriter(this.DRAG_DATA);

         try {
            writer.write(this.GSON.toJson(draggables.values()));
            System.out.println("Позиции draggable элементов успешно сохранены в файл " + this.DRAG_DATA.getAbsolutePath());
         } catch (Throwable var5) {
            try {
               writer.close();
            } catch (Throwable var4) {
               var5.addSuppressed(var4);
            }

            throw var5;
         }

         writer.close();
      } catch (IOException ex) {
         ex.printStackTrace();
      }

   }

   public void reset() {
      float off = 10.0F;

      for(Dragging dragging : draggables.values()) {
         float newX = (float)(dragging.getDefaultX() + 10);
         float newY = (float)dragging.getDefaultY() + off;
         dragging.setX(newX);
         dragging.setY(newY);
         dragging.targetX = newX;
         dragging.targetY = newY;
         off += dragging.getHeight() + 15.0F;
      }

      this.save();
   }
}
