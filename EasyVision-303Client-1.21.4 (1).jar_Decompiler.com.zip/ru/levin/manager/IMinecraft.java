package ru.levin.manager;

import net.minecraft.class_289;
import net.minecraft.class_310;
import net.minecraft.class_9779;

public interface IMinecraft {
   class_310 mc = class_310.method_1551();

   static class_9779 tickCounter() {
      return IMinecraft.Holder.tickCounter;
   }

   static class_289 tessellator() {
      return IMinecraft.Holder.tessellator;
   }

   static class_310 getMc() {
      return IMinecraft.Holder.minecraftClient;
   }

   public static class Holder {
      private static final class_310 minecraftClient = class_310.method_1551();
      private static final class_9779 tickCounter;
      private static final class_289 tessellator;

      static {
         tickCounter = IMinecraft.mc.method_61966();
         tessellator = class_289.method_1348();
      }
   }
}
