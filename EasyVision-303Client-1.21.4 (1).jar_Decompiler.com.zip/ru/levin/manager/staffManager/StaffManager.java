package ru.levin.manager.staffManager;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.nio.file.Files;
import java.nio.file.OpenOption;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;

public class StaffManager {
   private static final List<String> staffNames = new ArrayList();
   private final File file;

   public StaffManager() {
      this.file = new File(class_310.method_1551().field_1697, "\\files\\staff.ew");
   }

   public void init() throws Exception {
      if (!this.file.exists()) {
         this.file.createNewFile();
      } else {
         this.readStaffs();
      }

   }

   public void addStaff(String name) {
      staffNames.add(name);
      this.updateFile();
   }

   public boolean isStaff(String staffName) {
      return staffNames.stream().anyMatch((staff) -> staff.equals(staffName));
   }

   public void removeStaff(String name) {
      staffNames.removeIf((friend) -> friend.equalsIgnoreCase(name));
   }

   public void clearStaffs() {
      staffNames.clear();
      this.updateFile();
   }

   public List<String> getStaffNames() {
      return staffNames;
   }

   public void updateFile() {
      try {
         StringBuilder builder = new StringBuilder();
         staffNames.forEach((friend) -> builder.append(friend).append("\n"));
         Files.write(this.file.toPath(), builder.toString().getBytes(), new OpenOption[0]);
      } catch (Exception e) {
         e.printStackTrace();
      }

   }

   public void reload() {
      staffNames.clear();
      this.readStaffs();
   }

   private void readStaffs() {
      try {
         BufferedReader reader = new BufferedReader(new InputStreamReader(new DataInputStream(new FileInputStream(this.file.getAbsolutePath()))));

         String line;
         while((line = reader.readLine()) != null) {
            staffNames.add(line);
         }

         reader.close();
      } catch (Exception e) {
         e.printStackTrace();
      }

   }
}
