package ru.levin.manager;

import java.awt.Color;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.UUID;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2561;
import net.minecraft.class_2583;
import net.minecraft.class_266;
import net.minecraft.class_269;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_337;
import net.minecraft.class_345;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_640;
import net.minecraft.class_320.class_321;
import ru.levin.ExosWare;
import ru.levin.manager.themeManager.StyleManager;
import ru.levin.mixin.iface.BossBarHudAccessor;
import ru.levin.mixin.iface.MinecraftClientAccessor;
import ru.levin.util.KeyMappings;
import ru.levin.util.color.ColorUtil;
import ru.levin.util.math.MathUtil;

public class ClientManager implements IMinecraft {
   public static boolean legitMode = false;
   private static float fps = 0.0F;
   public static float TICK_TIMER = 1.0F;

   public static float getTPS() {
      return (float)Math.round(Manager.SYNC_MANAGER.tps * 10.0F) / 10.0F;
   }

   public static int getFps() {
      class_310 client = mc;
      int currentFps = client != null ? client.method_47599() : 0;
      fps = MathUtil.fast(fps, (float)currentFps, 6.0F);
      return Math.round(fps);
   }

   public static String getBps(class_1297 entity) {
      if (mc != null && mc.field_1724 != null) {
         double dx = entity.method_23317() - entity.field_6014;
         double dz = entity.method_23321() - entity.field_5969;
         return String.format(Locale.ROOT, "%.2f", Math.hypot(dx, dz) * (double)20.0F);
      } else {
         return "0.00";
      }
   }

   public static String getPing() {
      class_310 client = mc;
      if (client != null && client.field_1724 != null && client.method_1562() != null) {
         class_640 entry = client.method_1562().method_2871(client.field_1724.method_5667());
         return entry == null ? "N/A" : Integer.toString(entry.method_2959());
      } else {
         return "N/A";
      }
   }

   public static float[] getHealthFromScoreboard(class_1309 target) {
      float currentHealth = target.method_6032();
      float maxHealth = target.method_6063();
      if (target instanceof class_1657 player) {
         class_269 scoreboard = player.method_7327();
         class_266 found = null;

         for(class_266 objective : scoreboard.method_1151()) {
            if (objective.method_1114().getString().contains("Zdrowie")) {
               found = objective;
               break;
            }
         }

         if (found != null) {
            currentHealth = (float)scoreboard.method_1180(player, found).method_55409();
            maxHealth = 20.0F;
         }
      }

      return new float[]{currentHealth, maxHealth};
   }

   public static String getKey(int keyCode) {
      return KeyMappings.keyMappings(keyCode);
   }

   public static boolean playerIsPVP() {
      if (mc != null && mc.field_1705 != null) {
         class_337 bossOverlayGui = mc.field_1705.method_1740();
         Map<UUID, class_345> bossBars = ((BossBarHudAccessor)bossOverlayGui).getBossBars();

         for(class_345 bossInfo : bossBars.values()) {
            String nameStrLower = bossInfo.method_5414().getString().toLowerCase(Locale.ROOT);
            if (nameStrLower.contains("pvp") || nameStrLower.contains("PvP")) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   public static void loginAccount(String name) {
      UUID uuid = UUID.nameUUIDFromBytes(("OfflinePlayer:" + name).getBytes(StandardCharsets.UTF_8));
      class_320 session = new class_320(name, uuid, "invalid_token", Optional.empty(), Optional.empty(), class_321.field_1988);
      class_310 client = class_310.method_1551();
      ((MinecraftClientAccessor)client).setSession(session);
   }

   public static void message(String string) {
      if (mc != null && mc.field_1724 != null && mc.field_1687 != null && mc.field_1705 != null) {
         StyleManager theme = Manager.STYLE_MANAGER;
         int start = theme.getFirstColor();
         int end = theme.getSecondColor();
         mc.field_1705.method_1743().method_1812(applyGradient(string, start, end));
      }
   }

   public static String gradient(String message, int first, int end) {
      if (message != null && !message.isEmpty()) {
         int length = message.length();
         StringBuilder result = new StringBuilder(length * 9);
         float inv = length <= 1 ? 0.0F : 1.0F / (float)(length - 1);

         for(int i = 0; i < length; ++i) {
            float progress = length == 1 ? 0.5F : (float)i * inv;
            int color = ColorUtil.interpolateColor(first, end, progress) & 16777215;
            String hex = Integer.toHexString(color);
            if (hex.length() < 6) {
               String var10000 = "000000".substring(hex.length());
               hex = var10000 + hex;
            }

            result.append('§').append('#').append(hex).append(message.charAt(i));
         }

         return result.toString();
      } else {
         return "";
      }
   }

   private static class_2561 applyGradient(String string, int startColor, int endColor) {
      class_5250 component = class_2561.method_43473();
      Objects.requireNonNull(ExosWare.getInstance());
      String name = "303Client client";
      int length = name.length();
      float inv = length <= 1 ? 0.0F : 1.0F / (float)(length - 1);

      for(int i = 0; i < length; ++i) {
         int rgb = ColorUtil.blendColors(startColor, endColor, length == 1 ? 0.5F : (float)i * inv) & 16777215;
         component.method_10852(class_2561.method_43470(String.valueOf(name.charAt(i))).method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(rgb)).method_10982(true)));
      }

      int gray = Color.GRAY.getRGB() & 16777215;
      component.method_10852(class_2561.method_43470(" ➭ ").method_10862(class_2583.field_24360.method_27703(class_5251.method_27717(gray)).method_10982(true)));
      component.method_10852(class_2561.method_43470(string).method_10862(class_2583.field_24360.method_27706(class_124.field_1070)));
      return component;
   }
}
