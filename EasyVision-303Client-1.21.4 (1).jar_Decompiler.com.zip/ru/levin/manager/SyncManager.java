package ru.levin.manager;

import com.google.common.collect.ImmutableList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import net.minecraft.class_1297;
import net.minecraft.class_1799;
import net.minecraft.class_2761;
import net.minecraft.class_3532;
import net.minecraft.class_742;
import net.minecraft.class_746;
import ru.levin.events.Event;
import ru.levin.events.impl.EventPacket;
import ru.levin.events.impl.EventUpdate;
import ru.levin.events.impl.move.EventMotion;
import ru.levin.events.impl.render.EventPlayerRender;
import ru.levin.mixin.iface.ClientPlayerEntityAccessor;
import ru.levin.modules.combat.rotation.RotationController;

public class SyncManager implements IMinecraft {
   private volatile List<class_1297> cachedEntities = Collections.emptyList();
   private volatile List<class_742> cachedPlayers = Collections.emptyList();
   private volatile List<class_1799> cachedItems = Collections.emptyList();
   private float visualBodyYaw;
   private float visualHeadYaw;
   private float visualHeadPitch;
   private float visualPrevBodyYaw;
   private float visualPrevHeadYaw;
   private float visualPrevHeadPitch;
   public float tps = 20.0F;
   private long lastTime = System.nanoTime();
   private final float NANOS_IN_SECOND = 1.0E9F;

   public List<class_1297> getEntities() {
      return this.cachedEntities;
   }

   public List<class_1799> getItems() {
      return this.cachedItems;
   }

   public List<class_742> getPlayers() {
      return this.cachedPlayers;
   }

   public float getBodyYaw() {
      class_746 player = mc.field_1724;
      if (player == null) {
         return this.visualBodyYaw;
      } else {
         double dx = player.method_23317() - player.field_6014;
         double dz = player.method_23321() - player.field_5969;
         float offset = this.visualBodyYaw;
         if (dx * dx + dz * dz > (double)0.0025F) {
            offset = (float)(class_3532.method_15349(dz, dx) * (180D / Math.PI) - (double)90.0F);
         }

         ClientPlayerEntityAccessor accessor = (ClientPlayerEntityAccessor)player;
         float lastYaw = accessor.getLastYaw();
         if (player.field_6251 > 0.0F) {
            offset = lastYaw;
         }

         float deltaBodyYaw = class_3532.method_15363(class_3532.method_15393(lastYaw - (this.visualBodyYaw + class_3532.method_15393(offset - this.visualBodyYaw) * 0.3F)), -45.0F, 75.0F);
         return (deltaBodyYaw > 50.0F ? deltaBodyYaw * 0.2F : 0.0F) + lastYaw - deltaBodyYaw;
      }
   }

   public void onEvent(Event event) {
      if (mc.field_1687 != null && mc.field_1724 != null) {
         Objects.requireNonNull(event);
         byte var3 = 0;
         //$FF: var3->value
         //0->ru/levin/events/impl/EventUpdate
         //1->ru/levin/events/impl/move/EventMotion
         //2->ru/levin/events/impl/render/EventPlayerRender
         //3->ru/levin/events/impl/EventPacket
         switch (event.typeSwitch<invokedynamic>(event, var3)) {
            case 0:
               EventUpdate ignored = (EventUpdate)event;
               Manager.ROTATION.onUpdate();
               this.cachedEntities = ImmutableList.copyOf(mc.field_1687.method_18112());
               this.cachedPlayers = ImmutableList.copyOf(mc.field_1687.method_18456());
               this.cachedItems = ImmutableList.copyOf(mc.field_1724.method_56674());
               break;
            case 1:
               EventMotion em = (EventMotion)event;
               Manager.ROTATION.onUpdate();
               RotationController rc = Manager.ROTATION;
               rc.updateIfFree(em.getYaw(), em.getPitch());
               if (rc.isControlling()) {
                  em.setYaw(rc.getYaw());
                  em.setPitch(rc.getPitch());
               }

               this.visualPrevHeadYaw = this.visualHeadYaw;
               this.visualPrevHeadPitch = this.visualHeadPitch;
               this.visualHeadYaw = em.getYaw();
               this.visualHeadPitch = em.getPitch();
               this.visualPrevBodyYaw = this.visualBodyYaw;
               this.visualBodyYaw = this.getBodyYaw();
               break;
            case 2:
               EventPlayerRender epr = (EventPlayerRender)event;
               epr.setPrevYaw(this.visualPrevHeadYaw);
               epr.setPrevPitch(this.visualPrevHeadPitch);
               epr.setPrevBodyYaw(this.visualPrevBodyYaw);
               epr.setYaw(this.visualHeadYaw);
               epr.setPitch(this.visualHeadPitch);
               epr.setBodyYaw(this.visualBodyYaw);
               break;
            case 3:
               EventPacket ep = (EventPacket)event;
               if (ep.getPacket() instanceof class_2761) {
                  long now = System.nanoTime();
                  long delay = now - this.lastTime;
                  this.lastTime = now;
                  if (delay <= 0L) {
                     return;
                  }

                  float currentTPS = 20.0F * (1.0E9F / (float)delay);
                  currentTPS = class_3532.method_15363(currentTPS, 0.0F, 20.0F);
                  this.tps += (currentTPS - this.tps) * 0.05F;
               }
         }

      }
   }
}
