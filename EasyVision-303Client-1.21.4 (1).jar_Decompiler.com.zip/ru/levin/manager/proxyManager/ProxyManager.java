package ru.levin.manager.proxyManager;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.reflect.TypeToken;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Type;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import net.minecraft.class_310;
import net.minecraft.class_4185;
import org.apache.commons.io.FileUtils;
import ru.levin.manager.IMinecraft;

public class ProxyManager implements IMinecraft {
   private final File CONFIG_PATH;
   public HashMap<String, Proxy> accounts;
   public String lastPlayerName;
   public static boolean proxyEnabled = false;
   public static Proxy proxy = new Proxy();
   public static Proxy lastUsedProxy = new Proxy();
   public static class_4185 proxyMenuButton;

   public ProxyManager() {
      this.CONFIG_PATH = new File(class_310.method_1551().field_1697, "files/proxy.ew");
      this.accounts = new HashMap();
      this.lastPlayerName = "";
   }

   public static String getLastUsedProxyIp() {
      return lastUsedProxy.ipPort.isEmpty() ? "none" : lastUsedProxy.getIp();
   }

   public void init() {
      try {
         if (!this.CONFIG_PATH.exists() && !this.CONFIG_PATH.createNewFile()) {
            System.out.println("Error creating proxy config file");
            return;
         }

         String content = FileUtils.readFileToString(this.CONFIG_PATH, StandardCharsets.UTF_8);
         if (!content.isEmpty()) {
            JsonObject json = JsonParser.parseString(content).getAsJsonObject();
            proxyEnabled = json.get("proxy-enabled").getAsBoolean();
            Type type = (new TypeToken<HashMap<String, Proxy>>() {
            }).getType();
            this.accounts = (HashMap)(new Gson()).fromJson(json.get("accounts"), type);
            if (this.accounts == null) {
               this.accounts = new HashMap();
            }
         }
      } catch (Exception e) {
         System.out.println("Error reading proxy config");
         e.printStackTrace();
      }

   }

   public void setDefaultProxy(Proxy proxy) {
      this.accounts.put("", proxy);
   }

   public void saveConfig() {
      try {
         JsonObject json = new JsonObject();
         json.addProperty("proxy-enabled", proxyEnabled);
         json.add("accounts", (new Gson()).toJsonTree(this.accounts));
         FileUtils.write(this.CONFIG_PATH, (new GsonBuilder()).setPrettyPrinting().create().toJson(json), StandardCharsets.UTF_8);
      } catch (IOException e) {
         System.out.println("Error saving proxy config");
         e.printStackTrace();
      }

   }
}
