package ru.levin.manager.proxyManager;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_342;
import net.minecraft.class_4185;
import net.minecraft.class_4286;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_500;
import org.apache.commons.lang3.StringUtils;
import ru.levin.manager.Manager;

public class GuiProxy extends class_437 {
   private boolean isSocks4;
   private class_342 ipPort;
   private class_342 username;
   private class_342 password;
   private class_4286 enabledCheck;
   private final class_437 parentScreen;
   private String msg = "";
   private int[] positionY;
   private int positionX;

   public GuiProxy(class_437 parentScreen) {
      super(class_2561.method_43470("proxy"));
      this.parentScreen = parentScreen;
   }

   private static boolean isValidIpPort(String ipP) {
      String[] split = ipP.split(":");
      if (split.length == 2 && StringUtils.isNumeric(split[1])) {
         int port = Integer.parseInt(split[1]);
         return port >= 0 && port <= 65535;
      } else {
         return false;
      }
   }

   private boolean checkProxy() {
      if (!isValidIpPort(this.ipPort.method_1882())) {
         this.msg = String.valueOf(class_124.field_1061) + "Nieprawidłowy port";
         this.ipPort.method_25365(true);
         return false;
      } else {
         return true;
      }
   }

   private void centerButtons(int amount, int buttonLength, int gap) {
      this.positionX = (this.field_22789 - buttonLength) / 2;
      this.positionY = new int[amount];
      int startY = (this.field_22790 - (amount - 1) * gap) / 2;

      for(int i = 0; i < amount; ++i) {
         this.positionY[i] = startY + gap * i;
      }

   }

   public boolean method_25404(int keyCode, int scanCode, int modifiers) {
      this.msg = "";
      return super.method_25404(keyCode, scanCode, modifiers);
   }

   public void method_25394(class_332 context, int mouseX, int mouseY, float partialTicks) {
      super.method_25394(context, mouseX, mouseY, partialTicks);
      if (this.enabledCheck.method_20372() && !isValidIpPort(this.ipPort.method_1882())) {
         this.enabledCheck.method_25306();
      }

      context.method_25303(this.field_22793, "Typ proxy", this.positionX - 65, this.positionY[1] + 5, 10518656);
      context.method_25300(this.field_22793, "Uwierzytelnianie", this.field_22789 / 2, this.positionY[3] + 8, class_124.field_1068.method_532());
      context.method_25303(this.field_22793, "IP:PORT", this.positionX - 55, this.positionY[2] + 5, 10518656);
      this.ipPort.method_25394(context, mouseX, mouseY, partialTicks);
      this.username.method_25394(context, mouseX, mouseY, partialTicks);
      if (!this.isSocks4) {
         this.password.method_25394(context, mouseX, mouseY, partialTicks);
      }

   }

   public void method_25426() {
      ProxyManager pm = Manager.PROXY_MANAGER;
      this.centerButtons(10, 160, 26);
      this.isSocks4 = ProxyManager.proxy.type == Proxy.ProxyType.SOCKS4;
      this.method_37063(class_4185.method_46430(class_2561.method_43470(this.isSocks4 ? "Socks 4" : "Socks 5"), (b) -> {
         this.isSocks4 = !this.isSocks4;
         b.method_25355(class_2561.method_43470(this.isSocks4 ? "Socks 4" : "Socks 5"));
      }).method_46434(this.positionX, this.positionY[1], 160, 20).method_46431());
      this.ipPort = new class_342(this.field_22793, this.positionX, this.positionY[2], 160, 20, class_2561.method_43470(""));
      this.ipPort.method_1852(ProxyManager.proxy.ipPort);
      this.ipPort.method_1880(1024);
      this.ipPort.method_25365(true);
      this.method_25429(this.ipPort);
      this.username = new class_342(this.field_22793, this.positionX, this.positionY[4], 160, 20, class_2561.method_43470(""));
      this.username.method_1852(ProxyManager.proxy.username);
      this.username.method_1880(255);
      this.method_25429(this.username);
      this.password = new class_342(this.field_22793, this.positionX, this.positionY[5], 160, 20, class_2561.method_43470(""));
      this.password.method_1852(ProxyManager.proxy.password);
      this.password.method_1880(255);
      this.method_25429(this.password);
      int posXButtons = (this.field_22789 - 160) / 2;
      this.method_37063(class_4185.method_46430(class_2561.method_43471("Gotowe"), (b) -> {
         if (this.checkProxy()) {
            ProxyManager.proxy = new Proxy(this.isSocks4, this.ipPort.method_1882(), this.username.method_1882(), this.password.method_1882());
            ProxyManager.proxyEnabled = this.enabledCheck.method_20372();
            pm.setDefaultProxy(ProxyManager.proxy);
            pm.saveConfig();
            this.field_22787.method_1507(new class_500(new class_442()));
         }
      }).method_46434(posXButtons, this.positionY[8], 77, 20).method_46431());
      this.enabledCheck = class_4286.method_54787(class_2561.method_43471("Włącz"), this.field_22793).method_54789((this.field_22789 - 15 - this.field_22793.method_27525(class_2561.method_43471("Włącz"))) / 2, this.positionY[7]).method_54794(ProxyManager.proxyEnabled).method_54788();
      this.method_37063(this.enabledCheck);
      this.method_37063(class_4185.method_46430(class_2561.method_43471("Wstecz"), (b) -> this.field_22787.method_1507(this.parentScreen)).method_46434(posXButtons + 80 + 3, this.positionY[8], 77, 20).method_46431());
   }

   public void method_25419() {
      super.method_25419();
      this.msg = "";
   }
}
