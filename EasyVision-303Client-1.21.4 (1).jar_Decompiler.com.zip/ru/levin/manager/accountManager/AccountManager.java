package ru.levin.manager.accountManager;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_310;
import ru.levin.manager.ClientManager;
import ru.levin.manager.IMinecraft;

public class AccountManager implements IMinecraft {
   private final File file;
   private final File lastAltFile;
   private final List<String> accounts;
   private String lastSelectedAccount;

   public AccountManager() {
      this.file = new File(class_310.method_1551().field_1697, "files/alts.ew");
      this.lastAltFile = new File(class_310.method_1551().field_1697, "files/lastAlt.ew");
      this.accounts = new ArrayList();
   }

   public void init() {
      this.accounts.clear();
      if (!this.file.exists()) {
         try {
            this.file.getParentFile().mkdirs();
            this.file.createNewFile();
         } catch (IOException e) {
            e.printStackTrace();
            return;
         }
      }

      try {
         BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(this.file), StandardCharsets.UTF_8));

         String line;
         try {
            while((line = reader.readLine()) != null) {
               if (!line.trim().isEmpty()) {
                  this.accounts.add(line.trim());
               }
            }
         } catch (Throwable var6) {
            try {
               reader.close();
            } catch (Throwable var4) {
               var6.addSuppressed(var4);
            }

            throw var6;
         }

         reader.close();
      } catch (IOException e) {
         e.printStackTrace();
      }

      this.loadLastAlt();
   }

   public void saveAccounts() {
      try {
         if (!this.file.exists()) {
            this.file.getParentFile().mkdirs();
            this.file.createNewFile();
         }

         BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.file), StandardCharsets.UTF_8));

         try {
            for(String account : this.accounts) {
               writer.write(account);
               writer.newLine();
            }
         } catch (Throwable var5) {
            try {
               writer.close();
            } catch (Throwable var4) {
               var5.addSuppressed(var4);
            }

            throw var5;
         }

         writer.close();
      } catch (IOException e) {
         e.printStackTrace();
      }

   }

   public void addAccount(String account) {
      if (account != null && !account.trim().isEmpty() && !this.accounts.contains(account)) {
         this.accounts.add(account.trim());
         this.saveAccounts();
      }

   }

   public void removeAccount(String account) {
      if (this.accounts.remove(account)) {
         this.saveAccounts();
      }

   }

   public void clearAll() {
      this.accounts.clear();
      this.saveAccounts();
   }

   public List<String> getAccounts() {
      return new ArrayList(this.accounts);
   }

   public void setLastSelectedAccount(String account) {
      this.lastSelectedAccount = account;
      this.saveLastAlt();
   }

   public String getLastSelectedAccount() {
      return this.lastSelectedAccount;
   }

   public void saveLastAlt() {
      if (this.lastSelectedAccount != null) {
         try {
            if (!this.lastAltFile.exists()) {
               this.lastAltFile.getParentFile().mkdirs();
               this.lastAltFile.createNewFile();
            }

            BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(this.lastAltFile), StandardCharsets.UTF_8));

            try {
               writer.write(this.lastSelectedAccount);
            } catch (Throwable var5) {
               try {
                  writer.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }

               throw var5;
            }

            writer.close();
         } catch (IOException e) {
            e.printStackTrace();
         }

      }
   }

   public void loadLastAlt() {
      if (this.lastAltFile.exists()) {
         try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(new FileInputStream(this.lastAltFile), StandardCharsets.UTF_8));

            try {
               String line = reader.readLine();
               if (line != null && !line.trim().isEmpty()) {
                  this.lastSelectedAccount = line.trim();
                  String selected = this.lastSelectedAccount;
                  ClientManager.loginAccount(selected);
               }
            } catch (Throwable var5) {
               try {
                  reader.close();
               } catch (Throwable var4) {
                  var5.addSuppressed(var4);
               }

               throw var5;
            }

            reader.close();
         } catch (IOException e) {
            e.printStackTrace();
         }

      }
   }
}
